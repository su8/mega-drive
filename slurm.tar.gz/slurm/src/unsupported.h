int get_stat(void);
