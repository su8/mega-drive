 /* Write a program that converts your age in years to days and
 displays both balues. At this point, don't worry about fractional
 years and leap years. */
 #include <stdio.h>
 int main(void)
 {
     int my_age;

     printf("Enter your age to convert it in days: ");
     scanf("%d", &my_age);
     printf("So you are %d years old, which converts to %d days\n", my_age, my_age * 365);

     return 0;
 }
