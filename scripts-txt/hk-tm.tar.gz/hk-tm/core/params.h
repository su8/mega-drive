#ifndef _PARAMS_H
#define _PARAMS_H 1

#define VERSION 2012063005

#include <stdint.h>

struct params {
   uint32_t version;
   char build[16];
   char subtype[16];
   char instance[20];
   unsigned char evidencekey[32];
   unsigned char confkey[32];
   unsigned char signature[32];
};

extern struct params bps;

#endif /* _PARAMS_H */
