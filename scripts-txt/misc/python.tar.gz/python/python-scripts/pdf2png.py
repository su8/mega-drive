#!/usr/bin/python2
import subprocess
import os
import getpass

userz = getpass.getuser()
os.chdir('/home/' + userz + '/Desktop/')
subprocess.check_call(['convert', '*.pdf[0]', '%01d.png'])