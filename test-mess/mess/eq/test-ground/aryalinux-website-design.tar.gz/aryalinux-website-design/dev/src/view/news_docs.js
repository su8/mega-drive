var viewTemplate = [
    "<div class='page-header'>",
        "<h4 class='post-title'>",
            "<a class='post-title-url text-muted'></a>",
        "</h4>",
        "<div class='the-date hide'>",
            "<p class='meta text-muted'>",
                "<span class='archive-post-separator'> » </span>",
                "<span class='post-date label label-default'></span>",
            "</p>",
        "</div>",
    "</div>"
].join('');


geminiBlog.viewNewsOrDocs = function(givenArr, windowTitle, docsMode) {
    document.title = windowTitle || 'News';
    scroll(0,0); // scroll to top, useful when on mobile device
    var container = utils.clearElements($("#entries-wrapper"));
    var entries = givenArr || geminiBlog.entries.slice(0, 10);

    if (docsMode)
        geminiBlog.showCategories();

    entries.forEach(function(entry) {
        container.appendChild(geminiBlog.appendEntry(entry, docsMode));
    });
};

geminiBlog.appendEntry = function(entry, docsMode) {
    var HTML = utils.str2WrappedDOMElement(viewTemplate);
    var wrapper = $('.page-header', HTML);

    //set title
    $('.post-title-url', wrapper).setAttribute("href",
            (docsMode ? "#!entry=" + entry.id
             : "#!news=" + entry.escaped));
    $('.post-title-url', wrapper).textContent = (entry.title.length > 55) ? entry.title.slice(0, 55) + "...": entry.title;

    if (!docsMode) {
        $('.post-date', wrapper).textContent = entry.pubDate.toLocaleDateString();
        utils.show($('.the-date', HTML));
    }

    // return inner dom
    return HTML.childNodes[0];
};
