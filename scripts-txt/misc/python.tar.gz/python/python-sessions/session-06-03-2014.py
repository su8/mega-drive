Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> list('hi','whoa','dimmy')
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    list('hi','whoa','dimmy')
TypeError: list() takes at most 1 argument (3 given)
>>> ['hi','whoa','dimmy']
['hi', 'whoa', 'dimmy']
>>> '3'.isdigit()
True
>>> x = ['1',2]
>>> x[0]+5 if x[0].isdigit() else str(x[0])+5
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    x[0]+5 if x[0].isdigit() else str(x[0])+5
TypeError: Can't convert 'int' object to str implicitly
>>> str(x[0])
'1'
>>> x[0]+5 if x[0].isdigit() else int(x[0])+5
Traceback (most recent call last):
  File "<pyshell#6>", line 1, in <module>
    x[0]+5 if x[0].isdigit() else int(x[0])+5
TypeError: Can't convert 'int' object to str implicitly
>>> int(x[0])
1
>>> if x[0].isdigit() x[0]+5 else int(x[0])+5
SyntaxError: invalid syntax
>>> b = x[0]+5 if x[0].isdigit() else int(x[0])+5
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    b = x[0]+5 if x[0].isdigit() else int(x[0])+5
TypeError: Can't convert 'int' object to str implicitly
>>> int(x[0])+5
6
>>> x[0]+5
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    x[0]+5
TypeError: Can't convert 'int' object to str implicitly
>>> a = compile("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))
""")
Traceback (most recent call last):
  File "<pyshell#19>", line 8, in <module>
    """)
TypeError: Required argument 'filename' (pos 2) not found
>>> a = compile("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b)),
'<string>', 'exec'""")
Traceback (most recent call last):
  File "<pyshell#20>", line 8, in <module>
    '<string>', 'exec'""")
TypeError: Required argument 'filename' (pos 2) not found
>>> a = compile("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))""",
'<string>', 'exec')
Traceback (most recent call last):
  File "<pyshell#21>", line 8, in <module>
    '<string>', 'exec')
  File "<string>", line 7
    print(next(b))
                 ^
SyntaxError: unexpected EOF while parsing
>>> a = exec("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))""")
Traceback (most recent call last):
  File "<pyshell#22>", line 7, in <module>
    print(next(b))""")
  File "<string>", line 7
    print(next(b))
                 ^
SyntaxError: unexpected EOF while parsing
>>> a = exec("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))""")
Traceback (most recent call last):
  File "<pyshell#23>", line 7, in <module>
    print(next(b))""")
  File "<string>", line 7
    print(next(b))
                 ^
SyntaxError: unexpected EOF while parsing
>>> a = exec("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b)""")
Traceback (most recent call last):
  File "<pyshell#24>", line 7, in <module>
    print(next(b)""")
  File "<string>", line 7
    print(next(b)
                ^
SyntaxError: unexpected EOF while parsing
>>> a = exec("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while True:
    try:
        if next(b).isdigit():
            print(next(b))""")
Traceback (most recent call last):
  File "<pyshell#25>", line 7, in <module>
    print(next(b))""")
  File "<string>", line 7
    print(next(b))
                 ^
SyntaxError: unexpected EOF while parsing
>>> exec('3+4')
>>> a = compile("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))
            """,'<string>', 'exec')
Traceback (most recent call last):
  File "<pyshell#27>", line 8, in <module>
    """,'<string>', 'exec')
  File "<string>", line 8
    
    ^
SyntaxError: unexpected EOF while parsing
>>> a = compile("""
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        #if next(b).isdigit():
        print(next(b))
            """,'<string>', 'exec')
Traceback (most recent call last):
  File "<pyshell#28>", line 8, in <module>
    """,'<string>', 'exec')
  File "<string>", line 8
    
    ^
SyntaxError: unexpected EOF while parsing
>>> code_global = compile('''
sum = 0
for x in xrange(500000):
    sum += x
''', '<string>', 'exec')
>>> exec(code_global)
Traceback (most recent call last):
  File "<pyshell#30>", line 1, in <module>
    exec(code_global)
  File "<string>", line 3, in <module>
NameError: name 'xrange' is not defined
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        #if next(b).isdigit():
        print(next(b))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> exec(a)
1
2
quotes
brackets
6
10
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> exec(a)
2
10
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        print(next(b).isdigit())
    except StopIteration:
        break
''', '<string>', 'exec')
>>> exec(a)
True
Traceback (most recent call last):
  File "<pyshell#36>", line 1, in <module>
    exec(a)
  File "<string>", line 6, in <module>
AttributeError: 'int' object has no attribute 'isdigit'
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        print(next(b.isdigit()))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> exec(a)
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    exec(a)
  File "<string>", line 6, in <module>
AttributeError: 'list_iterator' object has no attribute 'isdigit'
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> x = ['1', 2, 'quotes', 'brackets', '6', 10]
>>> for z in x:
	if z.isdigit():
		print(z)

		
1
Traceback (most recent call last):
  File "<pyshell#44>", line 2, in <module>
    if z.isdigit():
AttributeError: 'int' object has no attribute 'isdigit'
>>> for z in x:
	if z.isdigit():
		print(int(z))

		
1
Traceback (most recent call last):
  File "<pyshell#46>", line 2, in <module>
    if z.isdigit():
AttributeError: 'int' object has no attribute 'isdigit'
>>> for z in x:
	print(z)

	
1
2
quotes
brackets
6
10
>>> 1.isdigit()
SyntaxError: invalid syntax
>>> for z in x:
	if z.isdigit():
		try:
			print(z)
		except:
			break

		
1
Traceback (most recent call last):
  File "<pyshell#54>", line 2, in <module>
    if z.isdigit():
AttributeError: 'int' object has no attribute 'isdigit'
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
while "compiling this bytecode":
    try:
        if next(b).isdigit():
            print(next(b))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> [z.isdigit() for z in x]
Traceback (most recent call last):
  File "<pyshell#56>", line 1, in <module>
    [z.isdigit() for z in x]
  File "<pyshell#56>", line 1, in <listcomp>
    [z.isdigit() for z in x]
AttributeError: 'int' object has no attribute 'isdigit'
>>> [z for z in x if z.isdigit()]
Traceback (most recent call last):
  File "<pyshell#57>", line 1, in <module>
    [z for z in x if z.isdigit()]
  File "<pyshell#57>", line 1, in <listcomp>
    [z for z in x if z.isdigit()]
AttributeError: 'int' object has no attribute 'isdigit'
>>> a = ['m','y','2','c','o','m','m','a','5','n','d','9']
>>> [z for z in a if z.isdigit()]
['2', '5', '9']
>>> [z for z in a if z.isdigit() and not isinstance(z, int)]
['2', '5', '9']
>>> [z for z in x if z.isdigit() and not isinstance(z, int)]
Traceback (most recent call last):
  File "<pyshell#61>", line 1, in <module>
    [z for z in x if z.isdigit() and not isinstance(z, int)]
  File "<pyshell#61>", line 1, in <listcomp>
    [z for z in x if z.isdigit() and not isinstance(z, int)]
AttributeError: 'int' object has no attribute 'isdigit'
>>> [z for z in a if not isinstance(z, int) and z.isdigit()]
['2', '5', '9']
>>> [z for z in x if not isinstance(z, int) and z.isdigit()]
['1', '6']
>>> [z for z in x if not isinstance(z, int) and z.isdigit() if isinstance(z, int) pass]
SyntaxError: invalid syntax
>>> [z for z in x if not isinstance(z, int) and z.isdigit() if isinstance(z, int)]
[]
>>> [z for z in x if isinstance(z, int)]
[2, 10]
>>> [z for z in x if not isinstance(z, int) and z.isdigit() else if isinstance(z, int)]
SyntaxError: invalid syntax
>>> [z for z in x if isinstance(z, int) or z.isdigt()]
Traceback (most recent call last):
  File "<pyshell#68>", line 1, in <module>
    [z for z in x if isinstance(z, int) or z.isdigt()]
  File "<pyshell#68>", line 1, in <listcomp>
    [z for z in x if isinstance(z, int) or z.isdigt()]
AttributeError: 'str' object has no attribute 'isdigt'
>>> [z for z in x if isinstance(z, int) or z.isdigit()]
['1', 2, '6', 10]
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
b = iter(x)
the_numbers_list = [z for z in x if isinstance(z, int) or z.isdigit()]
while "compiling this bytecode":
    try:
        print(next(the_numbers_list))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> exec(a)
Traceback (most recent call last):
  File "<pyshell#71>", line 1, in <module>
    exec(a)
  File "<string>", line 7, in <module>
TypeError: 'list' object is not an iterator
>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
the_numbers_list = iter([z for z in x if isinstance(z, int) or z.isdigit()])
while "compiling this bytecode":
    try:
        print(next(the_numbers_list))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> exec(a)
1
2
6
10
>>> [z for z in x if isinstance(z, int) or z.isdigit()]
['1', 2, '6', 10]
>>> class YClass( object ):
    pass

>>> y = YClass()
>>> setattr(y, 'myAttr', 'magic')
>>> y.myAttr
'magic'
>>> class A:
	def __init__(self, z):
		self.z = z

		
>>> b = setattr(A, 'z', 'hahoo')
>>> b.z
Traceback (most recent call last):
  File "<pyshell#85>", line 1, in <module>
    b.z
AttributeError: 'NoneType' object has no attribute 'z'
>>> setattr(A, 'z', 'hahoo')
>>> b
>>> A.z
'hahoo'
>>> class A:
	def __init__(self, z):
		self.z = z

>>> setattr(A, 'z', 'hahoo')
>>> A.z
'hahoo'
>>> class A:
	def __init__(self, z):
		self.z = z

		
>>> setattr(A, 'z', '("hahoo")')
>>> A.z
'("hahoo")'
>>> class A:
	def __init__(self, z):
		self.z = z

		
>>> setattr(A, 'z', ('hahoo'))
>>> A.z
'hahoo'
>>> setattr(A, 'z', '(hahoo)')
>>> A.z
'(hahoo)'
>>> class YClass( object ):
    pass

>>> y= YClass()
>>> for x in range(1,10:
	       
SyntaxError: invalid syntax
>>> for x in range(1,10):
	setattr( y, '{0}'.format(x), '{0}'.format(x))

	
>>> y.1
SyntaxError: invalid syntax
>>> y.2
SyntaxError: invalid syntax
>>> y
<__main__.YClass object at 0x7f1ed25db3d0>
>>> y.'1'.
SyntaxError: invalid syntax
>>> y.'1'
SyntaxError: invalid syntax
>>> for x in range(1,10):
	setattr( y, 'my', '{0}'.format(x))

	
>>> y.my
'9'
>>> program = {
"anjuta": "/usr/bin/anjuta",
"blender": "/usr/bin/blender",
"bluefish": "/usr/bin/bluefish",
"eclipse": "/usr/bin/eclipse",
"geany": "/usr/bin/geany",
"glade": "/usr/bin/glade",
"openjdk": "/etc/java-7-openjdk/",
"meld": "/usr/bin/meld",
"netbeans": "/usr/bin/netbeans",
"qt4": "/usr/lib/qt4/bin/designer",
"qt5": "/usr/lib/qt/bin/designer",
"qtcreator": "/usr/bin/qtcreator",
"ninja-ide": "/usr/bin/ninja-ide",
"evince": "/usr/bin/evince",
"f-spot": "/usr/bin/f-spot",
"gimp": "/usr/bin/gimp",
"gwenview": "/usr/bin/gwenview",
"imagemagick": "/usr/bin/convert",
"inkscape": "/usr/bin/inkscape",
"mypaint": "/usr/bin/mypaint",
"pinta": "/usr/bin/pinta",
"shotwell": "/usr/bin/shotwell",
"stellarium": "/usr/bin/stellarium",
"chromium": "/usr/bin/chromium",
"deluge": "/usr/bin/deluge",
"evolution": "/usr/bin/evolution",
"filezilla": "/usr/bin/filezilla",
"firefox": "/usr/bin/firefox",
"chrome": "/usr/bin/google-chrome-stable",
"xchat": "/usr/bin/xchat",
"liferea": "/usr/bin/liferea",
"midori": "/usr/bin/midori",
"minitube": "/usr/bin/minitube",
"opera": "/usr/bin/opera",
"pidgin": "/usr/bin/pidgin",
"skype": "/usr/bin/skype",
"steam": "/usr/bin/steam",
"thunderbird": "/usr/bin/thunderbird",
"transmission": "/usr/bin/transmission-gtk",
"linuxdcpp": "/usr/bin/linuxdcpp",
"amarok": "/usr/bin/amarok",
"audacious": "/usr/bin/audacious",
"banshee": "/usr/bin/banshee",
"cheese": "/usr/bin/cheese",
"clementine": "/usr/bin/clementine",
"flash-player": "/usr/bin/flash-player-properties",
"recordmydesktop": "/usr/bin/gtk-recordMyDesktop",
"guayadeque": "/usr/bin/guayadeque",
"mplayer": "/usr/bin/mplayer",
"openshot": "/usr/bin/openshot",
"pitivi": "/usr/bin/pitivi",
"rhythmbox": "/usr/bin/rhythmbox",
"soundconverter": "/usr/bin/soundconverter",
"totem": "/usr/bin/totem",
"vlc": "/usr/bin/vlc",
"winff": "/usr/bin/winff",
"xfburn": "/usr/bin/xfburn",
"kdenlive": "/usr/bin/kdenlive",
"simplescreenrecorder": "/usr/bin/simplescreenrecorder",
"vokoscreen": "/usr/bin/vokoscreen",
"gparted": "/usr/bin/gparted",
"guake": "/usr/bin/guake",
"hardinfo": "/usr/bin/hardinfo",
"htop": "/usr/bin/htop",
"keepassx": "/usr/bin/keepassx",
"playonlinux": "/usr/bin/playonlinux",
"terminator": "/usr/bin/terminator",
"thunar": "/usr/bin/thunar",
"truecrypt": "/usr/bin/truecrypt",
"unetbootin": "/usr/bin/unetbootin",
"virtualbox": "/usr/bin/virtualbox",
"wine": "/usr/bin/wine",
"wireshark": "/usr/bin/wireshark",
"xbmc": "/usr/bin/xbmc",
"gufw": "/usr/bin/gufw",
"octopi": "/usr/bin/octopi",
"pamac": "/usr/bin/pamac-manager",
"gnome-system-monitor": "/usr/bin//usr/bin/gnome-system-monitor",
"docky": "/usr/bin/docky",
"emacs": "/usr/bin/emacs",
"vim": "/usr/bin/vim",
"galculator": "/usr/bin/galculator",
"gedit": "/usr/bin/gedit",
"gloobus": "/usr/bin/gloobus-preview",
"leafpad": "/usr/bin/leafpad",
"scribes": "/usr/bin/scribes",
"tomboy": "/usr/bin/tomboy",
"tuxcards": "/usr/bin/tuxcards",
"imagewriter": "/usr/bin/imagewriter",
"7zip": "/usr/bin/7zFM"
}
>>> progmram.keys()
Traceback (most recent call last):
  File "<pyshell#118>", line 1, in <module>
    progmram.keys()
NameError: name 'progmram' is not defined
>>> program.keys()
dict_keys(['xchat', 'liferea', 'octopi', 'evolution', 'mplayer', 'transmission', 'vokoscreen', 'glade', 'audacious', 'midori', 'opera', 'meld', 'docky', 'qtcreator', 'geany', 'clementine', 'wireshark', 'vlc', 'imagemagick', 'gparted', 'pamac', 'playonlinux', 'gimp', 'blender', 'bluefish', 'firefox', 'amarok', 'scribes', 'mypaint', 'unetbootin', 'htop', 'vim', 'skype', 'ninja-ide', 'openshot', 'emacs', 'chromium', 'winff', 'galculator', 'netbeans', 'thunderbird', 'steam', 'eclipse', 'hardinfo', 'chrome', 'guake', 'totem', 'soundconverter', 'pitivi', 'openjdk', 'imagewriter', 'filezilla', 'linuxdcpp', 'terminator', 'thunar', 'f-spot', 'gedit', 'recordmydesktop', 'truecrypt', 'minitube', 'stellarium', 'inkscape', 'anjuta', 'xfburn', 'deluge', 'guayadeque', 'qt5', 'qt4', 'keepassx', 'flash-player', 'simplescreenrecorder', 'pinta', 'gufw', 'cheese', 'wine', 'tomboy', 'leafpad', 'xbmc', 'gloobus', '7zip', 'gnome-system-monitor', 'virtualbox', 'shotwell', 'rhythmbox', 'evince', 'kdenlive', 'tuxcards', 'banshee', 'pidgin', 'gwenview'])
>>> for x in program.items():
	setattr( y, '{}'.format(x[0]), '{0}'.format(x[1]))

	
>>> y.xchat
'/usr/bin/xchat'
>>> type(y.xchat)
<class 'str'>
>>> y.xchat = '/usr/bin/zchat'
>>> y.xchat
'/usr/bin/zchat'
>>> for x in y:
	print(x)

	
Traceback (most recent call last):
  File "<pyshell#128>", line 1, in <module>
    for x in y:
TypeError: 'YClass' object is not iterable
>>> class A(object):
	program = {
	"anjuta": "/usr/bin/anjuta",
	"blender": "/usr/bin/blender",
	"bluefish": "/usr/bin/bluefish",
	"eclipse": "/usr/bin/eclipse",
	"geany": "/usr/bin/geany",
	"glade": "/usr/bin/glade",
	"openjdk": "/etc/java-7-openjdk/",
	"meld": "/usr/bin/meld",
	"netbeans": "/usr/bin/netbeans",
	"qt4": "/usr/lib/qt4/bin/designer",
	"qt5": "/usr/lib/qt/bin/designer",
	"qtcreator": "/usr/bin/qtcreator",
	"ninja-ide": "/usr/bin/ninja-ide",
	"evince": "/usr/bin/evince",
	"f-spot": "/usr/bin/f-spot",
	"gimp": "/usr/bin/gimp",
	"gwenview": "/usr/bin/gwenview",
	"imagemagick": "/usr/bin/convert",
	"inkscape": "/usr/bin/inkscape",
	"mypaint": "/usr/bin/mypaint",
	"pinta": "/usr/bin/pinta",
	"shotwell": "/usr/bin/shotwell",
	"stellarium": "/usr/bin/stellarium",
	"chromium": "/usr/bin/chromium",
	"deluge": "/usr/bin/deluge",
	"evolution": "/usr/bin/evolution",
	"filezilla": "/usr/bin/filezilla",
	"firefox": "/usr/bin/firefox",
	"chrome": "/usr/bin/google-chrome-stable",
	"xchat": "/usr/bin/xchat",
	"liferea": "/usr/bin/liferea",
	"midori": "/usr/bin/midori",
	"minitube": "/usr/bin/minitube",
	"opera": "/usr/bin/opera",
	"pidgin": "/usr/bin/pidgin",
	"skype": "/usr/bin/skype",
	"steam": "/usr/bin/steam",
	"thunderbird": "/usr/bin/thunderbird",
	"transmission": "/usr/bin/transmission-gtk",
	"linuxdcpp": "/usr/bin/linuxdcpp",
	"amarok": "/usr/bin/amarok",
	"audacious": "/usr/bin/audacious",
	"banshee": "/usr/bin/banshee",
	"cheese": "/usr/bin/cheese",
	"clementine": "/usr/bin/clementine",
	"flash-player": "/usr/bin/flash-player-properties",
	"recordmydesktop": "/usr/bin/gtk-recordMyDesktop",
	"guayadeque": "/usr/bin/guayadeque",
	"mplayer": "/usr/bin/mplayer",
	"openshot": "/usr/bin/openshot",
	"pitivi": "/usr/bin/pitivi",
	"rhythmbox": "/usr/bin/rhythmbox",
	"soundconverter": "/usr/bin/soundconverter",
	"totem": "/usr/bin/totem",
	"vlc": "/usr/bin/vlc",
	"winff": "/usr/bin/winff",
	"xfburn": "/usr/bin/xfburn",
	"kdenlive": "/usr/bin/kdenlive",
	"simplescreenrecorder": "/usr/bin/simplescreenrecorder",
	"vokoscreen": "/usr/bin/vokoscreen",
	"gparted": "/usr/bin/gparted",
	"guake": "/usr/bin/guake",
	"hardinfo": "/usr/bin/hardinfo",
	"htop": "/usr/bin/htop",
	"keepassx": "/usr/bin/keepassx",
	"playonlinux": "/usr/bin/playonlinux",
	"terminator": "/usr/bin/terminator",
	"thunar": "/usr/bin/thunar",
	"truecrypt": "/usr/bin/truecrypt",
	"unetbootin": "/usr/bin/unetbootin",
	"virtualbox": "/usr/bin/virtualbox",
	"wine": "/usr/bin/wine",
	"wireshark": "/usr/bin/wireshark",
	"xbmc": "/usr/bin/xbmc",
	"gufw": "/usr/bin/gufw",
	"octopi": "/usr/bin/octopi",
	"pamac": "/usr/bin/pamac-manager",
	"gnome-system-monitor": "/usr/bin//usr/bin/gnome-system-monitor",
	"docky": "/usr/bin/docky",
	"emacs": "/usr/bin/emacs",
	"vim": "/usr/bin/vim",
	"galculator": "/usr/bin/galculator",
	"gedit": "/usr/bin/gedit",
	"gloobus": "/usr/bin/gloobus-preview",
	"leafpad": "/usr/bin/leafpad",
	"scribes": "/usr/bin/scribes",
	"tomboy": "/usr/bin/tomboy",
	"tuxcards": "/usr/bin/tuxcards",
	"imagewriter": "/usr/bin/imagewriter",
	"7zip": "/usr/bin/7zFM"
	}
	for x in program.items():
		setattr(A(), '{}'.format(x[0]), '{0}'.format(x[1]))

Traceback (most recent call last):
  File "<pyshell#130>", line 1, in <module>
    class A(object):
  File "<pyshell#130>", line 95, in A
    setattr(A(), '{}'.format(x[0]), '{0}'.format(x[1]))
TypeError: __init__() missing 1 required positional argument: 'z'
>>> class A(object):
	program = {
	"anjuta": "/usr/bin/anjuta",
	"blender": "/usr/bin/blender",
	"bluefish": "/usr/bin/bluefish",
	"eclipse": "/usr/bin/eclipse",
	"geany": "/usr/bin/geany",
	"glade": "/usr/bin/glade",
	"openjdk": "/etc/java-7-openjdk/",
	"meld": "/usr/bin/meld",
	"netbeans": "/usr/bin/netbeans",
	"qt4": "/usr/lib/qt4/bin/designer",
	"qt5": "/usr/lib/qt/bin/designer",
	"qtcreator": "/usr/bin/qtcreator",
	"ninja-ide": "/usr/bin/ninja-ide",
	"evince": "/usr/bin/evince",
	"f-spot": "/usr/bin/f-spot",
	"gimp": "/usr/bin/gimp",
	"gwenview": "/usr/bin/gwenview",
	"imagemagick": "/usr/bin/convert",
	"inkscape": "/usr/bin/inkscape",
	"mypaint": "/usr/bin/mypaint",
	"pinta": "/usr/bin/pinta",
	"shotwell": "/usr/bin/shotwell",
	"stellarium": "/usr/bin/stellarium",
	"chromium": "/usr/bin/chromium",
	"deluge": "/usr/bin/deluge",
	"evolution": "/usr/bin/evolution",
	"filezilla": "/usr/bin/filezilla",
	"firefox": "/usr/bin/firefox",
	"chrome": "/usr/bin/google-chrome-stable",
	"xchat": "/usr/bin/xchat",
	"liferea": "/usr/bin/liferea",
	"midori": "/usr/bin/midori",
	"minitube": "/usr/bin/minitube",
	"opera": "/usr/bin/opera",
	"pidgin": "/usr/bin/pidgin",
	"skype": "/usr/bin/skype",
	"steam": "/usr/bin/steam",
	"thunderbird": "/usr/bin/thunderbird",
	"transmission": "/usr/bin/transmission-gtk",
	"linuxdcpp": "/usr/bin/linuxdcpp",
	"amarok": "/usr/bin/amarok",
	"audacious": "/usr/bin/audacious",
	"banshee": "/usr/bin/banshee",
	"cheese": "/usr/bin/cheese",
	"clementine": "/usr/bin/clementine",
	"flash-player": "/usr/bin/flash-player-properties",
	"recordmydesktop": "/usr/bin/gtk-recordMyDesktop",
	"guayadeque": "/usr/bin/guayadeque",
	"mplayer": "/usr/bin/mplayer",
	"openshot": "/usr/bin/openshot",
	"pitivi": "/usr/bin/pitivi",
	"rhythmbox": "/usr/bin/rhythmbox",
	"soundconverter": "/usr/bin/soundconverter",
	"totem": "/usr/bin/totem",
	"vlc": "/usr/bin/vlc",
	"winff": "/usr/bin/winff",
	"xfburn": "/usr/bin/xfburn",
	"kdenlive": "/usr/bin/kdenlive",
	"simplescreenrecorder": "/usr/bin/simplescreenrecorder",
	"vokoscreen": "/usr/bin/vokoscreen",
	"gparted": "/usr/bin/gparted",
	"guake": "/usr/bin/guake",
	"hardinfo": "/usr/bin/hardinfo",
	"htop": "/usr/bin/htop",
	"keepassx": "/usr/bin/keepassx",
	"playonlinux": "/usr/bin/playonlinux",
	"terminator": "/usr/bin/terminator",
	"thunar": "/usr/bin/thunar",
	"truecrypt": "/usr/bin/truecrypt",
	"unetbootin": "/usr/bin/unetbootin",
	"virtualbox": "/usr/bin/virtualbox",
	"wine": "/usr/bin/wine",
	"wireshark": "/usr/bin/wireshark",
	"xbmc": "/usr/bin/xbmc",
	"gufw": "/usr/bin/gufw",
	"octopi": "/usr/bin/octopi",
	"pamac": "/usr/bin/pamac-manager",
	"gnome-system-monitor": "/usr/bin//usr/bin/gnome-system-monitor",
	"docky": "/usr/bin/docky",
	"emacs": "/usr/bin/emacs",
	"vim": "/usr/bin/vim",
	"galculator": "/usr/bin/galculator",
	"gedit": "/usr/bin/gedit",
	"gloobus": "/usr/bin/gloobus-preview",
	"leafpad": "/usr/bin/leafpad",
	"scribes": "/usr/bin/scribes",
	"tomboy": "/usr/bin/tomboy",
	"tuxcards": "/usr/bin/tuxcards",
	"imagewriter": "/usr/bin/imagewriter",
	"7zip": "/usr/bin/7zFM"
	}

>>> 
>>> for x in A.program.items():
	setattr(A(), '{}'.format(x[0]), '{0}'.format(x[1]))

>>> A.tuxcards
Traceback (most recent call last):
  File "<pyshell#134>", line 1, in <module>
    A.tuxcards
AttributeError: type object 'A' has no attribute 'tuxcards'
>>> A
<class '__main__.A'>
>>> A()
<__main__.A object at 0x7f1ed25e2290>
>>> A().vim
Traceback (most recent call last):
  File "<pyshell#137>", line 1, in <module>
    A().vim
AttributeError: 'A' object has no attribute 'vim'
>>> A.vim
Traceback (most recent call last):
  File "<pyshell#138>", line 1, in <module>
    A.vim
AttributeError: type object 'A' has no attribute 'vim'
>>> class A(object):
	pass
	program = {
	"anjuta": "/usr/bin/anjuta",
	"blender": "/usr/bin/blender",
	"bluefish": "/usr/bin/bluefish",
	"eclipse": "/usr/bin/eclipse",
	"geany": "/usr/bin/geany",
	"glade": "/usr/bin/glade",
	"openjdk": "/etc/java-7-openjdk/",
	"meld": "/usr/bin/meld",
	"netbeans": "/usr/bin/netbeans",
	"qt4": "/usr/lib/qt4/bin/designer",
	"qt5": "/usr/lib/qt/bin/designer",
	"qtcreator": "/usr/bin/qtcreator",
	"ninja-ide": "/usr/bin/ninja-ide",
	"evince": "/usr/bin/evince",
	"f-spot": "/usr/bin/f-spot",
	"gimp": "/usr/bin/gimp",
	"gwenview": "/usr/bin/gwenview",
	"imagemagick": "/usr/bin/convert",
	"inkscape": "/usr/bin/inkscape",
	"mypaint": "/usr/bin/mypaint",
	"pinta": "/usr/bin/pinta",
	"shotwell": "/usr/bin/shotwell",
	"stellarium": "/usr/bin/stellarium",
	"chromium": "/usr/bin/chromium",
	"deluge": "/usr/bin/deluge",
	"evolution": "/usr/bin/evolution",
	"filezilla": "/usr/bin/filezilla",
	"firefox": "/usr/bin/firefox",
	"chrome": "/usr/bin/google-chrome-stable",
	"xchat": "/usr/bin/xchat",
	"liferea": "/usr/bin/liferea",
	"midori": "/usr/bin/midori",
	"minitube": "/usr/bin/minitube",
	"opera": "/usr/bin/opera",
	"pidgin": "/usr/bin/pidgin",
	"skype": "/usr/bin/skype",
	"steam": "/usr/bin/steam",
	"thunderbird": "/usr/bin/thunderbird",
	"transmission": "/usr/bin/transmission-gtk",
	"linuxdcpp": "/usr/bin/linuxdcpp",
	"amarok": "/usr/bin/amarok",
	"audacious": "/usr/bin/audacious",
	"banshee": "/usr/bin/banshee",
	"cheese": "/usr/bin/cheese",
	"clementine": "/usr/bin/clementine",
	"flash-player": "/usr/bin/flash-player-properties",
	"recordmydesktop": "/usr/bin/gtk-recordMyDesktop",
	"guayadeque": "/usr/bin/guayadeque",
	"mplayer": "/usr/bin/mplayer",
	"openshot": "/usr/bin/openshot",
	"pitivi": "/usr/bin/pitivi",
	"rhythmbox": "/usr/bin/rhythmbox",
	"soundconverter": "/usr/bin/soundconverter",
	"totem": "/usr/bin/totem",
	"vlc": "/usr/bin/vlc",
	"winff": "/usr/bin/winff",
	"xfburn": "/usr/bin/xfburn",
	"kdenlive": "/usr/bin/kdenlive",
	"simplescreenrecorder": "/usr/bin/simplescreenrecorder",
	"vokoscreen": "/usr/bin/vokoscreen",
	"gparted": "/usr/bin/gparted",
	"guake": "/usr/bin/guake",
	"hardinfo": "/usr/bin/hardinfo",
	"htop": "/usr/bin/htop",
	"keepassx": "/usr/bin/keepassx",
	"playonlinux": "/usr/bin/playonlinux",
	"terminator": "/usr/bin/terminator",
	"thunar": "/usr/bin/thunar",
	"truecrypt": "/usr/bin/truecrypt",
	"unetbootin": "/usr/bin/unetbootin",
	"virtualbox": "/usr/bin/virtualbox",
	"wine": "/usr/bin/wine",
	"wireshark": "/usr/bin/wireshark",
	"xbmc": "/usr/bin/xbmc",
	"gufw": "/usr/bin/gufw",
	"octopi": "/usr/bin/octopi",
	"pamac": "/usr/bin/pamac-manager",
	"gnome-system-monitor": "/usr/bin//usr/bin/gnome-system-monitor",
	"docky": "/usr/bin/docky",
	"emacs": "/usr/bin/emacs",
	"vim": "/usr/bin/vim",
	"galculator": "/usr/bin/galculator",
	"gedit": "/usr/bin/gedit",
	"gloobus": "/usr/bin/gloobus-preview",
	"leafpad": "/usr/bin/leafpad",
	"scribes": "/usr/bin/scribes",
	"tomboy": "/usr/bin/tomboy",
	"tuxcards": "/usr/bin/tuxcards",
	"imagewriter": "/usr/bin/imagewriter",
	"7zip": "/usr/bin/7zFM"
	}
	for x in program.items():
		setattr(A(), '{}'.format(x[0]), '{0}'.format(x[1]))

		
>>> A.wine
Traceback (most recent call last):
  File "<pyshell#141>", line 1, in <module>
    A.wine
AttributeError: type object 'A' has no attribute 'wine'
>>> A()
<__main__.A object at 0x7f1ed25e96d0>
>>> a.wine
Traceback (most recent call last):
  File "<pyshell#143>", line 1, in <module>
    a.wine
AttributeError: 'code' object has no attribute 'wine'
>>> A.wine
Traceback (most recent call last):
  File "<pyshell#144>", line 1, in <module>
    A.wine
AttributeError: type object 'A' has no attribute 'wine'
>>> A.gedit
Traceback (most recent call last):
  File "<pyshell#145>", line 1, in <module>
    A.gedit
AttributeError: type object 'A' has no attribute 'gedit'
>>> class YClass( object ):
    pass

>>> for x in program.items():
		setattr(YClass(), '{}'.format(x[0]), '{0}'.format(x[1]))

		
>>> YClass.tuxcards
Traceback (most recent call last):
  File "<pyshell#150>", line 1, in <module>
    YClass.tuxcards
AttributeError: type object 'YClass' has no attribute 'tuxcards'
>>> program = {
"anjuta": "/usr/bin/anjuta",
"blender": "/usr/bin/blender",
"bluefish": "/usr/bin/bluefish",
"eclipse": "/usr/bin/eclipse",
"geany": "/usr/bin/geany",
"glade": "/usr/bin/glade",
"openjdk": "/etc/java-7-openjdk/",
"meld": "/usr/bin/meld",
"netbeans": "/usr/bin/netbeans",
"qt4": "/usr/lib/qt4/bin/designer",
"qt5": "/usr/lib/qt/bin/designer",
"qtcreator": "/usr/bin/qtcreator",
"ninja-ide": "/usr/bin/ninja-ide",
"evince": "/usr/bin/evince",
"f-spot": "/usr/bin/f-spot",
"gimp": "/usr/bin/gimp",
"gwenview": "/usr/bin/gwenview",
"imagemagick": "/usr/bin/convert",
"inkscape": "/usr/bin/inkscape",
"mypaint": "/usr/bin/mypaint",
"pinta": "/usr/bin/pinta",
"shotwell": "/usr/bin/shotwell",
"stellarium": "/usr/bin/stellarium",
"chromium": "/usr/bin/chromium",
"deluge": "/usr/bin/deluge",
"evolution": "/usr/bin/evolution",
"filezilla": "/usr/bin/filezilla",
"firefox": "/usr/bin/firefox",
"chrome": "/usr/bin/google-chrome-stable",
"xchat": "/usr/bin/xchat",
"liferea": "/usr/bin/liferea",
"midori": "/usr/bin/midori",
"minitube": "/usr/bin/minitube",
"opera": "/usr/bin/opera",
"pidgin": "/usr/bin/pidgin",
"skype": "/usr/bin/skype",
"steam": "/usr/bin/steam",
"thunderbird": "/usr/bin/thunderbird",
"transmission": "/usr/bin/transmission-gtk",
"linuxdcpp": "/usr/bin/linuxdcpp",
"amarok": "/usr/bin/amarok",
"audacious": "/usr/bin/audacious",
"banshee": "/usr/bin/banshee",
"cheese": "/usr/bin/cheese",
"clementine": "/usr/bin/clementine",
"flash-player": "/usr/bin/flash-player-properties",
"recordmydesktop": "/usr/bin/gtk-recordMyDesktop",
"guayadeque": "/usr/bin/guayadeque",
"mplayer": "/usr/bin/mplayer",
"openshot": "/usr/bin/openshot",
"pitivi": "/usr/bin/pitivi",
"rhythmbox": "/usr/bin/rhythmbox",
"soundconverter": "/usr/bin/soundconverter",
"totem": "/usr/bin/totem",
"vlc": "/usr/bin/vlc",
"winff": "/usr/bin/winff",
"xfburn": "/usr/bin/xfburn",
"kdenlive": "/usr/bin/kdenlive",
"simplescreenrecorder": "/usr/bin/simplescreenrecorder",
"vokoscreen": "/usr/bin/vokoscreen",
"gparted": "/usr/bin/gparted",
"guake": "/usr/bin/guake",
"hardinfo": "/usr/bin/hardinfo",
"htop": "/usr/bin/htop",
"keepassx": "/usr/bin/keepassx",
"playonlinux": "/usr/bin/playonlinux",
"terminator": "/usr/bin/terminator",
"thunar": "/usr/bin/thunar",
"truecrypt": "/usr/bin/truecrypt",
"unetbootin": "/usr/bin/unetbootin",
"virtualbox": "/usr/bin/virtualbox",
"wine": "/usr/bin/wine",
"wireshark": "/usr/bin/wireshark",
"xbmc": "/usr/bin/xbmc",
"gufw": "/usr/bin/gufw",
"octopi": "/usr/bin/octopi",
"pamac": "/usr/bin/pamac-manager",
"gnome-system-monitor": "/usr/bin//usr/bin/gnome-system-monitor",
"docky": "/usr/bin/docky",
"emacs": "/usr/bin/emacs",
"vim": "/usr/bin/vim",
"galculator": "/usr/bin/galculator",
"gedit": "/usr/bin/gedit",
"gloobus": "/usr/bin/gloobus-preview",
"leafpad": "/usr/bin/leafpad",
"scribes": "/usr/bin/scribes",
"tomboy": "/usr/bin/tomboy",
"tuxcards": "/usr/bin/tuxcards",
"imagewriter": "/usr/bin/imagewriter",
"7zip": "/usr/bin/7zFM"
}
>>> for x in program.items():
	setattr(YClass(), '{}'.format(x[0]), '{0}'.format(x[1]))

>>> YClass.tuxcards
Traceback (most recent call last):
  File "<pyshell#153>", line 1, in <module>
    YClass.tuxcards
AttributeError: type object 'YClass' has no attribute 'tuxcards'
>>> class A(object):
	pass

>>> for x in program.items():
	setattr(A(), '{}'.format(x[0]), '{0}'.format(x[1]))

	
>>> A.tuxcards
Traceback (most recent call last):
  File "<pyshell#159>", line 1, in <module>
    A.tuxcards
AttributeError: type object 'A' has no attribute 'tuxcards'
>>> program.items()
dict_items([('xchat', '/usr/bin/xchat'), ('liferea', '/usr/bin/liferea'), ('octopi', '/usr/bin/octopi'), ('evolution', '/usr/bin/evolution'), ('mplayer', '/usr/bin/mplayer'), ('transmission', '/usr/bin/transmission-gtk'), ('vokoscreen', '/usr/bin/vokoscreen'), ('glade', '/usr/bin/glade'), ('audacious', '/usr/bin/audacious'), ('midori', '/usr/bin/midori'), ('opera', '/usr/bin/opera'), ('meld', '/usr/bin/meld'), ('docky', '/usr/bin/docky'), ('qtcreator', '/usr/bin/qtcreator'), ('geany', '/usr/bin/geany'), ('clementine', '/usr/bin/clementine'), ('wireshark', '/usr/bin/wireshark'), ('vlc', '/usr/bin/vlc'), ('imagemagick', '/usr/bin/convert'), ('gparted', '/usr/bin/gparted'), ('pamac', '/usr/bin/pamac-manager'), ('playonlinux', '/usr/bin/playonlinux'), ('gimp', '/usr/bin/gimp'), ('blender', '/usr/bin/blender'), ('bluefish', '/usr/bin/bluefish'), ('firefox', '/usr/bin/firefox'), ('amarok', '/usr/bin/amarok'), ('scribes', '/usr/bin/scribes'), ('mypaint', '/usr/bin/mypaint'), ('unetbootin', '/usr/bin/unetbootin'), ('htop', '/usr/bin/htop'), ('vim', '/usr/bin/vim'), ('skype', '/usr/bin/skype'), ('ninja-ide', '/usr/bin/ninja-ide'), ('openshot', '/usr/bin/openshot'), ('emacs', '/usr/bin/emacs'), ('chromium', '/usr/bin/chromium'), ('winff', '/usr/bin/winff'), ('galculator', '/usr/bin/galculator'), ('netbeans', '/usr/bin/netbeans'), ('thunderbird', '/usr/bin/thunderbird'), ('steam', '/usr/bin/steam'), ('eclipse', '/usr/bin/eclipse'), ('hardinfo', '/usr/bin/hardinfo'), ('chrome', '/usr/bin/google-chrome-stable'), ('guake', '/usr/bin/guake'), ('totem', '/usr/bin/totem'), ('soundconverter', '/usr/bin/soundconverter'), ('pitivi', '/usr/bin/pitivi'), ('openjdk', '/etc/java-7-openjdk/'), ('imagewriter', '/usr/bin/imagewriter'), ('filezilla', '/usr/bin/filezilla'), ('linuxdcpp', '/usr/bin/linuxdcpp'), ('terminator', '/usr/bin/terminator'), ('thunar', '/usr/bin/thunar'), ('f-spot', '/usr/bin/f-spot'), ('gedit', '/usr/bin/gedit'), ('recordmydesktop', '/usr/bin/gtk-recordMyDesktop'), ('truecrypt', '/usr/bin/truecrypt'), ('minitube', '/usr/bin/minitube'), ('stellarium', '/usr/bin/stellarium'), ('inkscape', '/usr/bin/inkscape'), ('anjuta', '/usr/bin/anjuta'), ('xfburn', '/usr/bin/xfburn'), ('deluge', '/usr/bin/deluge'), ('guayadeque', '/usr/bin/guayadeque'), ('qt5', '/usr/lib/qt/bin/designer'), ('qt4', '/usr/lib/qt4/bin/designer'), ('keepassx', '/usr/bin/keepassx'), ('flash-player', '/usr/bin/flash-player-properties'), ('simplescreenrecorder', '/usr/bin/simplescreenrecorder'), ('pinta', '/usr/bin/pinta'), ('gufw', '/usr/bin/gufw'), ('cheese', '/usr/bin/cheese'), ('wine', '/usr/bin/wine'), ('tomboy', '/usr/bin/tomboy'), ('leafpad', '/usr/bin/leafpad'), ('xbmc', '/usr/bin/xbmc'), ('gloobus', '/usr/bin/gloobus-preview'), ('7zip', '/usr/bin/7zFM'), ('gnome-system-monitor', '/usr/bin//usr/bin/gnome-system-monitor'), ('virtualbox', '/usr/bin/virtualbox'), ('shotwell', '/usr/bin/shotwell'), ('rhythmbox', '/usr/bin/rhythmbox'), ('evince', '/usr/bin/evince'), ('kdenlive', '/usr/bin/kdenlive'), ('tuxcards', '/usr/bin/tuxcards'), ('banshee', '/usr/bin/banshee'), ('pidgin', '/usr/bin/pidgin'), ('gwenview', '/usr/bin/gwenview')])
>>> class B(object):
	pass

>>> for x in program.items():
	setattr(B(), '{}'.format(x[0]), '{0}'.format(x[1]))

	
>>> B.evince
Traceback (most recent call last):
  File "<pyshell#166>", line 1, in <module>
    B.evince
AttributeError: type object 'B' has no attribute 'evince'
>>> for x in program.items():
	setattr(B, '{}'.format(x[0]), '{0}'.format(x[1]))

	
>>> B.evince
'/usr/bin/evince'
>>> B.ninja-ide
Traceback (most recent call last):
  File "<pyshell#170>", line 1, in <module>
    B.ninja-ide
AttributeError: type object 'B' has no attribute 'ninja'
>>> B.7zip
SyntaxError: invalid syntax
>>> B.pinta
'/usr/bin/pinta'
>>> class B(object):
	pass

>>> a = compile('''
x = ['1', 2, 'quotes', 'brackets', '6', 10]
the_numbers_list = iter([z for z in x if isinstance(z, int) or z.isdigit()])
while "compiling this bytecode":
    try:
        print(next(the_numbers_list))
    except StopIteration:
        break
''', '<string>', 'exec')
>>> a = compile('''
def timethis(func):
    @wraps
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(func.__name__, end-start)
        return result
return wrapper
@timethis
def some():
    x = ['1', 2, 'quotes', 'brackets', '6', 10]
    the_numbers_list = iter([z for z in x if isinstance(z, int) or z.isdigit()])
    while "compiling this bytecode":
        try:
            print(next(the_numbers_list))
        except StopIteration:
            break
some()
''', '<string>', 'exec')
Traceback (most recent call last):
  File "<pyshell#176>", line 21, in <module>
    ''', '<string>', 'exec')
  File "<string>", line 10
SyntaxError: 'return' outside function
>>> a = compile('''
def timethis(func):
    @wraps
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(func.__name__, end-start)
        return result
    return wrapper
@timethis
def some():
    x = ['1', 2, 'quotes', 'brackets', '6', 10]
    the_numbers_list = iter([z for z in x if isinstance(z, int) or z.isdigit()])
    while "compiling this bytecode":
        try:
            print(next(the_numbers_list))
        except StopIteration:
            break
some()
''', '<string>', 'exec')
>>> 
