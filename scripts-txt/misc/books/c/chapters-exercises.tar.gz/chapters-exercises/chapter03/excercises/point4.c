/* Write a program that reads in a floating-point
number and prints it first in decimal-point notation,
then in exponential notation, and then, if your system
supports it, p notation. Have the output use the following
format (the actual number of digits displayed for the exponent
depends on the system):

Enter a floating point value: 64.25
fixed-point notation: 64.250000
expotential notation: 6.4250000e+01
p notation: 0x1.01p+6
*/
#include <stdio.h>
int main(void)
{
    float fp;

    printf("Enter a floating-point value: ");
    scanf("%f", &fp);

    printf("fixed-point notation: %f\n", fp);
    printf("expotential notation: %e\n", fp);
    printf("p notation: %a\n", fp);

    return 0;
}
