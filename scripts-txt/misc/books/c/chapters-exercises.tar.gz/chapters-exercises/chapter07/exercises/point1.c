/*

Write a program that reads input until encountering the # character and then reports
the number of spaces read, the number of newline characters read, and the number of all
other characters read.

*/

#include <stdio.h>
#include <ctype.h>
int main(void)
{
    unsigned short int spaces, new_lines, rest;
    char ch;

    while ((ch = getchar()) != '#')
    {
        if (ch == '\n')
            new_lines++;

        if (isspace(ch))
            spaces++;
        
        else
            rest++;
    }
    printf("spaces = %hu, newlines = %hu, other chars = %hu",
        spaces, new_lines, rest);

    return 0;
}