#define _BSD_SOURCE
#include <unistd.h>
#include <openssl/evp.h>
#include <pwd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

#include "config.h"
#include "eventmanager.h"
#include "actionmanager.h"

extern void createactions(void);

int main(int argc, char *argv[]);
void getuser(void);
void gethost(void);

int main(int argc, char *argv[])
{
   char cwd[256], *p;
   int ret;

   if((ret = readlink("/proc/self/exe", cwd, sizeof(cwd))) < 0) {
      printf("Unable to determine the working directory");
      exit(EXIT_FAILURE);
   } else if(ret == sizeof(cwd)) {
      printf("Working directory too long");
      exit(EXIT_FAILURE);
   }

   cwd[ret] = '\0';
   if(!(p = strrchr(cwd, '/'))) {
      printf("Unable to determine the working directory");
      exit(EXIT_FAILURE);
   }
   *p = '\0';

   if(chdir(cwd)) {
      printf("Unable to change working directory");
      exit(EXIT_FAILURE);
   }

   system("pwd");

   getuser();
   gethost();

   OpenSSL_add_all_ciphers();

   if(argc > 1) {
      parseconfig(argv[1]);
   } else {
      parseconfig("config.json");
   }

   createactions();
   em_scheduleevents();

   sleep(3600);

   return 0;
}

void getuser(void)
{
   struct passwd pwd;
   struct passwd *result;
   char buf[1024];

   getpwuid_r(getuid(), &pwd, buf, sizeof(buf), &result);
   if(result == NULL) {
      snprintf(user, sizeof(user), "(uid%u)", getuid());
   } else {
      snprintf(user, sizeof(user), "%s", pwd.pw_name);
   }

   return;
}

void gethost(void)
{
   if(gethostname(host, sizeof(host))) {
      snprintf(host, sizeof(host), "(unknown)");
   } else {
      host[sizeof(host) - 1] = '\0';
   }

   return;
}
