/* There are 2.54 centimeters to the inch. Write a
program that asks you to enter your height in inches
and then displays your height in centimeters. Or, if
you prefer, ask for height in centimeters and convert
that to inches */

/* Okay, gonna complete both - inches to cm and cm to inches */

#include <stdio.h>
int main(void)
{
    int my_height;
    float inches = 0.3937008;

    printf("cm to inch converter, enter your height: ");
    scanf("%d", &my_height);

    printf("%d cm is %f in inches.\n", my_height, my_height * inches);

    return 0;
}



/*

#include <stdio.h>
int main(void)
{
    float my_height, cm = 2.54;

    printf("inch to cm converter, enter your height: ");
    scanf("%f", &my_height);

    printf("%f inches is %.0f in cm.\n", my_height, my_height * cm);

    return 0;
}

*/

