
---

Went ahead and added two new videos in our youtube channel, showcasing the build process - for the base system, xorg-server and XFCE. These actions were performed after booting into the builder DVD. You can either use a DVD and write the builder DVD iso into it or you can write the iso to a pen drive, using dd. 
