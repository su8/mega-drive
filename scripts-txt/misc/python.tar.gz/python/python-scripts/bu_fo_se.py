import os


def include(filename):
    if os.path.exists(filename):
        execfile(filename)


include('forum_build.py')
include('search_build.py')
include('build.py')