xcb-examples
============

learning xcb

useful links
============

* Tutorial: http://xcb.freedesktop.org/tutorial/
* Tutorial: http://www.x.org/releases/current/doc/libxcb/tutorial/index.html
* API: http://xcb.freedesktop.org/manual/group__XCB____API.html
* API: http://xcb.freedesktop.org/manual/group__XCB__Core__API.html
* The Xlib Programming Manual: http://tronche.com/gui/x/xlib/
* The Xlib Programming Manual: http://menehune.opt.wfu.edu/Kokua/Irix_6.5.21_doc_cd/usr/share/Insight/library/SGI_bookshelves/SGI_Developer/books/XLib_PG/sgi_html/
* X Window System Protocol: http://www.x.org/releases/current/doc/xproto/x11protocol.html
* Xlib - C Language X Interface: http://www.x.org/releases/X11R7.7/doc/libX11/libX11/libX11.html
