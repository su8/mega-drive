#!/usr/bin/python2
import os
import shlex
import cairo
import getpass
import subprocess
from gi.repository import Gtk, GObject

class no_device:
    def __init__(self):
        no_device_dialog = Gtk.MessageDialog(None, 0, Gtk.MessageType.WARNING, Gtk.ButtonsType.OK, 
        "Before starting the program,\nplease plug in some device.")
        no_device_dialog.run()
        no_device_dialog.destroy()

class usb2format:

    def area_draw(self, widget, cr):
        cr.set_source_rgba(.1, .1, .1, 0.4)
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)

    def trigger_progressbar(self, user_data):
        new_value = self.progressbar.get_fraction() + 0.08
        self.progressbar.set_fraction(new_value)
        return True

    def on_format_clicked(self, widget):
        device_path = self.show_devices.get_active_text().split('(')[1].rstrip(')')
        os.system("umount {0}".format(device_path))

        if self.file_system.get_active_text() == "fat":
            self.progressbar.set_fraction(0.00)
            sp = subprocess.Popen(shlex.split('mkfs.vfat -n "{0}" -I {1}'.format(self.device_label.get_text(), device_path)), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = sp.communicate()
            os.system("echo '{0}{1}' > /home/".format(out, err) + getpass.getuser() + "/Desktop/usb2format.txt")
            GObject.timeout_add(80, self.trigger_progressbar, None)

        if self.file_system.get_active_text() == "ntfs":
            self.progressbar.set_fraction(0.00)
            sp = subprocess.Popen(shlex.split('mkfs.ntfs --fast --force --label "{0}" {1}'.format(self.device_label.get_text(), device_path)), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = sp.communicate()
            os.system("echo '{0}{1}' > /home/".format(out, err) + getpass.getuser() + "/Desktop/usb2format.txt")
            GObject.timeout_add(80, self.trigger_progressbar, None)

    def on_close_clicked(self, widget):
        Gtk.main_quit()

    def list_all_devices(self):
        current_directory = os.getcwd()
        list_devices = subprocess.Popen(shlex.split("python2 {0}/data_usb2format/list_usb_devices.py".format(current_directory)), stdout=subprocess.PIPE).communicate()[0]
       # list_devices = list_devices.decode()
        list_devices = list_devices.strip().split('\n')
        for item in list_devices:
            name, size = item.split(',')
            self.show_devices.append_text(name + ' (' + size.lstrip() + ')')
        self.device_label.set_text(name)
        self.show_devices.set_active(0)

    def __init__(self):
        self.intf = Gtk.Builder()
        self.intf.add_from_file('data_usb2format/usb2format.glade')
        self.intf.connect_signals(self)
        self.window = self.intf.get_object("window1")
        self.screen = self.window.get_screen()
        self.visual = self.screen.get_rgba_visual()
        if self.visual != None and self.screen.is_composited():
            self.window.set_visual(self.visual)

        self.window.set_app_paintable(True)
        self.window.connect("draw", self.area_draw)
        self.show_devices = self.intf.get_object("comboboxtext1")
        self.file_system = self.intf.get_object("comboboxtext2")
        self.progressbar = self.intf.get_object("progressbar1")
        self.device_label = self.intf.get_object("entry1")
        self.list_all_devices()
        self.window.connect("delete-event", Gtk.main_quit)
        self.window.show_all()

try:
    if __name__ == '__main__':
        usb2format()
        Gtk.main()
except ValueError:
    no_device()