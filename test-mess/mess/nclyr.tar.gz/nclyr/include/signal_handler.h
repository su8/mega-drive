#ifndef INCLUDE_SIGNAL_HANDLER_H
#define INCLUDE_SIGNAL_HANDLER_H

void signal_start_handler(int pipefd);
void signal_stop_handler(void);

#endif
