Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class InvalidWithdrawal(Exception):
	def __init__(self, balance, amount):
		super().__init__("acount doesn't have ${}".format(amount))
		self.amount = amount
		self.balance = balance
	def overage(self):
		return self.amount - self.balance

	
>>> raise InavlidWithdrawal(25, 50)
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    raise InavlidWithdrawal(25, 50)
NameError: name 'InavlidWithdrawal' is not defined
>>> raise InvalidWithdrawal(25, 50)
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    raise InvalidWithdrawal(25, 50)
InvalidWithdrawal: acount doesn't have $50
>>> try:
	raise InvalidWithdrawal(25, 50)
except InvalidWithdrawal as e:
	print("I'm sorry, but your withdrawal is "
	      "more than your balance by "
	      "${}".format(e.overage()))

	
I'm sorry, but your withdrawal is more than your balance by $25
>>> def divide_with_exception(number, divisor):
	try:
		print("{} / {} = {}".format(
			number, divisor, number / divisor * 1.0))
	except ZeroDivisionError:
		print('You can\'t divide by zero')

		
>>> def divide_with_if(number, divisor):
	if divisor == 0:
		print('You can\'t divide by zero')
	else:
		print("{} / {} = {}".format(
			number, divisor, number / divisor * 1.0))

		
>>> class Inventory(object):
	def lock(self, item_type):
		'''Select the type of item that is going to be manipulated. This method will lock the item so nobody else can manipulate the inventory until it\'s returned. This prevents selling the same item to two different customers'''
		pass

	
>>> def unlock(self, item_type):
	'''Release the give type so that other customers can access it.'''
	pass

>>> def purchase(self, item_type):
	'''If the item is not locked, raise an exception. If the itemtype does not exist, raise an exception. If the item is currently out of stock, raise an exception. If the item is available, subsctract one item and return the number of items left.'''
	pass

>>> item_type = 'widget'
>>> inv = Inventory()
>>> inv.lock(item_type)
>>> try:
	num_left = inv.purchase(item_type)
except InvalidItemType:
	print('Sorry, we don\'t sell {}'.format(item_type))

	
Traceback (most recent call last):
  File "<pyshell#50>", line 2, in <module>
    num_left = inv.purchase(item_type)
AttributeError: 'Inventory' object has no attribute 'purchase'

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<pyshell#50>", line 3, in <module>
    except InvalidItemType:
NameError: name 'InvalidItemType' is not defined
>>> import hashlib
>>> class User(object):
	def __init__(self, username, password):
		'''Create a new user object. The password will be encrypted before storing'''
		self.username = username
		self.password = self._encrypt_pw(password)
		self.is_logged_in = False
	def _encrypt_pw(self, password):
		'''Encrypt the password with the username and return the sha digest.'''
		hash_string = (self.username + password)
		hash_string = hash_string.encode('utf-8')
		return hashlib.sha256(hash_string).hexdigest()
	def check_password(self, password):
		'''Return True if the password is valid for this user, false otherwise'''
		encrypted = self._encrypt_pw(password)

		
>>> class User(object):
	def __init__(self, username, password):
		'''Create a new user object. The password will be encrypted before storing'''
		self.username = username
		self.password = self._encrypt_pw(password)
		self.is_logged_in = False
	def _encrypt_pw(self, password):
		'''Encrypt the password with the username and return the sha digest.'''
		hash_string = (self.username + password)
		hash_string = hash_string.encode('utf-8')
		return hashlib.sha256(hash_string).hexdigest()
	def check_password(self, password):
		'''Return True if the password is valid for this user, false otherwise'''
		encrypted = self._encrypt_pw(password)
		return encrypted == self.password

	
>>> class AuthException(Exception):
	def __init__(self, username, user=None):
		super().__init__(username, user)
		self.username = username
		self.user = user

		
>>> class UsernameAlreadyExists(AuthException):
	pass

>>> class PasswordTooShort(AuthException):
	pass

>>> class Authenticator(object):
	def __init__(self):
		'''Construct an authenticator to manage user logging in and out'''
		self.users = dict()
	def add_user(self, username, password):
		if username in self.users:
			raise UsernameAlreadyExists(username)
		if len(password) < 6:
			raise PasswordTooShort(username)
		self.users[username] = User(username, password)
	def is_logged_in(self, username):
		if username in self.users:
			return self.users[username].is_logged_in
		return False
	def login(self, username, password):
		try:
			user = self.users[username]
		except KeyError:
			raise InvalidUsername(username)
		if not user.check_password(password):
			raise InvalidPassword(username, password)
		user.is_logged_in = True
		return True

		
>>> class InvalidUsername(AuthException):
	pass

>>> class InvalidPassword(AuthException):
	pass

>>> def login(self, username, password):
	try:
		user = self.users[username]
	except KeyError:
		raise InvalidUsername(username)
	if not user.check_password(password):
		raise InvalidPassword(username, user)
	user.is_logged_in = True
	return True

>>> def is_logged_in(self, username):
	is username in self.users:
		
SyntaxError: invalid syntax
>>> def is_logged_in(self, username):
	if username in self.users:
		return self.users[username].is_logged_in
	return False

>>> authenticator = Authenticator()
>>> 
>>> class Authorizor(object):
	def __init__(self, authenticator):
		self.authenticator = authenticator
		self.permissions = dict()
	def add_permission(self, perm_name):
		'''create a new permission that users can be added to'''
		try:
			perm_set = self.permissions[perm_name]
		except KeyError:
			self.permissions[perm_name] = set()
		else:
			raise PermissionError("Permission Exists")
	def permit_user(self, perm_name, username):
		'''grant the given permission to the user'''
		try:
			perm_set = self.permissions[perm_name]
		except KeyError:
			raise PermissionError("Permission does not exists")
		else:
			if username not in self.authenticator.users:
				raise InvalidUsername(username)
			perm_set.add(username)
	def check_permission(self, perm_name, username):
		if not self.authenticator.is_logged_in(username):
			raise NotLoggedInError(username)
		try:
			perm_set = self.permissions[perm_name]
		except KeyError:
			raise PermissionError("Permission does not exists")
		else:
			if username not in perm_set:
				raise NotPermittedError(username)
			else:
				return True

			
>>> class PermissionError(Exception):
	pass

>>> def check_permission(self, perm_name, username):
	if not self.authenticator.is_logged_in(username):
		raise NotLoggedInError(username):
			
SyntaxError: invalid syntax
>>> def check_permission(self, perm_name, username):
	if not self.authenticator.is_logged_in(username):
		raise NotLoggedInError(username)
	try:
		perm_set = self.permissions[perm_name]
	except KeyError:
		raise PermissionError("Permission does not exists")
	else:
		if username not in perm_set:
			raise NotPermittedError(username)
		else:
			return True

		
>>> class NotLoggedInError(AuthException):
	pass

>>> class NotPermittedError(AuthException):
	pass

>>> authorizor = Authorizor(authenticator)
>>> import auth
Traceback (most recent call last):
  File "<pyshell#163>", line 1, in <module>
    import auth
ImportError: No module named 'auth'
>>> import oauthlib
>>> auth = oauthlib
>>> auth.authenticator.add('joe', 'joepassword')
Traceback (most recent call last):
  File "<pyshell#166>", line 1, in <module>
    auth.authenticator.add('joe', 'joepassword')
AttributeError: 'module' object has no attribute 'authenticator'
>>> 
