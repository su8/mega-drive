#include <stdio.h>
#include <signal.h>

static void handle_usr1(int signo)
{
    if (signo == SIGUSR1)
    {
        printf("Received SIGUSR1\n");
    }
    else /* This should not happen */
    {
        printf("Unknown signal!\n");
    }
}

int main(int argc, char ** argv)
{
    if (signal(SIGUSR1, handle_usr1) == SIG_ERR)
    {
        printf("There was an error while handling the SIGUSR1 signal.\n");
        return -1;
    }

    while(1)
        ;

    return 0;
}