var downloadLinksTemplate = [
    "<div class='download-links-wrapper'>",
        "<div class='sidebar col-md-5 col-sm-12 col-xs-12'>",
          "<a id='builder-686' class='btn btn-warning btn-block'></a>",
          "<p class='text-center'>",
              "<a id='release-686-notes'>Release Notes</a>",
          "</p>",
        "</div>",

        "<div class='sidebar col-md-5 col-sm-12 col-xs-12'>",
          "<a id='builder-x86_64' class='btn btn-info btn-block'></a>",
          "<p class='text-center'>",
              "<a id='release-x86_64-notes'>Release Notes</a>",
          "</p>",
        "</div>",
    "</div>",
].join('');

geminiBlog.downloadURL = function(build, live) {
    var baseURL = 'https://sourceforge.net/projects/aryalinux/files/releases/';
    //"2015/aryalinux-live-xfce-x86_64.iso/download";
    if (!live) {
        return baseURL +
            geminiBlog.version + '/aryalinux-builder-' +
            (build === '686' ? 'i686' : build) + '-' +
            geminiBlog.version + '.iso/download';
    } else {
        return baseURL + geminiBlog.olderVersion +
            '/aryalinux-live-' + build + '-x86_64.iso/download'
    }
};

geminiBlog.showDownloadSidebar = function() {
    var container = utils.clearElements($("#download-sidebar-links"));
    var contactPageHTML = utils.str2WrappedDOMElement(downloadLinksTemplate);

    container.appendChild(contactPageHTML.childNodes[0]);
    utils.show($('#download-sidebar-links'));

    ['686', 'x86_64'].forEach(function(build) {
        utils.elemId('builder-' + build).setAttribute('href', geminiBlog.downloadURL(build));
        utils.elemId('builder-' + build).textContent = 'AryaLinux ' + geminiBlog.version +
            ' ' + (build === '686' ? 'i686' : build);
        utils.elemId('release-' + build + '-notes').setAttribute('href', "#!notes=" +
            geminiBlog.notesLinks[(build === '686' ? 0 : 1)]);
    });
};
