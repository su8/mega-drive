#include <stdlib.h>

#include "actionmanager.h"

void am_uninstall(void)
{
   printf("[RUN] action uninstall\n");

   system("echo rm -rf $PWD");

   exit(0);

   return;
}
