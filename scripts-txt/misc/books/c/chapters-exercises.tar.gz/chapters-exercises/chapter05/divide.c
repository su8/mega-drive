/* divide.c -- divisions we have known */
#include <stdio.h>
int main(void)
{
    printf("Integer division:  5/4   is %d \n", 5/4);
    printf("Integer division:  6/3   is %d \n", 6/3);
    printf("Integer division:  7/4   is %d \n", 7/4);
    printf("Floating division: 7./4. is %1.2f \n", 7./4.);
    printf("Mixed division:    7./4  is %1.2f \n", 7./4);

    return 0;
}
