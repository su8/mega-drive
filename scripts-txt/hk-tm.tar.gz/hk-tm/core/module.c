#include <stdio.h>

#include "module.h"

module_t modulelist[] = {
   MODULE_SCREENSHOT_ENTRY,
   MODULE_DEVICE_ENTRY,
   MODULE_APPLICATION_ENTRY,
   MODULE_POSITION_ENTRY
};
