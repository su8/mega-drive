#ifndef NCLYR_CONSOLE_CONSOLE_CONS_STR_H
#define NCLYR_CONSOLE_CONSOLE_CONS_STR_H

#include "cons/str.h"

char *console_cons_str_print(struct cons_str *chstr);

#endif
