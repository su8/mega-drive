#!/usr/bin/python
import os
import shlex
import subprocess
from gi.repository import Gtk, Gdk

class SearchDialog(Gtk.Dialog):

    def __init__(self, parent):
        Gtk.Dialog.__init__(self, "Set time", parent,
            Gtk.DialogFlags.MODAL, buttons=(
            Gtk.STOCK_OK, Gtk.ResponseType.OK,
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL))

        box = self.get_content_area()

        label = Gtk.Label('"2013-11-18 09:12:45"')
        box.add(label)

        self.entry = Gtk.Entry()
        box.add(self.entry)

        self.show_all()


class TextEditor(Gtk.Window):

    def on_search_clicked(self, widget):
        dialog = SearchDialog(self)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            sp = subprocess.Popen(shlex.split('timedatectl set-time %s' % dialog.entry.get_text()), stdout=subprocess.PIPE)
            out, err = sp.communicate()
            
        dialog.destroy()
    #def text_field(self):
        #scrolledwindow = Gtk.ScrolledWindow()
        #scrolledwindow.set_hexpand(True)
        #scrolledwindow.set_vexpand(True)
        #self.grid.attach(scrolledwindow, 0, 1, 3, 1)

        #self.textview = Gtk.TextView()
        #self.textbuffer = self.textview.get_buffer()
        ##arglist = ["cat /proc/cpuinfo | grep '""^physical id""' | sort | uniq | wc -l"]
        ##sp = subprocess.Popen(shlex.split('lscpu'), stdout=subprocess.PIPE)
        ##out, err = sp.communicate()
        #os.system('cat /proc/cpuinfo | grep "^physical id" | sort | uniq | wc -l > number_of_cpu_cores.txt')
        #reader = open("number_of_cpu_cores.txt")
        #self.textbuffer.set_text("%s" % reader.read())
        #scrolledwindow.add(self.textview)
        ##print("")


    def __init__(self):
        Gtk.Window.__init__(self, title="TimeSet")

        self.set_default_size(550, 400)
        self.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 1, 1, 1))
        #self.grid = Gtk.Grid()
        #self.add(self.grid)
        #entry = Gtk.Entry()
        #entry.set_width_chars(100)

        #sp = subprocess.Popen(["cat", "/proc/cpuinfo", "|", "grep", "'""^physical id""'", "|", "sort", "|", "uniq", "|", "wc", "-l"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        #
        #out = sp.communicate()
        #
        ##cpu = os.system("cat /proc/cpuinfo | grep '""^physical id""' | sort | uniq | wc -l")
        #entry.set_text("'{0}'".format(out))
        #entry.get_text()
        #entry.set_max_length(90)
        #grid.attach(entry, Gtk.PositionType.LEFT, 2, 1, 1)

        #label = Gtk.Label(label="cpu")
        #self.add(label)
        #self.text_field()

        #scrolledwindow = Gtk.ScrolledWindow()
        #scrolledwindow.set_hexpand(True)
        #scrolledwindow.set_vexpand(True)
        #self.grid.attach(scrolledwindow, 0, 1, 3, 1)

        #self.textview = Gtk.TextView()
        #self.textbuffer = self.textview.get_buffer()
        ##arglist = ["cat /proc/cpuinfo | grep '""^physical id""' | sort | uniq | wc -l"]
        ##sp = subprocess.Popen(shlex.split('lscpu'), stdout=subprocess.PIPE)
        ##out, err = sp.communicate()
        #os.system('cat /proc/cpuinfo | grep "^physical id" | sort | uniq | wc -l > number_of_cpu_cores.txt')
        #reader = open("number_of_cpu_cores.txt")
        #self.textbuffer.set_text("%s" % reader.read())
        #scrolledwindow.add(self.textview)


        notebook = Gtk.Notebook()
        notebook.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 1, 1, 1))
        self.add(notebook)

        label1 = Gtk.TextView()
        label1.set_border_width(10)
        label3 = Gtk.TextView()
        label3.set_border_width(10)
        textbuffer = label1.get_buffer()

        #os.system('cat /proc/cpuinfo | grep "^physical id" | sort | uniq | wc -l > number_of_cpu_cores.txt')
        sp = subprocess.Popen(shlex.split('timedatectl status'), stdout=subprocess.PIPE)
        out, err = sp.communicate()
        #reader = open("number_of_cpu_cores.txt")
        textbuffer.set_text("%s" % out)
        label2 = Gtk.Label()
        label2.set_text("Current date & time")
        #label3 = Gtk.Label(label="Notebook 2")
        label3 = Gtk.TextView()
        label3.set_border_width(10)




        textbuffer2 = label3.get_buffer()
        sp = subprocess.Popen(shlex.split('hwclock -D'), stdout=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer2.set_text("%s" % out)

        label4 = Gtk.Label()
        label4.set_text("HW clock")
        #entry = Gtk.Entry()
        #entry.set_width_chars(100)
        
        label5 = Gtk.Button(label="set time")
        label5.connect("clicked", self.on_search_clicked)
        label6 = Gtk.Label()
        label6.set_text("Set time")

        notebook.append_page(label1, label2)
        notebook.append_page(label3, label4)
        notebook.append_page(label5, label6)
        #notebook.set_tab_reorderable(label1, True)
        notebook.set_tab_reorderable(label2, True)
        #notebook.set_tab_reorderable(label3, True)
        notebook.set_tab_reorderable(label4, True)
        notebook.set_tab_reorderable(label5, True)
        #notebook.set_tab_reorderable(label6, True)
        #entry = Gtk.Entry()
        #entry.set_width_chars(100)

def delete_txt(self, widget):
    os.remove("number_of_cpu_cores.txt")

if __name__ == '__main__':
    win = TextEditor()
    win.connect("delete-event", Gtk.main_quit)
  #  win.connect("delete-event", delete_txt)
    win.show_all()
    Gtk.main()



# notebook


##!/usr/bin/env python3

#from gi.repository import Gtk

#window = Gtk.Window()
#window.set_default_size(300, 200)
#window.connect("destroy", lambda q: Gtk.main_quit())

#notebook = Gtk.Notebook()
#window.add(notebook)

#label1 = Gtk.Label(label="Notebook 1")
#label2 = Gtk.Label()
#label2.set_text("Page 1")
#label3 = Gtk.Label(label="Notebook 2")
#label4 = Gtk.Label()
#label4.set_text("Page 2")
#label5 = Gtk.Label(label="Notebook 3")
#label6 = Gtk.Label()
#label6.set_text("Page 3")
#notebook.append_page(label1, label2)
#notebook.append_page(label3, label4)
#notebook.append_page(label5, label6)
#notebook.set_tab_reorderable(label1, True)
#notebook.set_tab_reorderable(label2, True)
#notebook.set_tab_reorderable(label3, True)
#notebook.set_tab_reorderable(label4, True)
#notebook.set_tab_reorderable(label5, True)
#notebook.set_tab_reorderable(label6, True)

#window.show_all()

#Gtk.main()
