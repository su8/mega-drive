/* 

roo2jpg v0.98 [c]2012 Topcat Software LLC.

http://www.topcat.hypermart.net/index.html

Permission  is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in  the Software without restriction, including without limitation the rights
to  use,  copy,  modify,  merge, publish, distribute, sublicense, and/or sell
copies  of  the  Software,  and  to  permit  persons  to whom the Software is
furnished to do so, subject to the following conditions:

The  above  copyright  notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE  SOFTWARE  IS  PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED,  INCLUDING  BUT  NOT  LIMITED  TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS  FOR  A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS  OR  COPYRIGHT  HOLDERS  BE  LIABLE  FOR  ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

compilation: gcc -Wall -Werror root2jpg.c -o root2jpg -lX11 -ljpeg

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <jpeglib.h>

// --------------------------------------------------------------------------

int exitmsg(int e) {

    char buf[256]; // buffer for error messages

    switch (e) {
        case 1:
            sprintf(buf, "value must be from 1 to 59");
            break;
        case 2:
            sprintf(buf, "error opening display");
            break;
        case 3:
            sprintf(buf, "error obtaining image");
            break;
        case 4:
            sprintf(buf, "error failed to open file");
            break;
    }

    fprintf(stderr, "roo2jpg: %s...\n", buf);

    return 1;

}

// --------------------------------------------------------------------------

int write_jpeg(XImage *img, const char* filename) {

    FILE* fp;
    unsigned long pixel;
    int x, y;
    char* tmp;
    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;
    JSAMPROW row_ptr;

    fp = fopen(filename, "wb");
    if (!fp) return 1;

    // parse RGB values into tmp

    tmp = malloc(sizeof(char)*3*img->width*img->height);
    for (y = 0; y < img->height; y++) {
        for (x = 0; x < img->width; x++) {
            pixel = XGetPixel(img,x,y);
            tmp[y*img->width*3+x*3+0] = (pixel>>16);           // red
            tmp[y*img->width*3+x*3+1] = ((pixel&0x00ff00)>>8); // green
            tmp[y*img->width*3+x*3+2] = (pixel&0x0000ff);      // blue
        }
    }

    // fill in jpg structures

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_compress(&cinfo);
    jpeg_stdio_dest(&cinfo, fp);

    cinfo.image_width      = img->width;
    cinfo.image_height     = img->height;
    cinfo.input_components = 3;
    cinfo.in_color_space   = JCS_RGB;

    jpeg_set_defaults(&cinfo);
    jpeg_set_quality(&cinfo, 85, TRUE);
    jpeg_start_compress(&cinfo, TRUE);

    // iterate through each scanline writing results to file

    while (cinfo.next_scanline < cinfo.image_height) {
        row_ptr = (JSAMPROW) &tmp[cinfo.next_scanline*\
            (img->depth>>3)*img->width];
        jpeg_write_scanlines(&cinfo, &row_ptr, 1);
    }

    // clean up

    free(tmp);
    jpeg_finish_compress(&cinfo);
    fclose(fp);

    return 0;

}

// --------------------------------------------------------------------------

int syntax(void) {

  system("clear");

  printf("%s","\n\n\
  roo2jpg screen-shot tool v0.98 [c]2012 Topcat Software LLC.\n\n\
  syntax: roo2jpg [-s seconds] [-f file.jpg]\n\n\
  where...\n\n\
  -s specifies sleep in secs. (1 to 59)\n\n\
  -f specifies filename\n\n");

  return 0;

}

// --------------------------------------------------------------------------

int main(int argc, char *argv[]) {

    if (argc < 1 || argc > 1) return syntax(); // bad syntax return
    int x = strcmp("-s", "-s");             // -s option
    int y = strcmp("-f", "-f");             // -f option
    if (x || y) return syntax();               // bad syntax return
    int n = atoi("1");                     // number of seconds to sleep
    if (n < 1 || n > 59) return exitmsg(1);    // out of range return error msg
    sleep(n);                                  // zzz... n seconds

    Display *dpy = XOpenDisplay(0);            // attempt to open display
    if (dpy == NULL) return exitmsg(2);        // else return error

    Window root = RootWindow(dpy,DefaultScreen(dpy)); // get root window
    XWindowAttributes rootAttributes;                 // and then...
    XGetWindowAttributes(dpy, root, &rootAttributes); // acquire attributes

    XImage *img = XGetImage(dpy,root,0,0,\
        rootAttributes.width,            \
        rootAttributes.height,           \
        XAllPlanes(),ZPixmap);          // nab XImage of root window

    if (img == NULL) {                  // if XGetImage() failed
        XCloseDisplay(dpy);             // close display and
        return exitmsg(3);              // return error
    } else {
        x = write_jpeg(img, "/tmp/Screenshot1.jpg");   // write jpg
        XDestroyImage(img);             // release memory
        if (x != 0) {                   // if libjpg failed
            XCloseDisplay(dpy);         // close display and
            return exitmsg(4);          // return error
        }
    }

    XCloseDisplay(dpy);                 // close display and
    return 0;                           // bring it on home


}

// eof