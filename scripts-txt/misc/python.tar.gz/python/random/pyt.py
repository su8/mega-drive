# inxi -F -c 0

with open("/home/frost/Desktop/inxi.txt") as read_title_and_date:
    for i, line in enumerate(read_title_and_date.readlines(), 0):
        s = line
        if i == 0:
            print("{0}".format(s[17:-1]))
        if i == 1:
            print("{0}".format(s[17:-1]))
        if i == 2:
            print("{0}".format(s[11:-1]))
        if i == 3:
            print("{0}".format(s[25:-1]))
        if i == 4:
            print("{0}".format(s[17:-1]))
        if i == 5:
            print("{0}".format(s[33:-1]))
        #if i == 6:
            #print("{0}".format(s[11:-1]))
        if i == 7:
            print("{0}".format(s[11:-1]))
        if i == 8:
            print("{0}".format(s[11:-1]))
        if i == 9:
            print("{0}".format(s[11:-1]))
        #if i == 10:
            #print("{0}".format(s[11:-1]))
        if i == 11:
            print("{0}".format(s[11:-1]))
        #if i == 12:
            #print("{0}".format(s[11:-1]))
        if i == 13:
            print("{0}".format(s[11:-1]))
        #if i == 14:
            #print("{0}".format(s[11:-1]))
        #if i == 15:
            #print("{0}".format(s[11:-1]))
        #if i == 16:
            #print("{0}".format(s[11:-1]))
        if i == 17:
            print("{0}".format(s[11:-1]))
        #if i == 18:
            #print("{0}".format(s[11:-1]))
