bash and zsh completions.
