
extern char * basename (const char *filename);

/* EOF */

