#!/bin/bash
/sbin/iptables -F
/sbin/iptables -X
/sbin/iptables -t nat -F
/sbin/iptables -t nat -X
/sbin/iptables -t mangle -F
/sbin/iptables -t mangle -X
modprobe ip_conntrack 
NIC="eth0"  
/sbin/iptables -A INPUT -i lo -j ACCEPT
/sbin/iptables -A OUTPUT -o lo -j ACCEPT
/sbin/iptables -P INPUT DROP
/sbin/iptables -P OUTPUT DROP
/sbin/iptables -P FORWARD DROP 
/sbin/iptables -A INPUT -i ${NIC} -p tcp ! --syn -m state --state NEW  -m limit --limit 5/m --limit-burst 7 -j LOG --log-level 4 --log-prefix "Drop Syn" 
/sbin/iptables -A INPUT -i ${NIC} -p tcp ! --syn -m state --state NEW -j DROP
/sbin/iptables -A INPUT -i ${NIC} -f  -m limit --limit 5/m --limit-burst 7 -j LOG --log-level 4 --log-prefix "Fragments Packets"
/sbin/iptables -A INPUT -i ${NIC} -f -j DROP  
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags ALL FIN,URG,PSH -j DROP
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags ALL ALL -j DROP 
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags ALL NONE -m limit --limit 5/m --limit-burst 7 -j LOG --log-level 4 --log-prefix "NULL Packets"
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags ALL NONE -j DROP
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags SYN,RST SYN,RST -j DROP 
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags SYN,FIN SYN,FIN -m limit --limit 5/m --limit-burst 7 -j LOG --log-level 4 --log-prefix "XMAS Packets"
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags FIN,ACK FIN -m limit --limit 5/m --limit-burst 7 -j LOG --log-level 4 --log-prefix "Fin Packets Scan"
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags FIN,ACK FIN -j DROP
/sbin/iptables  -A INPUT -i ${NIC} -p tcp --tcp-flags ALL SYN,RST,ACK,FIN,URG -j DROP  
/sbin/iptables -A INPUT -i eth0 -m state --state ESTABLISHED,RELATED -j ACCEPT
/sbin/iptables -A OUTPUT -o eth0 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT 
/sbin/iptables -A INPUT -p tcp --destination-port 22 -j REJECT
/sbin/iptables -A OUTPUT -p tcp --sport 22 -j REJECT
# Whenever you change the ssh port make sure to uncomment the line below and change the port
# iptables -I INPUT 4 -p tcp -d 192.168.10.30 --dport 3789 -j ACCEPT
#If you only need remote access from one IP address (say from work to your home server), then consider filtering connections at your firewall by either adding a firewall rule on your router or in iptables to limit access on port 3789 to only that specific IP address. For example, in iptables this could be achieved with the following type of rule:
# iptables -A INPUT -p tcp -s 72.232.194.162 --dport 3789 -j ACCEPT 
/sbin/iptables -A INPUT -p icmp --icmp-type 8 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
/sbin/iptables -A OUTPUT -p icmp --icmp-type 0 -m state --state ESTABLISHED,RELATED -j ACCEPT 
/sbin/iptables -A INPUT -p tcp -i eth0 --dport 137:139 -j REJECT
/sbin/iptables -A INPUT -p udp -i eth0 --dport 137:139 -j REJECT 
/sbin/iptables -A INPUT -j LOG
/sbin/iptables -A FORWARD -j LOG
/sbin/iptables -A INPUT -j DROP
echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all
echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_broadcasts
echo 1 > /proc/sys/net/ipv4/ip_forward
echo 64000 > /proc/sys/net/ipv4/ipfrag_high_thresh
echo 48000 > /proc/sys/net/ipv4/ipfrag_low_thresh 
echo 10 > /proc/sys/net/ipv4/ipfrag_time 
echo 5 > /proc/sys/net/ipv4/icmp_ratelimit
echo 1 > /proc/sys/net/ipv4/tcp_syncookies
echo 0 > /proc/sys/net/ipv4/conf/eth0/accept_source_route
echo 0 > /proc/sys/net/ipv4/conf/eth0/accept_redirects 
echo 1 > /proc/sys/net/ipv4/conf/eth0/log_martians 
echo 10 > /proc/sys/net/ipv4/neigh/eth0/locktime
echo 0 > /proc/sys/net/ipv4/conf/eth0/proxy_arp
echo 50 > /proc/sys/net/ipv4/neigh/eth0/gc_stale_time
echo 0 > /proc/sys/net/ipv4/conf/eth0/send_redirects
echo 0 > /proc/sys/net/ipv4/conf/eth0/secure_redirects
echo 1 > /proc/sys/net/ipv4/icmp_ignore_bogus_error_responses
echo 5 > /proc/sys/net/ipv4/igmp_max_memberships
echo 2 > /proc/sys/net/ipv4/igmp_max_msf
echo 1024 > /proc/sys/net/ipv4/tcp_max_orphans
echo 2 > /proc/sys/net/ipv4/tcp_syn_retries
echo 2 > /proc/sys/net/ipv4/tcp_synack_retries
echo 1 > /proc/sys/net/ipv4/tcp_abort_on_overflow
echo 10 > /proc/sys/net/ipv4/tcp_fin_timeout
echo 0 > /proc/sys/net/ipv4/route/redirect_number
echo 1 > /proc/sys/net/ipv4/conf/all/rp_filter
echo 1 > /proc/sys/net/ipv4/conf/eth0/rp_filter
echo 0 > /proc/sys/net/ipv4/conf/all/accept_source_route
echo 61 > /proc/sys/net/ipv4/ip_default_ttl
echo "1800" > /proc/sys/net/ipv4/tcp_keepalive_time
echo "0" > /proc/sys/net/ipv4/tcp_window_scaling
echo "0" > /proc/sys/net/ipv4/tcp_sack
echo 4096 87380 4194304 >/proc/sys/net/ipv4/tcp_rmem
echo 4096 87380 4194304 >/proc/sys/net/ipv4/tcp_wmem
echo 1 > /proc/sys/net/ipv4/tcp_ecn
echo "30000 60000" > /proc/sys/net/ipv4/ip_local_port_range 
service iptables save
service iptables restart
exit 0
