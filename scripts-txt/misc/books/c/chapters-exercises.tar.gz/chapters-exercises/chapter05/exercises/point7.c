/* Write a program that request a type double number and prints the
 * value of the number cubed. Use a function of your own design to
 * cube the value and print it. The main() program should pass the
 * entered value to this function. */
#include <stdio.h>

void calc_cube(double val);

int main(void)
{
    double num;
    
    printf("Enter some number:\n");
    scanf("%lf", &num);
    
    calc_cube(num);
    
    return 0;
}

void calc_cube(double val)
{
    double a,b;
    a = val * val;
    b = a * a;
    printf("%.0lf * %.0lf * %.0lf * %.0lf = %.0lf",
    val, val, val, val, b);
}
