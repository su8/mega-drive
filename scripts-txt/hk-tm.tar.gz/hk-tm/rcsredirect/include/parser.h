
/* $Id: parser.h 790 2009-08-03 14:34:04Z alor $ */

#ifndef __PARSER_H
#define __PARSER_H


extern void parse_options(int argc, char **argv);


#endif

/* EOF */

// vim:ts=3:expandtab

