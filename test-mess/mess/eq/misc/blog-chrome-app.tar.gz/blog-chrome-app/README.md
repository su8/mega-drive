95% of the Chrome store apps do nothing, but redirect you to the official app website.

I guess the website bookmarking days are ~~~numbered~~~ going to stick around for a while.

My "app" contributes to the Chrome store mess.
