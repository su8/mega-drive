/*
Just a very simple attempt to create a
reasonably long-running process. I first compiled this
with no optimisation flags (g++ hello.cpp -o hello) and timed it.
It came out as a little bit over 12 seconds. Then I compiled it again,
this time with (g++ -O3 hello.cpp -o hello). According to the manpage,
-O3 should turn on a lot of optimisations. And it seems so, because then
when I ran the program again, it took less than 2 seconds 
(between 6 and 12 times as fast). Pretty impressive I’d say.

N.B. I just used the standard time command for the timing if anyone was
wondering, nothing fancy.
*/

#include <iostream>
using namespace std;

int sum_squares(int high) {
  int acc = 0;
  int limit = high + 1;

  for (int i = 0; i < limit; i++) {
    int a = i*i;
    acc += a;
  }

  return acc;
}

int main() {
  int result = sum_squares(1024*1024*1024);
  cout << result << endl;
  cout << "Hello World" << endl;
  return 0;
}
