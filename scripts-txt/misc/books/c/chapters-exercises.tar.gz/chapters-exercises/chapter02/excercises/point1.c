 /* write a program that uses one printf() call to
 print your first name and last name on one line,
 uses a second printf() call to print your first and last
 names on two separate lines, and uses a pair of printf calls to
 print your first and last names on one line.
 */
 #include <stdio.h>
 int main(void)
 {
     printf("Aaron Caffrey\n");
     printf("Aaron\n");
     printf("Caffrey\n");
     printf("Aaron ");
     printf("Caffrey\n");

     return 0;
 }
