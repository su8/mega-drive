#!/bin/bash
for i in forum_build search_build build;
do python2 /home/frost/blog/$i.py & done
