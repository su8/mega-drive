import commands

ret = commands.getoutput("akonadictl stop")

print(ret)

# python 3 equivalent
#import subprocess

#ret = subprocess.getoutput("akonadictl stop")

#print(ret)



