/* 10. Write a program that requests lower and upper integer limits, calculates the sum of all
the integer squares from the square of the lower limit to the square of the upper limit,
and displays the answer. The program should then continue to prompt for limits and
display answers until the user enters an upper limit that is equal to or less than the lower
limit. A sample run should look something like this:
Enter lower and upper integer limits: 5 9
The sums of the squares from 25 to 81 is 255
Enter next set of limits: 3 25
The sums of the squares from 9 to 625 is 5520
Enter next set of limits: 5 5
Done */
#include <stdio.h>
int main(void)
{
    /*long num1, num2;
    
    printf("Enter lower and upper integer limits: ");
    scanf("%ld%ld", &num1, &num2);
    while (num1 < num2)
    {
        printf("The sum of squares from %ld to %ld is %ld\n",
        num1 * num1, num2 * num2,
        (num1 * num1) * num2 + (num1 * num1) + num1);
        
        printf("Enter next set of limits: ");
        scanf("%ld%ld", &num1, &num2);
    }
    printf("Done\n");
    
    return 0;*/
    int lower, upper, index;
    int square, cube;
    
    printf("Enter starting integer: ");
    scanf("%d", &lower);
    printf("Enter ending integer: ");
    scanf("%d", &upper);
    
    printf("%5s %10s %15s\n", "num", "square", "cube");
    for (index = lower; index <= upper; index++)
    {
        square = index * index;
        cube = index * square;
        printf("%5d %10d %15d\n", index, square, cube);
    }
    
    return 0;
}
