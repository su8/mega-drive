Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> # 13.10 READING CONFIGURATION FILES
>>> # configz.ini
>>> from configparser import ConfigParser
>>> cfg = ConfigParser()
>>> cfg.read('config.ini')
[]
>>> cfg.read('configz.ini')
['configz.ini']
>>> cfg.sections()
['installation', 'debug', 'server']
>>> cfg.get('installation','library')
'/usr/local/lib'
>>> cfg.getboolean('debug','log_errors')
True
>>> cfg.getint('server','port')
8080
>>> cfg.get('server','signature')
'\n=====================================\nBrought to you by the Python CookBook\n====================================='
>>> cfg.set('server','port', 9000)
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    cfg.set('server','port', 9000)
  File "/usr/lib/python3.3/configparser.py", line 1166, in set
    self._validate_value_types(option=option, value=value)
  File "/usr/lib/python3.3/configparser.py", line 1155, in _validate_value_types
    raise TypeError("option values must be strings")
TypeError: option values must be strings
>>> cfg.set('server','port', '9000')
>>> cfg.set('debug','log_errors','False')
>>> import sys
>>> cfg.write(sys.stdout)
[installation]
library = %(prefix)s/lib
include = %(prefix)s/include
bin = %(prefix)s/bin
prefix = /usr/local

[debug]
log_errors = False
show_warnings = False

[server]
port = 9000
nworkers = 32
pid-file = /tmp/spam.pid
root = /www/root
signature = 
	=====================================
	Brought to you by the Python CookBook
	=====================================

>>> cfg.get('debug','log_errors')
'False'
>>> with open('aha.ini', 'wt') as f:
	f.write(sys.stdout)

	
Traceback (most recent call last):
  File "<pyshell#19>", line 2, in <module>
    f.write(sys.stdout)
TypeError: must be str, not PseudoOutputFile
>>> with open('aha.ini', 'wt') as f:
	f.write(cfg.write(sys.stdout))

	
[installation]
library = %(prefix)s/lib
include = %(prefix)s/include
bin = %(prefix)s/bin
prefix = /usr/local

[debug]
log_errors = False
show_warnings = False

[server]
port = 9000
nworkers = 32
pid-file = /tmp/spam.pid
root = /www/root
signature = 
	=====================================
	Brought to you by the Python CookBook
	=====================================

Traceback (most recent call last):
  File "<pyshell#21>", line 2, in <module>
    f.write(cfg.write(sys.stdout))
TypeError: must be str, not None
>>> with open('aha.ini', 'wt') as f:
	f.write('{}'.format(cfg.write(sys.stdout)))

	
[installation]
library = %(prefix)s/lib
include = %(prefix)s/include
bin = %(prefix)s/bin
prefix = /usr/local

[debug]
log_errors = False
show_warnings = False

[server]
port = 9000
nworkers = 32
pid-file = /tmp/spam.pid
root = /www/root
signature = 
	=====================================
	Brought to you by the Python CookBook
	=====================================

4
>>> with open('aha.ini', 'wt') as f:
	f.write('{}'.format(sys.stdout))

	
59
>>> a = list()
>>> for x in cfg.write(sys.stdout):
	a.append(x)

	
[installation]
library = %(prefix)s/lib
include = %(prefix)s/include
bin = %(prefix)s/bin
prefix = /usr/local

[debug]
log_errors = False
show_warnings = False

[server]
port = 9000
nworkers = 32
pid-file = /tmp/spam.pid
root = /www/root
signature = 
	=====================================
	Brought to you by the Python CookBook
	=====================================

Traceback (most recent call last):
  File "<pyshell#29>", line 1, in <module>
    for x in cfg.write(sys.stdout):
TypeError: 'NoneType' object is not iterable
>>> sys.stdout
<idlelib.PyShell.PseudoOutputFile object at 0x7fa85536fdd0>
>>> cfg.write('aha.ini')
Traceback (most recent call last):
  File "<pyshell#31>", line 1, in <module>
    cfg.write('aha.ini')
  File "/usr/lib/python3.3/configparser.py", line 897, in write
    self._sections[section].items(), d)
  File "/usr/lib/python3.3/configparser.py", line 901, in _write_section
    fp.write("[{}]\n".format(section_name))
AttributeError: 'str' object has no attribute 'write'

>>> cfg.write()
Traceback (most recent call last):
  File "<pyshell#32>", line 1, in <module>
    cfg.write()
TypeError: write() missing 1 required positional argument: 'fp'
>>> # 13.11 adding logging to simple scripts
>>> import logging
>>> def main()
SyntaxError: invalid syntax
>>> def main():
	logging.basicConfig(
		filename='app.log',
		level=logging.ERROR
		)
	# Variables (to make the calls that follow work)
	hostname = 'www.python.org'
	item = 'spam'
	filename = 'data.csv'
	more = 'r'
	# example logging calls (insert into your program)
	logging.critical('Host {} unknown'.format(hostname))
	logging.error('Couldnt find', item)
	logging.warning('Feature deprecated')
	logging.info('Opening file {0}, mode={1}'.format(filename, mode))
	logging.debug('Got here')

	
>>> if __name__ == '__main__':
	main()

	
Traceback (most recent call last):
  File "/usr/lib/python3.3/logging/__init__.py", line 939, in emit
    msg = self.format(record)
  File "/usr/lib/python3.3/logging/__init__.py", line 810, in format
    return fmt.format(record)
  File "/usr/lib/python3.3/logging/__init__.py", line 548, in format
    record.message = record.getMessage()
  File "/usr/lib/python3.3/logging/__init__.py", line 311, in getMessage
    msg = msg % self.args
TypeError: not all arguments converted during string formatting
Logged from file <pyshell#52>, line 13
Traceback (most recent call last):
  File "<pyshell#55>", line 2, in <module>
    main()
  File "<pyshell#52>", line 15, in main
    logging.info('Opening file {0}, mode={1}'.format(filename, mode))
NameError: global name 'mode' is not defined
>>> # mode not more lol
>>> def main():
	logging.basicConfig(
		filename='app.log',
		level=logging.ERROR
		)
	# Variables (to make the calls that follow work)
	hostname = 'www.python.org'
	item = 'spam'
	filename = 'data.csv'
	mode = 'r'
	# example logging calls (insert into your program)
	logging.critical('Host {} unknown'.format(hostname))
	logging.error('Couldnt find', item)
	logging.warning('Feature deprecated')
	logging.info('Opening file {0}, mode={1}'.format(filename, mode))
	logging.debug('Got here')

	
>>> if __name__ == '__main__':
	main()

	
Traceback (most recent call last):
  File "/usr/lib/python3.3/logging/__init__.py", line 939, in emit
    msg = self.format(record)
  File "/usr/lib/python3.3/logging/__init__.py", line 810, in format
    return fmt.format(record)
  File "/usr/lib/python3.3/logging/__init__.py", line 548, in format
    record.message = record.getMessage()
  File "/usr/lib/python3.3/logging/__init__.py", line 311, in getMessage
    msg = msg % self.args
TypeError: not all arguments converted during string formatting
Logged from file <pyshell#58>, line 13
>>> def main():
	logging.basicConfig(
		filename='app.log',
		level=logging.ERROR
		)
	# Variables (to make the calls that follow work)
	hostname = 'www.python.org'
	item = 'spam'
	filename = 'data.csv'
	mode = 'r'
	# example logging calls (insert into your program)
	logging.critical('Host %s unknown', hostname)
	logging.error('Couldnt find', item)
	logging.warning('Feature deprecated')
	logging.info('Opening file %r, mode=%r', filename, mode)
	logging.debug('Got here')

	
>>> if __name__ == '__main__':
	main()

	
Traceback (most recent call last):
  File "/usr/lib/python3.3/logging/__init__.py", line 939, in emit
    msg = self.format(record)
  File "/usr/lib/python3.3/logging/__init__.py", line 810, in format
    return fmt.format(record)
  File "/usr/lib/python3.3/logging/__init__.py", line 548, in format
    record.message = record.getMessage()
  File "/usr/lib/python3.3/logging/__init__.py", line 311, in getMessage
    msg = msg % self.args
TypeError: not all arguments converted during string formatting
Logged from file <pyshell#62>, line 13
>>> def main():
	logging.basicConfig(
		filename='app.log',
		level=logging.ERROR
		)
	# Variables (to make the calls that follow work)
	hostname = 'www.python.org'
	item = 'spam'
	filename = 'data.csv'
	mode = 'r'
	# example logging calls (insert into your program)
	logging.critical('Host %s unknown', hostname)
	logging.error('Couldnt find %r', item)
	logging.warning('Feature deprecated')
	logging.info('Opening file %r, mode=%r', filename, mode)
	logging.debug('Got here')

	
>>> if __name__ == '__main__':
	main()

	
>>> def main():
	logging.basicConfig(
		filename='app.log',
		level=logging.ERROR
		)
	# Variables (to make the calls that follow work)
	hostname = 'www.python.org'
	item = 'spam'
	filename = 'data.csv'
	mode = 'r'
	# example logging calls (insert into your program)
	logging.critical('Host %s unknown', hostname)
	logging.error('Couldnt find %r', item)
	logging.warning('Feature deprecated')
	logging.info('Opening file %r, mode=%r', filename, mode)
	logging.debug('Got here')

	
>>> if __name__ == '__main__':
	main()

>>> def main():
	logging.basicConfig(
		level=logging.INFO
		)
	# Variables (to make the calls that follow work)
	hostname = 'www.python.org'
	item = 'spam'
	filename = 'data.csv'
	mode = 'r'
	# example logging calls (insert into your program)
	logging.critical('Host %s unknown', hostname)
	logging.error('Couldnt find %r', item)
	logging.warning('Feature deprecated')
	logging.info('Opening file %r, mode=%r', filename, mode)
	logging.debug('Got here')

	
>>> if __name__ == '__main__':
	main()

	
>>> main()
>>> def main():
	logging.basicConfig(level=logging.INFO)
	# Variables (to make the calls that follow work)
	hostname = 'www.python.org'
	item = 'spam'
	filename = 'data.csv'
	mode = 'r'
	# example logging calls (insert into your program)
	logging.critical('Host %s unknown', hostname)
	logging.error('Couldnt find %r', item)
	logging.warning('Feature deprecated')
	logging.info('Opening file %r, mode=%r', filename, mode)
	logging.debug('Got here')

>>> if __name__ == '__main__':
	main()

	
>>> # 13.13 making a stopwatch timer
>>> import time
>>> class Timer:
	def __init__(self, func=time.perf_counter):
		self.elapsed = 0.0
		self._func = func
		self._start = None
	def start(self):
		if self._start is not None:
			raise RuntimeError('Already started')
		self._start = self._func()
	def stop(self):
		if self._start is None:
			raise RuntimeError('Not started')
		end = self._func()
		self.elapsed += end - self._start
		self._start = None
	def reset(self):
		self.elapsed = 0.0
	@property
	def running(self):
		return self._start in not None
	
SyntaxError: invalid syntax
>>> class Timer:
	def __init__(self, func=time.perf_counter):
		self.elapsed = 0.0
		self._func = func
		self._start = None
	def start(self):
		if self._start is not None:
			raise RuntimeError('Already started')
		self._start = self._func()
	def stop(self):
		if self._start is None:
			raise RuntimeError('Not started')
		end = self._func()
		self.elapsed += end - self._start
		self._start = None
	def reset(self):
		self.elapsed = 0.0
	@property
	def running(self):
		return self._start is not None
	def __enter__(self):
		self.start()
		return self
	def __exit__(self, *args):
		self.stop()

		
>>> def countdown(n):
	while n > 0:
		n -= 1

		
>>> # use 1: explicit start/stop
>>> t = Timer()
>>> t.start()
>>> countdown(1000000)
>>> t.stop()
>>> print(t.elapsed)
20.087264345999756
>>> # use 2: as a context manager
>>> with t:
	countdown(1000000)
	print(t.elapsed)

	
20.087264345999756
>>> with Timer() as t2:
	countdown(1000000)

	
>>> print(t.elapsed)
20.242647077999663
>>> 
