/* curs.c -- example1 */
/* gcc -Wall -O2 curs.c -o main -lncurses */
#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <string.h>
int main(void)
{
    char mesg[] = "Just a string"; /* message to be appeared on the screen*/
    char str[80];
    int row, col; /* to store the number of rows and columns */
    initscr(); /* start curses mode*/

    getmaxyx(stdscr, row, col); /* get the numbers of rows and
                                    columns to center the message
                                    on to the screen */
    mvprintw(row/2, (col-strlen(mesg))/2, "%s", mesg);

    getstr(str);
    mvprintw(LINES - 2, 0, "You entered %s", str);
    getch(); /* wait for user input */
    endwin(); /* end curses mode */

    return EXIT_SUCCESS;
}