
extern void * memmem(const char *haystack, size_t haystacklen,
                     const char *needle, size_t needlelen);

/* EOF */
