/* swap1.c -- first attempt at a swapping function */
#include <stdio.h>
#include <stdlib.h>

void interchange(int u, int v); /* declare function */

int main(void)
{
    int x = 5, y = 10;

    printf("Originally x = %d and y = %d.\n", x, y);
    interchange(x, y);
    printf("Now x = %d and y = %d.\n", x, y);

    return EXIT_SUCCESS;
}

void interchange(int u, int v)  /* define function */
{
    int temp;

    printf("Originally u = %d and v = %d.\n", u, v);

    temp = u;
    u = v;
    v = temp;
    printf("Now u = %d and v = %d.\n", u, v);
}