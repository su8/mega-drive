#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void handle_sigalrm(int);

int main(int argc, char **argv)
{
    char name[100];

    signal(SIGALRM, handle_sigalrm);
    alarm(10);

    while (1)
    {
        printf("You only have 10 seconds to type your name: ");
        scanf("%s", name);
        break;
    }

    printf("Hello %s\n", name);

    return 0;
}

void handle_sigalrm(int signo)
{
    printf("Too late...");
    printf("Please try again...\n");
    alarm(10);
}