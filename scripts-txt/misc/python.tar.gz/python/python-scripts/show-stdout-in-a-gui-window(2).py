import gtk,pygtk
import subprocess
import gobject

class CommandTextView(gtk.TextView):
    def __init__(self,command):
        super(CommandTextView,self).__init__()
        
        self.command = "timedatectl status"
    def run(self):
        proc = subprocess.Popen(self.command,shell=True,stdout=subprocess.PIPE)
        gobject.io_add_watch(proc.stdout,
                          gobject.IO_IN,
                          self.write_to_buffer)
    def write_to_buffer(self, fd, condition):
        if condition == gobject.IO_IN:
            char = fd.read(1)
            buf = self.get_buffer()
            buf.insert_at_cursor(char)
            return True
        else:
            return False

def test():
    win=gtk.Window()
    win.set_size_request(300,300)
    win.connect('delete-event',lambda w,e : gtk.main_quit())
    ctv=CommandTextView("ls")
    win.add(ctv)
    win.show_all()
    ctv.run()
    gtk.main()

if __name__=='__main__': test()