/* Now modify the program exercise 5 so that it computes the sum of the
 * squares of the integers. (If you prefer, how much money you receive
 * if you get $1 the first day, $4 the second day, $9 the third day,
 * and so on. This looks like much better deal!) C doesn't have a
 * squaring function, but you can use the fact that the square of n
 * is "n * n" */
#include <stdio.h>
int main(void)
{
    int count = 0, sum;
    int read_int;
    
    
    printf("Enter some number:\n");
    scanf("%d", &read_int);
    
    while (count++ < read_int)
    {
        sum = count * count;
        printf("%d * %d = %d\n", count, count, sum);
    }
    
    return 0;
}
