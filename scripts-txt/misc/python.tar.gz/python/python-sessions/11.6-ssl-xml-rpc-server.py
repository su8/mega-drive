import ssl
class SSLMixin:
	'''
Mixin class that adds support for SSL to existing servers based on the socketserver module.
'''
	def __init(self, *args,
		   keyfile=None, certfile=None, ca_certs=None,
		   cert_reqs=ssl.NONE, **kwargs):
		self._keyfile = keyfile
		self._cerfile = certfile
		self_ca_certs = ca_certs
		self._cert_reqs = cert_reqs
		super().__init__(*args, **kwargs)
	def get_request(self):
		client, addr = super().get_request()
		client_ssl = ssl.wrap_socket(client,
					     keyfile = self._keyfile,
					     certfile = self._certfile,
					     ca_certs = self._ca_certs,
					     cert_reqs = self._cert_reqs,
					     server_side = True)
		return client_ssl, addr 

from xmlrpc.server import SimpleXMLRPCServer
class SSLSimpleXMLRPCServer(SSLMixin, SimpleXMLRPCServer):
	pass

class KeyValueServer:
	_rpc_methods_ = ['get', 'set', 'delete', 'exists', 'keys']
	def __init__(self, *args, **kwargs):
		self._data = dict()
        self._serv = SSLSimpleXMLRPCServer(*args, allow_none=True, **kwargs)
        for name in self._rpc_methods_:
        	self._serv.register_function(getattr(self, name))

    def get(self, name):
        return self._data[name]
    def set(self, name, value):
        self._data[name] = value
    def delete(self, name):
        del self._data[name]
    def exists(self, name):
        return name in self._data
    def keys(self):
        return list(self._data)
    def serve_forever(self):
        self._serv.serve_forever()
if __name__ == '__main__':
    KEYFILE = 'server_key.pem' # private key of the server
    CERTFILE = 'server_cert.pem' # server certificate
    kvserv = KeyValueServer(('', 15000),
        keyfile=KEYFILE,
        certfile=CERTFILE),
    kvserv.serve_forever()

# to use this server you can connect using the normal xmlrpc.client module.
# just specify https: in the URL
'''
from xmlrpc.client import ServerProxy
s = ServerProxy('https://localhost:15000', allow_none=True)
s.set('foo','bar')
s.set('spam', [1,2,3])
s.keys()
['spam', 'foo']
s.get('foo')
'bar'
s.get('spam')
[1,2,3]
s.delete('spam')
s.exists('spam')
False
'''

'''
# my post from kris python tutorial
>>> class RandoM:
	def __init__(self, *given_args):
		self.list = list()
		for item in given_args:
			self.list.append(item)
	def __repr__(self):
		return str(self.list)
	def __getitem__(self, required_index_position):
		return self.list[required_index_position]
	def __getattr__(self, item_name):
		return getattr(self.list, item_name)
	def __setitem__(self, item_position, item):
		self.list[item_position] = item
	def __delitem__(self, item_position):
		del self.list[item_position]
	def __len__(self):
		return len(self.list)

	
>>> p = RandoM(3,4,5,6,7,8,9)
>>> p.append('where is batman ?')
>>> p
[3, 4, 5, 6, 7, 8, 9, 'where is batman ?']
>>> p[0]
3
>>> p[-1]
'where is batman ?'
>>> len(p)
8
>>> p.insert(0, 328138213)
>>> p
[328138213, 3, 4, 5, 6, 7, 8, 9, 'where is batman ?']
>>> del p[-1]
>>> p
[328138213, 3, 4, 5, 6, 7, 8, 9]
'''