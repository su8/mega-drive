#ifndef INC_CONFIG_CONFIG_C_H
#define INC_CONFIG_CONFIG_C_H

#include "output_config.h"

extern struct config_output c_output;

#endif
