install py2exe and python 2.7
copy python.exe over the directory where is setup.py
then open up cmd (command prompt) and cd to the directory
then type:

python setup.py py2exe
