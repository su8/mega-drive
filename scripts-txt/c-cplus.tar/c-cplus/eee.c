// gcc eee.c -o ee
#include <stdlib.h>

int main()
{
system("xprop -root | grep '_NET_ACTIVE_WINDOW(WINDOW)' | awk '{print$5}' > out.txt");
return 0;
} 
