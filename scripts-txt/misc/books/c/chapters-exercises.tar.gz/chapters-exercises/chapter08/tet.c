/* tet.c --  */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
int main(void)
{
    char *str = "100";
    char str2[20];
    int x, count;

    //scanf("%s", str);

    for (x = 0, count = 0; x < strlen(str); x++)
    {
        if (isdigit(str[x]))
        {
            str2[x] = str[x];
            count++;
        }
        //else
            //break;
        //else
          //  printf("%d is not a digit\n", str[x]);
    }
    str2[count] = '\0';
    //while ()
    printf("str = %s, str2 = %s\n", str, str2);

    return EXIT_SUCCESS;
}