static const char screensaver_id[] = "@(#)xscreensaver 3.17 (15-Jul-99), by Jamie Zawinski (jwz@jwz.org)";
