## Useless Chrome App

Spread the word about your blog, attract your blog visitors with clickbait useless chrome app that does nothing, but redirects them to your blog page.

It's so awesome and useless in the same time.

## Resources

https://chrome.google.com/webstore/developer/update

https://developer.chrome.com/apps/manifest/key

https://stackoverflow.com/questions/23873623/obtaining-chrome-extension-id-for-development

https://support.google.com/chrome/a/answer/2714278?hl=en
