/* 9. Modify exercise 8 so that it uses a function to return the value of the calculation.
#include <stdio.h>
double some_func(double n1, double n2);
int main(void)
{

    double num1, num2, num3;

    printf("Please enter two floating-point numbers: ");
    while (scanf("%lf%lf", &num1, &num2) == 2)
    {
        num3 = some_func(num1, num2);
        printf("%0.5lf %0.5lf\n", num3 / num1, num3 / num2);
        printf("Please enter two floating-point numbers: ");
    } 
    printf("See you later.\n");
    
    return 0;
}
double some_func(double n1, double n2)
{
    double n3 = n1 - n2;
    
    return n3;
}
*/
#include <stdio.h>
double some_func(double n1, double n2);
int main(void)
{

    double num1, num2, num3;

    printf("Please enter two floating-point numbers: ");
    while (scanf("%lf%lf", &num1, &num2) == 2)
    {
        num3 = some_func(num1, num2);
        printf("(%.3g - %.3g)/(%.3g*%.3g) = %.5g\n", num1, num2,num1,num2, num3);
        printf("Please enter two floating-point numbers: ");
    } 
    printf("See you later.\n");
    
    return 0;
}
double some_func(double n1, double n2)
{
    double n3 = (n1 - n2) / (n1 * n2);
    
    return n3;
}
