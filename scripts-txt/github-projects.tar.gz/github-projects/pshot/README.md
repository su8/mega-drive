pshot
=====
<img src="data_pshot/pshot_preview.png" alt="" /><br/>
Screenshot Utility written in python

Capture Modes: Full Screen, Active Window ,Grab Region

Send Image To imgurl clicked:
<img src="data_pshot/upload.png" alt="" /><br/>

Send Image To - viewer or editor clicked, so far it supports up to 21 different image viewers and editors.
<img src="data_pshot/send_to.png" alt="" /><br/>

## Archlinux support
Archlinux users can install the program directly from AUR, without the need to download it from here.

    yaourt -S pshot-git

## Requirements


* scrot
* imagemagick
* python2
* python2-gobject
* webkitgtk
* pywebkitgtk