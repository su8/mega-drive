#/usr/bin/python2
import os
import shlex
import getpass
import subprocess
from gi.repository import Gtk


class inxi_gui:







    def __init__(self):
        intf = Gtk.Builder()
        intf.add_from_file('i_radeon.glade')
        intf.connect_signals(self)
        #entry = intf.get_object('entry1')
        #entry.connect("changed", self.on_entry1_activate)
        window = intf.get_object("window1")

        textview1 = intf.get_object("sensors_textview")
        textbuffer1 = textview1.get_buffer()
        sp = subprocess.Popen(shlex.split('sensors'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer1.set_text("{0}".format(out))

        window.connect("delete-event", Gtk.main_quit)
        window.show_all()

if __name__ == '__main__':
    inxi_gui()
    Gtk.main()