/* point1.c -- 

1. Devise a function called min(x,y) that returns the smaller of two double values. Test
the function with a simple driver.
 */
#include <stdio.h>
#include <stdlib.h>

double min(double x, double y);

int main(void)
{
    double a,b;

    printf("Gimme some float values: (q to quit) ");
    while (scanf("%lf %lf", &a, &b) == 2)
    {
        printf("The smallest of %0.0f and %0.0f is %0.0f\n",
            a, b, min(a, b));
        printf("Gimme moar floats: (q to quit) ");
    }

    return EXIT_SUCCESS;
}

double min(double x, double y)
{
    return x > y ? y : x;
}