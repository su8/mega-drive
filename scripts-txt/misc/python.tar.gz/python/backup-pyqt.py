#!/usr/bin/env python2
import os
import sys
from subprocess import call
from PyQt4 import QtGui, QtCore


class Backup(QtGui.QWidget):
    
    def __init__(self):
        super(Backup, self).__init__()
        self.initUI()
        
    def initUI(self):
        self.pub_key = '148A94F9AA92AE64'

        folder_btn = QtGui.QPushButton('Folder', self)
        #folder_btn.resize(folder_btn.sizeHint())
        folder_btn.move(5, 5)
        QtCore.QObject.connect(folder_btn, QtCore.SIGNAL('clicked()'), self.encrypt_folder_clicked)

        file_btn = QtGui.QPushButton('File', self)
        #file_btn.resize(file_btn.sizeHint())
        file_btn.move(110, 5)
        QtCore.QObject.connect(file_btn, QtCore.SIGNAL('clicked()'), self.encrypt_file_clicked)

        self.setGeometry(850, 500, 200, 40)
        self.setWindowTitle('Backup program')
        self.show()

    def encrypt_folder_clicked(self):
        obj = QtGui.QFileDialog.getExistingDirectory(None, '', os.getenv('HOME'))
        if obj:
            #obj = (obj if not obj.endswith(os.sep) else obj[:-1])
            call(
                'XZ_OPT=-9e tar cJf - -C "{dir}" . | \
                    gpg -z 9 --batch --yes --encrypt \
                    --hidden-recipient {pub_key_id} --output "{encrypted_file}"'
                        .format(dir=obj, pub_key_id=self.pub_key,
                            encrypted_file=obj + '.tar.xz.gpg'), shell=True)

    def encrypt_file_clicked(self):
        obj = QtGui.QFileDialog.getOpenFileName(None, '', os.getenv('HOME'))
        if obj:
        #if os.path.isfile(obj):
            call('gpg --hidden-recipient {pub_key_id} \
                    --encrypt "{obj_to_encrypt}"'
                        .format(
                            pub_key_id=self.pub_key, obj_to_encrypt=obj), shell=True)

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    ex = Backup()
    sys.exit(app.exec_())

# the original - cli based

# import os
# from sys import argv
# from subprocess import call

# class Backup(object):

#     def __init__(self, obj):
#         given_obj = (obj if not obj.endswith(os.sep) else obj[:-1])
#         pub_key = 'AA92AE64'  # type gpg --list-keys and replace this one

#         self.encrypt(given_obj, pub_key)

#     def encrypt(self, obj, key):
#         if os.path.isfile(obj):
#             call('gpg --recipient {pub_key_id} \
#                     --encrypt "{obj_to_encrypt}"'
#                         .format(
#                             pub_key_id=key, obj_to_encrypt=obj), shell=True)
#         else:
#             call(
#                 'XZ_OPT=-9e tar cJf - -C "{dir}" . | \
#                     gpg -z 9 --batch --yes --encrypt \
#                     --recipient {pub_key_id} --output "{encrypted_file}"'
#                         .format(dir=obj, pub_key_id=key,
#                             encrypted_file=obj + '.tar.xz.gpg'), shell=True)

# if __name__ == '__main__':
#     Backup(''.join(argv[1:]))