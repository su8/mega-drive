/* Enjoy it mate ! */

(function(){
    var options = {
        renderer: new marked.Renderer(),
        gfm: true,
        tables: true,
        breaks: false,
        pedantic: false,
        sanitize: true,
        smartLists: true,
        smartypants: false,
        //langPrefix: 'hljs ',
        highlight: function(code, lang) {
            return hljs.highlightAuto(code, [lang]).value;
        }
    };
    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    xhr.timeout = 4000;
    xhr.overrideMimeType("text/plain; charset=UTF-8");
    xhr.ontimeout = function() {
        console.error("Request timed out");
    };
    xhr.onerror = function() {
        console.log(xhr);
    };
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            convertMdToHtml(xhr.responseText);
        }
    };
    xhr.open("GET", "posts.md", true);
    xhr.send(null);

    var convertMdToHtml = function(content) {
        var container = document.querySelector('#inner-posts');
        var daDiv = document.createElement('div');
        daDiv.innerHTML = marked(content, options)
            .replace('<table>',
                    '<table class="table table-hover table-striped">');
        container.appendChild(daDiv);
    };
})();
