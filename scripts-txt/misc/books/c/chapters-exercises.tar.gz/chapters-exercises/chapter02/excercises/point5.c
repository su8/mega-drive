/* write a program that produces the following output:
Brazil, Russia, India, China
India, China,
Brazil, Russia */
#include <stdio.h>
int main(void)
{
    char bra[] = "Brazil", rus[] = "Russia";
    char ind[] = "India", chi[] = "China";

    printf("%s, %s, %s, %s\n", bra, rus, ind, chi);
    printf("%s, %s,\n%s, %s\n", ind, chi, bra, rus);

    return 0;
}
