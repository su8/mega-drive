[gawk](https://www.gnu.org/software/gawk/manual/gawk.pdf) extension containing functions to make array access easier, so you can write much shorter and nested code.

It is written to be used in the GNU version of [awk](https://www.gnu.org/software/gawk/manual/gawk.html#POSIX\_002fGNU)

Listing all of the functions in no particular order.

* [arrjoin(" ", "keys", arr)](#arrjoin)
* [arrfirst("key", arr)](#arrfirst)
* [arrlast("key", arr)](#arrlast)

---

## arrjoin

arrjoin is advanced version of https://www.gnu.org/software/gawk/manual/html\_node/Join-Function.html

**arrjoin** takes 4 arguments of which 3 are mandatory.

arg1 mandatory is separator to be used.

arg2 mandatory is string to request the joining of **keys**/**values**/**kv**, kv stands for both.

arg3 mandatory is the array itself.

arg4 non mandatory is string used as pattern for excluding keys and values.

You can even use it to merge multiple arrays into singular one.

```
@load "arraysfuncs";
{
  x["hello"]++;
  x["world"]++;

  // hello world
  printf("%s\n", arrjoin(" ", "keys", x));

  // 1 1
  printf("%s\n", arrjoin(" ", "values", x));

  // all keys and values
  printf("%s\n", arrjoin(" ","kv", x));

  // exclude all "foo" keys/values when found
  printf("%s\n", arrjoin(" ", "kv", x, "foo"));

  // python's equivalent of
  // dict to list conversion
  split(arrjoin(" ", "kv", x), arr2, " ");

  // now we can access arr2 in numeric way
  printf("%s\n",arr2[3]);

  // merging multiple arrays into one larger
  // named intoVar
  a1 = arrjoin(" ", "keys", a);
  b1 = arrjoin(" ", "values", b);
  intoVar = a1" "b1;
  printf("%s\n", intoVar);
}
```

Arrays in gawk are associative, which makes them harder to be indexed in numeric way, since the left and right operand (key/value) can be of string and/or numeric type. The "dict to list" conversion is really handy when you don't know what the keys/values in given array are, and you would like to index the array in numeric way.

```python
# python
a=["hello","world"]  # list
b=("hello", "world") # tuple
c={"hello":"world","123":456} # dict

# KeyError
print("{0}".format(c["nonExisting"]))

# dict converted into a sorted list of tuples
# [('123', 456), ('hello', 'world')]
d=[(x,z) for x,z in c.items()]

# ('hello', 'world') 456
print("{0} {1}".format(d[1],  d[0][1]))
```

---

## arrfirst

arrfirst("key", x) will return the first **key**/**value**/**kv** in the array x.

**arrfirst** takes 2 arguments, first one must be string in the form of **keys**/**values**/**kv**, kv stands for both, second one is the array.

```
@load "arraysfuncs";
{
  x[0]="hello";
  x[1]="world";
  x[2]="hi";

  // "hello"
  printf("%s\n", arrfirst("value", x));
}
```

---

## arrlast

arrlast("key", x) will return the last **key**/**value**/**kv** in the array x.

**arrlast** takes 2 arguments, first one must be string in the form of **key**/**value**/**kv**, kv stands for both, second one is the array.

```
@load "arraysfuncs";
{
  x[0]="hello";
  x[1]="world";
  x[2]="hi";

  // "hi"
  printf("%s\n", arrlast("value", x));
}
```

---

## Installation

```bash
export AWKLIBPATH=$AWKLIBPATH:/tmp/lib/gawk
autoreconf -if
./configure --prefix=/tmp
make
make install

# one liner
 ... gawk -larrayfuncs '{x["hello"]++;x["world"]++;x["1"]="hi";x["2"]="again";printf("%s\n" ,arrjoin(" ","keys",x));}'
```
