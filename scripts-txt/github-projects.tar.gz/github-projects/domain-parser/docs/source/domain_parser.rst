domain_parser package
=====================

Submodules
----------

domain_parser.domain_parser module
----------------------------------

.. automodule:: domain_parser.domain_parser
    :members: get_tlds, parse_domain 
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: domain_parser
    :members:
    :undoc-members:
    :show-inheritance:
