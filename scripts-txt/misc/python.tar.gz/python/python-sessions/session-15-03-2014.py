Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> # 12.1 Starting and Stopping Threads
>>> import time
>>> def countdown(n):
	while n > 0:
		print('T-minus', n)
		n -= 1
		time.sleep(5)

		
>>> # create and launch a thread
>>> from theading import Thread
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    from theading import Thread
ImportError: No module named 'theading'
>>> from threading import Thread
>>> t = Thread(target=countdown, args=(10,))
>>> t.start()
T-minus
>>>  10
T-minus 9
T-minus 8
T-minus 7
T-minus 6
T-minus 5
T-minus 4
T-minus 3
T-minus 2
T-minus 1
KeyboardInterrupt
>>> if t.is_alive():
	print('Still running')
else:
	print('Completed!')

	
Completed!
>>> # if you want to be able to terminate threads, the thread must be programmed to poll for exit at selected points:
>>> class CountdownTask:
	def __init__(self):
		self._running = True
	def terminate(self):
		self._running = False
	def run(self, n)
	
SyntaxError: invalid syntax
>>> class CountdownTask:
	def __init__(self):
		self._running = True
	def terminate(self):
		self._running = False
	def run(self, n):
		while self._running and n > 0:
			print('T-minus', n)
			n -= 1
			time.sleep(2)
		break
	
SyntaxError: 'break' outside loop
>>> class CountdownTask:
	def __init__(self):
		self._running = True
	def terminate(self):
		self._running = False
	def run(self, n):
		while self._running and n > 0:
			print('T-minus', n)
			n -= 1
			time.sleep(2)
		finally:
			
SyntaxError: invalid syntax
>>> class CountdownTask:
	def __init__(self):
		self._running = True
	def terminate(self):
		self._running = False
	def run(self, n):
		while self._running and n > 0:
			print('T-minus', n)
			n -= 1
			time.sleep(2)
			finally:
				
SyntaxError: invalid syntax
>>> class CountdownTask:
	def __init__(self):
		self._running = True
	def terminate(self):
		self._running = False
	def run(self, n):
		while self._running and n > 0:
			print('T-minus', n)
			n -= 1
			time.sleep(2)
		else:
			break
		
SyntaxError: 'break' outside loop
>>> class CountdownTask:
	def __init__(self):
		self._running = True
	def terminate(self):
		self._running = False
	def run(self, n):
		while self._running and n > 0:
			print('T-minus', n)
			n -= 1
			time.sleep(2)

			
>>> c = CountdownTask()
>>> t = Thread(target=c.run, args(10,))
SyntaxError: non-keyword arg after keyword arg
>>> t = Thread(target=c.run, args=(10,))
>>> t.start()
T-minus
>>>  10
T-minus 9
T-minus 8
T-minus 7
T-minus 6
T-minus 5
T-minus 4
T-minus 3
T-minus 2
T-minus 1
c.terminate()
>>> while False:
	print('hi')

	
>>> '''
class IOTask:
	def terminate(self):
		self._running = False
	def run(self, sock):
		# sock is a socket
		sock.settimeout(5)
		while self._running:
			# perform a blocking I/O operating w/ timeout
			try:
				data = sock.recv(8192)
				break
			except socket.timeout:
				continue
			# continue processing
			...
		# Terminated
		return
'''
'\nclass IOTask:\n\tdef terminate(self):\n\t\tself._running = False\n\tdef run(self, sock):\n\t\t# sock is a socket\n\t\tsock.settimeout(5)\n\t\twhile self._running:\n\t\t\t# perform a blocking I/O operating w/ timeout\n\t\t\ttry:\n\t\t\t\tdata = sock.recv(8192)\n\t\t\t\tbreak\n\t\t\texcept socket.timeout:\n\t\t\t\tcontinue\n\t\t\t# continue processing\n\t\t\t...\n\t\t# Terminated\n\t\treturn\n'
>>> from threading import Thread
>>> class CountdownThread(Thread):
	def __init__(self, n):
		super().__init__()
		self.n = 0
	def run(self):
		while self.n > 0:
			print('T-minus', n)
			n -= 1
			time.sleep(2)

			
>>> c = CountdownThread(5)
>>> c.start()
>>> 
>>> 
>>> from time import sleep
>>> class CountdownThread(Thread):
	def __init__(self, n):
		super().__init__()
		self.n = 0
	def run(self):
		while self.n > 0:
			print('T-minus', n)
			n -= 1
			sleep(2)

			
>>> c = CountdownThread(5)
>>> c.start()
>>> class CountdownThread(Thread):
	def __init__(self, n):
		super().__init__()
		self.n = 0
	def run(self):
		while self.n > 0:
			print('T-minus', self.n)
			self.n -= 1
			sleep(2)

			
>>> c = CountdownThread(5)
>>> c.start()
>>> 
>>> import multiprocessing
>>> c = CountdownTask(5)
Traceback (most recent call last):
  File "<pyshell#88>", line 1, in <module>
    c = CountdownTask(5)
TypeError: __init__() takes 1 positional argument but 2 were given
>>> 
