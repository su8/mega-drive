int machine_is_dell(void);
int dell_get_fan_status(void);
int dell_get_temperature(void);
