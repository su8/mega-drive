<?php

namespace rootio\Bundle\vmailmeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class rootiovmailmeBundle extends Bundle
{
}
