/* Determine which expressions are true and which are false .
a. 100 > 3 && 'a'>'c' -- false
b. 100 > 3 || 'a'>'c' -- true if 100 is bigger than 3, false otherwise
c. !(100>3)           -- false    */