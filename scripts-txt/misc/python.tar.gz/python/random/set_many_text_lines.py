        try:
          f = open("tt.txt")
          while True:
            line = f.readline()
            if len(line) == 0:
              break
            self.textbuffer.insert(self.textbuffer.get_end_iter(),"{0}".format(line))
            #print(line, end="", flush=True)
            #sleep(0.05)
            sleep(0.07)
        except KeyboardInterrupt:
          print("Why did you pressed CTRL-C ?")
        finally:
          if f:
            f.close() 
