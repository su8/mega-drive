Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> from collections import OrderedDict
>>> class Typed:
	_expected_type = type(None)
	def __init__(self, name=None):
		self._name = name
	def __set__(self, instance, value):
		if not isinstance(value, self._expected_type):
			raise TypeError('Expected' + str(self._expected_type))
		instance.__dict__[self._name] = value

		
>>> class Integer(Typed):
	_expected_type = int

	
>>> class Float(Typed):
	expected_type = float

	
>>> class String(Typed):
	_expected_type = str

	
>>> class Float(Typed):
	_expected_type = float

	
>>> # metaclass that uses an ordereddict for class body
>>> class OrderedMeta(type):
	def __new__(cls, clsname, bases, clsdict):
		d = dict(clsdict):
			
SyntaxError: invalid syntax
>>> class OrderedMeta(type):
	def __new__(cls, clsname, bases, clsdict):
		d = dict(clsdict)
		order = []
		for name, value in clsdict.items():
			if isinstance(value, Typed):
				value._name = name
				order.append(name)
			d['_order'] = order
			return type.__new__(cls, clsname, bases, d)
	@classmethod
	def __prepare__(cls, clsname, bases):
		return OrderedDict()

	
>>> class Structure(metaclass=OrderedMeta):
	def as_csv(self):
		return ','.join(str(getattr(self, name)) for name in self._order)

	
>>> class Stock(Structure):
	name = String()
	shares = Integer()
	price = Float()
	def __init__(self, name, shares, price):
		self.name = name
		self.shares = shares
		self.price = price

		
>>> s = Stock('Goodyear', 100, 490.1)
>>> s.name
<__main__.String object at 0x7f91a0622e10>
>>> s.as_csv()
''
>>> class OrderedMeta(type):
	def __new__(cls, clsname, bases, clsdict):
		d = dict(clsdict)
		order = []
		for name, value in clsdict.items():
			if isinstance(value, Typed):
				value._name = name
				order.append(name)
		d['_order'] = order
		return type.__new__(cls, clsname, bases, d)
	@classmethod
	def __prepare__(cls, clsname, bases):
		return OrderedDict()

>>> class Structure(metaclass=OrderedMeta):
	def as_csv(self):
		return ','.join(str(getattr(self, name)) for name in self._order)

	
>>> class Stock(Structure):
	name = String()
	shares = Integer()
	price = Float()
	def __init__(self, name, shares, price):
		self.name = name
		self.shares = shares
		self.price = price

		
>>> s = Stock('Goodyear', 100, 490.1)
>>> s.name
'Goodyear'
>>> s.shares
100
>>> s.price
490.1
>>> s.as_csv()
'Goodyear,100,490.1'
>>> Stock('Goodyear', "d", 490.1)
Traceback (most recent call last):
  File "<pyshell#63>", line 1, in <module>
    Stock('Goodyear', "d", 490.1)
  File "<pyshell#57>", line 7, in __init__
    self.shares = shares
  File "<pyshell#9>", line 7, in __set__
    raise TypeError('Expected' + str(self._expected_type))
TypeError: Expected<class 'int'>
>>> 
