int checkinterface(void);
int get_stat(void);
#ifdef __linux__
#define BUFSIZE 256
#endif
