#cd /home/frost/Desktop/New\ Folder/blogfy-new/generated/
#cd /home/frost/Documents/blog-new2/generated/
cd /home/frost/Documents/random/github-projects/blogfy-new/generated/
rm -rf tags
rm -rf post
rm -rf page
rm -rf sitemap.xml
rm -rf atom.xml
rm -rf index.html
rm -rf archive.html
#rm -rf contact.html
clear