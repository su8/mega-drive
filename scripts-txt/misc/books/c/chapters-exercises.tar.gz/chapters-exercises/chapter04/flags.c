/* flags.c -- illustrates some formatting flags */
#include <stdio.h>
int main(void)
{
    int n1 = 31, n2 = 42, n3 = 6;
    printf("%x %X %#x\n", n1, n1, n1);
    printf("**%d**%  d**%  d**\n", n2, n2, -42);
    printf("**%d**%5.3d**%05d**%05.3d**\n", n3, n3, n3, n3);

    return 0;
}
