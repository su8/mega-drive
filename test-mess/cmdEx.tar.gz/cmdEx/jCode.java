public class jCode {
     public static void invoke() {
          System.out.println("Hello World!");
     }
}
