/* 6. Use nested loops to write a program that produces this pattern:
$$$$$$$$
$$$$$$$$
$$$$$$$$
$$$$$$$$
*/
#include <stdio.h>
#define ROWS 4
#define CHARS 8
int main(void)
{
    const char dolla = '$';
    int row;
    char ch;
    
    for (row = 0; row < ROWS; row++)
    {
        for (ch = 0; ch < CHARS; ch++)
        {
            printf("%c", dolla);
        }
        printf("\n");
    }

    printf("%c", ch);

    return 0;
}
