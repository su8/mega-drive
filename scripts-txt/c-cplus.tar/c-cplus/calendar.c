/* compile with:
gcc -Wall -O2 -o main 2.c `pkg-config --cflags --libs gtk+-3.0` 
*/
#include <gtk/gtk.h>

GtkWidget *window, *box, *calendar;
int main (int argc, char *argv[])
{

    gtk_init(&argc, &argv);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Calendar");

    box = gtk_vbox_new(FALSE, 0);
    gtk_container_add(GTK_CONTAINER(window), box);

    calendar = gtk_calendar_new();
    gtk_box_pack_start(GTK_BOX(box), calendar, TRUE, TRUE, 0);

    g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}
