python_idle_themes
==================
<img src="idle-ninja-theme2.png" alt="" />
6 themes for the python's IDLE. The ninja-ide theme was created by me, the rest are from other people.