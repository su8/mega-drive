/* point6.c -- 

Write a program that reads input up to # and reports the number of times that the
sequence ei occurs.

Note: The program will have to "remember" the preceding character as well as the current character.
Test it with input such as “Receive your eieio award.”


 */
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    char ch, prev;
    unsigned short int ei_vols;

    while ((ch = getchar()) != '#')
    {
        switch(ch)
        {
            case 'i':
                    if (prev == 'e')
                    {
                        ei_vols++;
                        continue;
                    }

        }
        prev = ch;
    }
    printf("Occurence of sequence 'ei' = %d",
        ei_vols);

    return EXIT_SUCCESS;
}