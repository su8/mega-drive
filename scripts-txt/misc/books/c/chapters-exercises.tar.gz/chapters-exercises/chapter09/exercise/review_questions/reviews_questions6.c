/*

6. Devise a function called alter() that takes two int variables, x and y , and changes their
values to their sum and their difference, respectively.

*/
#include <stdio.h>
#include <stdlib.h>

void alter(int *x, int *y);

int main(void)
{
    int o = 6;
    int p = 1;

    printf("Before o = %d, p = %d\n", o, p);
    alter(&o, &p);
    printf("After o = %d, p = %d\n", o, p);

    return EXIT_SUCCESS;
}

void alter(int *x, int *y)
{
    *x = *x - *y;
    *y = *x + *y;
}