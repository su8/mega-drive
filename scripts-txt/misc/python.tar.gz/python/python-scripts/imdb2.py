#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import re
import sys
import subprocess
from urllib.request import urlopen

class IMDB(object):

    def generate_imdb_info(self):
        imdb_txt = self.txt_dir + 'imdb.txt'

        with open(imdb_txt, 'wt') as f:
            f.write(str())

        lizt_1 = urlopen(self.imdb).read().decode('utf-8').split("\n")

        def check(check_str, s):
            return check_str in s
        def append_text(*given_str):
            with open(imdb_txt, 'a') as f:
                f.write('{}\n'.format((''.join(given_str))))

        casts = str()
        country = str()
        director = str()
        for x in lizt_1:
            if check('class="header"', x):
                append_text(self.strip_html(x).lstrip())
                year = ' '.join(self.strip_html(
                    lizt_1[lizt_1.index(x) + 1]).replace('(', '')\
                    .replace(')', '').split())
                append_text('Year: ', year)
            if check('/country/', x):
                country += x
            if check('<h4 class="inline">Runtime:</h4>', x):
                append_text('Runtime: ', ' '.join(self.strip_html(
                    lizt_1[lizt_1.index(x) + 1]).split()))
            if check('tt_ov_dr', x) and \
            check('<span class="itemprop" itemprop="name">', x):
                director += x
            if check('tt_ov_st', x) and \
            check('<span class="itemprop" itemprop="name">', x):
                casts += self.strip_html(x).replace('|', '')
            if check('<strong><span itemprop="ratingValue">', x):
                append_text('Ratings: ', ' '.join(self.strip_html(x).split()))
            m = re.search('<p itemprop="description">', x, re.M|re.I)
            if m:
                ba = lizt_1[lizt_1.index(m.group())+1]
                append_text('Plot: ', self.strip_html(ba)\
                    .replace('See full summary&nbsp;&raquo;', ''))

        if casts:
            append_text('Casts: ', casts)
        if country:
            append_text('Country: ', ', '.join(self.strip_html(country)\
                .split()))
        if director:
            print(self.strip_html(director))
            append_text('Director: ', (' '.join\
                (self.strip_html(director).split())))

    def strip_html(self, val):
        return re.sub('<[^>]*>', '', val)

    def generate_mediainfo(self):
        os.chdir(self.just_the_path)
        subprocess.call('mediainfo "{}" > nfo/mediainfo.txt'.format(self.video)
            ,shell=True)
        self.generate_imdb_info()


    def generate_snapshots(self):
        for root,dirs,files in os.walk('/home/'):
            for name in files:
                if name == self.video:
                    self.real_path = os.path.realpath(os.path.join(root, name))
                    self.just_the_path = os.path.split(self.real_path)[0]
                    self.pic_dir = '{}/Pictures/'.format(self.just_the_path)
                    self.txt_dir = '{}/nfo/'.format(self.just_the_path)

        if self.pic_dir and self.real_path:
            self.make_dirs()
            os.chdir(self.just_the_path)
            subprocess.check_output('cvlc -vvv -I dummy --start-time=20 \
                --stop-time=27 --video-filter=scene --vout=dummy --no-audio \
               --scene-format=png --scene-prefix=snap --scene-path=Pictures/ \
                "{0}" vlc://quit'.format( 
                   os.path.split(self.real_path)[1]), shell=True)

    def make_dirs(self):
        for x in [self.pic_dir, self.txt_dir]:
            if not os.path.exists(x):
                os.mkdir(x)
        self.generate_mediainfo()

    def __init__(self, video_file, imdb_link):
        self.video = video_file
        self.imdb = imdb_link

        self.real_path = str()
        self.just_the_path = str()
        self.pic_dir = str()
        self.txt_dir = str()

        self.generate_snapshots()

if __name__ == '__main__':
    IMDB(str(sys.argv[1]), str(sys.argv[2]))