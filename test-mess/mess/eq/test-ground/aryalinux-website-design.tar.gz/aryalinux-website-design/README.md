# aryalinux-website-design

See the **showcase** folder for quick website preview in pictures.

See the **dev** folder and **js/config.js** file.

Design & coding by wifiextender.

Based on [geminiblog](https://github.com/arpanpal010/geminiblog)
