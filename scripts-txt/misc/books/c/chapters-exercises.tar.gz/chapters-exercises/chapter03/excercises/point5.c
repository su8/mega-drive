/* There are aproximately 3.156 x 10 to the 7th power
seconds in a year. Write a program that requests
your age in years and the displays the equivalent
number of seconds. */
#include <stdio.h>
int main(void)
{
    int age;
    float seconds = 3.156e7;  // same as 31560000

    printf("How old are you ? ");
    scanf("%d", &age);

    printf("%d years are equivalent to %.0f seconds.\n",
           age, age * seconds);

    return 0;
}
