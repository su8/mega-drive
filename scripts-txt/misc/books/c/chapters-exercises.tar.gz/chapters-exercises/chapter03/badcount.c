/* badcound.c -- incorrect argument counts */
#include <stdio.h>
int main(void)
{
    int n = 4, m = 5;
    float f = 7.0f, g = 8.0f;

    printf("%d\n", n, m); /* too many arguments */
    printf("%d %d %d\n", n); /* too few arguments */
    printf("%d %d\n", f, g); /* wrong format specifiers */

    return 0;
}
