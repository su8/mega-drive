/* 4. Represent each of the following test conditions:
a. scanf() succeeds in reading a single integer.
b. x is not 5 .
c. x is 20 or greater.
*/
#include <stdio.h>
int main(void)
{
    int x;
    printf("Enter some number: ");
    scanf("%d", &x);
    
    while (x != 5)
    {
        x -= 1;
    }
    
    x = 30;
    
    printf("x has the value of %d", x);
    
    return 0;
}
