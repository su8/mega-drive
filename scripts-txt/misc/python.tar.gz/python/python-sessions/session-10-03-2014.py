Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> import requests
>>> # 11.2 creating TCP Server
>>> from socketserver import BaseRequestHandler, TCPServer
>>> class EchoHandler(BaseRequestHandler):
	def handle(self):
		print("Got connection from", self.client_address)
		while True:
			msg = self.request.recv(8192)
			if not msg:
				break
			self.request.send(msg)
if __name__ == '__main__':
	
SyntaxError: invalid syntax
>>> class EchoHandler(BaseRequestHandler):
	def handle(self):
		print("Got connection from", self.client_address)
		while True:
			msg = self.request.recv(8192)
			if not msg:
				break
			self.request.send(msg)
	if __name__ == '__main__':
		serv = TCPServer(('', 20000), EchoHandler)
		serv.serve_forever()

		
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    class EchoHandler(BaseRequestHandler):
  File "<pyshell#15>", line 10, in EchoHandler
    serv = TCPServer(('', 20000), EchoHandler)
NameError: name 'EchoHandler' is not defined
>>> class EchoHandler(BaseRequestHandler):
	def handle(self):
		print("Got connection from", self.client_address)
		while True:
			msg = self.request.recv(8192)
			if not msg:
				break
			self.request.send(msg)

			
>>> if __name__ == '__main__':
	serv = TCPServer(('', 20000), EchoHandler)
	serv.serve_forever()

	
Got connection from ----------------------------------------
Exception happened during processing of request from ('127.0.0.1', 54488)
Traceback (most recent call last):
  File "/usr/lib/python3.3/socketserver.py", line 306, in _handle_request_noblock
    self.process_request(request, client_address)
  File "/usr/lib/python3.3/socketserver.py", line 332, in process_request
    self.finish_request(request, client_address)
  File "/usr/lib/python3.3/socketserver.py", line 345, in finish_request
    self.RequestHandlerClass(request, client_address, self)
  File "/usr/lib/python3.3/socketserver.py", line 666, in __init__
    self.handle()
  File "<pyshell#17>", line 5, in handle
KeyboardInterrupt
----------------------------------------
Traceback (most recent call last):
  File "<pyshell#19>", line 3, in <module>
    serv.serve_forever()
  File "/usr/lib/python3.3/socketserver.py", line 237, in serve_forever
    poll_interval)
  File "/usr/lib/python3.3/socketserver.py", line 155, in _eintr_retry
    return func(*args)
KeyboardInterrupt
>>> 
KeyboardInterrupt
>>> 
KeyboardInterrupt
>>> ''' testing the connection from other opened idle
>>> from socket import socket, AF_INET, SOCK_STREAM
>>> s = socket(AF_INET, SOCK_STREAM)
>>> s.connect(('localhost', 20000))
>>> s.send(b'Hello')
5
>>> s.recv(8192)
b'Hello'
>>> s.send(b'Hello')
5
>>> '''
" testing the connection from other opened idle\n>>> from socket import socket, AF_INET, SOCK_STREAM\n>>> s = socket(AF_INET, SOCK_STREAM)\n>>> s.connect(('localhost', 20000))\n>>> s.send(b'Hello')\n5\n>>> s.recv(8192)\nb'Hello'\n>>> s.send(b'Hello')\n5\n>>> "
>>> import socket
>>> class EchoHandler(StreamRequestHandler):
	timeout = 5 # timeout on all socket operations
	rbufsize = -1 # read buffer size
	wbufsize = 0 # write buffer size
	disable_nagle_algorith = False # sets tcp_nodelay socket option
	def handle(self):
		print('Got connection from', self.client_address)
		try:
			for line in self.rfile:
				# self.wfile is a file-like object for writing
				self.wfile.write(line)
		except socket.timeout:
			print('Timed out!')

			
Traceback (most recent call last):
  File "<pyshell#36>", line 1, in <module>
    class EchoHandler(StreamRequestHandler):
NameError: name 'StreamRequestHandler' is not defined
>>> from socket import socket, AF_INET, SOCK_STREAM
>>> def echo_handler(address, client_sock):
	print("Got connection from {}".format(address))
	while True:
		msg = client_sock.recv(8192)
		if not msg:
			break
		client_sock.sendall(msg)
	client_sock.close()

>>> def echo_server(address, backlog=5):
	sock = socket(AF_INET, SOCK_STREAM)
	sock.bind(address)
	sock.listen(backlog)
	while True:
		client_sock, client_addr = sock.accept()
		echo_handler(client_addr, client_sock)

		
>>> # if __name__ == '__main__':
>>> #	echo_server(('', 20000))
>>> 
>>> 
