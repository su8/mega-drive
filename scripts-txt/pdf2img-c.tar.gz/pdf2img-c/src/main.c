/*
   main.c
 
   Copyright 12/17/2014 Aaron Caffrey https://github.com/wifiextender
 
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
   MA 02110-1301, USA.
*/

#include <stdlib.h>     /* EXIT_SUCCESS    */
#include <gtk/gtk.h>
#include <locale.h>     /* setlocale()     */
#include "gettext.h"    /* _(), textdomain */
#include "my_constants.h"
#include "my_functions.h"


/* gtk related classes */
GtkWidget *window, *grid, *spinbutton1, *spinbutton2, *about_label;
GtkWidget *entry_label, *entry, *about_button, *button1, *alias_combo;
GtkWidget *from_label, *to_label, *button1_lbl, *trans_switch, *expand1;
GtkWidget *image_label, *sdevice_lbl, *image_combo, *sdev_combo, *expand2;


int main(int argc, char *argv[])
{

    /* Localization */
    setlocale(LC_ALL, "");
    textdomain(GETTEXT_PACKAGE);
    bindtextdomain(GETTEXT_PACKAGE, LOCALEDIR);
    bind_textdomain_codeset(GETTEXT_PACKAGE, "UTF-8");

    gtk_init(&argc, &argv);

    window       = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), _(PROGRAM_TITLE));
    gtk_container_set_border_width(GTK_CONTAINER(window), 6);
    gtk_window_set_default_size(GTK_WINDOW(window), 200, 20);
    gtk_window_set_default_icon_from_file(PROGRAM_ICON, NULL);

    if (DECORATE_VIA_CUSTOM_CSS)  /* --enable-custom-css */
    {
        GtkCssProvider *provider = gtk_css_provider_new();
        gtk_css_provider_load_from_data(provider, APP_CSS, -1, NULL);
        /* GtkStyleContext *context = gtk_widget_get_style_context(window); */
        GdkScreen *screen = gtk_widget_get_screen(GTK_WIDGET(window));
        gtk_style_context_add_provider_for_screen(screen,
                                                  GTK_STYLE_PROVIDER(provider),
                                                  GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    }

    grid         = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 7);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_container_set_border_width(GTK_CONTAINER(grid), 2);
    gtk_container_add(GTK_CONTAINER(window), grid);

    entry_label  = gtk_label_new(_(RESOLUTION_LBL));
    gtk_grid_attach(GTK_GRID(grid), entry_label, POSITION_LEFT, 1, 1, 1);

    entry        = gtk_entry_new();
    gtk_entry_set_width_chars(GTK_ENTRY(entry), 1);
    gtk_entry_set_text(GTK_ENTRY(entry), RESOLUTION_NUM);
    gtk_entry_set_max_length(GTK_ENTRY(entry), 4);
    gtk_grid_attach(GTK_GRID(grid), entry, POSITION_LEFT, 2, 1, 1);

    if (SHOW_IMAGES_ON_BUTTONS)  /* --enable-button-images */
    {
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(entry), GTK_ENTRY_ICON_SECONDARY, "video-display");
        about_label  = gtk_label_new(_(ABOUT_LBL)); 
        gtk_grid_attach(GTK_GRID(grid), about_label, POSITION_RIGHT, 1, 1, 1);
        about_button = gtk_button_new_from_icon_name("starred", GTK_ICON_SIZE_BUTTON);
        button1      = gtk_button_new_from_icon_name("folder-documents", GTK_ICON_SIZE_BUTTON);
    }
    else
    {
        about_button = gtk_button_new_with_label(_(ABOUT_LBL));
        button1      = gtk_button_new_with_label(_(BUTTONE_LBL));
    }
    
    g_signal_connect(G_OBJECT(about_button), "clicked", G_CALLBACK(on_about_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), about_button, POSITION_RIGHT, 2, 1, 1);

    from_label   = gtk_label_new(_(FROM_LBL));
    gtk_grid_attach(GTK_GRID(grid), from_label, POSITION_LEFT, 4, 1, 1);

    spinbutton1  = gtk_spin_button_new_with_range(1, 9999, 1);
    gtk_grid_attach(GTK_GRID(grid), spinbutton1, POSITION_LEFT, 5, 1, 1);

    to_label     = gtk_label_new(_(TO_LBL));
    gtk_grid_attach(GTK_GRID(grid), to_label, POSITION_RIGHT, 4, 1, 1);

    spinbutton2  = gtk_spin_button_new_with_range(1, 9999, 1);
    gtk_grid_attach(GTK_GRID(grid), spinbutton2, POSITION_RIGHT, 5, 1, 1);

    image_label  = gtk_label_new(_(IMG_LBL));
    gtk_grid_attach(GTK_GRID(grid), image_label, POSITION_LEFT, 6, 1, 1);

    unsigned short int x;
    image_combo  = gtk_combo_box_text_new();
    static const char *img_formats[] = { PNG, JPG, BMP, TIFF };
    for (x = 0; x < 4; x++)
        gtk_combo_box_text_append(GTK_COMBO_BOX_TEXT(image_combo), img_formats[x], img_formats[x]);
    gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 0);
    g_signal_connect(G_OBJECT(image_combo), "changed", G_CALLBACK(on_image_combo), NULL);
    gtk_grid_attach(GTK_GRID(grid), image_combo, POSITION_LEFT, 7, 1, 1);

    sdevice_lbl  = gtk_label_new(_(SDEVICE_LBL));
    gtk_grid_attach(GTK_GRID(grid), sdevice_lbl, POSITION_RIGHT, 6, 1, 1);

    sdev_combo   = gtk_combo_box_text_new();
    static const char *sdevices[] = { PNG16M, PNGALPHA, PNGGRAY, JPEG, JPEGCMYK, JPEGGRAY,
                                      BMP16M, BMPGRAY, TIFF24NC, TIFFGRAY };
    for (x = 0; x < 10; x++)
        gtk_combo_box_text_append(GTK_COMBO_BOX_TEXT(sdev_combo), sdevices[x], sdevices[x]);
    gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 0);
    g_signal_connect(G_OBJECT(sdev_combo), "changed", G_CALLBACK(on_sdevice_combo), NULL);
    gtk_grid_attach(GTK_GRID(grid), sdev_combo, POSITION_RIGHT, 7, 1, 1);

    expand1      = gtk_expander_new(_(ANTI_ALIASING_LBL));
    gtk_grid_attach(GTK_GRID(grid), expand1, POSITION_LEFT, 8, 1, 1);

    alias_combo  = gtk_combo_box_text_new();
    static const char *alias_values[] = { "1", "2", "4" };
    for (x = 0; x < 3; x++)
        gtk_combo_box_text_append(GTK_COMBO_BOX_TEXT(alias_combo), alias_values[x], alias_values[x]);
    gtk_combo_box_set_active(GTK_COMBO_BOX(alias_combo), 2);
    gtk_container_add(GTK_CONTAINER(expand1), alias_combo);

    expand2      = gtk_expander_new(_(TRANSP_LBL));
    gtk_grid_attach(GTK_GRID(grid), expand2, POSITION_RIGHT, 8, 1, 1);

    trans_switch = gtk_switch_new();
    gtk_switch_set_active(GTK_SWITCH(trans_switch), TRUE);
    gtk_container_add(GTK_CONTAINER(expand2), trans_switch);

    button1_lbl  = gtk_label_new(_(SELECT_PDF_LBL));
    gtk_grid_attach(GTK_GRID(grid), button1_lbl, POSITION_LEFT, 9, POSITION_CENTER, 1);

    g_signal_connect(G_OBJECT(button1), "clicked", G_CALLBACK(on_button1_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), button1, POSITION_LEFT, 10, POSITION_CENTER, 1);

    g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(window);
    gtk_main();

    return EXIT_SUCCESS;
}