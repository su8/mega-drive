import os

# Full path to the file containing the data - Adjust to your needs.
addressbook = "phonebook.txt"

# Write and Search functions
def WriteEntry_():
    name = raw_input("        Enter name: ")
    phone = raw_input("        Enter phone number: ")
    f=open(addressbook, 'a')
    f.write(name + "    " + phone + '\n')
    f.close()
    print "\n"
    print "        Added: " + name + "   " + phone + " to the phone list.\n"


def SearchEntry_():
    os.system(['clear','cls'][os.name == 'nt'])
    print "-------------------------------------------\n"
    print "------ A Simple Python Phone Book v2 ------\n"
    print "-----------------------------------Crouse--\n\n"
    searchfor= raw_input("        Enter search term: ")
    print "\n"
    print "--------- RESULTS --------\n"
    searchforlower=searchfor.lower()
    try:
        f=open(addressbook, 'r')
        for line in f:
            if line.lower().startswith(searchforlower):
                print line.rstrip("\n")
        f.close()
    except:
        print "Sorry - There doesn't appear to be a database yet."
        print "Please create an entry first and then retry searching."
    print "--------------------------\n"

 # The Menu
while True:
        os.system(['clear','cls'][os.name == 'nt'])
        # Menu Displayed
        print "-------------------------------------------\n"
        print "------ A Simple Python Phone Book v2 ------\n"
        print "-----------------------------------Crouse--\n"
        selection = raw_input("\n\
        s) Search Phonebook\n\
        a) Add to Phonebook\n\
        q) Quit\n\n\
        What would you like to do?  ")
        print"\n"
        # Returned Answer acted upon.
        if selection == "s":
                SearchEntry_()
        elif selection == "a":
                WriteEntry_()
        elif selection == "e":
                break
        elif selection == "q":
                break
        else:
                print "        Not a valid Choice."
        raw_input("        Hit any key to continue") 
exit