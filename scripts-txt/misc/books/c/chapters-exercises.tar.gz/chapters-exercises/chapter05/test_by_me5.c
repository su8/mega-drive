#include <stdio.h>

int main(void)
{
    char a = 'a';
    
    while (a < 'h')
    {
        printf("%5c", a);
        a++;
    }
    
    printf("\n");
    
    return 0;
}
