#!/bin/bash
xfce4-terminal -H -x /home/frost/q.sh
exit

