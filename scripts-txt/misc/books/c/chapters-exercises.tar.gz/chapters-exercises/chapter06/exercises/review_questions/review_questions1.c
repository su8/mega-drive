/* Find the value of quack after each line; each of the final five statements uses the value of
quack produced by the preceding statement.
*/
#include <stdio.h>
int main(void)
{
    int quack = 2;

    quack += 5;
    quack *= 10;
    quack -= 6;
    quack /= 8;
    quack %= 3;
    printf("%d", quack);

    return 0;
}
