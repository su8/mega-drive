/* 13. Write a program that creates an eight-element array of int s and sets the elements to the
first eight powers of 2 and then prints the values. Use a for loop to set the values, and,
for variety, use a do while loop to display the values. */
#include <stdio.h>
#define SIZE 8
int main( void )
{
    int twopows[SIZE];
    int i;
    int value = 1;    /* 2 to the 0 */
    
    for (i = 0; i < SIZE; i++)
    {
        twopows[i] = value;
        value *= 2;
    }
    
    i = 0;
    do
    {
        printf("%d ", twopows[i]);
        i++;
    } while (i < SIZE);
    printf("\n");
                    
    return 0;
}
