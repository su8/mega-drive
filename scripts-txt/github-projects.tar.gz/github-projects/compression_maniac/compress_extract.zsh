#-----------------------------------------------------------
# Create meatballs with the highest possible compression.
# The first entry will be used as archive name.
# You can compress multiple directories and files
# that doesn't belong to the current directory.
# Example: 
# compresslz4 /var/log /usr/bin /usr/include $HOME/.xinitrc
# Mind that the archive will be created in the
# current working directory, so you need "write" permission.
#
#
# The best of all is that you can easily provide "compress" 
# and "extract" action options in your file manager, no-brainer!
# See https://github.com/wifiextender/dotfiles/blob/master/archlinux-openbsd/home/frost/.config/misc/my_thunar_plugin.zsh
# Right click 'n enjoy :}
#-----------------------------------------------------------

compresstar() { tar --verbose --dereference --create --file\
                 `basename $1`.tar "$@" }
compressxz()  { compresstar "$@"
                 xz --verbose -9 --extreme `basename $1.tar` }
compressgz()  { compresstar "$@" 
                 gzip --verbose -9 `basename $1.tar` }
compressbz()  { compresstar "$@" 
                 bzip2 --verbose -9 `basename $1.tar` }
compresslz()  { compresstar "$@"
                 xz --verbose -9 --extreme \
                    --format=lzma `basename $1.tar` }
compresslz4() { compresstar "$@" 
                 lz4 -v -9 `basename $1.tar`
                 rm `basename $1.tar` }
compresslzo() { compresstar "$@" 
                 lzop --verbose -9 `basename $1.tar`
                 rm `basename $1.tar` }
compress7z()  { 7za a -mx=9 `basename $1`.7z "$@" ;}
# zlib is required for ZIP_DEFLATED
# compresszip 'dir1 dir2 dir3 file file1 file2'
# The quotes are mandatory for multiple entries.
compresszip() { 
python2 -c"import os;from zipfile import ZipFile,ZIP_DEFLATED;
ufo_obj='"$1"'.split(' ');the_list=list();path_join=os.path.join;
norm='\033[0m';blue='\033[1;94m';green='\033[1;92m';magenta='\033[1;95m';
def zip_filez():
  with ZipFile(os.path.basename(ufo_obj[0])+'.zip','a',ZIP_DEFLATED) as archive:
    [archive.write(x) for x in the_list];info=archive.getinfo;
    for x in the_list:
      x=(x if not x.startswith(os.sep) else x.replace(os.sep,str(),1))
      busted=(info(x).file_size*info(x).compress_size);
      nuts=busted/int('1{0}'.format('0'*(len(str(busted))-2)));
      print(' {0}adding{1}: {2}{3} {1}(deflated {4}{5}%{1})'\
        .format(magenta,norm,blue,x,green,nuts))
for x in ufo_obj:
  if os.path.isdir(x):
    for root,_,files in os.walk(x):
      for z in files:
         the_list.append(path_join(root,z))
  else:  the_list.append(x)
zip_filez()"
}


######## END ########


#--------------------------------------------------
# Extract single/multiple archives
# Lazy people: extract *
#--------------------------------------------------
extract() {
  for xXx in "$@"; do
    if [[ -f $xXx ]] ; then
      pork_mince() {
                 # Now you can also extract archives that
                 # doesn't belong to the cwd, example:
                 # extract /home/user/somedir/archive.tar.gz /tmp/archive2.zip
                 if [[ "$(dirname $xXx)" == "." ]] ; then
                   dir_name="$(pwd)"
                 else
                   dir_name="$(dirname $xXx)"
                 fi
                 f_name="$(basename $xXx)"
                 # Protection while extracting
                 # the archive(s). Read the WHOLE
                 # `info tar' document to 
                 # get the protection point.
                 dday_one="$(mktemp --directory --tmpdir XXXXXXX)"
                 dday="$(mktemp --directory --tmpdir=$dday_one XXXXXXX)"
                      # mktemp automatically `u+rwx'
                      # dday="${dir_name}/.UntrusteD_DiR"
                      # chmod go-rwx "${dir_name}"
                      # mkdir --mode go-rwx "${dday}"
                 mv $xXx "${dday}" ; cd "${dday}"
                 case $1 in
                   bz2-orig)  bunzip2 --verbose "${f_name}"              ;;
                   gz-orig)   gunzip  --verbose "${f_name}"              ;;
                   xz-orig)   unxz    --verbose "${f_name}"              ;;
                   zip-orig)  python2 -c"from zipfile import ZipFile;
with ZipFile('"$f_name"', 'r') as archive:
  print('\n'.join(' \033[1;95mextracted\033[0m: \033[1;94m{0}\033[0m'.format(x.filename)\
    for x in archive.infolist()));archive.extractall()"                  ;;
                   seven_zip) 7z x "${f_name}"                           ;;
                   rar-orig)  unrar x "${f_name}"                        ;;
                   lzop-orig) lzop --verbose --extract "${f_name}"       ;;
                   tar-orig|lz4-orig)  
                              if [[ "$1" == "lz4-orig"  ]] ; then
                               lz4 -v -d "${f_name}"
                               f_name="${f_name%%.lz4}"
                              fi
                              if [[ "${f_name}" == *.tar ]] ; then
                               tar --skip-old-files --no-overwrite-dir \
                                   --verbose --extract --file "${f_name}"
                              fi                                         ;;
                   # filter the archive through program $1(--xxx)
                   *) tar --skip-old-files --no-overwrite-dir\
                          --verbose --extract $1 --file "${f_name}"      ;;
                 esac
                 # The more scenarios I can think of, `mv'
                 # becomes true troublemaker. Let's leave
                 # python to deal most common issue (if any)
                 # The question here is NOT "couldn't you
                 # wrote this in zsh". Read everything again.
                 python2 -c"import os;from shutil import move,rmtree;
whos_here=os.listdir(os.getcwd());charge=os.path.join;
is_grenate=os.path.isfile;is_dynamite=os.path.isdir;defuse=os.remove;
for x in whos_here:
  say_what=charge('"$dir_name"',x);
  if is_grenate(say_what):  defuse(say_what);
  if is_dynamite(say_what): rmtree(say_what);
[move(x,'"$dir_name"') for x in whos_here]"
                 cd "${dir_name}"; rm -rf "${dday_one}"
               }
      # --bzip2, --gzip, --xz, --lzma, --lzop
      # are 'long' `tar' options standing for:
      # extract the archive and filter it
      # through program --xxx
      case $xXx in
         *.tar.bz2) pork_mince   --bzip2          ;;
         *.bz2)     pork_mince   bz2-orig         ;;
         *.t[zb]?*) pork_mince   --bzip2          ;;
         *.tar.gz)  pork_mince   --gzip           ;;
         *.gz)      pork_mince   gz-orig          ;;
         *.t[ag]z)  pork_mince   --gzip           ;;
         *.tz)      pork_mince   --gzip           ;;
         *.tar.xz)  pork_mince   --xz             ;;
         *.xz)      pork_mince   xz-orig          ;;
         *.txz)     pork_mince   --xz             ;;
         *.lzma)    pork_mince   --lzma           ;;
         *.tlz)     pork_mince   --lzma           ;;
         *.tar)     pork_mince   tar-orig         ;;
         *.rar)     pork_mince   rar-orig         ;;
         *.zip)     pork_mince   zip-orig         ;;
         *.lz4)     pork_mince   lz4-orig         ;;
         *.tar.lzo) pork_mince   --lzop           ;;
         *.lzo)     pork_mince   lzo-orig         ;;
         *.Z)       uncompress   $xXx             ;;
         *.7z)      pork_mince   seven_zip        ;;
         *.exe)     cabextract   $xXx             ;;
         *)                                       ;;
      esac
    fi
  done
}