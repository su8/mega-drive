/*
   my_functions.h
 
   Copyright 12/17/2014 Aaron Caffrey https://github.com/wifiextender
 
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
   MA 02110-1301, USA.
*/


/* protection against multiple inclusions */
#ifndef MY_FUNCTIONS_H_
#define MY_FUNCTIONS_H_


/* function prototypes */
void on_image_combo(void);
void on_sdevice_combo(void);
void on_about_clicked(void);
void on_button1_clicked(void);
void pdf_to_img(const char *filename);
void RaiseWarning(const char *str_to_warn1, const char *str_to_warn2);


#endif /* MY_FUNCTIONS_H_ */