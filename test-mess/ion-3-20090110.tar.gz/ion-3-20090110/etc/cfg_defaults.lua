--
-- Ion default settings
--

dopath("cfg_ioncore")
dopath("cfg_kludges")
dopath("cfg_layouts")

dopath("mod_query")
dopath("mod_menu")
dopath("mod_tiling")
dopath("mod_statusbar")
--dopath("mod_dock")
dopath("mod_sp")

-- Deprecated.
dopath("cfg_user", true)
