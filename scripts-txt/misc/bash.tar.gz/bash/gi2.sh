#!/bin/bash
cd /home/frost/blog/site
git add -A
git commit -am "blog"
git push origin gh-pages
exit

