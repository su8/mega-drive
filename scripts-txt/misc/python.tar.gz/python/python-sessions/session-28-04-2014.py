Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> '''
from zip_processor import ZipProcessor
from pygame import image
from pygame.transform import scale
import os
import sys

class ScaleZip(ZipProcessor):
    def process_files(self):
        #scale each image in directory to 640x480
        for filename in os.listdir(self.temp_directory):
            im = image.load(self._full_filename(filename))
            scaled = scale(im, (640, 480))
            image.save(scaled, self._full_filename(filename))

if __name__ == "__main__":
    ScaleZip(*sys.argv[1:4]).process.zip()'''
'\nfrom zip_processor import ZipProcessor\nfrom pygame import image\nfrom pygame.transform import scale\nimport os\nimport sys\n\nclass ScaleZip(ZipProcessor):\n    def process_files(self):\n        #scale each image in directory to 640x480\n        for filename in os.listdir(self.temp_directory):\n            im = image.load(self._full_filename(filename))\n            scaled = scale(im, (640, 480))\n            image.save(scaled, self._full_filename(filename))\n\nif __name__ == "__main__":\n    ScaleZip(*sys.argv[1:4]).process.zip()'
>>> # now lets try solving the same problem using a composition-based solution
>>> import os,shutil,zipfile
>>> class ZipProcessor(object):
	def __init__(self, zipname, processor):
		self.zipname = zipname
		self.temp_directory = "unzipped-{}".format(
			zipname[:-4])
		self.processor = processor
	def _full_filename(self, filename):
		return os.path.join(self.temp_directory, filename)
	def process_zip(self):
		self.unzip_files()
		self.processor.process(self)
		self.zip_files()
	def unzip_files(self):
		os.mkdir(self.temp_directory)
		zipp = zipfile.ZipFile(self.zipname)
		try:
			zipp.extractall(self.temp_directory)
		finally:
			zipp.close()
	def zip_files(self):
		filee = zipfile.ZipFile(self.zipname, 'w')
		for filename in os.listdir(self.temp_directory):
			filee.write(self._full_filename(filename), filename)
		shutil.rmtree(self.temp_directory)

		
>>> '''
from zip_processor import ZipProcessor
import sys
import os
class ZipReplace(object):
    def __init__(self, search_string,
    replace_string):
        self.search_string = search_string
        self.replace_string = replace_string
    def process(self, zipprocessor):
    # perform a search and replace on all files in the temporary directory
        for filename in os.listdir(zipprocessor.temp_directory):
            with open(zipprocessor._full_filename(filename)) as filee:
                contents = filee.read()
            contents = contents.replace(self.search_string, self.replace_string)
            with open(zipprocessor._full_filename(
            filename), "w") as filee:
                filee.write(contents)
if __name__ == "__main__":
    zipreplace = ZipReplace(*sys.argv[2:4])
    ZipProcessor(sys.argv[1], zipreplace).process_zip()'''
'\nfrom zip_processor import ZipProcessor\nimport sys\nimport os\nclass ZipReplace(object):\n    def __init__(self, search_string,\n    replace_string):\n        self.search_string = search_string\n        self.replace_string = replace_string\n    def process(self, zipprocessor):\n    # perform a search and replace on all files in the temporary directory\n        for filename in os.listdir(zipprocessor.temp_directory):\n            with open(zipprocessor._full_filename(filename)) as filee:\n                contents = filee.read()\n            contents = contents.replace(self.search_string, self.replace_string)\n            with open(zipprocessor._full_filename(\n            filename), "w") as filee:\n                filee.write(contents)\nif __name__ == "__main__":\n    zipreplace = ZipReplace(*sys.argv[2:4])\n    ZipProcessor(sys.argv[1], zipreplace).process_zip()'
>>> class Document(object):
	def __init__(self):
		self.characters = list()
		self.cursor = 0
		self.filename = str()
	def insert(self, character):
		self.characters.insert(self.cursor, character)
		self.cursor += 1
	def delete(self):
		del self.characters[self.cursor]
	def save(self):
		with open(self.filename, 'w') as f:
			f.write(''.join(self.characters))
	def forward(self):
		self.cursor += 1
	def back(self):
		self.cursor -= 1

		
>>> doc = Document()
>>> doc.filename = "test_document"
>>> doc.insert('h')
>>> doc.insert('e')
>>> doc.insert('l')
>>> doc.insert('l')
>>> doc.insert('o')
>>> doc.characters
['h', 'e', 'l', 'l', 'o']
>>> dock.back
Traceback (most recent call last):
  File "<pyshell#93>", line 1, in <module>
    dock.back
NameError: name 'dock' is not defined
>>> doc.back
<bound method Document.back of <__main__.Document object at 0x7fa5726f2c50>>
>>> doc.delete()
Traceback (most recent call last):
  File "<pyshell#95>", line 1, in <module>
    doc.delete()
  File "<pyshell#84>", line 10, in delete
    del self.characters[self.cursor]
IndexError: list assignment index out of range
>>> doc.back()
>>> doc.delete()
>>> doc.inser('p')
Traceback (most recent call last):
  File "<pyshell#98>", line 1, in <module>
    doc.inser('p')
AttributeError: 'Document' object has no attribute 'inser'
>>> doc.insert('p')
>>> ''.join(doc.characters)
'hellp'
>>> class Cursor(object):
	def __init__(self, document):
		self.document = document
		self.position = 0
	def forward(self):
		self.position += 1
	def back(self):
		self.position -= 1
	def home(self):
		while self.document.characters[self.position - 1] != '\n':
			self.position -= 1
			if self.position == 0:
				# got to beginning of file before newline
				break
	def end(self):
		while self.position < len(self.document.characters) and self.document.characters[self.position] != '\n':
			self.position += 1

			
>>> class Document(object):
	def __init__(self):
		self.characters = list()
		self.cursor = Cursor(self)
		self.filename = str()
	def insert(self, character):
		self.characters.insert(self.cursor.position, character)
	def delete(self):
		del self.characters[self.cursor.position]
	def save(self):
		with open(self.filename, 'w') as f:
			f.write(''.join(self.characters))

			
>>> d = Document()
>>> d.insert('h')
>>> d.insert('e')
>>> d.insert('l')
>>> d.insert('l')
>>> d.insert('o')
>>> d.insert('\n')
>>> d.insert('w')
>>> d.insert('o')
>>> d.insert('r')
>>> d.insert('l')
>>> d.insert('d')
>>> d.cursor.home()
>>> d.insert('*')
>>> ''.join(d.characters)
'dlrow\n*olleh'
>>> print(''.join(d.characters))
dlrow
*olleh
>>> class Document(object):
	def __init__(self):
		self.characters = list()
		self.cursor = Cursor(self)
		self.filename = str()
	def insert(self, character):
		self.characters.insert(self.cursor.position, character)
		self.cursor.forward()
	def delete(self):
		del self.characters[self.cursor.position]
	def save(self):
		with open(self.filename, 'w') as f:
			f.write(''.join(self.characters))

			
>>> d = Document()
>>> d.insert('h')
>>> d.insert('e')
>>> d.insert('l')
>>> d.insert('l')
>>> d.insert('o')
>>> d.insert('\n')
>>> d.insert('w')
>>> d.insert('o')
>>> d.insert('r')
>>> d.insert('l')
>>> d.insert('d')
>>> d.cursor.home()
>>> d.insert('*')
>>> print(''.join(d.characters))
hello
*world
>>> # we can add a property to the document class to give use the complete string
>>> #@property
>>> #def string(self):
>>> #    return ''.join(self.characters)
>>> class Character(object):
	def __init__(self, character,
		     bold=False, italic=False, underline=False):
		asser len(character) == 1
		
SyntaxError: invalid syntax
>>> class Character(object):
	def __init__(self, character,
		     bold=False, italic=False, underline=False):
		assert len(character) == 1
		self.character = character
		self.bold = bold
		self.italic = italic
		self.underline = underline
	def __str__(self):
		bold = "*" if self.bold else str()
		italic = "/" if self.italic else str()
		underline = "_" if self.underline else str()
		return bold + italic + underline + self.character

	
>>> # in document class we add these two lines at the beginning of the insert method
>>> #def insert(self, character):
>>> #    if not hasattr(character, 'character'):
>>> #        character = Character(character)
>>> class Document(object):
	def __init__(self):
		self.characters = list()
		self.cursor = Cursor(self)
		self.filename = str()
	def insert(self, character):
		if not hasattr(character, 'character'):
			character = Character(character)
		self.characters.insert(self.cursor.position, character)
		self.cursor.forward()
	def delete(self):
		del self.characters[self.cursor.position]
	def save(self):
		with open(self.filename, 'w') as f:
			f.write(''.join(self.characters))

			
>>> class Document(object):
	def __init__(self):
		self.characters = list()
		self.cursor = Cursor(self)
		self.filename = str()
	def insert(self, character):
		if not hasattr(character, 'character'):
			character = Character(character)
		self.characters.insert(self.cursor.position, character)
		self.cursor.forward()
	def delete(self):
		del self.characters[self.cursor.position]
	def save(self):
		with open(self.filename, 'w') as f:
			f.write(''.join(self.characters))
	@property
	def string(self):
		return ''.join((str(c) for c in self.characters))

	
>>> class Cursor(object):
	def __init__(self, document):
		self.document = document
		self.position = 0
	def forward(self):
		self.position += 1
	def back(self):
		self.position -= 1
	def home(self):
		while self.document.characters[self.position - 1].character != '\n':
			self.position -= 1
			if self.position == 0:
				# got to beginning of file before newline
				break
	def end(self):
		while self.position < len(self.document.characters) and self.document.characters[self.position].character != '\n':
			self.position += 1

			
>>> d = Document()
>>> d.insert('h')
>>> d.insert('e')
>>> d.insert(Character('1', bold=True))
>>> d.insert(Character('1', bold=True))
>>> d.insert('o')
>>> d.insert('\n')
>>> d.insert(Character('w', italic=True))
>>> d.insert(Character('o', italic=True))
>>> d.insert(Character('r', underline=True))
>>> d.inesrt('l')
Traceback (most recent call last):
  File "<pyshell#197>", line 1, in <module>
    d.inesrt('l')
AttributeError: 'Document' object has no attribute 'inesrt'
>>> d.insert('l')
>>> d.insert('d')
>>> print(d.string)
he*1*1o
/w/o_rld
>>> d.cursor.home()
>>> d.delete()
>>> d.delete('W')
Traceback (most recent call last):
  File "<pyshell#203>", line 1, in <module>
    d.delete('W')
TypeError: delete() takes 1 positional argument but 2 were given
>>> d.insert('W')
>>> print(d.string)
he*1*1o
W/o_rld
>>> d.character[0].underline = True
Traceback (most recent call last):
  File "<pyshell#206>", line 1, in <module>
    d.character[0].underline = True
AttributeError: 'Document' object has no attribute 'character'
>>> d.characters[0].underline = True
>>> print(d.string)
_he*1*1o
W/o_rld
>>> 
