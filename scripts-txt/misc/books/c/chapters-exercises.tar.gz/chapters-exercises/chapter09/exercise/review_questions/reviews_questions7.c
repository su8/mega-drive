/* reviews_questions1.c --  */
/*

7. Is anything wrong with this function definition?
void salami(num)
{
    int num, count;
    for (count = 1; count <= num; num++)
        printf(" O salami mio!\n");
}

*/

/* missing formal argument to declare the formal parameter type
 In the function body we are shadowing the formal parameter variable that the function will receive.

 */