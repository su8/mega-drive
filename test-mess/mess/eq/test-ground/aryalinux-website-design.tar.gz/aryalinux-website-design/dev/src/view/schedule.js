var createScheduleTable = function(tableEntries) {
    return [
        "<div class='col-md-12'>",
            "<h3>Release Schedule</h3>",
            "<table class='table table-striped table-hover'>",
              "<thead>",
                "<tr class='success'>",
                  "<th>Status</th>",
                  "<th>Name</th>",
                  "<th>Codename</th>",
                  "<th>Arrives</th>",
                  "<th>Released</th>",
                "</tr>",
              "</thead>",
              "<tbody>",
                tableEntries,
              "</tbody>",
            "</table>",
        "</div>"
    ].join('');
};

geminiBlog.schedulePage = function() {
    scroll(0,0);
    document.title = "Release Schedule";
    var container = utils.clearElements($("#entries-wrapper"));
    var x = '', concatStr = '';

    for (x in geminiBlog.releaseSchedule) {
        concatStr += [
            "<tr class='active'>",
                "<td>" + geminiBlog.releaseSchedule[x][0] + "</td>",
                "<td>" + geminiBlog.releaseSchedule[x][1] + "</td>",
                "<td>" + geminiBlog.releaseSchedule[x][2] + "</td>",
                "<td>" + geminiBlog.releaseSchedule[x][3] + "</td>",
                "<td>" + geminiBlog.releaseSchedule[x][4] + "</td>",
            "</tr>"
        ].join('');
    }

    var schedulePageHTML = utils.str2WrappedDOMElement(
            createScheduleTable(concatStr));
    container.appendChild(schedulePageHTML.childNodes[0]);
};
