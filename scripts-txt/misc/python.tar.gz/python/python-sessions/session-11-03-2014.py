Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> # 11.5 creating a simple REST-Based Interface
>>> # resty.pu
>>> def notfound_404(environ, start_response):
	start_response('404 Not Found', [ ('Content-type', 'text/plain') ])
	return [b'Not Found']

>>> import cgi
>>> class PathDispatcher:
	def __init__(self):
		self.pathmap = dict()
	def __call__(self, environ, start_response):
		path = environ['PATH_INFO']
		params = cgi.FieldStorage(environ['wsgi.input'],
					  environ=environ)
		method = environ['REQUEST_METHOD'].lower()
		environ['params'] = { key: params.getvalue(key) for key in params }
		handler = self.pathmap.get((method, path), notfound_404)
		return handler(environ, start_response)
	def register(self, method, path, function):
		self.pathmap[method.lower(), path] = function
		return function

	
>>> # to use this dispatcher, you simply write different handlers, such as the following:
>>> 
