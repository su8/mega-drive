/* Write a program that requests your height in inches
and your name, and then displays the information
in the following form:
Dabney, you are 6.208 feet tall */
#include <stdio.h>
int main(void)
{
    float height;
    char name[20];
    float multiplier = 0.083333333333;

    printf("Enter your height in inches followed by your name:\n");
    scanf("%f %s", &height, name);

    printf("%s, you are %.3f feet tall.\n",
           name, height * multiplier);

    return 0;
}
