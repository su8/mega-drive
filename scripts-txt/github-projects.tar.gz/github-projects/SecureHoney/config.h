#ifndef CONFIG_H
#define CONFIG_H

#define LISTENADDRESS   "127.0.0.1"
#define DEFAULTPORT     1234
#define RSA_KEYFILE     "pubkey"
#define LOGFILE         "sshpot_auth.log"
#define DEBUG           1

#endif
