
---

Thank you all for your support!

Its been quiet a while and LFS and BLFS have both moved ahead. There had been very few updates because most of the work that was happening kept me so involved that I was finding little time to make updates. With this release, in fact a whole lot of new things, refinements and process streamlining is going to happen. But before I give a preview of the same, here's something that has happened of late:

* We got listed in distrowatch. Visit [distrowatch.com/arya] for more details. I know our distrowatch profile looks pretty deserted as of now, but things would surely improve with time.

* Of late I realized a lot of things, of course the hard way which could have been taken care of in the previous versions of AryaLinux but errors simply happened because, the whole Linux landscape is so dynamic and changes so fast that its diffiult to keep up. Things like being able to be boot on most machines(if not all), error free builds, correctness and validity of instructions in the articles etc could have been much better and improved. Well, the good part is, have solved a lot of such issues and you could see that in the next release which would be out within the next few weeks.

* Arya does not have a fixed release cycle which I think is not a good thing at all so, in order to take care of that soon would be putting a road map in the website and would strictly adhere to the same.

* I would also be sharing stuff that I am currently working on so that beta testing and bug fixes can be done swiflty and this would be done on a regular basis.

I guess that's that and, well, watch out for the next release! Have fun building!!

[distrowatch.com/arya]: http://distrowatch.com/arya 
