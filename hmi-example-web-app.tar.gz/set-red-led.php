<?php

// We'll run tshwctl --redledon or tshwctl --redledon, depending on
// URL parameters
$led = isset($_GET['led']) ? $_GET['led'] : null;

if (isset($led)) {

  if ($led === "on") {
    exec("tshwctl --redledon");
    $led_status = "On";
  }

  else if ($led === "off") {
    exec("tshwctl --redledoff");
    $led_status = "Off";
  }

  else {
    $led_status = "Error";
  }

  echo $led_status;
}
else 
  echo "Error";
