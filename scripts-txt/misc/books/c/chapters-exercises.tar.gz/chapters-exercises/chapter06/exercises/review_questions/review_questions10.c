/*10. Consider the following declaration:
double mint[10];
a. What is the array name?
b. How many elements does the array have?
c. What kind of value can be stored in each element?
d. Which of the following is a correct usage of scanf() with this array?
i. scanf("%lf", mint[2])
ii. scanf("%lf", &mint[2])
iii. scanf("%lf", &mint)*/


// a. mint
// b. 10
// c. double (float)
// d. scanf("%lf", &mint[2])
