Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> #the diamon problem
>>> class BaseClass:
	num_base_calls = 0
	def call_me(self):
		print('Calling method on Base Class')
		self.num_base_cals += 1

		
>>> class LeftSubclass(BaseClass):
	num_left_calls = 0
	def call_me(self):
		BaseClass.call_me(self)
		print('Calling method on Left Subclass')
		self.num_left_calls += 1

		
>>> class RightSubclass(BaseClass):
	num_right_calls = 0
	def call_me(self):
		BaseClass.call_me(self)
		print('Calling method on Right Subclass')
		self.num_right_calls += 1

		
>>> class Subclass(LeftSubclass, RightSubclass):
	num_sub_calls = 0
	def call_me(self):
		LeftSubclass.call_me(self)
		RightSubclass.call_me(self)
		print('Calling method on Subclass')
		self.num_sub_calls += 1

		
>>> s = Subclass()
>>> s.call_me()
Calling method on Base Class
Traceback (most recent call last):
  File "<pyshell#10>", line 1, in <module>
    s.call_me()
  File "<pyshell#8>", line 4, in call_me
    LeftSubclass.call_me(self)
  File "<pyshell#4>", line 4, in call_me
    BaseClass.call_me(self)
  File "<pyshell#2>", line 5, in call_me
    self.num_base_cals += 1
AttributeError: 'Subclass' object has no attribute 'num_base_cals'
>>> class BaseClass:
	num_base_calls = 0
	def call_me(self):
		print('Calling method on Base Class')
		self.num_base_calls += 1

		
>>> s = Subclass()
>>> s.call_me()
Calling method on Base Class
Calling method on Left Subclass
Calling method on Base Class
Calling method on Right Subclass
Calling method on Subclass
>>> print(s.num_sub_calls, s.num_left_calls, s.num_right_calls, s.num_base_calls)
1 1 1 2
>>> # code written with super
>>> class BaseClass:
	num_base_calls = 0
	def call_me(self):
		print('Calling method on Base Class')
		self.num_base_calls += 1

		
>>> class LeftSubclass(BaseClass):
	num_left_calls = 0
	def call_me(self):
		super().call_me(self)
		print('Calling method on Left Subclass')
		self.num_left_calls += 1

		
>>> class RightSubclass(BaseClass):
	num_right_calls = 0
	def call_me(self):
		super().call_me(self)
		print('Calling method on Right Subclass')
		self.num_right_calls += 1

		
>>> class Subclass(LeftSubclass, RightSubclass):
	num_sub_calls = 0
	def call_me(self):
		super().call_me(self)
		print('Calling method on Subclass')
		self.num_sub_calls += 1

		
>>> s = Subclass()
>>> s.call_me()
Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    s.call_me()
  File "<pyshell#24>", line 4, in call_me
    super().call_me(self)
TypeError: call_me() takes 1 positional argument but 2 were given
>>> class LeftSubclass(BaseClass):
	num_left_calls = 0
	def call_me(self):
		super().call_me()
		print('Calling method on Left Subclass')
		self.num_left_calls += 1

		
>>> class RightSubclass(BaseClass):
	num_right_calls = 0
	def call_me(self):
		super().call_me()
		print('Calling method on Right Subclass')
		self.num_right_calls += 1

		
>>> class Subclass(LeftSubclass, RightSubclass):
	num_sub_calls = 0
	def call_me(self):
		super().call_me()
		print('Calling method on Subclass')
		self.num_sub_calls += 1

		
>>> s = Subclass()
>>> s.call_me()
Calling method on Base Class
Calling method on Right Subclass
Calling method on Left Subclass
Calling method on Subclass
>>> print(s.num_sub_calls, s.num_left_calls, s.num_right_calls, s.num_base_calls)
1 1 1 1
>>> class Contact:
	all_contacts = list()
	def __init__(self, name=str(), email=str(), **kwargs):
		super().__init__(**kwargs)
		self.name = name
		self.email = email
		self.all_contacts.append(self)

		
>>> class AddressHolder:
	def __init__(self, street=str(), city=str(), state=str(), code=str(), **kwargs):
		super().__init__(**kwargs)
		self.street = street
		self.city = city
		self.state = state
		self.code = code

		
>>> class Friend(Contact, AddressHolder):
	def __init__(self, phone=str(), **kwargs):
		super()__init__(**kwargs)
		
SyntaxError: invalid syntax
>>> sclass Friend(Contact, AddressHolder):
	def __init__(self, phone=str(), **kwargs):
		super().__init__(**kwargs)
		self.phone = phone
		
SyntaxError: invalid syntax
>>> 
>>> class Friend(Contact, AddressHolder):
	def __init__(self, phone=str(), **kwargs):
		super().__init__(**kwargs)
		self.phone = phone

		
>>> f = Friend('az','baz','555-444-333')
Traceback (most recent call last):
  File "<pyshell#60>", line 1, in <module>
    f = Friend('az','baz','555-444-333')
TypeError: __init__() takes from 1 to 2 positional arguments but 4 were given
>>> f = Friend('555-444-333')
>>> f
<__main__.Friend object at 0x7f845dc2e2e8>
>>> f.phone
'555-444-333'
>>> f.state
''
>>> f.city
''
>>> f.email = "hello Jack"
>>> f.email
'hello Jack'
>>> f.ko = "ewqwe"
>>> f.ko
'ewqwe'
>>> Contact().ko
Traceback (most recent call last):
  File "<pyshell#70>", line 1, in <module>
    Contact().ko
AttributeError: 'Contact' object has no attribute 'ko'
>>> f.all_contacts
[<__main__.Friend object at 0x7f845dc2e2e8>, <__main__.Contact object at 0x7f845c1f7be0>]
>>> 
