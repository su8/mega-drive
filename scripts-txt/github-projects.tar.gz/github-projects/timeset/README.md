timeset
=======
<img src="img/timeset.png" alt="" />

Gui for <a href="https://github.com/aadityabagga/timeset" target="_blank">https://github.com/aadityabagga/timeset</a>