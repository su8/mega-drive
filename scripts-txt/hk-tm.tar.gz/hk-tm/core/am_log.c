#include "actionmanager.h"

void am_log(subaction_log_t *s)
{
   printf("[RUN] action log\n");

   return;
}
