#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>

struct sigaction act;

void handle_sigterm(int signum, siginfo_t *info, void *ptr)
{
    printf("Received signal %d\n", signum);
    printf("From process %lu\n", (unsigned long)info->si_pid);
}

int main(int argc, char **argv)
{
    printf("My process ID is %lu", (unsigned long)getpid());

    memset((&act, 0, sizeof(act)));
    act.sa_sigaction = handle_sigterm;
    act.sa_flags = SA_SIGINFO;

    sigaction(SIGTERM, &handle_sigterm, NULL);

    sleep(5);

    return 0;
}