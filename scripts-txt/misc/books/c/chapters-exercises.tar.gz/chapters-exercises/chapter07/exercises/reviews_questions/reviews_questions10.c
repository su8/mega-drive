/*

Rewrite the program in Review Question 9 so that it exhibits the same behavior but does
not use a continue or a goto .

*/

#include <stdio.h>
int main(void)
{
    char ch;
    while ((ch = getchar()) != '#')
    {
        if (ch != '\n')
        {
            printf("Step 1\n");
            if (ch == 'b')
                break;
            else if (ch != 'c')
            {
            if (ch != 'h')
                printf("Step 2\n");
            printf("Step 3\n");
            }
        }
    }
    printf("Done\n");
    return 0;
}