SystemJS.config({
  paths: {
    "npm:*": "/jspm_packages/npm/*"
  }
});