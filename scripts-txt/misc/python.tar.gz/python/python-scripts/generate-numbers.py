numbers = [2016]
while numbers[-1] < 2100:
    numbers.append(numbers[-1] + 1)

print ', '.join(map(str, numbers))