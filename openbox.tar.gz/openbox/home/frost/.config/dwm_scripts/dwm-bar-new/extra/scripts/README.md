Scripts used to extend pinky-bar in various languages.
