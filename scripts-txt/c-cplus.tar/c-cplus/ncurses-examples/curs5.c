/* curs.c -- example1 */
/* gcc -Wall -O2 curs.c -o main -lncurses */
#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
int main(int argc, char *argv[])
{
    int ch, prev;
    FILE *fp;
    int goto_prev = FALSE, y, x;

    if (argc != 2)
    {
        printf("Usage %s <a c filename>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    fp = fopen(argv[1], "r");

    if (fp == NULL)
    {
        perror("Canno open input file");
        exit(EXIT_FAILURE);
    }

    initscr(); /* start curses mode*/

    prev = EOF;

    while ((ch = fgetc(fp)) != EOF)
    {
        if (prev == '/' && ch == '*') /* switch bold on */
        {
            attron(A_BOLD);
            goto_prev = TRUE; /* go to prev char */
        }

        if (goto_prev == TRUE)
        {
            getyx(stdscr, y, x);
            move(y, x - 1);
            printw("%c%c", '/', ch);

            ch = 'a'; /* dummy character*/

            goto_prev = FALSE; /* set it to FALSE or every thing from here will be / */
        }

        else
            printw("%c", ch);
        refresh();

        if (prev == '*' && ch == '/')
            attroff(A_BOLD); /* switch bold off */

        prev = ch;
    }

    getch(); /* wait for user input */
    endwin(); /* end curses mode */

    return EXIT_SUCCESS;
}