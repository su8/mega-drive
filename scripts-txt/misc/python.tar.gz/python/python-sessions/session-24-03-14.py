Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> # 13.14 putting limits on memory and cpu usage
>>> import signal, resource, os
>>> def time_exceeded(signo, frame):
	print("Time's up!")
	raise SystemExit(1)

>>> def set_max_runtime(seconds):
	# Install the signal handler and set a resource limit
	soft, hard = resource.getrlimit(resource.RLIMIT_CPU)
	resource.setrlimit(resource.RLIMIT_CPU, (seconds, hard))
	signal.signal(signal.SIGXCPU, time_exceeded)

	
>>> if __name___ == '__main__':
	set_max_runtime(15)
	while True:
		pass

	
Traceback (most recent call last):
  File "<pyshell#16>", line 1, in <module>
    if __name___ == '__main__':
NameError: name '__name___' is not defined
>>> if __name__ == '__main__':
	set_max_runtime(15)
	while True:
		pass

	
Time's up!
>>> # to restrict memory use, put a limit on the total address space in use
>>> import resouce
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    import resouce
ImportError: No module named 'resouce'
>>> import resource
>>> def limit_memory(maxsize):
	soft, hard = resouce.getrlimit(resource.RLIMIT_AS)
	resource.setrlimit(resource.RLIMIT_AS, (maxsize, hard))

	
>>> ================================ RESTART ================================
>>> # 13.15 Launching a web browser
>>> import webbrowser
>>> webbrowser.open('linux.sytes.net')
True
>>> webbrowser.open('http://www.linux.sytes.net')
True
>>> # open the page in new browser window
>>> # webbrowser.open_new('http://website.com')
>>> # open the page in a new browser tab
>>> # webbrowser.open_new_tab('http://website.com')
>>> webbrowser.get()
<webbrowser.BackgroundBrowser object at 0x7f9f2488b190>
>>> webbrowser.get('chromium')
<webbrowser.Chrome object at 0x7f9f2488b1d0>
>>> webbrowser.get('midori')
Traceback (most recent call last):
  File "<pyshell#36>", line 1, in <module>
    webbrowser.get('midori')
  File "/usr/lib/python3.3/webbrowser.py", line 53, in get
    raise Error("could not locate runnable browser")
webbrowser.Error: could not locate runnable browser
>>> webbrowser.get('firefox')
<webbrowser.Mozilla object at 0x7f9f2488b050>
>>> a = webbrowser.get('firefox')
>>> a.open_new_tab('http://webiste.com')
True
>>> webbrowser.open('http://www.linux.sytes.net')
True
>>> webbrowser.open('http://www.linux.sytes.net')
True
>>> 
