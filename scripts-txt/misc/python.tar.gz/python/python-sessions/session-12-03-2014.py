Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> # 11.9 authenticating clients simply
>>> import hmac
>>> import os
>>> def client_authenticate(connection, secret_key):
	'''
authenticate client to a remote service.
connection represents a network connection.
secret_key is a key known only to both client/server.
'''
	message = connection.recv(32)
	hash = hmac.new(secret_key, message)
	digest = hash.digest()
	connection.send(digest)

	
>>> def server_authenticate(connection, secret_key):
	'''
request client authentication
'''
	message = os.urandom(32)
	connection.send(message)
	hash = hmac.new(secret_key, message)
	digest = hash.digest()
	response = connection.recv(len(digest))
	return hmac.compare_digest(digest, response)

>>> # to use these functions you would incorporate them into existing networking or messaging code.
>>> from socket import socket, AF_INET, SOCK_STREAM
>>> secret_key = b'peekaboo'
>>> def echo_handler(client_sock):
	if not server_authenticate(client_sock, secret_key):
		client_sock.close()
		return
	while True:
		msg = client_sock.recv(8192)
		if not msg:
			break
		client_sock.sendall(msg)

		
>>> def echo_server(address):
	s = socket(AF_INET, SOCK_STREAM)
	s.bind(address)
	s.listen(5)
	while True:
		c, a = s.accept()
		echo_handler(c)

		
>>> echo_server(('', 18000))
Traceback (most recent call last):
  File "<pyshell#45>", line 1, in <module>
    echo_server(('', 18000))
  File "<pyshell#44>", line 7, in echo_server
    echo_handler(c)
  File "<pyshell#36>", line 6, in echo_handler
    msg = client_sock.recv(8192)
KeyboardInterrupt
>>> 
