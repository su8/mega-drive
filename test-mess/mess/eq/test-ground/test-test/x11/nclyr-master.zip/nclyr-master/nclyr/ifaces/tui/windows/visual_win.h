#ifndef NCLYR_CURSES_VISUAL_WIN_H
#define NCLYR_CURSES_VISUAL_WIN_H

#include "window.h"

struct nclyr_win *visual_win_new(void);

#endif
