\*BSD users should add the "musicpd" daemon **user** on their own
