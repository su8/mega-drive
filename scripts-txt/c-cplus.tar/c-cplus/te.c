#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[])
{
    int count;
    char ql[50];

    printf("The command line has %d arguments:\n", argc - 1);
    for (count = 1; count < argc; count++)
        printf("%d: %s\n", count, argv[count]);
    printf("\n");

    //printf("%s", argv[3]);
    //puts(&argv[3][2]);
    //[(strlen(argv[3])-4)]
    //printf("%lu", strlen(argv[3])-2);
    strncpy(ql, argv[3], strlen(argv[3])-4);
    printf("%s", ql);

    return 0;
}