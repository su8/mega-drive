	chooser_dialog = Gtk.FileChooserDialog(title="Open file" 
	,action=Gtk.FileChooserAction.OPEN 
	,buttons=["Open", Gtk.ResponseType.OK, "Cancel", Gtk.ResponseType.CANCEL]
	) 
	pyFilter = Gtk.FileFilter()	
	pyFilter.add_mime_type('text/x-python') 
	pyFilter.add_pattern('*.py') 
	pyFilter.set_name('Python files') 
	chooser_dialog.add_filter(pyFilter) 
	response = chooser_dialog.run()	
	filename = chooser_dialog.get_filename()	
	chooser_dialog.destroy() 
