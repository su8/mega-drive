#include "jni.h"

int main() {
     JNIEnv *env;
     JavaVM *vm;
     jint res;
     JavaVMInitArgs vm_args;
     JavaVMOption options[1];
     options[0].optionString = "-Djava.class.path=.";
     vm_args.version = JNI_VERSION_1_2;
     vm_args.options = options;
     vm_args.nOptions = 1;
     vm_args.ignoreUnrecognized = JNI_TRUE;
     res = JNI_CreateJavaVM(&vm, (void**)&env, &vm_args);
     jclass invokeeClass = (*env)->FindClass(env, "jCode");
     if (invokeeClass == NULL) {
          printf("Failed to find Invokee class");
          return -1;
     }
     jmethodID invokeID = (*env)->GetStaticMethodID(env, invokeeClass, "invoke", "()V");
     if (invokeID == NULL) {
          printf("Failed to find invoke() method");
          return -1;
     }
     (*env)->CallStaticVoidMethod(env, invokeeClass, invokeID);
     return 0;
}
