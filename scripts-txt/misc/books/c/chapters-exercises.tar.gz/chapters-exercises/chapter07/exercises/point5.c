/* point5.c -- 

Redo exercise 4 using a switch

 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main(void)
{
    unsigned short int shebang, exclamation_mark;
    char ch;

    while ((ch = getchar()) != '#')
    {
        switch(ch)
        {
            case '.':
                        ch = '!';
                        putchar(ch);
                        shebang++;
                        continue;
            case '!':
                        ch = '!';
                        putchar(ch);
                        putchar(ch);
                        exclamation_mark++;
                        continue;
            default:
                        putchar(ch);
        }
    }
    printf("\nEncountered shebangs = %hu, exclamation marks = %hu\n",
        shebang, exclamation_mark);

    return EXIT_SUCCESS;
}