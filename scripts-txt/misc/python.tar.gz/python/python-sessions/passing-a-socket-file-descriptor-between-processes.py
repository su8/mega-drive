import multiprocessing
from multiprocessing.reduction import recv_handle, send_handle
import socket

def worker(in_p, out_p):
	out_p.close()
	while True:
		fd = recv_handle(in_p)
		print('CHILD: GOT FD', fd)
		with socket.socket(socket.AF_INET, socket.SOCK_STREAM, fileno=fd) as s:
			while True:
				msg = s.recv(1024)
				if not msg:
					break
				print('CHILD: RECV {!r}'.format(msg))
				s.send(msg)
def server(address, in_p, out_p, worker_pid):
	in_p.close()
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
	s.bind(address)
	s.listen(1)
	while True:
		client, addr = s.accept()
		print('SERVER: Got connection from', addr)
		send_handle(out_p, client.fileno(), worker_pid)
		client.close()

if __name__ == '__main__':
    c1, c2 = multiprocessing.Pipe()
    worker_p = multiprocessing.Process(target=worker, args=(c1, c2))
    worker_p.start()

    server_p = multiprocessing.Process(target=server,
    	args=(('', 15000), c1, c2, worker_p.pid))
    server_p.start()
    c1.close()
    c2.close()

'''
start the program and open-up the browser - localhost:15000
[frost@frost-pc python-sessions]$ python3 passing-a-socket-file-descriptor-between-processes.py 
SERVER: Got connection from ('127.0.0.1', 50688)
CHILD: GOT FD 7
SERVER: Got connection from ('127.0.0.1', 50689)
CHILD: RECV b'GET / HTTP/1.1\r\nHost: 127.0.0.1:15000\r\nConnection: keep-alive\r\nCache-Control: max-age=0\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nUser-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36\r\nDNT: 1\r\nAccept-Encoding: gzip,deflate,sdch\r\nAccept-Language: en-US,en;q=0.8,bg;q=0.6\r\n\r\n'
CHILD: GOT FD 7

'''