#include <stdio.h>
int main(void)
{
    int i = 1;
    float n;
    printf("Watch out! Here comes a bunch of fractions!\n");
    
    while (i < 30)
    {
    
        n = i++;
        printf(" %f\n", n);

    }
    printf("That's all folks!\n");

    return 0;
}

/* original:
 * 
 * int main(void)
 * {
 * int i = 1,
 * float n;
 * printf("Watch out! Here come a bunf of fractions!\n");
 * while (i < 30)
 *     n = 1/i;
 *     printf(" %f", n);
 *     printf("That's all, folks!\n");
 *     return;
 * }
 * 
*/
