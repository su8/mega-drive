/*

5. What changes, if any, would you need to make to have the function of question 4 add
two double numbers instead?

*/

/* since we are using function prototype, the compiler knows that
the return value have to be int type, so we can safely pass float variables/values and be safe that C will automatically truncate any fraction after the decimal point, so 3.49312 will be truncated to just 3, some compilers may raise warnings */