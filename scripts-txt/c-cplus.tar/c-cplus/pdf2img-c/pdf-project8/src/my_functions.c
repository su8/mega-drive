/*
   my_functions.c
 
   Copyright 12/18/2014 Aaron Caffrey https://github.com/wifiextender
 
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
   MA 02110-1301, USA.
*/

#include <stdio.h>      /* rename()                                 */
#include <stdlib.h>     /* system()                                 */
#include <string.h>     /* strncpy(), strcmp(), sprintf(), strlen() */
#include <stdbool.h>    /* bool - true(1) / false(0)                */
#include <ctype.h>      /* isdigit()                                */
#include <sys/stat.h>   /* mkdir(), stat(), stat struct, S_ISDIR()  */
#include <gtk/gtk.h>
#include "gettext.h"    /* _()                                      */
#include "my_constants.h"
#include "my_functions.h"

/* string comparison */
#define STREQ(x, z) (0 == strcmp(x, z))


/*
   external definitions referring 
   to the defining declarations in main.c
*/
extern GtkWidget *window, *spinbutton1, *spinbutton2, *trans_switch;
extern GtkWidget *entry, *sdev_combo, *image_combo, *alias_combo;


/*
   The resolution string must contain
   only numbers, if it doesn't have numbers
   or is empty remind it to the user.
*/
bool resolution_has_nums(void)
{
    const gchar *entry_str = gtk_entry_get_text(GTK_ENTRY(entry));  /* gtk gchar type */
    size_t entry_len       = strlen(entry_str);
    bool   entry_bool      = true;
    char   detected_chars[5], resolution_warn_str[25];
    unsigned short int x, count_not_zero;

    for (count_not_zero = 0, x = 0; x < entry_len; x++)
        if ( !(isdigit(entry_str[x])) )
            detected_chars[count_not_zero++] = entry_str[x];

    if (count_not_zero)
    {
        entry_bool = false;
        detected_chars[count_not_zero] = '\0';
        sprintf(resolution_warn_str, _(DETECTED_CHARS_BODY), detected_chars);
        RaiseWarning(_(RESOLUTION_WARN_TITLE), resolution_warn_str);
    }

    if (0 == x)
    {
        entry_bool = false;
        RaiseWarning(_(EMPTY_RES_TITLE), _(EMPTY_RES_BODY));
    }

    return entry_bool;
}


/* 
   return the last seperator '/' index number,
   we will use this index number to create our own
   `basename' alternative in C
*/
unsigned short int index_last_sep(const char *str)
{
    size_t str_len = strlen(str);
    unsigned short int sep_index = 0;
    unsigned short int x;

    for (x = 0; x < str_len; x++)
        if (str[x] == '/')
            sep_index = x; /* keep in mind that we use loop */

    return sep_index;
}


/* Show about dialog */
void on_about_clicked(void)
{

    /*
         The difference between 'gtk_about_dialog_new' and
         'gtk_show_about_dialog' is that in the first case
         you can't map any parent, but in same time it's needed.
    */

    /* about_dialog = gtk_about_dialog_new();
    gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG(about_dialog),ABOUT_PROG_NAME);
    gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(about_dialog),ABOUT_COMMENTS);
    gtk_about_dialog_set_website(GTK_ABOUT_DIALOG(about_dialog),ABOUT_WEBSITE);
    gtk_about_dialog_set_website_label(GTK_ABOUT_DIALOG(about_dialog),ABOUT_WEBSITE_LABEL);
    gtk_about_dialog_set_license_type(GTK_ABOUT_DIALOG(about_dialog),GTK_LICENSE_GPL_3_0);
    gtk_dialog_run(GTK_DIALOG(about_dialog));
    gtk_widget_destroy(about_dialog); */

    gtk_show_about_dialog(GTK_WINDOW(window),
                         "program-name", ABOUT_PROG_NAME,
                         "comments", _(ABOUT_COMMENTS),
                         "website", ABOUT_WEBSITE,
                         "website-label", _(ABOUT_WEBSITE_LABEL),
                         "license-type", GTK_LICENSE_GPL_3_0, NULL);
}


/* 
   handle signal 'changed' from sdevice combobox
   and workaround the problem when setting
   different active item.
*/
void on_sdevice_combo(void)
{
    /*
       Even 'short' int type is pretty much
       overkiller for our smallest ints.
    */
    unsigned char next = 0, current = 0;
    char *active = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(sdev_combo));

    if (STREQ(active,PNG16M))
        next = 0;
    else
        if (STREQ(active,PNGALPHA))
            next = 1;
        else
            if (STREQ(active,PNGGRAY))
                next = 2;
            else    /* 'active' not in png group */
            {
                current = 1; /* The jpg group */
                if (STREQ(active,JPEG))
                    next = 3;
                else
                    if (STREQ(active,JPEGCMYK))
                        next = 4;
                    else
                        if (STREQ(active,JPEGGRAY))
                            next = 5;
                        else    /* 'active' not in jpg group */
                        {
                            current = 2; /* The bmp group */
                            if (STREQ(active,BMP16M))
                                next = 6;
                            else
                                if (STREQ(active,BMPGRAY))
                                    next = 7;
                                else    /* 'active' not in bmp group */
                                {
                                    current = 3; /* The tiff group */
                                    next = (STREQ(active,TIFF24NC)) ? 8 : 9;
                                }
                        }
            }

    gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), current);
    gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), next);
}


/* handle signal 'changed' from image format combobox */
void on_image_combo(void)
{
    unsigned char current = 0;
    char *active = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(image_combo));

    if (STREQ(active,PNG))
        current = 0;
    else
        if (STREQ(active,JPG))
            current = 3;
        else
            current = (STREQ(active,BMP)) ? 6 : 8;

    gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), current);
}


/* Launch file chooser dialog */
void on_button1_clicked(void)
{
    if (resolution_has_nums())
    {
        unsigned short int spin1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
        unsigned short int spin2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));

        if (spin1 > spin2)
            RaiseWarning(_(REVERSED), _(REVERSED_BODY));
        else
        {
            char *filename;
            GtkWidget *chooser_dialog = gtk_file_chooser_dialog_new(_(SELECT_PDF_LBL),
                                                                    GTK_WINDOW(window),
                                                                    GTK_FILE_CHOOSER_ACTION_OPEN,
                                                                    _(CANCEL_BTN),
                                                                    GTK_RESPONSE_CANCEL,
                                                                    _(CONVERT_BTN),
                                                                    GTK_RESPONSE_ACCEPT, NULL);

            GtkFileFilter *filter_pdf = gtk_file_filter_new();
            gtk_file_filter_set_name(GTK_FILE_FILTER(filter_pdf),_(PDF_FILTER));
            gtk_file_filter_add_pattern(GTK_FILE_FILTER(filter_pdf),PDF_PATTERN);
            gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(chooser_dialog),GTK_FILE_FILTER(filter_pdf));

            if (gtk_dialog_run(GTK_DIALOG(chooser_dialog)) == GTK_RESPONSE_ACCEPT)
            {
                filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(chooser_dialog));
                pdf_to_img(filename);
            }
            gtk_widget_destroy(chooser_dialog);
        }
    }
}


/*
   If you use the program correctly
   you won't see this function in action.
   --------------------------------------
   In gtk2 the yellow warning icon is
   displayed but not in gtk3, because the
   devs behind gtk decided to deprecate
   all standard icons.
*/
void RaiseWarning(const char *str_to_warn1, const char *str_to_warn2)
{
    GtkWidget *warn_dialog = gtk_message_dialog_new(GTK_WINDOW(window),
                                                    GTK_DIALOG_MODAL,
                                                    GTK_MESSAGE_WARNING,
                                                    GTK_BUTTONS_OK, 
                                                    "%s", str_to_warn1);
    gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(warn_dialog), "%s", str_to_warn2);
    gtk_dialog_run(GTK_DIALOG(warn_dialog));
    gtk_widget_destroy(warn_dialog);
}


/* 
   Remove the '.pdf' extension, 
   `gs' the formal parameter 'filename',
   create new folder if it doesn't exists and 
   rename the converted images to match the
   'from' and 'to' page range.
*/
void pdf_to_img(const char *filename)
{
    size_t fit = strlen(filename);   /* Actually we don't need `malloc' */
    if (fit >= 1850)
        RaiseWarning(_(JOKE), _(FILENAME_TOO_LONG));
    else
    {
        char pdfname[fit];
        size_t fit2 = fit - 4;
        strncpy(pdfname, filename, fit2);
        pdfname[fit2] = '\0';

        unsigned short int x, z;
        unsigned short int dirname_len = index_last_sep(filename);
        char BaseName[fit-dirname_len+20];

        for (z = 0, x = dirname_len+1; x < fit2; x++, z++)
            BaseName[z] = pdfname[x]; /* /path/to/some.pdf -> some      */
        BaseName[z] = '\0';

        if (strlen(BaseName) > 240)   /* Up to 244 (240 + 4 '.pdf')     */
            RaiseWarning(_(RESOLUTION_WARN_TITLE), _(FILESYSTEM_LIMITS_BODY));
        else
        {
            /* 
               params: input + output filename + 300 for the whole gs string
               The longest filename on 64-bit system is 4096 characters, so
               if 'filename' is up to 1849 characters long, we will be within
               the limits, because 1849 + 1849 + 300 = 3998

               ren1: /path/to/some_pAge_1.png
               ren2: /path/to/some converted/some_page_1.png
            */
            char params[fit+fit+300], ren1[fit+20], ren2[fit+strlen(BaseName)+20], created_dir[fit+20];
            unsigned short int spin1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
            unsigned short int spin2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));
            char *im_combo = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(image_combo));
            struct stat DiR;

            unsigned short int small_range = (spin2 - spin1) + 2;
            unsigned short int big_range = spin1;

            sprintf(created_dir, "%s converted", pdfname);
            stat(created_dir, &DiR);

            if (0 == S_ISDIR(DiR.st_mode))
                mkdir(created_dir, 0700);

            sprintf(params, "gs -dBATCH -dNOPAUSE -dQUIET -dFirstPage=%hu -dLastPage=%hu "
                            "-sOutputFile=\"%s\"_pAge_%%01d.%s -sDEVICE=%s -r%s "
                            "-dGraphicsAlphaBits=%s -sBandListStorage=memory "
                            "-dBufferSpace=99000 -dNumRenderingThreads=1 %s\"%s\"",
                spin1, spin2, pdfname, im_combo,
                gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(sdev_combo)),
                gtk_entry_get_text(GTK_ENTRY(entry)),
                gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(alias_combo)),
                gtk_switch_get_active(GTK_SWITCH(trans_switch)) ? "" : "-dNOTRANSPARENCY ", filename);
            system(params);

            for (x = 1; x < small_range; x++, big_range++)
            {
                sprintf(ren1, "%s_pAge_%hu.%s", pdfname, x, im_combo);
                sprintf(ren2, "%s/%s_page_%hu.%s", created_dir, BaseName,
                                                   big_range, im_combo);
                rename(ren1, ren2);
            }
        }
    }
}