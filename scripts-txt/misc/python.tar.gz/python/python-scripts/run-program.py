#!/usr/bin/python
import subprocess
import os

os.getcwd()
os.chdir('/home/frost/blog/')
params = ['python2', 'build.py']
subprocess.check_call(params)
