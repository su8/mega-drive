#!/bin/bash
clear 
echo -e "\033[41m Hello World"
echo -e "\033[44m Hello World"
echo -e "\033[0m "
 
