/* 15. Write a program that reads in a line of input and then prints the line in reverse order.
You can store the input in an array of char ; assume that the line is no longer than 255
characters. Recall that you can use scanf() with the %c specifier to read a character at
a time from input and that the newline character ( \n ) is generated when you press the
Enter key. */
#include <stdio.h>
#include <string.h>
int main(void)
{
    int n2;
    char nums[20];
    //scanf("%s", nums);
    //printf("%s", nums);

    for (n2 = 0; n2 < 8; n2++)
    {
        printf("Enter char #%d: ", n2 + 1);
        scanf("%c", &nums[n2]);
    }
    
    for (n2 = 8 - 1; n2 > 0; n2--)
    {
        printf("%c", nums[n2]);
    }
    

    //for (n2 = 0; n2 <= 8; n2++)
        //nums[n2] = n2;
    //for (n2 = 8 - 1; n2 > 0; n2--)
        //printf("%d", nums[n2]);

    return 0;
}
