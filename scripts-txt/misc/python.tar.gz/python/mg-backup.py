import os
from subprocess import call
from datetime import datetime

class Mega(object):
    def __init__(self):
        current = datetime.now()
        mdb = 'mega-drive-backup'
        mdb_ib = 'mega-drive-backup/increment-backup'
        mdb_cd = mdb + '/current_date'

        #os.chdir(os.getenv('HOME') + os.sep + 'Documents')
        if os.path.exists(mdb):
            call('XZ_OPT=-9e tar -cJf {back_dir_cur_date}/mega-drive-{day}-{month}-{year}.tar.xz \
                mega-drive -g {back_dir}/increment'
                .format(back_dir_cur_date=mdb_cd, day=current.day,
                    month=current.month, year=current.year,
                    back_dir=mdb), shell=True)

            call('tar -cJf {mdb_ib_}/increment-backup-{day}-{month}-{year}.tar.xz \
                            {back_dir}/increment'
                            .format(mdb_ib_=mdb_ib, day=current.day,
                                month=current.month, year=current.year,
                                back_dir=mdb), shell=True)
        else:
            os.makedirs(mdb)
            call('XZ_OPT=-9e tar -cJf {back_dir}/mega-drive.tar.xz \
                mega-drive -g {back_dir}/increment'.format(back_dir=mdb),
                 shell=True)

            os.makedirs(mdb_ib)
            os.makedirs(mdb_cd)
            call('tar -cJf {mdb_ib_}/increment-backup.tar.xz \
            {back_dir}/increment'.format(mdb_ib_=mdb_ib,
                back_dir=mdb), shell=True)

        # tar xvf archive.tar.xz
        # tar xvf archive-1.tar.xz

if __name__ == '__main__':
    Mega()