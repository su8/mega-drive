#!/usr/bin/env python3

from gi.repository import Gtk

class GettingStarted:
    def __init__(self):
        window = Gtk.Window()
        window.show()
  
GettingStarted()
Gtk.main()