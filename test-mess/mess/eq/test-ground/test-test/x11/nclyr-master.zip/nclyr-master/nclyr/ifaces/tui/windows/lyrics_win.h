#ifndef NCLYR_CURSES_LYRICS_WIN_H
#define NCLYR_CURSES_LYRICS_WIN_H

#include "window.h"
#include "line_win.h"

struct nclyr_win *lyrics_win_new(void);

#endif
