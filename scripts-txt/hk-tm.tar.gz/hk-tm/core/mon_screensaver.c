#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#include "monitor.h"

struct mon_screensaver_entry {
   void *(*callback)(void *);
   void *args;
   int flags;
   struct mon_screensaver_entry *next;
   struct mon_screensaver_entry *prev;
};

static void *mon_screensaver_run(void *args);
static void mon_screensaver_dump(void);

static pthread_t t;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static struct mon_screensaver_entry *list = NULL;
static int running = 0;

static void *mon_screensaver_run(void *args)
{
   struct mon_screensaver_entry *p, *e;
   int active;

   while(1) {
      pthread_mutex_lock(&m);

      if(!list) {
         running = 0;
         pthread_mutex_unlock(&m);
         return NULL;
      }

      active = system("gnome-screensaver-command -q | grep -q 'inactive'");
      p = list;
      while(p) {
         if((!(p->flags & MON_FLAG_NEG) && active) || ((p->flags & MON_FLAG_NEG) && !active)) {
            pthread_create(&t, NULL, p->callback, p->args);
            if(p == list) list = p->next;
            if(p->next) p->next->prev = p->prev;
            if(p->prev) p->prev->next = p->next;
            e = p;
            p = p->next;
            free(e);
         } else {
            p = p->next;
         }
      }

      mon_screensaver_dump();

      pthread_mutex_unlock(&m);

      sleep(1);
   }
}

void mon_screensaver_start(void *args) {
   pthread_mutex_lock(&m);
   if(!running) if(!pthread_create(&t, NULL, mon_screensaver_run, NULL)) running = 1;
   pthread_mutex_unlock(&m);
}

void *mon_screensaver_addwatch(void *(*callback)(void *), void *args, int flags, ...)
{
   struct mon_screensaver_entry *p = NULL;

   pthread_mutex_lock(&m);

   do {
      if(!list) {
         if(!(list = malloc(sizeof(struct mon_screensaver_entry)))) break;
         list->prev = NULL;
         p = list;
      } else {
         for(p = list; p->next; p = p->next);
         if(!(p->next = malloc(sizeof(struct mon_screensaver_entry)))) break;
         p->next->prev = p;
         p = p->next;
      }
      p->next = NULL;
      p->callback = callback;
      p->args = args;
      p->flags = flags;

      if(!running) if(!pthread_create(&t, NULL, mon_screensaver_run, NULL)) running = 1;
   } while(0);

   mon_screensaver_dump();

   pthread_mutex_unlock(&m);

   return p;
}

void mon_screensaver_delwatch(void *entry)
{
   struct mon_screensaver_entry *p = NULL, *e = (struct mon_screensaver_entry *)entry;

   if(!list || !e) return;

   pthread_mutex_lock(&m);

   for(p = list; p && (p != e); p = p->next);
   if(p) {
      if(p == list) list = p->next;
      if(p->next) p->next->prev = p->prev;
      if(p->prev) p->prev->next = p->next;
      free(p);
   }

   pthread_mutex_unlock(&m);

   return;
}

void mon_screensaver_dump(void)
{
#if 0
   struct mon_screensaver_entry *p = NULL;

   printf("\n--- SCREENSAVER MONITOR LIST ---\n");
   for(p = list; p; p = p->next) printf("- (at %p)\n", (void *)p);
   printf("\n");
#endif

   return;
}
