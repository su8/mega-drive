#ifndef _SCROT_H_
#define _SCROT_H_

struct Area {
	int x;
	int y;
	int width;
	int height;
};

#endif
