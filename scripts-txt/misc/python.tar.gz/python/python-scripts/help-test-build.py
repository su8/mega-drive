import os
import markdown2
import codecs
import string
import re
import subprocess
import argparse
import textwrap

page2 = ""
# rss_post = []
index_posts, recent_posts, forum_posts, search_posts, archive_links = [], [], [], [], []
action_button = '"action-button"'
# Return a list containing the names of the entries in the directory given by path "/md/"
posts = os.listdir(os.getcwd() + "/md/")

# opens are rewrites all the content in these five pages, also if you create another
# page add it here: contact_file = codecs.open("site/contact-us.html", mode="w", encoding="utf8")
# , ('site/rss.html','rss_file')
inst_dict = {}
for file in [('site/index.html', 'index_file'), ('site/archive.html', 'archive_file'), ('site/forum.html', 'forum_file'), ('site/search.html', 'search_file')]:
    inst_dict[file[1]] = codecs.open(file[0], mode='w', encoding='utf8')

# opens,reads and includes the content from static/xxx to the particular file(s)
# if you create another page, copy and paste 2 of the lines that are hf = staticFile , and header = hf()
# rename them according to your personal like, make sure to copy and paste those files !


class staticFile:

    def __init__(self, filename):
        self.filename = filename

    def __call__(self):
        with codecs.open(self.filename, mode="r", encoding="utf8") as a:
            return a.read()

    def __str__(self):
        return self.filename


hf = staticFile("static/header")
header = hf()
fh = staticFile("static/header_forum")
forum_header = fh()
sh = staticFile("static/header_search")
search_header = sh()
# rh = staticFile("static/header_rss")
# rss_header = rh()
ah = staticFile("static/header_archive")
archive_header = ah()
fp = staticFile("static/footer_post")
footer_p = fp()
fi = staticFile("static/footer")
footer_i = fi()


# opens, reads the title, date and the text,
# then converts all posts from md folder to html files
for post in posts:

    input_file = codecs.open("md/" + post, mode="r", encoding="utf8")
    # how many characters to show for each post in your index page, default is 400.
    file_content = input_file.read(400)
    file_content_lines = string.split(file_content, '\n')
    title = file_content_lines[0]
    date = file_content_lines[2]
    input_file.close()

    md = markdown2.Markdown()
    html = md.convert(file_content)

# this is regex, don't change anything after " = ", it searches this specific
# div and includes everything below this div in the particular page from your md file(s)
    html_post_start = re.search('<div class="articleline2">', html)

    # basic html knowledge will help you to understand these 6 lines below
    index_posts.append("<div class=" + date + "><a href='" + page2 + post + ".html'><h1>" + string.replace(title, '#', '') + "</h1></a>" + html[html_post_start.start():] + "</div><br /><a href='" + page2 + post + ".html' class="+action_button+">READ MORE</a><br /><br /><br />")
    archive_links.append("<span>" + date + "</span><a href='" + page2 + post + ".html'>" + string.replace(title, '#', '') + "</a><br />")
    # sort recent posts for other pages, if you create another page add it here
# , rss_posts
    for other_pages in recent_posts, forum_posts, search_posts:
        other_pages.append("<li class=" + date + "><a href='" + page2 + post + ".html'>" + string.replace(title, '#', '') + "</a></li>")
        other_pages.sort()
        other_pages.reverse()
    # sort the posts in [in]dex and [ar]chive pages = inar
    for inar in archive_links, index_posts:
        inar.sort()
        inar.reverse()

# how many recent posts to display, the default number is 12
postgroup = ""
postgroup_count = 0
for post in recent_posts:
    if(postgroup_count < 12):
        postgroup = postgroup + post
    postgroup_count += 1

# how many posts to display in the main page, the default number is 5
index_body = ""
index_post_count = 0
for link in index_posts:
    if (index_post_count < 5):
        index_body = index_body + link
    index_post_count += 1

# opens the index header and default footer (footer, not footer_post) and replaces the
# title with index, also it tells to sort and include all latest recent + main posts
index_header = string.replace(header, "titlefixed", "Aaron's Blog")
inst_dict['index_file'].write(index_header + index_body + string.replace(footer_i, "<!-- recent posts -->", postgroup))
inst_dict['index_file'].close()

# opens, reads the title, date and the text,
# then converts all posts from md folder to html files
post_count = 0
for post in posts:

    post_count += 1
    input_file = codecs.open("md/" + post, mode="r", encoding="utf8")
    file_content = input_file.read()
    input_file.close()

    title = string.split(file_content, '\n')[0]

    md = markdown2.Markdown()
    html = md.convert(file_content)
    post_file = codecs.open("site/" + post + ".html", "w", encoding="utf8")

    titlefixed = string.replace(title, '#', '')
    titlefixed = string.replace(titlefixed, '\n', '')
    curr_header = string.replace(header, "titlefixed", titlefixed)
    post_file.write(curr_header + html + string.replace(footer_p, "<!-- recent posts -->", postgroup))
    post_file.close()

# sort and adds " #16 - " in front of every link in the archive page, 16 is just example
archive_links_count = len(archive_links)
archive_body = ""
for link in archive_links:
    archive_body = archive_body + "#" + str(archive_links_count) + " - " + link
    archive_links_count -= 1

# opens the archive header and default footer (footer, not footer_post) and replaces the
# title with archive, also it tells to sort and include all latest recent posts
archive_header = string.replace(archive_header, "titlefixed", "Archive")
inst_dict['archive_file'].write(archive_header + archive_body + string.replace(footer_i, "<!-- recent posts -->", postgroup))
inst_dict['archive_file'].close()

# if you create another page add it here (contact_header, contact_file)
# ,(rss_header, inst_dict['rss_file'])
lStuff = [(forum_header, inst_dict['forum_file']), (search_header, inst_dict['search_file'])]
for header, fosers in lStuff:
    header = string.replace(header, "titlefixed", "Aaron's Blog")
    fosers.write(header + string.replace(footer_i, "<!-- recent posts -->", postgroup))
    fosers.close

parser = argparse.ArgumentParser(
     prog='build.py rss',
     formatter_class=argparse.RawDescriptionHelpFormatter,
     description=textwrap.dedent('''\
         python build.py rss
         --------------------------------
         '''))
parser.add_argument('rss', action="store_false", default=None,
                    help='Turn A off',)
print parser.parse_args()



#def rss(self):
#    subprocess.check_call(['perl', 'rssgenerator.pl'])