My various scripts and config files.
