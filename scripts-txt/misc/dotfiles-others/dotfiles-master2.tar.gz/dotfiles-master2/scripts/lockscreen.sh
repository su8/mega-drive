#! /bin/bash

xtrlock &
sleep 1
xset dpms force off
