#!/bin/bash
readonly DIRECTORY=/home/frost/Documents/test/
readonly GPG_PUBKEY_ID=AA92AE64
readonly ENCRYPTED_FILE=/home/frost/Documents/encrypted_folder.tar.xz.gpg

XZ_OPT=-9e tar cJf - -C $DIRECTORY . | \
    gpg -z 9 --batch --yes --encrypt \
    --recipient $GPG_PUBKEY_ID --output $ENCRYPTED_FILE