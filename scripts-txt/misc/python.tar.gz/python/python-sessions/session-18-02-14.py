Python 3.3.3 (default, Nov 26 2013, 13:33:18) 
[GCC 4.8.2] on linux
Type "copyright", "credits" or "license()" for more information.
>>> import math
>>> class Circle:
	def __init__(self, radius):
		self.radius = radius
	@property
	def area(self):
		return "The area is multiplied by math.pi and radius", math.pi * self.radius ** 2

	
>>> class Circle:
	def __init__(self, radius):
		self.radius = radius
	@property
	def area(self):
		return "The area is multiplied by math.pi and radius", math.pi * self.radius ** 2
	@property
	def perimeter(self):
		return "perimeter", 2 * math.pi * self.radius

	
>>> c = Circle(14.8)
>>> c.radius
14.8
>>> c.area
('The area is multiplied by math.pi and radius', 688.1344548423084)
>>> c.perimeter
('perimeter', 92.99114254625788)
>>> class Person:
	def __init__(self, first_name):
		self.first_name = first_name
	# getter
	@property
	def first_name(self):
		return self._first_name
	# setter
	@first_name.setter
	def first_name(self, value):
		if not isinstance(value, str):
			raise TypeError('Expected a string')
		self._first_name = value
	# deleter
	@first_name.deleter
	def first_name(self):
		raise AttributeError("Can'\t delete attribute")

	
>>> c = Person("Danny")
>>> c
<__main__.Person object at 0x7fd78c1bbf50>
>>> c.first_name
'Danny'
>>> c.first_name = "Bannany"
>>> c.first_name
'Bannany'
>>> del c.first_name
Traceback (most recent call last):
  File "<pyshell#37>", line 1, in <module>
    del c.first_name
  File "<pyshell#31>", line 17, in first_name
    raise AttributeError("Can'\t delete attribute")
AttributeError: Can'	 delete attribute
>>> a.first_name = 41
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    a.first_name = 41
NameError: name 'a' is not defined
>>> c.first_name = 41
Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    c.first_name = 41
  File "<pyshell#31>", line 12, in first_name
    raise TypeError('Expected a string')
TypeError: Expected a string
>>> c.first_name
'Bannany'
>>> class sample:
	def __init__(self, sa):
		self.sa = sa
	def aa(self, widget):
		return self.sa
	def bb(self, widget):
		self.sa = widget

		
>>> sample("danny")
<__main__.sample object at 0x7fd78c1bec90>
>>> c = sample("danny")
>>> c.aa()
Traceback (most recent call last):
  File "<pyshell#51>", line 1, in <module>
    c.aa()
TypeError: aa() missing 1 required positional argument: 'widget'
>>> class sample:
	def __init__(self, sa):
		self.sa = sa
	def aa(self):
		return self.sa
	def bb(self, widget):
		self.sa = widget

		
>>> c.aa()
Traceback (most recent call last):
  File "<pyshell#54>", line 1, in <module>
    c.aa()
TypeError: aa() missing 1 required positional argument: 'widget'
>>> c = sample("danny")
>>> c.aa()
'danny'
>>> c.bb("haho")
>>> c.aa()
'haho'
>>> c
<__main__.sample object at 0x7fd78c1ca390>
>>> class A:
	def spam(self):
		print('A.spam')
class B(A):
	
SyntaxError: invalid syntax
>>> class A:
	def spam(self):
		print('A.spam')
class B(A):
	
SyntaxError: invalid syntax
>>> class A:
	def spam(self):
		print('A.spam')

		
>>> class B(A):
	def spam(self):
		print('B.spam')
		super().spam()

		
>>> B()
<__main__.B object at 0x7fd78c1ca650>
>>> A()
<__main__.A object at 0x7fd78c1ca510>
>>> B().spam()
B.spam
A.spam
>>> A().spam()
A.spam
>>> class A:
	def __init__(self):
		self.x = 0

		
>>> class B(A):
	def __init__(self):
		super().__init__()
		self.y = 1

		
>>> A()
<__main__.A object at 0x7fd78c1bee10>
>>> B()
<__main__.B object at 0x7fd78c1ca8d0>
>>> A().__init__()
>>> class A:
	def __init__(self):
		self.x = 0
		print("a.x", self.x)

		
>>> class B(A):
	def __init__(self):
		super().__init__()
		self.y = 1
		print("b.y", self.y)

		
>>> A().__init__()
a.x 0
a.x 0
>>> A()
a.x 0
<__main__.A object at 0x7fd78c1cac10>
>>> B().__init__()
a.x 0
b.y 1
a.x 0
b.y 1
>>> B()
a.x 0
b.y 1
<__main__.B object at 0x7fd78c1ca9d0>
>>> A()
a.x 0
<__main__.A object at 0x7fd78c1ca8d0>
>>> class A:
	def __init__(self):
		print("a __init__")

		
>>> class B(A):
	def __init__(self):
		super().__init__()
		print("b __init__ ")

		
>>> B()
a __init__
b __init__ 
<__main__.B object at 0x7fd78c1cae50>
>>> A()
a __init__
<__main__.A object at 0x7fd78c1cf050>
>>> 
