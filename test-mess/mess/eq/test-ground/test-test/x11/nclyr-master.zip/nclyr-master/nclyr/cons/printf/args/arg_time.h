#ifndef NCLYR_TUI_PRINTF_ARGS_ARG_TIME_H
#define NCLYR_TUI_PRINTF_ARGS_ARG_TIME_H

#include "printf/compiler.h"

struct printf_opt *printf_arg_parse_time(int index, char *id_par, size_t arg_count, const struct cons_printf_arg *args);

#endif
