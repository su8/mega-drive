<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Acme, Inc. Control Center</title>
    <style>
      h1.header {
        font-size: 18px;
        color: #006CC7;
        border-bottom: 1px solid #9DBCD6;
        padding-bottom: 10px;
      }
      .cpu-temp p, 
      .led p {
        margin: 10px 0px 10px 10px;
        font-size: 20px;
        font-family: monospace;
        font-weight: bold;
      }
      .cpu-temp span#temp,
      .led span#status {
        font-size: 14px;
      }
      .error {
        color: red;
	font-weight: bold;
      }
    </style>
  </head>
<body>
  <h1 class="header">Acme, Inc. Control Center</h1>
  <div class="cpu-temp">
    <p>
      CPU: <span id="temp">?</span>
    </p>
  </div>
  <div class="led">
    <p>
      LED: <span id="status">?</span>
    </p>
    <input type="button" value="Turn Red LED On" id="red_led_on"/>
    <input type="button" value="Turn Red LED Off" id="red_led_off"/>
  </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script>
    function get_cpu_temp() {
      $.ajax({
        url: 'get-cpu-temp.php',
        success: function(data) {
 	  $('#temp').removeClass("error");
	  $('#temp').html(data + " &deg;C");
        },
	error: function() {
 	  $('#temp').addClass("error");
	  $('#temp').html("!");
        },
	complete: function() {
          setTimeout(get_cpu_temp, 3000);
        }
      });
    }

    function set_red_led(led) {
      $.ajax({
        url: 'set-red-led.php',
	data: { "led": led },
        success: function(data) {
	  $('#status').html(data);
        }
      });
    }

    $(document).ready(function() {
      // Run for the first time; all subsequent calls will take care of themselves
      get_cpu_temp();
    });

    $('input').on('click', function(e) {
      var id = $(this).attr('id');
      if (id == "red_led_on") {
        set_red_led("on");
      }
      else if (id == "red_led_off") {
        set_red_led("off");
      }
    });
  </script>

</body>
</html>
