from gi.repository import Gtk
import threading, time

class Foo5(threading.Thread):

    def __init__(self, x):
        self.__x = x
        threading.Thread.__init__(self)
        window = Gtk.Window()
        window.set_default_size(200, 200)
        window.set_title("a3")
        layout = Gtk.Layout()
        window.add(layout)
        button = Gtk.Button(label="OK I give up3")
        label = Gtk.Label(label="Aligment3")
        layout.put(button, 40, 60)
        layout.put(label, 155, 80)
        #window.connect("destroy", self.aab)
        window.connect("destroy", lambda q: Gtk.main_quit())
        window.show_all()

    def run(self):
        print str(self.__x)
        if str(self.__x) == "19":
            print("hurray")
            #a3()

class Foo4(threading.Thread):

    def __init__(self, x):
        self.__x = x
        threading.Thread.__init__(self)
        window = Gtk.Window()
        window.set_default_size(200, 200)
        window.set_title("a3")
        layout = Gtk.Layout()
        window.add(layout)
        button = Gtk.Button(label="OK I give up3")
        label = Gtk.Label(label="Aligment3")
        layout.put(button, 40, 60)
        layout.put(label, 155, 80)
        #window.connect("destroy", self.aab)
        window.connect("destroy", lambda q: Gtk.main_quit())
        window.show_all()

    def run(self):
        print str(self.__x)
        if str(self.__x) == "19":
            print("hurray")
            #a3()

class Foo3(threading.Thread):

    def __init__(self, x):
        self.__x = x
        threading.Thread.__init__(self)
        window = Gtk.Window()
        window.set_default_size(200, 200)
        window.set_title("a3")
        layout = Gtk.Layout()
        window.add(layout)
        button = Gtk.Button(label="OK I give up3")
        label = Gtk.Label(label="Aligment3")
        layout.put(button, 40, 60)
        layout.put(label, 155, 80)
        #window.connect("destroy", self.aab)
        window.connect("destroy", lambda q: Gtk.main_quit())
        window.show_all()

    def run(self):
        print str(self.__x)
        if str(self.__x) == "19":
            print("hurray")
            #a3()


class Foo2(threading.Thread):

    def __init__(self, x):
        self.__x = x
        threading.Thread.__init__(self)
        window = Gtk.Window()
        window.set_default_size(200, 200)
        window.set_title("a2")
        layout = Gtk.Layout()
        window.add(layout)
        button = Gtk.Button(label="OK I give up2")
        label = Gtk.Label(label="Aligment2")
        layout.put(button, 40, 60)
        layout.put(label, 155, 80)
        #window.connect("destroy", self.aab)
        window.connect("destroy", lambda q: Gtk.main_quit())
        window.show_all()

    def run(self):
        print str(self.__x)
        if str(self.__x) == "19":
            print("hurray")
            #a3()


class Foo(threading.Thread):

    def __init__(self, x):
        self.__x = x
        threading.Thread.__init__(self)
        window = Gtk.Window()
        window.set_default_size(200, 200)
        window.set_title("a1")
        layout = Gtk.Layout()
        window.add(layout)
        button = Gtk.Button(label="OK I give up")
        label = Gtk.Label(label="Aligment")
        layout.put(button, 40, 60)
        layout.put(label, 155, 80)
        #window.connect("destroy", self.aab)
        window.connect("destroy", lambda q: Gtk.main_quit())
        window.show_all()

    def run(self):
        print str(self.__x)
        if str(self.__x) == "19":
            print("hurray")
            #a3()

#for x in xrange(20):
Foo(1).start()
time.sleep(1)
Foo2(2).start()
time.sleep(1)
Foo3(3).start()
time.sleep(1)
Foo4(4).start()
time.sleep(1)
Foo5(5).start()

#a3()

##import thread / ing
#from time import sleep
#from gi.repository import Gtk

#class a1:
    #def aab(self, widget):
        #a1()
    #def __init__(self):
        #window = Gtk.Window()
        #window.set_default_size(200, 200)
        #window.set_title("a1")
        #layout = Gtk.Layout()
        #window.add(layout)
        #button = Gtk.Button(label="OK I give up")
        #label = Gtk.Label(label="Aligment")
        #layout.put(button, 40, 60)
        #layout.put(label, 155, 80)
        #window.connect("destroy", self.aab)
        #window.show_all()

#class a2:
    #def aaab(self, widget):
        #a2()
    #def __init__(self):
        #window = Gtk.Window()
        #window.set_default_size(200, 200)
        #window.set_title("a2")
        #layout = Gtk.Layout()
        #window.add(layout)
        #button = Gtk.Button(label="OK I give up")
        #label = Gtk.Label(label="Aligment")
        #layout.put(button, 50, 90)
        #layout.put(label, 50, 60)
        #window.connect("destroy", self.aaab)
        #window.show_all()

#class a3:
    #def aaab(self, widget):
        #a2()
    #def __init__(self):
        #sleep(2)
        #window = Gtk.Window()
        #window.set_default_size(200, 200)
        #window.set_title("a2")
        #layout = Gtk.Layout()
        #window.add(layout)
        #button = Gtk.Button(label="OK I give up")
        #label = Gtk.Label(label="Aligment")
        #layout.put(button, 50, 90)
        #layout.put(label, 50, 60)
        #window.connect("destroy", self.aaab)
        #window.show_all()



#a3()



if __name__ == '__main__':
    #a1()
    #a2()
    #Foo()
    Gtk.main()