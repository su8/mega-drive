/* getsputs.c -- using gets() and puts() */
#include <stdio.h>
#include <stdlib.h>
#define STRLEN 81
int main(void)
{
    char words[STRLEN];

    puts("Enter a string, please.");
    gets(words);

    printf("Your string twice:\n");
    printf("%s\n", words);

    puts(words);
    puts("Done.");

    return EXIT_SUCCESS;
}