#ifndef NCLYR_CURSES_BROWSE_WIN_H
#define NCLYR_CURSES_BROWSE_WIN_H

#include "cons/printf.h"
#include "window.h"
#include "directory.h"

struct nclyr_win *browse_win_new(void);

#endif
