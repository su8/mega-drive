#!/bin/bash
cd /home/frost/Documents/OpenMu
wine main.exe
exit 0
