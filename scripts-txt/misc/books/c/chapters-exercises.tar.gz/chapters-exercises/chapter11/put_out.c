/* put_out.c -- using puts() */
#include <stdio.h>
#include <stdlib.h>
#define DEF "I am a #defined string."
int main(void)
{
    char str1[] = "An array was initialized to me";
    const char *str2 = "A pointer was initialized to me.";

    puts("I'm an arguments to puts().");
    puts(DEF);
    puts(str1);
    puts(str2);
    puts(&str1[5]);
    puts(str2+4);

    return EXIT_SUCCESS;
}