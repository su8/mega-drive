// convert.c -- converts inch to cm
#include <stdio.h>
int main(void)
{

    float inch, entered_inch;
    printf("inch to cm converter, enter inch: ");
    scanf("%f", &entered_inch);
    inch = entered_inch * 2.54;

    printf("There are %.6g cm in %.6g inch\n", inch, entered_inch);
    /* cast a number to convert it - (int) 2.5324423 will result 3
    '%.6g' will remove the trailing zeroes, %f returns float
    */
    return 0;
}
