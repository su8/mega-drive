#import zipfile, os

#def makeArchive(fileList, archive):
    #"""
    #'fileList' is a list of file names - full path each name
    #'archive' is the file name for the archive with a full path
    #"""
    #try:
        #a = zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED)
        #for f in fileList:
            #print("archiving file {0}".format(f))
            #a.write(f)
        #a.close()
        #return True
    #except: return False

#def dirEntries(dir_name, subdir, *args):
    #'''Return a list of file names found in directory 'dir_name'
    #If 'subdir' is True, recursively access subdirectories under 'dir_name'.
    #Additional arguments, if any, are file extensions to match filenames. Matched
        #file names are added to the list.
    #If there are no additional arguments, all files found in the directory are
        #added to the list.
    #Example usage: fileList = dirEntries(r'H:\TEMP', False, 'txt', 'py')
        #Only files with 'txt' and 'py' extensions will be added to the list.
    #Example usage: fileList = dirEntries(r'H:\TEMP', True)
        #All files and all the files in subdirectories under H:\TEMP will be added
        #to the list.
    #'''
    #fileList = []
    #for file in os.listdir(dir_name):
        #dirfile = os.path.join(dir_name, file)
        #if os.path.isfile(dirfile):
            #if not args:
                #fileList.append(dirfile)
            #else:
                #if os.path.splitext(dirfile)[1][1:] in args:
                    #fileList.append(dirfile)
        ## recursively access file names in subdirectories
        #elif os.path.isdir(dirfile) and subdir:
            #print("Accessing directory:", dirfile)
            #fileList.extend(dirEntries(dirfile, subdir, *args))
    #return fileList

#if __name__ == '__main__':
    #folder = '/home/frost/github-zipped/'
    #zipname = '/home/frost/test.zip'
    #makeArchive(dirEntries(folder, True), zipname)
#fileList = ['/home/frost/github projects/']
#a = zipfile.ZipFile('/home/frost/test.zip', 'w', zipfile.ZIP_DEFLATED)
#for f in fileList:
    #print("archiving file {0}".format(f))
    #a.write(f)
#a.close()
#import os, zipfile
#from os.path import join
#def zipfolder(foldername, filename, includeEmptyDIr=True):
    #empty_dirs = []
    #zip = zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED)
    #for root, dirs, files in os.walk(foldername):
        #empty_dirs.extend([dir for dir in dirs if os.listdir(join(root, dir)) == []])
        #for name in files:
            #zip.write(join(root ,name))
        #if includeEmptyDIr:
            #for dir in empty_dirs:
                #zif = zipfile.ZipInfo(join(root, dir) + "/")
                #zip.writestr(zif, "")
        #empty_dirs = []
    #zip.close()

#if __name__ == "__main__":
    #zipfolder('/home/frost/github-zipped/yoimnotpro.zip', '/home/frost/test.zip')
#import shutil
#shutil.make_archive("/home/frost/test", "bztar", "/home/frost/github projects/")

import zipfile
files = ("/home/frost/github-zipped/yoimnotpro.zip", "/home/frost/github-zipped/yoimnotpro.7z")
zf = zipfile.ZipFile("/home/frost/test.zip", 'w', compression=zipfile.ZIP_DEFLATED)
for file in files:
    zf.write(file)
 
zf.close()