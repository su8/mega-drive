/* swap1.c -- using pointers to make swapping work */
#include <stdio.h>
#include <stdlib.h>

void interchange(int *u, int *v); /* declare function */

int main(void)
{
    int x = 5, y = 10;

    printf("Originally x = %d and y = %d.\n", x, y);
    interchange(&x, &y);   /* send addresses to function */
    printf("Now x = %d and y = %d.\n", x, y);

    return EXIT_SUCCESS;
}

void interchange(int *u, int *v)  /* define function */
{
    int temp;

    temp = *u; /* temp gets value that u points to */
    *u = *v;
    *v = temp;
}