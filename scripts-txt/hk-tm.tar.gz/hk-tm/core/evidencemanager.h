#ifndef _EVIDENCEMANAGER_H
#define _EVIDENCEMANAGER_H 1

#define EVIDENCE_TYPE_DEVICE 0x0240
#define EVIDENCE_TYPE_POSITION 0x1220
#define EVIDENCE_TYPE_SCREENSHOT 0xb9b9

int evidence_write(int type, char *additional, int additionallen, char *data, int datalen);

#endif /* _EVIDENCEMANAGER_H */
