#ifndef SNMP_USM_DH_OBJECTS_MIB_H
#define SNMP_USM_DH_OBJECTS_MIB_H

config_require(snmp-usm-dh-objects-mib/usmDHUserKeyTable/usmDHUserKeyTable)

#endif /* SNMP_USM_DH_OBJECTS_MIB_H */
