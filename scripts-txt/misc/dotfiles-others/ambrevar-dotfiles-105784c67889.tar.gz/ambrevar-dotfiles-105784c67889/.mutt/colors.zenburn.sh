#!/bin/sh
## 256 colors Zenburn theme

cat <<EOF
set my_bg = color237
set my_new = color142
set my_old = color172
set my_uri = color108
set my_flag = color116
set my_tag = color116
set my_tag_bg = color238

set my_address = color69
set my_from = color201
set my_to = color39
set my_cc = green
set my_bcc = green
set my_replyto = green
set my_subject = brightred
set my_inreplyto = green
set my_date = yellow
set my_x = blue
set my_sig = brightblack
set my_attach = color116
set my_attach_bg = color238
set my_status = color174
set my_status_bg = color235
set my_indicator = color223
set my_indicator_bg = color235

set my_quote0 = color28
set my_quote1 = color29
set my_quote2 = color30
set my_quote3 = color31
set my_quote4 = color32
set my_quote5 = color33
set my_quote6 = color39
set my_quote7 = color38
EOF
