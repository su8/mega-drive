/* curs.c -- example1 */
/* gcc -Wall -O2 curs.c -o main -lncurses */
#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
int main(void)
{
    initscr(); /* start curses mode*/
    printw("Hello World !!!"); /* printf hello world*/
    refresh(); /* print it on to the real screen */
    getch(); /* wait for user input */
    endwin(); /* end curses mode */

    return EXIT_SUCCESS;
}