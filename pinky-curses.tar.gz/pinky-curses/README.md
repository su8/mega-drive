ncurses based status line/bar program.

![](6.png)

# Installation

```bash
gcc -std=c99 -D_POSIX_C_SOURCE=200112L -Wall -Wextra -O2 ncurses.c -o pinky_curses -lncurses
```

# Usage

```bash
# ^B - Blue , ^M - Magenta , ^Y - Yellow
while true; do echo "^BOh ^Mhello ^Ydear";sleep 1;done | ./pinky_curses

# CTRL + C to stop it
```

# Requirements

* gcc/clang
* ncurses
* glibc/libc
