OpenBSD_package_finder
======================

Basically when you run it for first time, it downloads and saves the content from ftp://ftp.openbsd.org/pub/OpenBSD/{release_version}/packages/{cpu_arch}/SHA256 in your users home directory as text file, after that when you perform a package search like pack openvpn it will show you all openvpn strings that match it, so you can use pkg_add to install the openvpn package. I find it really strange that OpenBSD doesn't have a search tool (except the ports) and we are left to invent our own solutions.

Download the program, exctract the archive and:

    cp pack /usr/local/bin/
    chmod +x /usr/local/bin/pack

## Package search:

    pack nginx
    
## Requirements:
* python 2 or 3 symlinked as python