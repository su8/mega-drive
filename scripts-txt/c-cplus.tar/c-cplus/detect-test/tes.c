/* tes.c --  */
#include <stdio.h>
#include <stdlib.h>
#define MAX_STRLEN 128

void detect_wm_theme(char *str, const char *wm_str);
void main_text_output(char *data[], char *data_names[]);

int main(void)
{

    char wm_theme_str[MAX_STRLEN] = "Unknown";
    char wm_str[MAX_STRLEN] = "Unknown";


    char *detected_arr[16] =
    {
        wm_str,
        wm_theme_str,
    };

    char *detected_arr_names[16] =
    {
        "WM Theme: ",
        "GTK: "
    };

    detect_wm_theme(wm_theme_str, wm_str);

    main_text_output(detected_arr, detected_arr_names);

    return EXIT_SUCCESS;
}

void detect_wm_theme(char *str, const char *wm_str)
{
    char exec_str[MAX_STRLEN];
    FILE *wm_theme_file;

    snprintf(exec_str, MAX_STRLEN, "sh detectwm %s 2> /dev/null", wm_str);

    wm_theme_file = popen(exec_str, "r");
    fgets(str, MAX_STRLEN, wm_theme_file);
    pclose(wm_theme_file);

    return;
}

void main_text_output(char *data[], char *data_names[])
{
    int i;

    for (i = 0; i < 2; i++)
        printf("%s %s\n", data_names[i], data[i]);

    return;
}