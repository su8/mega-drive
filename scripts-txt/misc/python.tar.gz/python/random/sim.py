import subprocess
from gi.repository import Gtk, Gdk



        #try:
          #f = open("tt.txt")
          #while True:
            #line = f.readline()
            #if len(line) == 0:
              #break
            #self.textbuffer.insert(self.textbuffer.get_end_iter(),"{0}".format(line))
            ##print(line, end="", flush=True)
            ##sleep(0.05)
            #sleep(0.07)
        #except KeyboardInterrupt:
          #print("Why did you pressed CTRL-C ?")
        #finally:
          #if f:
            #f.close() 







class ss:

    def on_togglebutton1_toggled(self, widget):
        print("prev clicked")

    def on_togglebutton2_toggled(self, widget):
        #print("next clicked")
        #self.textbuffer2.set_text("dsa2")
        try:
          f = open("message1.txt")
          while True:
            line = f.readline()
            if len(line) == 0:
              break
            self.textbuffer2.insert(self.textbuffer2.get_end_iter(),"{0}".format(line))
            #print(line, end="", flush=True)
            #sleep(0.05)
            #sleep(0.07)
        except KeyboardInterrupt:
          print("Why did you pressed CTRL-C ?")
        finally:
          if f:
            f.close() 

    def entry1_activated(self, widget):
        self.textbuffer.insert(self.textbuffer.get_end_iter(),"[frost@frost-pc ~]$ {0}\n".format(self.entry1.get_text()))
        if self.entry1.get_text() == "pwd":
            pwd_requested = subprocess.check_output("pwd", shell=True)
            self.textbuffer.insert(self.textbuffer.get_end_iter(), "{0}".format(pwd_requested))
        if self.entry1.get_text() == "uname -a":
            uname_requested = subprocess.check_output("uname -a", shell=True)
            self.textbuffer.insert(self.textbuffer.get_end_iter(), "{0}".format(uname_requested))
            #self.textbuffer2.set_text("dsa")

    def __init__(self):

        self.intf = Gtk.Builder()
        self.intf.add_from_file('simulator.glade')
        self.intf.connect_signals(self)


        #self.vbox = self.intf.get_object("box1")
        #self.upload_label = self.intf.get_object("label1")
       # self.vbox.remove(self.upload_label)



        self.entry1 = self.intf.get_object("entry1")
        self.entry1.set_placeholder_text('>>> ')
        self.text = self.intf.get_object("textview1")
        self.text2 = self.intf.get_object("textview2")
        self.text.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.2, 0.2, 0.2, 0.2))
        self.text.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 1, 1, 1))
        self.textbuffer = self.text.get_buffer()
        self.text2.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.2, 0.2, 0.2, 0.2))
        self.text2.override_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(1, 1, 1, 1))
        self.textbuffer2 = self.text2.get_buffer()



        self.entry1.connect("activate", self.entry1_activated)


        self.window = self.intf.get_object("window1")
        self.window.override_background_color(Gtk.StateFlags.NORMAL, Gdk.RGBA(0.5, 0.5, 0.5, 0.5))

        self.scrolledwindow = self.intf.get_object("scrolledwindow1")
        self.scrolledwindow.set_hexpand(True)
        self.scrolledwindow.set_vexpand(True)


        self.screen = Gdk.Screen.get_default()
        self.css_provider = Gtk.CssProvider()
        self.css_provider.load_from_path('style.css')
        self.priority = Gtk.STYLE_PROVIDER_PRIORITY_USER
        self.context = Gtk.StyleContext()
        self.context.add_provider_for_screen(self.screen, self.css_provider, self.priority)

        self.window.connect("delete-event", Gtk.main_quit)
        self.window.show_all()



if __name__ == '__main__':
    ss()
    Gtk.main()