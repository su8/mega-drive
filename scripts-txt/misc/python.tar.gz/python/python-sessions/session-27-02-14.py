Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> import types
>>> from functools import wraps
>>> class Profiled:
	def __init__(self, func):
		wraps(func)(self)
		self.ncalls = 0
	def __call__(self, *args, **kwargs):
		self.ncalls += 1
		return self.__wrapped__(*args, **kwargs)
	def __get__(self, instance, cls):
		if instance is None:
			return self
		else:
			return types.MethodType(self, instance)

		
>>> @Profiled
def add(x, y):
	return x + y

>>> add(3,4)
7
>>> class Spam:
	@Profiled
	def bar(self, x):
		print(self, x)

		
>>> add.ncalls
1
>>> Spam().bar(3)
<__main__.Spam object at 0x7fb77dc4f1d0> 3
>>> Spam().bar(213)
<__main__.Spam object at 0x7fb77d72fdd0> 213
>>> Spam.bar.ncalls
2
>>> def log_getattribute(cls):
	# Get the original implementation
	orig_getattribute = cls.__getattribute__
def new_get_attribute(self, name):
	
SyntaxError: invalid syntax
>>> 
>>> def log_getattribute(cls):
	# Get the original implementation
	orig_getattribute = cls.__getattribute__

	
>>> def new_get_attribute(self, name):
	print('getting:', name)
	return orig_getattribute(self, name)
	cls.__getattribute__ = new_get_attribute
	return cls

>>> @log_getattribute
class A:
	def __init__(self, x):
		self.x = x
	def spam(self):
		pass

	
>>> a = A(42)
Traceback (most recent call last):
  File "<pyshell#50>", line 1, in <module>
    a = A(42)
TypeError: 'NoneType' object is not callable
>>> def log_getattribute(cls):
	# Get the original implementation
	orig_getattribute = cls.__getattribute__
	def new_get_attribute(self, name):
		print('getting:', name)
		return orig_getattribute(self, name)
	cls.__getattribute__ = new_get_attribute
	return cls

>>> @log_getattribute
class A:
	def __init__(self, x):
		self.x = x
	def spam(self):
		pass

	
>>> a = A(42)
>>> a.x
getting: x
42
>>> a.spam()
getting: spam
>>> class LoggedGetattribute:
	def __getattribute__(self, name):
		print('getting:', name)
		return super().__getattribute__(name)
class A:
	
SyntaxError: invalid syntax
>>> class LoggedGetattribute:
	def __getattribute__(self, name):
		print('getting:', name)
		return super().__getattribute__(name)

	
>>> class A(LoggedGetattribute):
	def __init__(self, x):
		self.x = x
	def spam(self):
		pass

	
>>> a = A(42)
>>> a.x
getting: x
42
>>> a.spam()
getting: spam
>>> 
