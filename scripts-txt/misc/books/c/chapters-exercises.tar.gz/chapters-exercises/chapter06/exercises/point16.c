/* 16. Daphne invests $100 at 10% simple interest. (That is, every year, the investment earns
an interest equal to 10% of the original investment.) Deirdre invests $100 at 5% interest
compounded annually. (That is, interest is 5% of the current balance, including previous
addition of interest.) Write a program that finds how many years it takes for the value
of Deirdre’s investment to exceed the value of Daphne’s investment. Also show the two
values at that time. */
#include <stdio.h>

#define RATE_SIMP 0.10
#define RATE_COMP 0.05
#define INIT_AMT 100.0
int main(void)
{
    double daphne = INIT_AMT;
    double deidre = INIT_AMT;
    int years = 0;
    
    while (deidre <= daphne)
    {
        daphne += RATE_SIMP * INIT_AMT;
        deidre += RATE_COMP * deidre;
        ++years;
    }
    printf("Investment values after %d years:\n", years);
    printf("Daphne: $%.2f\n", daphne);
    printf("Deidre: $%.2f\n", deidre);

    return 0;
}
