/*

Write a program that reads integers until 0 is entered. After input terminates, the
program should report the total number of even integers (excluding the 0) entered, the
average value of the even integers, the total number of odd integers entered, and the
average value of the odd integers.

*/

#include <stdio.h>

int main(void)
{
    unsigned short int num, count;
    unsigned short int sum_odd,sum_even;

    while (1 == scanf("%hu", &num))
    {
        if (num != 0)
        {
            if (!(num % 2))
                sum_even += num;
            else
                sum_odd += num;

            count++;
        }
        else
            break;
    }

    printf("Total number of even integers = %hu\n", sum_even);
    printf("Average value for the even integers = %0.2f\n", (float) sum_even / count);

    printf("Total number of odd integers = %hu\n", sum_odd);
    printf("Average value for the odd integers = %0.2f\n", (float) sum_odd / count);

    return 0;
}