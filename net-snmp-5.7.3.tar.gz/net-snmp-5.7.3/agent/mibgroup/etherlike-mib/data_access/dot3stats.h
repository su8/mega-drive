/*
 * module to include the modules
 */

#if defined(linux)
config_require(etherlike-mib/data_access/dot3stats_linux)
#endif
