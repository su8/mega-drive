#ifndef error_h_
#define error_h_

extern void warn (const char * fmt, ...) ;
extern void error (const char * fmt, ...) ;

#endif /* error_h_ */

