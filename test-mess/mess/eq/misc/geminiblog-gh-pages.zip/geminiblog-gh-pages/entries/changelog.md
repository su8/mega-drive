#Changelog

* setup showing entry based on id
* default view is a snippetView of 10 recent entries
* clicking on any loads sidebar view and displays that entry in main section
* write function getEntryById()
* add tags support, getEntriesByTags()
* make tag links in snippet head
* add and setup showArchive and showAllTags under listview
* write snippetView()
* and detailsView()
* setup markdown css
* sidebar hidden, lists of entries shown in archiveView
* started writing doc
* make it responsive
* script the contact part
* set different z indexes to increase touch/click visibility - not needed
* maybe write a 404/50x error message
* added shadows and transitions to elements
* changed colorscheme css

###TODO:
* continue writing doc
* use it as own blog - match/update css with github.io page 
* add a wrapper function to automate the xFtech() and marked() method, with error correction(40x, 50x) and variable replacement
* add a date parser to normalize all different date outputs
* show a default message while the entry is fetched.
* start writing validation/error checks
* setup DISQUS for comments - one page multiple disqus box iframes displayed by entry-id
* MAKE IT ASYNC!!!!

