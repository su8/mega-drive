var contactPageTemplate = [
    "<div class='contact-page'>",
    "<div class='col-md-7 col-sm-12'>",
        "<h2>Contact Us</h2>",
        "<p>",
            "For technical questions/issues head over to our forum at ",
            "<a href='http://www.linuxquestions.org/questions/aryalinux-120/' target='_blank'>linuxquestions.org</a>",
        "</p>",
        "<p>",
            "Please check the forum for issues that you might be facing and have been answered.",
        "</p>",
        "<p>",
            "For any other queries/suggestions/comments/praise;-) please mail us at ",
            "<a href='mailto: aryalinux11@gmail.com'>aryalinux11@gmail.com</a>",
        "</p>",
        "</div>",
    "</div>",
].join('');

geminiBlog.contactPage = function() {
    scroll(0,0);
    document.title = "Contact Us";
    var container = utils.clearElements($("#entries-wrapper"));
    var contactPageHTML = utils.str2WrappedDOMElement(contactPageTemplate);

    container.appendChild(contactPageHTML.childNodes[0]);
    geminiBlog.showDownloadSidebar();
};
