pdf2img written in C
=======
<img src="img/preview1.png" alt="" /> <img src="img/preview2.png" alt="" />

This is the C version of pdf2img. C is new language to me and I'm really interested to master it fully like python. 

The program will be decorated by your gtk theme, there isn't any predefined background colour or css theming involved as it was in the previous two versions.

Open up **my_constants.h** and change **SHOW_IMAGES_ON_BUTTONS** value, by default it's 0 which means the buttons won't show any icons.

## Installation

    make && sudo make install clean

## Requirements

* gcc - compiler
* gtk3 - gui toolkit
* glibc / libc - standard C libs
* pkg-config - will locate the gtk libs
* ghostscript - pdf processing