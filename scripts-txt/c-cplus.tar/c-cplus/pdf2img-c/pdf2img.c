/* compile with:
gcc -Wall -O2 -o main 2.c `pkg-config --cflags --libs gtk+-3.0` 
*/
#include <gtk/gtk.h>

GtkWidget *window, *box, *calendar, *table;
GtkWidget *source_label, *source_entry, *source_button,
*source_folder_button, *frame;
//GtkSpinButton* spinbutton;
int main (int argc, char *argv[])
{

    gtk_init(&argc, &argv);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_container_set_border_width(GTK_CONTAINER(window), 6);
    gtk_window_set_title(GTK_WINDOW(window), "PDF to IMG");
    //gtk_container_set_size_request(GTK_CONTAINER(window), 200, 20);

    box = gtk_box_new(FALSE, 0);
    gtk_container_add(GTK_CONTAINER(window), box);

    frame = gtk_frame_new("Choose DVD");
    gtk_box_pack_start(GTK_BOX(box), frame, TRUE, TRUE, 0);

    table = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(table), 7);
    gtk_grid_set_column_spacing(GTK_GRID(table), 5);
    gtk_container_set_border_width(GTK_CONTAINER(table), 2);
    //gtk_container_add(GTK_CONTAINER(box), table);

    source_label = gtk_label_new("Input file or folder:");
    source_entry = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(source_entry), "dvd://");
    source_button = gtk_button_new_with_label("Open file");
    source_folder_button = gtk_button_new_with_label("Open folder");
    //spinbutton = gtk_spin_button_new(1,1, 9999);


    /*g_signal_connect(G_OBJECT(source_button), "clicked", G_CALLBACK(on_select_source_path), NULL);
    g_signal_connect(G_OBJECT(source_folder_button), "clicked", G_CALLBACK(on_select_source_path), (gpointer) 1);*/


    calendar = gtk_calendar_new();

    gtk_grid_attach(GTK_GRID(table), source_entry, 1, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(table), source_button, 2,2,1,2);
    gtk_grid_attach(GTK_GRID(table), source_folder_button, 1,4,1,1);
    gtk_grid_attach(GTK_GRID(table), calendar, 1,5,1,1);
    //gtk_grid_attach(GTK_GRID(table), spinbutton, 1,6,1,1);

    gtk_container_add(GTK_CONTAINER(frame), table);

    g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}
