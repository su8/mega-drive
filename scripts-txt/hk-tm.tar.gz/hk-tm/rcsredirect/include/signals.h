
/* $Id: signals.h 790 2009-08-03 14:34:04Z alor $ */

#ifndef __SIGNAL_H
#define __SIGNAL_H

void signal_handler(void);

#endif

/* EOF */

// vim:ts=3:expandtab

