var postTemplate = [
    "<article class='details-wrapper'>",
        "<div class='details-head'>",
            "<div class='details-head-wrapper'>",
                "<span class='details-separator'> » </span>",
                "<span class='details-date label label-default'></span>",
            "</div>",
        "</div>",
        "<div id='details-body'>",
        "</div>",
        "<div class='details-footer'>",
            "<hr>",
            "<span>",
                "( The source markdown file for this entry can be found <a id='md-src'>Here</a> )",
            "</span>",
        "</div>",
    "</article>"
].join('');

var ajax = function(o) {
    var xhr = new XMLHttpRequest();
    xhr.timeout = 4000;
    if (o.mimeType) {
        xhr.overrideMimeType('text/plain; charset=UTF-8');
    }
    xhr.ontimeout = function() {
        console.error("Request timed out: " + o.url);
    };
    xhr.onerror = o.error ? o.error: function() {
        console.log(xhr);
    };
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            o.success(xhr.responseText);
        }
    };
    xhr.open('GET', o.url, true);
    xhr.send(null);
};
var convertMDtoHTML = function(md) {
    var regularTable = new RegExp('<table>', 'g');
    var markDownOptions = {
        renderer: new marked.Renderer(),
        gfm: true,
        tables: true,
        breaks: false,
        pedantic: false,
        sanitize: true,
        smartLists: true,
        smartypants: false,
        //langPrefix: 'hljs ',
        highlight: function(code, lang) {
            return hljs.highlightAuto(code, [lang]).value;
        }
    };
    return marked(md, markDownOptions)
        .replace(regularTable, '<table class="table table-hover">');
};
