#!/usr/bin/python2

import subprocess

cmd = 'grep temp /proc/acpi/thermal_zone/TZ00/temperature'
p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

output = p.stdout.read()
output = output.split(': ')[1].split('\n')[0]

print("%s" % output)