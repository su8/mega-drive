This is my personal fork of [dwm](http://dwm.suckless.org/).

Only the **dwm.c** file here is vanilla, and the patches are applied by the **patchdwm** script.

If you want to see my previous commits head over [here](https://github.com/wifiextender/dotfiles/commits/master)

## Installation

    bash patchdwm
    make
    sudo make install


## Goodies

Do you want [statusbar](https://github.com/wifiextender/dwm-bar) program <img src="https://raw.githubusercontent.com/wifiextender/dwm-bar/master/img/pic.png" alt="" /> ?

I've recently switched to dwm, read my blog [post](http://wifiextender.github.io/post/openbox-to-dwm/) for more information.
