------------------------------------------------------------------------

2016-02-02

##### Pull an sqlite DB from an Android app

```java
adb shell "run-as *package.name* chmod 0644 /data/data/*package.name*/databases/*db.name*"
adb shell "cat /data/data/*package.name*/databases/*db.name* > /sdcard/Download/foo"
adb pull /sdcard/Download/foo
```

Easier, with Android 5+:

```java
adb exec-out run-as *package.name* cat databases/*db.name* > foo
```

------------------------------------------------------------------------

2015-09-10

##### Android status bar background color change

Easily change android status bar background color if device is running android 5.x or more recent.

```java
public static void setStatusBarBackgroundColor( Activity activity, int color ) {
        if ( Build.VERSION.SDK_INT >= 21 ) {
            Window window = activity.getWindow();
            try {
                window.addFlags( 0x80000000 );
                window.clearFlags( 0x04000000 );
                Class cls = window.getClass();
                Method method = cls.getDeclaredMethod( "setStatusBarColor", new Class[] { Integer.TYPE } );
                method.invoke( window, color );
            } catch ( Exception e ) {
                Log.warn( "unexpected failure: " + e );
            }
        }
    }        
```
------------------------------------------------------------------------

2015-07-08

##### "You should not use the xxxhdpi qualifier for UI elements other than the launcher icon."

A 9-patch image, displayed properly on all xhdpi and xxhdpi
screens, was displayed with the black border lines on a xxxhdpi
screen. No idea why.
Android [doc](http://developer.android.com/guide/practices/screens_support.html)
provides a small not very visible mention that "You should not use
the xxxhdpi qualifier for UI elements other than the launcher
icon.". So I removed all xxxhdpi assets and the display on the
xxxhdpi screen worked again..

------------------------------------------------------------------------

2015-04-08

##### Ingress/IITC draw tools: convert fields to links

In order to plan great ops, IITC draw tools + bookmarks + autodraw
is great. However, to create a field, nothing beats selecting
three portals from bookmarks and doing "draw" in autodraw. But it
creates a polygon, and it creates a solid color inside the
polygon. For one field this is okay, but for dozens of layers, it
sucks: the inside of the field is completely shadowed by the
polygons.

With this simple perl script, one can export the draw, convert the
polygons to lines, and inport the draw back.

```perl
perl -pi -e 's/{"type":"polygon","latLngs":\[{"lat":(.*?),"lng":(.*?)},{"lat":(.*?),"lng":(.*?)},{"lat":(.*?),"lng":(.*?)}\],"color":"(.*?)"}/{"type":"polyline","latLngs":[{"lat":$1,"lng":$2},{"lat":$3,"lng":$4}],"color":"$7"},{"type":"polyline","latLngs":[{"lat":$3,"lng":$4},{"lat":$5,"lng":$6}],"color":"$7"},{"type":"polyline","latLngs":[{"lat":$5,"lng":$6},{"lat":$1,"lng":$2}],"color":"$7"}/g' pasted_draw
```

------------------------------------------------------------------------

2015-04-01

##### Android: automatically remove unused strings

I haven't found an easy way to automatically remove unused strings
for an android project. Android lint does all the job of finding
them though, so a simple script on top of its input does the job.

```bash
for i in $(lint . | grep 'The resource R.string.* appears to be unused' |
    perl -ne 'print "$1\n" if /R.string.(.*) appears/'); do
      perl -pi -e 's/.*<string name="'$i'".*\n//' res/values*/strings.xml
done
```
------------------------------------------------------------------------

2014-03-15

##### QuiLivreChezMoi.com and DeliverAtMyHouse.com

J'ai créé avec un ami un site web qui référence les
professionnels de la restauration qui fournissent
la [livraison à domicile](http://quilivrechezmoi.com/)
de pizza et cie, QuiLivreChezMoi.com.

I and a friend have created a website referencing food
businesses providing [homedelivery](http://deliveratmyhouse.com/) of pizza and alike, DeliverAtMyHouse.com.

------------------------------------------------------------------------

2014-03-12

##### CSS media queries: what's the size of that display?

When trying to test and optimize a web page according to various
browsers, troubleshooting is sometimes difficult when I am not
sure of the display size selected by CSS media queries. What's the
actual "display width" on iPhone 4? On Nexus 5? On whatever tablet
model? It can help a lot tuning the various slight changes needed
to implement a good "responsive" site.

I've written a
small [Perl
script](http://zarb.org/%7Egc/t/prog/display_size_media_query.pl) that generates a
small [web page](http://booh.org/s.html) which displays
screen size according to media queries.

| phone          | browser        | mode      | width | height |
|----------------|----------------|-----------|-------|--------|
| Nexus 5        | Chrome/Firefox | portrait  | 360   | 518    |
| Nexus 5        | Chrome/Firefox | landscape | 598   | 286    |
| Nexus 7 (2012) | Chrome         | portrait  | 600   | 792    |
| Nexus 7 (2012) | Chrome         | landscape | 962   | 440    |
| Nexus 7 (2012) | Firefox        | portrait  | 600   | 822    |
| Nexus 7 (2012) | Firefox        | landscape | 960   | 470    |

------------------------------------------------------------------------

2013-09-26

##### Android: customizing tab indicator color of action bar

I needed to change the default thin bar of color appearing below
the selected tab in an action bar layout with tab bar ([what are you talking about?](https://developer.android.com/images/training/basics/actionbar-theme-custom-tabs@2x.png)).

[Official
doc](https://developer.android.com/training/basics/actionbar/styling.html) describes customizing the background without separating
the background for the text and the thin bar of color for
selection, which looked odd to
me; [official
doc](http://developer.android.com/guide/topics/ui/actionbar.html), elsewhere, specifically
describes `actionBarTabBarStyle` as "a style resource for
the thin bar that appears below the navigation tabs", but when
changed the tiny bar *between* tabs is actually changed.

Finally, looking inside what is generated by the
nice [Android
Action Bar Style Generator](http://jgilfelt.github.io/android-actionbarstylegenerator/), I got what I missed: a single
background image is actually used for both text background and the
thin bottom bar of color, with the help of 9-patch images.
Actionbar doc might be improved with such an information.

------------------------------------------------------------------------

2013-05-14

##### Android: javax.net.ssl.SSLPeerUnverifiedException: No peer certificate

On a test Android device, all https URLs suddenly failed with 
`javax.net.ssl.SSLPeerUnverifiedException: No peer certificate` although
the certificates are accepted on a PC browser and on other Android devices.

Turned out the test Android device had lost power for enough time priorly for the date/time to be off by a few years, and that
was the way the underlying library was reporting the certificates were not valid for the current date/time. Thanks Odie! (when
will SSL libraries be able to report meaningful error informations?)

------------------------------------------------------------------------

2013-01-10

##### Postfix relaying mail in SSL + user authentication on Mageia 2

Basics is

```bash
smtp_tls_security_level = encrypt
smtp_sasl_auth_enable = yes
smtp_sasl_password_maps = hash:/etc/postfix/sasl_passwd
smtp_sasl_tls_security_options = noanonymous
```

and a proper user/password in `/etc/postfix/sasl_passwd`. But then
postfix insisted on showing in logs "SASL authentication failure: No worthy mechs found"
and the doc only referred to `smtp_sasl_tls_security_options` for that problem.
It took a lot of time to discover I needed to install
`lib64sasl2-plug-plain-2.1.23-19.mga2`, I got no clue in
any logs for that kind of problem - and I got a hint as the needs
to install `libsasl2-modules` on debian, but I wrongly installed
`libsasl2-plug-plain-2.1.23-19.mga2` instead of the 64 bit version :(

Now two questions: what 64 bit systems really have brought us,
other than multiple pain in the ass, 3% performance gain?

Why the package `lib64sasl2-plug-plain` is split, it only makes
sense to split lib packages when they have further specific
dependencies we might not want, which is absolutely not the case
here.

------------------------------------------------------------------------

2012-05-31

##### Android on Mageia 2

Normally udev rules must be added in `/etc/udev/rules.d`,
but `51-android.rules` doesn't work there to fix development
device permissions (how do we trace what udev loads?). I noticed udev own rules are
in `/lib/udev/rules.d` so I moved it there and it worked.

------------------------------------------------------------------------

2012-05-15

##### Linux on Gigabyte H77-DS3H

I bought a Core i7-3770 Ivy Bridge based computer with a Gigabyte
H77-DS3H motherboard. 

I tried to boot from Mageia 2 RC but the
computer would automatically reboot itself at CDROM boot load
time. 

I tried to tweak a few BIOS settings while not understanding
half of them, to no avail. 

Finally I chose "load optimized
defaults" and suddenly it would boot. 

Then I got no particular
problems afterwards, except the sound was not working up
until I manually installed the pulseaudio package (something
draksound wasn't able to do or advice). 

The 3d works beautifully
out of the box, and it's so fucking smooth I can't believe this
is happening on Linux with free drivers (webgl in chrome, google-earth in 1920x1080,
neverball; xorg 1.11.4 of 2012-01-27, Mesa DRI Intel(R) Ivybridge Desktop,
2.1 Mesa 8.0.2).

------------------------------------------------------------------------

2012-03-15

##### Accessing a local service with network latency

Ssh port forwarding (`-L` or `-R` in openssh)
is so useful I use it regularly. Today I wanted to simulate
network latency but felt it would be tedious to install some
server software elsewhere than on my dev machine. No worry,
ssh port forwarding can get you that! (pause: how would you
do it? you found an idea? great)

Easy. Say your server software is on port 1234 on your dev
machine. `ssh -L 1235:localhost:1234 some.server.org`
on one console, `ssh -R 1234:localhost:1234
some.server.org` on another console, and voila: you can
access directly your service on `localhost:1234`, or
with network latency on `localhost:1235` (actually,
you get twice worse performance as if the service was on
some.server.org but hey, nothing's totally free in life).

Ssh port forwarding is a gift from gods.

------------------------------------------------------------------------

2012-03-15

##### Lftp, fish, ssh identity file (key-based login)

I like lftp a lot. It's very powerful, in particular the
"mirror" commands does a lot of the tedious job for me.
The `fish://` protocol works "over an ssh connection
to a unix account" which is very useful. Some ssh-based
accounts allow only key-based login (a private key for RSA or
DSA authentication). It's possible to use it with lftp/fish
by specifying that parameter in the lftp console:

```bash
set fish:connect-program "ssh -i /path/to/private/key"
```

------------------------------------------------------------------------

2011-07-08

##### Mass import to Google Calendar from text

There are ways to import and export calendars from well known
calendar programs but no simple documented way to import from
text, and I needed that to import the dates of lessons I'll soon
take. So here's a base that works. Duplicate the last part into
more stuff.

```bash
BEGIN:VCALENDAR
PRODID:-//Google Inc//Google Calendar 70.9054//EN
VERSION:2.0
CALSCALE:GREGORIAN
METHOD:PUBLISH
X-WR-TIMEZONE:Europe/Zurich
BEGIN:VTIMEZONE
TZID:Europe/Zurich
X-LIC-LOCATION:Europe/Zurich
BEGIN:DAYLIGHT
TZOFFSETFROM:+0100
TZOFFSETTO:+0200
TZNAME:CEST
DTSTART:19700329T020000
RRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU
END:DAYLIGHT
BEGIN:STANDARD
TZOFFSETFROM:+0200
TZOFFSETTO:+0100
TZNAME:CET
DTSTART:19701025T030000
RRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU
END:STANDARD
END:VTIMEZONE

BEGIN:VEVENT
DTSTART:20110708T120000Z
DTEND:20110708T140000Z
SUMMARY:whatever
TRANSP:OPAQUE
END:VEVENT

END:VCALENDAR
```

------------------------------------------------------------------------

2011-06-30

##### Fight passwords stored unsecurely

We all know passwords are either not securely transmitted,
not securely stored, not stored hashed, or all of these :(
[Here's a
simple method to generate a unique password per website](http://zarb.org/%7Egc/html/fight-passwords-stored-unsecurely.html)
so that if your password is compromised, your logins on other
sites aren't; this method doesn't rely on some encrypted or
physical data, but it is probably a little less secure than
using these. Thanks Odie :)

------------------------------------------------------------------------

2011-03-30

##### Android screenshot without rooting the device

I do Android development and taking screenshots is often useful.
However, I don't like running the emulator only for that because,
for one, it's so slow it's a massive PITA, and for two, I often
need some non available or hardly available features (a real
operator network, a camera, GPS or other sensors). Until today I
believed the device had to be rooted (as all apps on the market
state so in the description), and I didn't want to move away from
standard phones, but I learnt today thanks to Michael Blackwood
that in the "ddms" tool of the SDK, a simple "Device/Screen
Capture" will do. Yeah!

------------------------------------------------------------------------

2011-03-01

##### Fast mail searching from within gnus

After odie spent quite some time playing with
[whoosh](http://whoosh.ca/) to build efficient
searching from within mutt, I looked again at how to do that from
within gnus (since not using gnus anymore is a
[scary
idea](http://zarb.org/%7Egc/html/howto-adopt-gnus.html)). Some time ago I already identified the problem of mail
searching, in particular how default mail searching in gnus is
terrible compared to searching in a gmail account, for example. I
asked some gnus-enabled friends about that issue, but they replied
they do not do better and anyway they do not use gnus so much
nowadays, and I assumed it was not possible or at least not easy.
But I should not always trust friends, even if they've proved to
be very worth trusting in the past (e.g.
even [Pixel](http://rigaux.org/) is sometimes human).

It turns out [swish-e](http://swish-e.org/)
and `nnir.el` work great together with no efforts - for
example thanks
to [that
documentation on Emacs website](http://www.emacswiki.org/emacs/IndexMail). The only problem is that
swish-e is very, very memory hungry. For example, to index nnml
directories worth 895 MB (24,000 files), it needs to grow to 1.5
GB of RSS (using the `-e` switch to save memory, of
course). This morning, I naively tried to index 1,800 MB of mails
and my machine, which has 2 GB of real memory and 1 GB of swap,
became so deeply locked I had to reboot it :/. It's a pity there
seems to be no way to create bigger indexes in swish-e without
[having
a unusually large amount of memory installed](http://swish-e.org/docs/swish-faq.html#i_run_out_of_memory_trying_to_index_my_files_).

------------------------------------------------------------------------

2011-02-22

##### git-reflog to recover accidentally dropped patch

Locally use **git-svn**. Hack hack hack, **git-commit**.
More hack, more **git-commit**. Ok I need to synchronize with upstream
now: **git-svn rebase**. Conflict detected between binary
files. Suck it,
**git-rebase --skip**. Argh, there was useful text diffs in
that dropped patch! **git-reflog** to find the old commit,
apply it locally, pheww. **git-svn dcommit**.

------------------------------------------------------------------------

2011-02-16

##### SAX parser: don't stupidly download external DTD's!

Server-side downloading of external DTD's referenced by XML
documents received from the wild can be very dangerous. For
example, feeding a document with the following first line to Java
SAX parser 

```java
org.xml.sax.XMLReader from XMLReaderFactory.createXMLReader
```

```html
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                             "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">"
```

results in a 2 minutes solid lock waiting for data using the
bloody default JDK object **URLConnection**. Even if the
document doesn't contain any entities to resolve, and the parser
is configured to not perform validation! So I'll do that on my
parser now:

```java
parser.setFeature("http://xml.org/sax/features/validation", false);
    parser.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
```

------------------------------------------------------------------------

2010-11-26

##### Emulate data delay on mobile networks

My little [delay_load_resource.php](http://zarb.org/%7Egc/resource/delay_load_resource.php.bin)
is useful to emulate delays on mobile networks; it outputs a resource after a time delay,
so that one may test the behaviour of his website/service/app if used with data
received from a choppy mobile network.

------------------------------------------------------------------------

2010-11-08

##### Don't stupidly reinvent the wheel (JavaScript + URLDecode)

Don't use Google's first match for "javascript urldecode" -
[http://www.webtoolkit.info/javascript-url-decode-encode.html](http://www.webtoolkit.info/javascript-url-decode-encode.html),
the
builtin [decodeURI](http://www.w3schools.com/jsref/jsref_decodeuri.asp)
does exist and works just fine!

------------------------------------------------------------------------

2010-10-22

##### Stopping a runaway SQL query the clean way in PostgreSQL

`pg_cancel_backend` sends a query cancel (SIGINT) signal to
a backend process identified by process ID. The process ID of an
active backend can be found from the `procpid` column in the
`pg_stat_activity` view, or by listing the postgres processes on the
server with ps.

------------------------------------------------------------------------

2010-05-27

##### git-svn rulz

Out of a repo with nearly 20,000 revisions:

```bash
[gc@meuh ~/src/soft/trunk.svn] time svn log --revision=5000 2>&1|tail -2|head -1
0.08user 0.00system 0:22.77 elapsed 0%CPU (0avgtext+0avgdata 0maxresident)k
[gc@meuh ~/src/soft/trunk.svn] time svn log --revision=5000 2>&1|tail -2|head -1
0.07user 0.01system 0:13.99 elapsed 0%CPU (0avgtext+0avgdata 0maxresident)k

[gc@meuh ~/src/soft/trunk.git] time git svn log --revision=5000 2>&1|tail -2|head -1
0.46user 0.12system 0:00.75 elapsed 78%CPU (0avgtext+0avgdata 0maxresident)k
[gc@meuh ~/src/soft/trunk.git] time git svn log --revision=5000 2>&1|tail -2|head -1
0.46user 0.11system 0:00.64 elapsed 90%CPU (0avgtext+0avgdata 0maxresident)k
```

------------------------------------------------------------------------

2010-05-25

##### Transcoding videos from HTC Magic

When shooting a video in "portrait" mode, we need to rotate it, or
else using it in blogs or so forth it will be incorrectly
displayed. Even if mplayer properly replays the videos, when
transcoding, the video is made much too fast. After much
investigations, trials and errors, upgrades of ffmpeg and mplayer
to latest from cooker, I discovered it's probably due to the video
lying about its FPS (or not saving the information). Adding "-fps
17" to mencoder commandline workarounds the problem.

```bash
mencoder sourcefile.3gp -oac mp3lame -ovc lavc -vf rotate=1 -o outputfile -fps 17
```

------------------------------------------------------------------------

2010-02-24

##### Watching Kaamelott show on HTC Magic

Recently I've been watching again the Kaamelott DVD's from first
book (season) at home - this french hilarious show everyone should
own in his DVDtheque. To optmize a bit, I figured out I could
transfer some of my DVD's to my HTC Magic to watch while commuting
by train.

First step is to rip the DVD and create one VOB file per chapter;
I use [dvdrip](http://www.exit1.org/dvdrip/), check
"All" in "Specify Chapter Mode" in "RIP Title" tab, then rip.

Second step is to transcode in a format suitable for my HTC Magic;
the aspects being slightly different, the default look is not good
(too high forms); between adding vertical pads and cropping
horizontally, I chose the latter, in order to use the whole screen
area; I also raise volume (256 -> 640) because maximum volume on
the phone is not enough to overcome train noise.

```bash
ffmpeg -i sourcefile -s "560x320" -vcodec mpeg4 -b 600k \
    -cropleft 40 -cropright 40 -acodec libfaac -ac 2 -ar 32000 \
    -vol 640 -r 13 -ab 64k outputfile
```

If videos sometimes slow down, it might be interesting to install
[Task
Manager](http://www.androlib.com/android.application.com-wingtseng123-systemmemorymonitor-qFC.aspx) to kill background tasks not closed.

------------------------------------------------------------------------

2010-01-25

##### Network slowing reminder

It's just a reminder
for [trickle](http://monkey.org/%7Emarius/pages/?page=trickle),
the very useful userspace bandwidth shaper.

------------------------------------------------------------------------

2010-01-10

##### Nicer text outline in Gimp

Say you want to use the Text Tool in Gimp. Most of the time,
an outline in a solid color improves readability and is nice
to see. Given
your [text
(zoomed here)](http://zarb.org/%7Egc/resource/gimp-text-background-1.png), naively you could use the Select by Color
Tool, grow the selection by a few pixels, and fill with some
color in a separate layer, but the
result [doesn't
look so good](http://zarb.org/%7Egc/resource/gimp-text-background-2.png) because the outline edges are too sharp.

Trading the Select by Color Tool for Layer/Transparency/Alpha
to Selection, the selection will take advantage of the
translucent edges of the text, and the result
will [look
better](http://zarb.org/%7Egc/resource/gimp-text-background-3.png).

------------------------------------------------------------------------

2009-11-26

##### Transcoding videos for my HTC Magic

```bash
ffmpeg -i *sourcefile* -s "480x320" -vcodec mpeg4 -b 512000 \
    -acodec libfaac -ac 1 -ar 16000 -r 13 -ab 32000 -aspect 3:2 *outputfile*
```

------------------------------------------------------------------------

2009-11-06

##### GTK+ with default X composition

Just upgraded to Mandriva 2010.0, which uses Xorg 1.6.5. I use a
qwerty-us keyboard, with the right Windows key configured as
the [Compose
key](http://en.wikipedia.org/wiki/Compose_key). It wasn't working anymore and keyboarddrake didn't seem
to propose the option, so I had to copy-paste the following
section in `/etc/X11/xorg.conf`:

```bash
Section "InputDevice"
    Identifier "Keyboard1"
    Driver "kbd"
    Option "XkbModel" "pc105"
    Option "XkbLayout" "us"
    Option "XkbOptions" "compose:rwin"
EndSection
```

With that, composition worked properly in terminal (rxvt-unicode)
and in Emacs but not in GTK+ based apps (the sequences work only
if the Compose key is not hold when pressing the subsequent key,
which is a painful limitation when typing fast). Seems that GTK+
uses its own composition mechanisms, except we tell it to stop
being silly with the environment
variable `GTK_IM_MODULE=xim`. Kudos to
[Kragen
Javier Sitaker](http://canonical.org/%7Ekragen/setting-up-keyboard.html).

------------------------------------------------------------------------

2009-09-23

##### valgrind reminder

I always forget the needed parameter for the useful use of
valgrind which is getting the backtrace of segmentation faults
together with getting information on memory leaks. So here it is:

```bash
valgrind --log-file=logfile.out --tool=memcheck --leak-check=full ..binary..
```

------------------------------------------------------------------------

2009-05-06

##### Telling svn to ignore space changes

This one is not magic but I often forget the exact command. The
aim is to use the `-b` switch of the diff command, to
ignore changes in the amount of white space. It is useful when
commiters reindented stuff.

```bash
svn diff -x -b ...
```

------------------------------------------------------------------------

2009-01-24

##### Setting Bash's IFS to newline only

When I need that 

```bash
for i in `cat foo`; do ...; done
```

iterate over each line of the file, I always forget how to
set Bash's IFS to newline only, and I never find it
immediately with Google, so here's my personal cache.

```bash
IFS=$'\n'
```

------------------------------------------------------------------------

2008-10-15

##### Diffing ZIP files

When deploying a new
[WAR
file](http://en.wikipedia.org/wiki/Sun_WAR_%28file_format%29) in production, I like to view exactly what are the
changes to the current one; it helps spot what bugfixes/features
are actually in the new WAR file, and avoid misleadingly deploying
wrong versions or with unwanted changed.

To do so, I've written
a [script to
output diff from ZIP files](http://zarb.org/%7Egc/html/diffzips.html). It is cool.

------------------------------------------------------------------------

2008-09-18

##### PostgreSQL implements POSIX regexp, Java doesn't

For Java's `Pattern` class, `foo{` is an incorrect
regular expression, but for PostgreSQL's POSIX regular expression
operator `~`, it is totally fine.

For Java's `Pattern` class, `foo$*` is a perfectly
valid regular expression, but for PostgreSQL's POSIX regular
expression operator `~`, it is incorrect!

Ouch.

------------------------------------------------------------------------

2008-09-03

##### Deinterlacing mini-DV with mplayer

I used to use the simplest / most suggested way to
deinterlace my mini-DV videos with mplayer e.g. use
`-vf lavcdeint`. After reading some stuff
on [linuxfr](http://linuxfr.org/%7Edtschump/27113.html)
and making some experiments, I came to the following
conclusions:

*   it's much better to use `-vf yadif=0`, in
      particular to obtain sharper images;
*   the yadif filter has some magic in it, as it can
      allow to produce 50 fps videos of quite high quality;
      try to watch your mini-DV videos in 50 fps, videos
      feel much more "realistic"..

Some details with screenshots can be
found [here](http://zarb.org/%7Egc/deint/view.html).

------------------------------------------------------------------------

2008-08-21

##### PostgreSQL JDBC: setting an Array value

It's not possible to easily use `#setArray` on
a `PreparedStatement` object with PostgreSQL's JDBC driver,
as no provided class implements the required
interface `java.sql.Array` (and it seems tough to implement
it for that use).

There are two handy workarounds (at least). The first is to use an
existing SQL `ARRAY` value: you can craft an SQL query
returning an array, then use that value directly
with `#setArray`; in that situation, the first query will
look like:

```sql
SELECT ARRAY( SELECT lanname FROM pg_language ) AS foo;
```

The second possible workaround is to use the
function `string_to_array`. For example, you can use
e.g. `#setString("internal,sql")` on a query like:

```sql
SELECT * FROM pg_language WHERE lanname = ANY( string_to_array(?, ',') )
```

------------------------------------------------------------------------

2008-06-10

##### Publishing Git repositories on a shared server

So you are the happy admin or user of a shared Linux server.
You know that Git is very cool, and you want to install
what's necessary on the shared server to host user
repositories there. You're like me: you've read some Git
documentation, but you just haven't found some sort of
executive summary comprehensively listing how to do that. 
[This
place](http://zarb.org/%7Egc/html/git-on-a-shared-server.html) may help!

------------------------------------------------------------------------

2008-02-19

##### Fun with Google Translate

Here are a series of translations given by [Google Translate](http://translate.google.com/translate_t):

| German              | -&gt; | English         |
|---------------------|-------|-----------------|
| M�ller              |       | Mueller         |
| Frau M�ller         |       | Mrs. Johnson    |
| Geehrte Frau M�ller |       | Dear Mrs. Smith |

Sadly, from German to French, Madame Dupont isn't returned :/.

------------------------------------------------------------------------

2007-12-19

##### Help your Windows friends and increase your karma

By default, Microsoft Outlook doesn't do proper quoting of
replies - e.g. each line of reply is not prefixed with
"`> `"; however, it should, to improve readability
and allow for faster typing of multiple responses "inline" the replied message: if the
replied message is [left as is](http://zarb.org/%7Egc/resource/reply_quoted_badly.png),
the person has to [manually "prefix"
each part of his response with some special text](http://zarb.org/%7Egc/resource/reply_quoted_badly_2.png), or manually set a style or 
coloring; however, when it's [already prefixed](http://zarb.org/%7Egc/resource/reply_quoted_properly.png),
it's as easy as moving inside the replied message and
[type your text on a new line](http://zarb.org/%7Egc/resource/reply_quoted_properly_2.png).

It's possible to configure Outlook to perform proper quoting of
replied messages.. if you know where the option is buried.
I bet that most of our Windows friends would be
happy to use more standard and more efficient emailing.

*   In the `Tools` menu, choose `Options`. On the `Preferences` tab, click `E-mail Options`.
*   Under `When replying to a message`, choose `Prefix each line of the original message`.
*   Click `OK` twice.

------------------------------------------------------------------------

2007-09-25

##### Eclipse 3.3.0 and broken Show Tooltip Description key binding

I personally try to use the keyboard as much as possible, opposedly
to the mouse, when editing source code: I think it's much faster.
When using Eclipse to edit Java, Java errors and warnings are
[displayed "inline"](http://zarb.org/%7Egc/resource/e33_1.png)
(as spelling mistakes in a word processor: a curly underline below the offending words); details about each
problem can be obtained [as a tooltip](http://zarb.org/%7Egc/resource/e33_2.png)
by hovering the mouse, but
also with the Show Tooltip Description key binding. Strangely enough,
when upgrading from Eclipse 3.2 to 3.3.0, the key binding stopped
working. After a lot of head scratching, with no information on the net
about this, I finally found that opening once the Problems window after
starting Eclipse workarounds the problem. Quite strange.

------------------------------------------------------------------------

2007-08-26

##### Ruby equivalent to Java's synchronized {} block

In Ruby, the base synchronization tool is the Mutex class. You can use
its `synchronize` method and pass it a block which will be guaranteed
to not be interrupted by another Thread also synchronizing on this mutex.
Unfortunately, the `synchronize` method doesn't like to be called
from a Thread already owning the lock. If you look for something easier
to use, as Java's `synchronized {}` blocks are (in my personal experience,
calling/recursing into another method which also wants to synchronize on
the same resource is a common use-case), the solution is
to use Ruby's `Monitor` class. It's even possible to mix it in any other
class and then synchronize on the object representing the resource which
should be synchronized, as we can do with every Object in Java.

```java
require 'monitor'

whateverobject.extend(MonitorMixin)
whateverobject.synchronize { ... }
```

------------------------------------------------------------------------

2007-07-26

##### There *is* an official list of MIME types

My daily work involves dealing with MIME types quite a lot, as I maintain
a web application and as I work with MMS data. I've been unhappily
questing for a bright light each time I struggle with finding the
official/standard MIME type for any content; is there any official/standard
list for this pile of *** ?; and finally the great
Odie found the grail: [this
actually is the official list of registered MIME types, provided by the
IANA](http://www.iana.org/assignments/media-types/). It is so kind to provide RFC links when applicable.

------------------------------------------------------------------------

2007-06-26

##### [Zattoo](http://zattoo.com/) on Mandriva

The [Zattoo Linux installation
procedure](https://zattoo.com/downloadlinux) is manual. Here are the steps which worked for me:

*   download their player, untar it in `/tmp` (it goes to `/tmp/dist`)
*   download their xulrunner, untar it in `/tmp/dist` (it goes to `/tmp/dist/xulrunner`)
*   rename all xulrunner shared libs: in `/tmp/dist/xulrunner`, do `for i in * .so; do mv $i ${i}.0d; done`
*   `urpmi libgtkglext-1.0_0`
*   have data files accessible to the player: `sudo ln -s /tmp/dist/usr/share/zattoo_player /usr/share`

*   start it with (in one line):

```bash
LD_PRELOAD=/tmp/dist/usr/lib/zattoo/libavcodec.so.51:\
         /tmp/dist/usr/lib/zattoo/libavformat.so.50:\
         /tmp/dist/usr/lib/zattoo/libavutil.so.49:\
         /tmp/dist/usr/lib/zattoo/libfaad.so.0.0.0

LD_LIBRARY_PATH=/tmp/dist/xulrunner /tmp/dist/usr/bin/zattoo_player
```

------------------------------------------------------------------------

2007-06-16

##### `identify` sucks for reading EXIF orientation of a JPEG file

My web-album software [booh](http://booh.org/) is
great, but somehow kinda slow. Most of the slowness comes
from XML parsing (since it's done with REXML, a pure Ruby XML
parser, which is not too fast) and image resizing (since it's
done with `convert` of ImageMagick, which is not too
fast either). Though, there's also the fact that I use
`identify` from ImageMagick to read the EXIF
orientation tag of photos; and actually, on my Pentium-4
2.8�GHz, it takes exactly one second to extract the
orientation of a 3�MB digital photo! that sucks! I've made a
comparison with commandline's `exif` tool on a
directory with 428�photos, and `identify` absolutely
cannot stand:

```bash
time identify -format "%[EXIF:orientation]" *.jpg >/dev/null
    07:34.42 elapsed
time exif --tag Orientation *.jpg >/dev/null
    00:05.73 elapsed
```

------------------------------------------------------------------------

2007-06-07

##### tcpdump reminder

I always forget the needed parameter for a useful probe with
tcpdump. So here it is:

```bash
tcpdump -s65535 -w/tmp/tcpdump.out host blabla.bla and port 22
```

Then of course, launching wireshark and clicking on "Follow TCP Stream"
are a must.

------------------------------------------------------------------------

2007-06-06

##### kill -QUIT's brother

It's possible to show interesting GC related information from
a running java program with the `jmap` utility.

```bash
[gc@meuh ~] jmap -heap 12377
Attaching to process ID 12377, please wait...
Debugger attached successfully.
Client compiler detected.
JVM version is 1.5.0_09-b03

using thread-local object allocation.
Mark Sweep Compact GC

Heap Configuration:
[...]
```

Notice that in this information, it's possible to view if you're close
to reaching an [out of memory because
of a too small *permanent generation*](#2006-09-06).

------------------------------------------------------------------------

2007-06-04

##### Verifying a S/MIME signed email

[Openssl](http://www.openssl.org/)'s `smime` utility will do.

```bash
[gc@meuh ~] openssl smime -verify -in mailfile -signer /tmp/signer.pem >/dev/null
Verification successful
[gc@meuh ~] openssl x509 -noout -text -in /tmp/signer.pem
[...]
```

------------------------------------------------------------------------

2007-05-24

##### What threads are running inside my Java application?

`kill -QUIT` triggers an stdout-based full thread dump.
Including a backtrace of all threads, with precise locations where
they are currently locked if applicable!

------------------------------------------------------------------------

2007-05-22

##### Ruby presentation at Linux Days

This morning, I gave a Ruby presentation (in french) in the [LinuxDays](http://www.linuxdays.ch/) event, Geneva. Was
kinda cool, [room
was pretty nice](http://zarb.org/%7Egc/t/conf_ruby_linuxdays_2007-05-22.jpg), in a building close to the *Palais des
Nations* of Geneva. About 20 to 30 attendees. The french
presentation, made with OpenOffice.org, is [available](http://zarb.org/%7Egc/t/ruby-linuxdays-2007-05-22.odp).

------------------------------------------------------------------------

2007-05-21

##### Linux + Laptop + Radeon + Beamer = 640x480

Well, at least on the "ATI Radeon 9250 and earlier" of the HP
pavilion ze4300 (PCI 1002/4337), when plugging a beamer, Xorg (X
Window System Version 1.3.0, Release date 19 April 2007, X
protocol version 11, revision 9, release 1.3) says:

`(WW) RADEON(0): Failed to detect secondary monitor DDC, default HSync and VRefresh used`

And then nearly all modes are removed because of default low
frequencies, and both laptop and beamer start up at 640x480
(laptop screen is 1400x1050). This is not lethal for
OpenOffice.org/Impress which will scale slideshows, but for the
rest of your applications, you will probably end up pretty much
screwed (however, this is ideal for Frozen-Bubble, which is
probably the most important).

The solution I found on a [forum](http://ubuntuforums.org/showthread.php?t=190567)
is to force timings. I am not sure how large you can set, and
if there is a possibility to break your beamer, so don't use
too large values, but the results of my experiments, with a 4
years old beamer, are (within the `Device` section of
the X configuration file) that the following setting allow
1024x768 output.

`Option "CRT2HSync" "28-50"`

When using 60 instead of 50, the device chooses 1280x1024, and
when using 70, 1400x1050 (but that's unreadable on the beamer
output, of course).

------------------------------------------------------------------------

2007-05-16

##### PostgreSQL: VACUUM and VACUUM FULL

Due to PostgreSQL approach to MVCC, the databases need to be
regularly VACUUMed and ANALYZEd, else the disk usage and
performance will decrease to a crawl. Unfortunately, if
databases have not been VACUUMed regularly enough in the
past, a new run of VACUUM will not completely recover
performance, due to a large number of unused space within
actual data. I went to the extend of [submitting
a documentation patch](http://archives.postgresql.org/pgsql-performance/2007-05/msg00272.php) to make it more clear in PostgreSQL
documentation; fortunately, after the sterile troll that
occurred in the thread, the patch was accepted upstream by a
more sensible guy than the futile trollers who answered in
the ML.

Notice that unfortunately, there is no easy way to know if
there is a lot to gain from VACUUM FULL prior to trying it -
and as it fully locks tables (and the DB connection which is
performing the request, even if used for a totally different
statement), you badly need to know for large tables. You may:

*   on the production database, you can use
`contrib/pgstattuple`. If the `free_percent` reported for
interesting tables is large, and `free_space` is large compared to
8K, then VACUUM FULL should be very helpful.
*   another way is to dump your production database, restore it
somewhere, issue VACUUM VERBOSE on a given table on both databases
(in production, and on the restore) and compare the reported
number of pages needed. The difference is the potential benefit of
running VACUUM FULL.

```sql
production_db=# VACUUM VERBOSE table;
    [...]
INFO:  "table": found 408 removable, 64994 nonremovable row versions in **4395 pages**

restored_db=# VACUUM VERBOSE table;
    [...]
INFO:  "table": found 0 removable, 64977 nonremovable row versions in **628 pages**
```

In the above example, 6/7 of the data is unused. Scanning the
table will be 7 times faster (or more - lower data amount means
higher cache hit rate) after a VACUUM FULL!

------------------------------------------------------------------------

2006-09-18

##### Generating a DVD to play on a DVD device

It's somehow not so simple to generate a DVD to play on a
regular DVD device (the one below your TV). There are details
to make right, or the device will refuse to play it, jerk
sound or things like that. It turned out that I didn't manage
to properly generate a DVD with mencoder or transcode, but I
could do it with [ffmpeg](http://en.wikipedia.org/wiki/FFmpeg). Here
it is:

```bash
ffmpeg -i source.avi -target dvd -bf 2 target.mpeg
```

Don't forget to [*deinterlace*](http://en.wikipedia.org/wiki/Deinterlacing)
interlaced material such as DV with `-deinterlace`.
You can also add `-threads 2` if you have a
hyperthreading or dual core CPU. Personally, I dislike the little black
borders left and right of the image when coming from a DV, so I also
use `-aspect 4:3`.

Of course, I only showed the `.mpeg`-generation phase.
Now you need to [*author*](http://en.wikipedia.org/wiki/DVD_authoring)
the DVD. Under Linux, most tools suck bigtime. I use
*qdvdauthor*, which looks promising, but which seems to
still be unable to easily generate a menu with a video
background, and to properly save project parameters between
runs.

------------------------------------------------------------------------

2006-09-06

##### Java out-of-memory error with plenty of memory left

Happened on me that my web application running inside tomcat
received the out-of-memory exception, although it was obvious it
didn't run out of memory (java heap space). When looking closer at
how the memory is handled, it turns out the GC of the JVM has
several locations where objects are put, and classes and methods
are actually loaded inside a specific one, the *permanent
generation*. In my case, it turned out that I had a lot of
classes loaded, and after some time the default size for the
permanent generation (which is 64 MB, and is not altered by setting the heap
space with `-Xmx`) was not enough to hold them all. Why the
JVM (1.4.2) is not able to properly hint in the out-of-memory
exception in that case is a pity, but life's sometimes full of
unexpected things :). The solution was to enlarge the permanent
generation with `-XX:MaxPermSize`.

------------------------------------------------------------------------

2006-09-01

##### What are the currently running SQL statements?

In an application using PostgreSQL, it might not be obvious to
list the currently running SQL statements, together with the date
they started. It is particularly useful if you see in the
processes that you have running statements (`ps auxw | grep
postgres: | grep -v idle`), and your machine is loaded, but
you don't know where the load is coming from. Set:

```bash
stats_command_string = on
```

in **postgresql.conf**, then you may see the running
statements with:

```sql
db=# SELECT current_query, query_start FROM pg_stat_activity WHERE current_query <> '<IDLE>';
```

------------------------------------------------------------------------

2006-08-06

##### strncat sucks

Contrary to popular belief, using **strncpy** and **strncat**
in C programs is [not the panacea](http://www.courtesan.com/todd/papers/strlcpy.html).
While **strncpy** would probably be still acceptable, **strncat**
is truly braindead. As I could not find a GPL implementation of OpenBSD's **strlcat**,
I wrote my own (for inclusion in the Frozen-Bubble server). So, this is GPLv2:

```cpp
size_t strconcat(char *dst, const char *src, size_t size)
{
    char *ptr = dst + strlen(dst);
    while (ptr - dst < size - 1 && *src) {
        *ptr = *src;
        ptr++;
        src++;
    }
    *ptr = '\0';
    return ptr - dst;
}
```
Notice it doesn't check **src** and **dst** are not **NULL**.

------------------------------------------------------------------------

2005-05-04

##### UTF-8 Byte Order Mark?

Some sucking Windows software add a BOM in front of UTF-8 files,
even if it [makes no
sense](http://en.wikipedia.org/wiki/Byte_Order_Mark). The BOM in UTF-8 is **0xEFBBBF**. As a
consequence, you might end up needing to remove such byte sequence
in front of UTF-8 text documents you receive from the wild -
especially when you feed it to an XML parser, because anything
in front of the XML declaration will trigger a parse error.

------------------------------------------------------------------------
