Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> stock = "goog", 613, 625, 610
>>> stock[2]
625
>>> stock[1:3]
(613, 625)
>>> stock
('goog', 613, 625, 610)
>>> stock[1:2]
(613,)
>>> from collections import namedtuple
>>> Stock = namedtuple("Stock", 'symobl current high low')
>>> st = Stock("GOOG", 613, high=625, low=610)
>>> st.goog
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    st.goog
AttributeError: 'Stock' object has no attribute 'goog'
>>> st
Stock(symobl='GOOG', current=613, high=625, low=610)
>>> st.current
613
>>> s.high
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    s.high
NameError: name 's' is not defined
>>> st.high
625
>>> st.low
610
>>> st.symobl
'GOOG'
>>> 
