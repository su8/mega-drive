from distutils.core import setup

setup(name = "blogfy",
      author = "Aaron",
      url = "https://github.com/wifiextender/blogfy/blob/master/blogfy-linux/customization%20guides/calling%20blogfy%20without%20python%20infront",
      description = "Blogfy is a shortcut that navigates and executes build.py automatically for you, which saves a lot of your time",
      version = "0.1",
      scripts = ["blogfy"])