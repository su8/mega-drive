/* point7.c -- 

Write a program that requests the hours worked in a week and then prints the gross pay,
the taxes, and the net pay. Assume the following:
a. Basic pay rate = $10.00/hr
b. Overtime (in excess of 40 hours) = time and a half
c. Tax rate: #15% of the first $300
20% of the next $150
25% of the rest
Use #define constants, and don’t worry if the example does not conform to current
tax law.

 */
#include <stdio.h>
#include <stdlib.h>
#define PAY_RATE 10
#define RATE1 0.15
#define RATE2 0.20
#define RATE3 0.25
#define OVERTIME 40
#define BREAK1 300
#define BREAK2 150
int main(void)
{
    double worked_hours, gross_pay, taxes, net_pay,x,z,c;

    printf("Please enter the hours worked in a week: ");

    scanf("%lf", &worked_hours);

    if (worked_hours <= OVERTIME)
        gross_pay = worked_hours * PAY_RATE;
    else
    {
        for (x = OVERTIME; x <= worked_hours; c++, x++)
            z = c;
        gross_pay = worked_hours * PAY_RATE + (z * (PAY_RATE+PAY_RATE+PAY_RATE/2));
        printf("%.1f\n\n",z);
    }

    if (gross_pay <= BREAK1)
        taxes = RATE1 * worked_hours;
    else if (gross_pay <= BREAK2)
        taxes = RATE2 * worked_hours;
    else
        taxes = RATE3 * worked_hours;

    net_pay = gross_pay - taxes;

    printf("Gross pay = $%.1f, taxes = $%.1f, net pay = $%.1f",
        gross_pay, taxes, net_pay);

    return EXIT_SUCCESS;
}