Python 3.3.3 (default, Nov 26 2013, 13:33:18) 
[GCC 4.8.2] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class Product():
	def __init__(self, name, price):
		self.name = name
		self._price = price
	@property
	def price(self):
		return self._price * 0.015
	@price.setter
	def price(self, value):
		self._price = value

		
>>> Product("Ferrari", 40000)
<__main__.Product object at 0x7f8bae6dce90>
>>> a = Product("Ferrari", 40000)
>>> a.name
'Ferrari'
>>> a.price
600.0
>>> 40000 * 0.015
600.0
>>> a.price = 500
>>> a.price
7.5
>>> a.price = 50000
>>> a.price
750.0
>>> class Product():
	def __init__(self, name, price):
		self.name = name
		self._price = price
	@property
	def price(self):
		return self._price * 0.015
	@price.setter
	def price(self, value):
		self._price = value
	def __str__(self):
		return '{}, {}'.format(self.name, self._price)

	
>>> Product("Ferrari", 40000)
<__main__.Product object at 0x7f8bae1c0a90>
>>> class Product():
	def __init__(self, name, price):
		self.name = name
		self._price = price
	def __str__(self):
		return '{}, {}'.format(self.name, self._price)
	@property
	def price(self):
		return self._price * 0.015
	@price.setter
	def price(self, value):
		self._price = value

		
>>> p = Product("Ferrari", 40000)
>>> print(p)
Ferrari, 40000
>>> p
<__main__.Product object at 0x7f8bae1c0d90>
>>> class Product():
	def __init__(self, name, price):
		self.name = name
		self._price = price
	@property
	def price(self):
		return self._price * 0.015
	@price.setter
	def price(self, value):
		self._price = value

		
>>> p = Product("Ferrari", 40000)
>>> print(p)
<__main__.Product object at 0x7f8bae1c2050>
>>> class Product():
	def __init__(self, name, price):
		self.name = name
		self._price = price
	def __str__(self):
		return '{}, {}'.format(self.name, self._price)
	@property
	def price(self):
		return self._price * 0.015
	@price.setter
	def price(self, value):
		self._price = value

		
>>> for x in p:
	print(x)

	
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    for x in p:
TypeError: 'Product' object is not iterable
>>> def a():
	return Product("Ferrari", 40000)

>>> a()
<__main__.Product object at 0x7f8bae1c2d10>
>>> def a():
	p = Product("Ferrari", 40000)
	return p

>>> a()
<__main__.Product object at 0x7f8bae1c2dd0>
>>> class Product():
	def __init__(self, name, price):
		self.name = name
		self._price = price
	def __str__(self):
		return '{}, {}'.format(self.name, self._price)
	def __repr__(self):
		return '{}, {}'.format(self.name, self._price)
	@property
	def price(self):
		return self._price * 0.015
	@price.setter
	def price(self, value):
		self._price = value

		
>>> Product("Ferrari", 40000)
Ferrari, 40000
>>> 
