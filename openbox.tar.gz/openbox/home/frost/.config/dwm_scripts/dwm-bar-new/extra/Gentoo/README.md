ebuild for Gentoo users. To compile locally run:

```bash
ebuild pinky-bar-9999.ebuild manifest clean prepare configure compile install qmerge merge
```
