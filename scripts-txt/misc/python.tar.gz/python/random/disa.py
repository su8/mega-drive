#!/usr/bin/python2
import os
import shlex
import getpass
import subprocess
from gi.repository import Gtk


class encrypt_decrypt_gui:

    def on_format_clicked(self, widget):
        device_path = self.show_devices.get_active_text().split('(')[1].rstrip(')')
        os.system("umount {0}".format(device_path))

        if self.file_system.get_active_text() == "fat":
            sp = subprocess.Popen(shlex.split('mkfs.vfat -n "{0}" -I {1}'.format(self.entry.get_text(), device_path)), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = sp.communicate()
            os.system("echo '{0}{1}' > /home/" + getpass.getuser() + "/Desktop/curemyusb.txt".format(out, err))
            self.progressbar.set_fraction(1.00)

        if self.file_system.get_active_text() == "ntfs":
            sp = subprocess.Popen(shlex.split('mkfs.ntfs --fast --force --label "{0}" {1}'.format(self.entry.get_text(), device_path)), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = sp.communicate()
            os.system("echo '{0}{1}' > /home/frost/" + getpass.getuser() + "/curemyusb.txt".format(out, err))
            self.progressbar.set_fraction(1.00)

    def on_close_clicked(self, widget):
        Gtk.main_quit()

    def list_all_devices(self):
        list_devices = subprocess.Popen(shlex.split("python2 /home/frost/Desktop/documents-export-2013-12-02/find_devices.py"), stdout=subprocess.PIPE).communicate()[0]
        list_devices = list_devices.strip().split('\n')
        for item in list_devices:
            name,size = item.split(',')
            self.show_devices.append_text(name+' ('+size.lstrip()+')')
        self.entry1 = self.intf.get_object("entry1")
        self.entry1.set_text(name)

    def __init__(self):
        self.intf = Gtk.Builder()
        self.intf.add_from_file('distro2usb.glade')
        self.intf.connect_signals(self)
        self.window = self.intf.get_object("window1")
        self.show_devices = self.intf.get_object("comboboxtext1")
        self.file_system = self.intf.get_object("comboboxtext2")
        self.progressbar = self.intf.get_object("progressbar1")
        self.entry = self.intf.get_object("entry1")
        self.list_all_devices()
        self.window.connect("delete-event", Gtk.main_quit)
        self.window.show_all()

if __name__ == '__main__':
    encrypt_decrypt_gui()
    Gtk.main()