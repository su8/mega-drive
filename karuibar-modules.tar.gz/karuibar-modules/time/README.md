karuibar:time
=================

This module display the date according to a user-defined date format.

![time.png](scrot/time.png)

X resource                 | Description
:--------------------------|:---------------------------------------------
`karuibar.time.format`     | Date format (see the manual for `date (1)`)
`karuibar.time.foreground` | Foreground (text) colour
`karuibar.time.background` | Background colour

Module       | `time`
:------------|:-------------------------------------------------
Author       | Tinu Weber ([ayekat](https://github.com/ayekat/))
Dependencies | None
Callbacks    | `init`, `poll`, `term`
License      | GPLv3
