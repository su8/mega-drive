
#define GetNumberOfSlot() 8
#define SLOT_MAX 9   //for linpac, slot0~slot8, 20141220

extern unsigned int SlotAddr[9];
extern int Diff;
extern slot_fd[SLOT_MAX];

