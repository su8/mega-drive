Python 3.3.5 (default, Mar 10 2014, 03:21:31) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> from HTMLParser import HTMLParser
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    from HTMLParser import HTMLParser
ImportError: No module named 'HTMLParser'
>>> def remove_tags(text):
    ''.join(xml.etree.ElementTree.fromstring(text).itertext())

    
>>> a = """               <tr>
                    <th>Pos</th>
                    <th>Driver</th>
                    <th>Nationality</th>
                    <th>Team</th>
                    <th>Points</th>
                </tr>
    
        <tr>
            <td>1</td>
            <td><a href="/results/driver/2014/809.html"> Nico Rosberg</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>
            <td>25</td>           
        </tr>
    
        <tr>
            <td>2</td>
            <td><a href="/results/driver/2014/899.html"> Kevin Magnussen</a></td>
            <td>Danish</td>
            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>
            <td>18</td>           
        </tr>
    
        <tr>
            <td>3</td>
            <td><a href="/results/driver/2014/6.html"> Jenson Button</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>
            <td>15</td>           
        </tr>
    
        <tr>
            <td>4</td>
            <td><a href="/results/driver/2014/30.html"> Fernando Alonso</a></td>
            <td>Spanish</td>
            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>
            <td>12</td>           
        </tr>
    
        <tr>
            <td>5</td>
            <td><a href="/results/driver/2014/865.html"> Valtteri  Bottas</a></td>
            <td>Finnish</td>
            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>
            <td>10</td>           
        </tr>
    
        <tr>
            <td>6</td>
            <td><a href="/results/driver/2014/840.html"> Nico Hulkenberg</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>
            <td>8</td>           
        </tr>
    
        <tr>
            <td>7</td>
            <td><a href="/results/driver/2014/12.html"> Kimi Räikkönen</a></td>
            <td>Finnish</td>
            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>
            <td>6</td>           
        </tr>
    
        <tr>
            <td>8</td>
            <td><a href="/results/driver/2014/870.html"> Jean-Eric Vergne</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>
            <td>4</td>           
        </tr>
    
        <tr>
            <td>9</td>
            <td><a href="/results/driver/2014/906.html"> Daniil Kvyat</a></td>
            <td>Russian</td>
            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>
            <td>2</td>           
        </tr>
    
        <tr>
            <td>10</td>
            <td><a href="/results/driver/2014/867.html"> Sergio Perez</a></td>
            <td>Mexican</td>
            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>
            <td>1</td>           
        </tr>
    
        <tr>
            <td>11</td>
            <td><a href="/results/driver/2014/818.html"> Adrian Sutil</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>12</td>
            <td><a href="/results/driver/2014/854.html"> Esteban Gutierrez</a></td>
            <td>Mexican</td>
            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>13</td>
            <td><a href="/results/driver/2014/887.html"> Max Chilton</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>14</td>
            <td><a href="/results/driver/2014/850.html"> Jules Bianchi</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>15</td>
            <td><a href="/results/driver/2014/838.html"> Romain Grosjean</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>16</td>
            <td><a href="/results/driver/2014/869.html"> Pastor Maldonado</a></td>
            <td>Venezuelan</td>
            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>17</td>
            <td><a href="/results/driver/2014/862.html"> Marcus Ericsson</a></td>
            <td>Swedish</td>
            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>18</td>
            <td><a href="/results/driver/2014/822.html"> Sebastian Vettel</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>19</td>
            <td><a href="/results/driver/2014/828.html"> Lewis Hamilton</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>20</td>
            <td><a href="/results/driver/2014/18.html"> Felipe Massa</a></td>
            <td>Brazilian</td>
            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>21</td>
            <td><a href="/results/driver/2014/837.html"> Kamui Kobayashi</a></td>
            <td>Japanese</td>
            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>22</td>
            <td><a href="/results/driver/2014/857.html"> Daniel Ricciardo</a></td>
            <td>Australian</td>
            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>
            <td>0</td>           
        </tr>
    """
>>> remove_tags(a)
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    remove_tags(a)
  File "<pyshell#2>", line 2, in remove_tags
    ''.join(xml.etree.ElementTree.fromstring(text).itertext())
NameError: global name 'xml' is not defined
>>> import xml.etree.ElementTree
>>> remove_tags(a)
Traceback (most recent call last):
  File "<pyshell#6>", line 1, in <module>
    remove_tags(a)
  File "<pyshell#2>", line 2, in remove_tags
    ''.join(xml.etree.ElementTree.fromstring(text).itertext())
  File "/usr/lib/python3.3/xml/etree/ElementTree.py", line 1356, in XML
    parser.feed(text)
  File "<string>", line None
xml.etree.ElementTree.ParseError: junk after document element: line 9, column 8
>>> remove_tags('<td><a href="/results/driver/2014/857.html"> Daniel Ricciardo</a></td>')
>>> def remove_tags(text):
    return ''.join(xml.etree.ElementTree.fromstring(text).itertext())

>>> remove_tags('<td><a href="/results/driver/2014/857.html"> Daniel Ricciardo</a></td>')
' Daniel Ricciardo'
>>> remove_tags(a)
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    remove_tags(a)
  File "<pyshell#9>", line 2, in remove_tags
    return ''.join(xml.etree.ElementTree.fromstring(text).itertext())
  File "/usr/lib/python3.3/xml/etree/ElementTree.py", line 1356, in XML
    parser.feed(text)
  File "<string>", line None
xml.etree.ElementTree.ParseError: junk after document element: line 9, column 8
>>> remove_tags('''<tr>
            <td>1</td>
            <td><a href="/results/driver/2014/809.html"> Nico Rosberg</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>
            <td>25</td>           
        </tr>
    
        <tr>
            <td>2</td>
            <td><a href="/results/driver/2014/899.html"> Kevin Magnussen</a></td>
            <td>Danish</td>
            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>
            <td>18</td>           
        </tr>
    
        <tr>
            <td>3</td>
            <td><a href="/results/driver/2014/6.html"> Jenson Button</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>
            <td>15</td>           
        </tr>
    
        <tr>
            <td>4</td>
            <td><a href="/results/driver/2014/30.html"> Fernando Alonso</a></td>
            <td>Spanish</td>
            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>
            <td>12</td>           
        </tr>
    
        <tr>
            <td>5</td>
            <td><a href="/results/driver/2014/865.html"> Valtteri  Bottas</a></td>
            <td>Finnish</td>
            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>
            <td>10</td>           
        </tr>
    
        <tr>
            <td>6</td>
            <td><a href="/results/driver/2014/840.html"> Nico Hulkenberg</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>
            <td>8</td>           
        </tr>
    
        <tr>
            <td>7</td>
            <td><a href="/results/driver/2014/12.html"> Kimi Räikkönen</a></td>
            <td>Finnish</td>
            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>
            <td>6</td>           
        </tr>
    
        <tr>
            <td>8</td>
            <td><a href="/results/driver/2014/870.html"> Jean-Eric Vergne</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>
            <td>4</td>           
        </tr>
    
        <tr>
            <td>9</td>
            <td><a href="/results/driver/2014/906.html"> Daniil Kvyat</a></td>
            <td>Russian</td>
            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>
            <td>2</td>           
        </tr>
    
        <tr>
            <td>10</td>
            <td><a href="/results/driver/2014/867.html"> Sergio Perez</a></td>
            <td>Mexican</td>
            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>
            <td>1</td>           
        </tr>
    
        <tr>
            <td>11</td>
            <td><a href="/results/driver/2014/818.html"> Adrian Sutil</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>12</td>
            <td><a href="/results/driver/2014/854.html"> Esteban Gutierrez</a></td>
            <td>Mexican</td>
            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>13</td>
            <td><a href="/results/driver/2014/887.html"> Max Chilton</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>14</td>
            <td><a href="/results/driver/2014/850.html"> Jules Bianchi</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>15</td>
            <td><a href="/results/driver/2014/838.html"> Romain Grosjean</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>16</td>
            <td><a href="/results/driver/2014/869.html"> Pastor Maldonado</a></td>
            <td>Venezuelan</td>
            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>17</td>
            <td><a href="/results/driver/2014/862.html"> Marcus Ericsson</a></td>
            <td>Swedish</td>
            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>18</td>
            <td><a href="/results/driver/2014/822.html"> Sebastian Vettel</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>19</td>
            <td><a href="/results/driver/2014/828.html"> Lewis Hamilton</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>20</td>
            <td><a href="/results/driver/2014/18.html"> Felipe Massa</a></td>
            <td>Brazilian</td>
            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>21</td>
            <td><a href="/results/driver/2014/837.html"> Kamui Kobayashi</a></td>
            <td>Japanese</td>
            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>22</td>
            <td><a href="/results/driver/2014/857.html"> Daniel Ricciardo</a></td>
            <td>Australian</td>
            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>
            <td>0</td> ''')
Traceback (most recent call last):
  File "<pyshell#12>", line 174, in <module>
    <td>0</td> ''')
  File "<pyshell#9>", line 2, in remove_tags
    return ''.join(xml.etree.ElementTree.fromstring(text).itertext())
  File "/usr/lib/python3.3/xml/etree/ElementTree.py", line 1356, in XML
    parser.feed(text)
  File "<string>", line None
xml.etree.ElementTree.ParseError: junk after document element: line 9, column 8
>>> import re
>>> def cleanhtml(raw_html):

  cleanr =re.compile('<.*?>')

  cleantext = re.sub(cleanr,'', raw_html)

  return cleantext

>>> cleanhtml(a)
'               \n                    Pos\n                    Driver\n                    Nationality\n                    Team\n                    Points\n                \n    \n        \n            1\n             Nico Rosberg\n            German\n             Mercedes\n            25           \n        \n    \n        \n            2\n             Kevin Magnussen\n            Danish\n             McLaren-Mercedes\n            18           \n        \n    \n        \n            3\n             Jenson Button\n            British\n             McLaren-Mercedes\n            15           \n        \n    \n        \n            4\n             Fernando Alonso\n            Spanish\n             Ferrari\n            12           \n        \n    \n        \n            5\n             Valtteri  Bottas\n            Finnish\n             Williams-Mercedes\n            10           \n        \n    \n        \n            6\n             Nico Hulkenberg\n            German\n             Force India-Mercedes\n            8           \n        \n    \n        \n            7\n             Kimi Räikkönen\n            Finnish\n             Ferrari\n            6           \n        \n    \n        \n            8\n             Jean-Eric Vergne\n            French\n             STR-Renault\n            4           \n        \n    \n        \n            9\n             Daniil Kvyat\n            Russian\n             STR-Renault\n            2           \n        \n    \n        \n            10\n             Sergio Perez\n            Mexican\n             Force India-Mercedes\n            1           \n        \n    \n        \n            11\n             Adrian Sutil\n            German\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            12\n             Esteban Gutierrez\n            Mexican\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            13\n             Max Chilton\n            British\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            14\n             Jules Bianchi\n            French\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            15\n             Romain Grosjean\n            French\n             Lotus-Renault\n            0           \n        \n    \n        \n            16\n             Pastor Maldonado\n            Venezuelan\n             Lotus-Renault\n            0           \n        \n    \n        \n            17\n             Marcus Ericsson\n            Swedish\n             Caterham-Renault\n            0           \n        \n    \n        \n            18\n             Sebastian Vettel\n            German\n             Red Bull Racing-Renault\n            0           \n        \n    \n        \n            19\n             Lewis Hamilton\n            British\n             Mercedes\n            0           \n        \n    \n        \n            20\n             Felipe Massa\n            Brazilian\n             Williams-Mercedes\n            0           \n        \n    \n        \n            21\n             Kamui Kobayashi\n            Japanese\n             Caterham-Renault\n            0           \n        \n    \n        \n            22\n             Daniel Ricciardo\n            Australian\n             Red Bull Racing-Renault\n            0           \n        \n    '
>>> from BeautifulSoup import BeautifulSoup
Traceback (most recent call last):
  File "<pyshell#17>", line 1, in <module>
    from BeautifulSoup import BeautifulSoup
ImportError: No module named 'BeautifulSoup'
>>> from HTMLParser import HTMLParser
Traceback (most recent call last):
  File "<pyshell#18>", line 1, in <module>
    from HTMLParser import HTMLParser
ImportError: No module named 'HTMLParser'
>>> from html.parser import HTMLParser
>>> class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()
SyntaxError: invalid syntax
>>> class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)

>>> def strip_tags(html):
    s = MLStripper()
    s.feed(a)
    return s.get_data()

>>> def strip_tags(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

>>> strip_tags(a)
Traceback (most recent call last):
  File "<pyshell#27>", line 1, in <module>
    strip_tags(a)
  File "<pyshell#26>", line 3, in strip_tags
    s.feed(html)
  File "/usr/lib/python3.3/html/parser.py", line 145, in feed
    self.goahead(0)
  File "/usr/lib/python3.3/html/parser.py", line 189, in goahead
    k = self.parse_starttag(i)
  File "/usr/lib/python3.3/html/parser.py", line 323, in parse_starttag
    endpos = self.check_for_whole_start_tag(i)
  File "/usr/lib/python3.3/html/parser.py", line 383, in check_for_whole_start_tag
    if self.strict:
AttributeError: 'MLStripper' object has no attribute 'strict'
>>> re.sub('<[^<]+?>', '', a)
'               \n                    Pos\n                    Driver\n                    Nationality\n                    Team\n                    Points\n                \n    \n        \n            1\n             Nico Rosberg\n            German\n             Mercedes\n            25           \n        \n    \n        \n            2\n             Kevin Magnussen\n            Danish\n             McLaren-Mercedes\n            18           \n        \n    \n        \n            3\n             Jenson Button\n            British\n             McLaren-Mercedes\n            15           \n        \n    \n        \n            4\n             Fernando Alonso\n            Spanish\n             Ferrari\n            12           \n        \n    \n        \n            5\n             Valtteri  Bottas\n            Finnish\n             Williams-Mercedes\n            10           \n        \n    \n        \n            6\n             Nico Hulkenberg\n            German\n             Force India-Mercedes\n            8           \n        \n    \n        \n            7\n             Kimi Räikkönen\n            Finnish\n             Ferrari\n            6           \n        \n    \n        \n            8\n             Jean-Eric Vergne\n            French\n             STR-Renault\n            4           \n        \n    \n        \n            9\n             Daniil Kvyat\n            Russian\n             STR-Renault\n            2           \n        \n    \n        \n            10\n             Sergio Perez\n            Mexican\n             Force India-Mercedes\n            1           \n        \n    \n        \n            11\n             Adrian Sutil\n            German\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            12\n             Esteban Gutierrez\n            Mexican\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            13\n             Max Chilton\n            British\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            14\n             Jules Bianchi\n            French\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            15\n             Romain Grosjean\n            French\n             Lotus-Renault\n            0           \n        \n    \n        \n            16\n             Pastor Maldonado\n            Venezuelan\n             Lotus-Renault\n            0           \n        \n    \n        \n            17\n             Marcus Ericsson\n            Swedish\n             Caterham-Renault\n            0           \n        \n    \n        \n            18\n             Sebastian Vettel\n            German\n             Red Bull Racing-Renault\n            0           \n        \n    \n        \n            19\n             Lewis Hamilton\n            British\n             Mercedes\n            0           \n        \n    \n        \n            20\n             Felipe Massa\n            Brazilian\n             Williams-Mercedes\n            0           \n        \n    \n        \n            21\n             Kamui Kobayashi\n            Japanese\n             Caterham-Renault\n            0           \n        \n    \n        \n            22\n             Daniel Ricciardo\n            Australian\n             Red Bull Racing-Renault\n            0           \n        \n    '
>>> import htmlentitydefs
Traceback (most recent call last):
  File "<pyshell#29>", line 1, in <module>
    import htmlentitydefs
ImportError: No module named 'htmlentitydefs'
>>> class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def handle_entityref(self, name):
        self.fed.append('&%s;' % name)
    def get_data(self):
        return ''.join(self.fed)

>>> def html_to_text(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

>>> html_to_text(a)
Traceback (most recent call last):
  File "<pyshell#34>", line 1, in <module>
    html_to_text(a)
  File "<pyshell#33>", line 3, in html_to_text
    s.feed(html)
  File "/usr/lib/python3.3/html/parser.py", line 145, in feed
    self.goahead(0)
  File "/usr/lib/python3.3/html/parser.py", line 189, in goahead
    k = self.parse_starttag(i)
  File "/usr/lib/python3.3/html/parser.py", line 323, in parse_starttag
    endpos = self.check_for_whole_start_tag(i)
  File "/usr/lib/python3.3/html/parser.py", line 383, in check_for_whole_start_tag
    if self.strict:
AttributeError: 'MLStripper' object has no attribute 'strict'
>>> class MLStripper(HTMLParser):
    def __init__(self):
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def handle_entityref(self, name):
        self.fed.append('&{}s;'.format(name))
    def get_data(self):
        return ''.join(self.fed)

>>> def html_to_text(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

>>> html_to_text(a)
Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    html_to_text(a)
  File "<pyshell#38>", line 3, in html_to_text
    s.feed(html)
  File "/usr/lib/python3.3/html/parser.py", line 145, in feed
    self.goahead(0)
  File "/usr/lib/python3.3/html/parser.py", line 189, in goahead
    k = self.parse_starttag(i)
  File "/usr/lib/python3.3/html/parser.py", line 323, in parse_starttag
    endpos = self.check_for_whole_start_tag(i)
  File "/usr/lib/python3.3/html/parser.py", line 383, in check_for_whole_start_tag
    if self.strict:
AttributeError: 'MLStripper' object has no attribute 'strict'
>>> class MLStripper(HTMLParser):
    def __init__(self):
	super().__init__()
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def handle_entityref(self, name):
        self.fed.append('&{}s;'.format(name))
    def get_data(self):
        return ''.join(self.fed)
SyntaxError: inconsistent use of tabs and spaces in indentation
>>> 
>>> class MLStripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def handle_entityref(self, name):
        self.fed.append('&{}s;'.format(name))
    def get_data(self):
        return ''.join(self.fed)

>>> def html_to_text(html):
    s = MLStripper()
    s.feed(html)
    return s.get_data()

>>> html_to_text(a)
'               \n                    Pos\n                    Driver\n                    Nationality\n                    Team\n                    Points\n                \n    \n        \n            1\n             Nico Rosberg\n            German\n             Mercedes\n            25           \n        \n    \n        \n            2\n             Kevin Magnussen\n            Danish\n             McLaren-Mercedes\n            18           \n        \n    \n        \n            3\n             Jenson Button\n            British\n             McLaren-Mercedes\n            15           \n        \n    \n        \n            4\n             Fernando Alonso\n            Spanish\n             Ferrari\n            12           \n        \n    \n        \n            5\n             Valtteri  Bottas\n            Finnish\n             Williams-Mercedes\n            10           \n        \n    \n        \n            6\n             Nico Hulkenberg\n            German\n             Force India-Mercedes\n            8           \n        \n    \n        \n            7\n             Kimi Räikkönen\n            Finnish\n             Ferrari\n            6           \n        \n    \n        \n            8\n             Jean-Eric Vergne\n            French\n             STR-Renault\n            4           \n        \n    \n        \n            9\n             Daniil Kvyat\n            Russian\n             STR-Renault\n            2           \n        \n    \n        \n            10\n             Sergio Perez\n            Mexican\n             Force India-Mercedes\n            1           \n        \n    \n        \n            11\n             Adrian Sutil\n            German\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            12\n             Esteban Gutierrez\n            Mexican\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            13\n             Max Chilton\n            British\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            14\n             Jules Bianchi\n            French\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            15\n             Romain Grosjean\n            French\n             Lotus-Renault\n            0           \n        \n    \n        \n            16\n             Pastor Maldonado\n            Venezuelan\n             Lotus-Renault\n            0           \n        \n    \n        \n            17\n             Marcus Ericsson\n            Swedish\n             Caterham-Renault\n            0           \n        \n    \n        \n            18\n             Sebastian Vettel\n            German\n             Red Bull Racing-Renault\n            0           \n        \n    \n        \n            19\n             Lewis Hamilton\n            British\n             Mercedes\n            0           \n        \n    \n        \n            20\n             Felipe Massa\n            Brazilian\n             Williams-Mercedes\n            0           \n        \n    \n        \n            21\n             Kamui Kobayashi\n            Japanese\n             Caterham-Renault\n            0           \n        \n    \n        \n            22\n             Daniel Ricciardo\n            Australian\n             Red Bull Racing-Renault\n            0           \n        \n    '
>>> html_to_text('<<b>script>alert("hacked")<</b>/script>
	     
SyntaxError: EOL while scanning string literal
>>> html_to_text('<<b>script>alert("hacked")<</b>/script>')
'<script>alert("hacked")</script>'
>>> class MLStripper(HTMLParser):
    def __init__(self):
	    super().__init__()
        self.reset()
        self.fed = []
        self.containstags = False

    def handle_starttag(self, tag, attrs):
       self.containstags = True

    def handle_data(self, d):
        self.fed.append(d)

    def has_tags(self):
        return self.containstags

    def get_data(self):
        return ''.join(self.fed)
SyntaxError: unindent does not match any outer indentation level
>>> class MLStripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.fed = []
        self.containstags = False

    def handle_starttag(self, tag, attrs):
       self.containstags = True

    def handle_data(self, d):
        self.fed.append(d)

    def has_tags(self):
        return self.containstags

    def get_data(self):
        return ''.join(self.fed)

>>> def strip_tags(html):
    must_filtered = True
    while ( must_filtered ):
        s = MLStripper()
        s.feed(html)
        html = s.get_data()
        must_filtered = s.has_tags()
    return html

>>> strip_tags(a)
'               \n                    Pos\n                    Driver\n                    Nationality\n                    Team\n                    Points\n                \n    \n        \n            1\n             Nico Rosberg\n            German\n             Mercedes\n            25           \n        \n    \n        \n            2\n             Kevin Magnussen\n            Danish\n             McLaren-Mercedes\n            18           \n        \n    \n        \n            3\n             Jenson Button\n            British\n             McLaren-Mercedes\n            15           \n        \n    \n        \n            4\n             Fernando Alonso\n            Spanish\n             Ferrari\n            12           \n        \n    \n        \n            5\n             Valtteri  Bottas\n            Finnish\n             Williams-Mercedes\n            10           \n        \n    \n        \n            6\n             Nico Hulkenberg\n            German\n             Force India-Mercedes\n            8           \n        \n    \n        \n            7\n             Kimi Räikkönen\n            Finnish\n             Ferrari\n            6           \n        \n    \n        \n            8\n             Jean-Eric Vergne\n            French\n             STR-Renault\n            4           \n        \n    \n        \n            9\n             Daniil Kvyat\n            Russian\n             STR-Renault\n            2           \n        \n    \n        \n            10\n             Sergio Perez\n            Mexican\n             Force India-Mercedes\n            1           \n        \n    \n        \n            11\n             Adrian Sutil\n            German\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            12\n             Esteban Gutierrez\n            Mexican\n             Sauber-Ferrari\n            0           \n        \n    \n        \n            13\n             Max Chilton\n            British\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            14\n             Jules Bianchi\n            French\n             Marussia-Ferrari\n            0           \n        \n    \n        \n            15\n             Romain Grosjean\n            French\n             Lotus-Renault\n            0           \n        \n    \n        \n            16\n             Pastor Maldonado\n            Venezuelan\n             Lotus-Renault\n            0           \n        \n    \n        \n            17\n             Marcus Ericsson\n            Swedish\n             Caterham-Renault\n            0           \n        \n    \n        \n            18\n             Sebastian Vettel\n            German\n             Red Bull Racing-Renault\n            0           \n        \n    \n        \n            19\n             Lewis Hamilton\n            British\n             Mercedes\n            0           \n        \n    \n        \n            20\n             Felipe Massa\n            Brazilian\n             Williams-Mercedes\n            0           \n        \n    \n        \n            21\n             Kamui Kobayashi\n            Japanese\n             Caterham-Renault\n            0           \n        \n    \n        \n            22\n             Daniel Ricciardo\n            Australian\n             Red Bull Racing-Renault\n            0           \n        \n    '
>>> strip_tags('<<b>script>alert("hacked")<</b>/script>')
'alert("hacked")'
>>> a = """       <div class="contentContainer">
            <table class="raceResults" cellpadding="0" cellspacing="0" summary="">
                <tr>
                    <th>Pos</th>
                    <th>Driver</th>
                    <th>Nationality</th>
                    <th>Team</th>
                    <th>Points</th>
                </tr>
    
        <tr>
            <td>1</td>
            <td><a href="/results/driver/2014/809.html"> Nico Rosberg</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>
            <td>25</td>           
        </tr>
    
        <tr>
            <td>2</td>
            <td><a href="/results/driver/2014/899.html"> Kevin Magnussen</a></td>
            <td>Danish</td>
            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>
            <td>18</td>           
        </tr>
    
        <tr>
            <td>3</td>
            <td><a href="/results/driver/2014/6.html"> Jenson Button</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>
            <td>15</td>           
        </tr>
    
        <tr>
            <td>4</td>
            <td><a href="/results/driver/2014/30.html"> Fernando Alonso</a></td>
            <td>Spanish</td>
            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>
            <td>12</td>           
        </tr>
    
        <tr>
            <td>5</td>
            <td><a href="/results/driver/2014/865.html"> Valtteri  Bottas</a></td>
            <td>Finnish</td>
            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>
            <td>10</td>           
        </tr>
    
        <tr>
            <td>6</td>
            <td><a href="/results/driver/2014/840.html"> Nico Hulkenberg</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>
            <td>8</td>           
        </tr>
    
        <tr>
            <td>7</td>
            <td><a href="/results/driver/2014/12.html"> Kimi Räikkönen</a></td>
            <td>Finnish</td>
            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>
            <td>6</td>           
        </tr>
    
        <tr>
            <td>8</td>
            <td><a href="/results/driver/2014/870.html"> Jean-Eric Vergne</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>
            <td>4</td>           
        </tr>
    
        <tr>
            <td>9</td>
            <td><a href="/results/driver/2014/906.html"> Daniil Kvyat</a></td>
            <td>Russian</td>
            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>
            <td>2</td>           
        </tr>
    
        <tr>
            <td>10</td>
            <td><a href="/results/driver/2014/867.html"> Sergio Perez</a></td>
            <td>Mexican</td>
            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>
            <td>1</td>           
        </tr>
    
        <tr>
            <td>11</td>
            <td><a href="/results/driver/2014/818.html"> Adrian Sutil</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>12</td>
            <td><a href="/results/driver/2014/854.html"> Esteban Gutierrez</a></td>
            <td>Mexican</td>
            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>13</td>
            <td><a href="/results/driver/2014/887.html"> Max Chilton</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>14</td>
            <td><a href="/results/driver/2014/850.html"> Jules Bianchi</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>15</td>
            <td><a href="/results/driver/2014/838.html"> Romain Grosjean</a></td>
            <td>French</td>
            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>16</td>
            <td><a href="/results/driver/2014/869.html"> Pastor Maldonado</a></td>
            <td>Venezuelan</td>
            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>17</td>
            <td><a href="/results/driver/2014/862.html"> Marcus Ericsson</a></td>
            <td>Swedish</td>
            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>18</td>
            <td><a href="/results/driver/2014/822.html"> Sebastian Vettel</a></td>
            <td>German</td>
            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>19</td>
            <td><a href="/results/driver/2014/828.html"> Lewis Hamilton</a></td>
            <td>British</td>
            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>20</td>
            <td><a href="/results/driver/2014/18.html"> Felipe Massa</a></td>
            <td>Brazilian</td>
            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>21</td>
            <td><a href="/results/driver/2014/837.html"> Kamui Kobayashi</a></td>
            <td>Japanese</td>
            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>
            <td>0</td>           
        </tr>
    
        <tr>
            <td>22</td>
            <td><a href="/results/driver/2014/857.html"> Daniel Ricciardo</a></td>
            <td>Australian</td>
            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>
            <td>0</td>           
        </tr>
    
            </table>
         </div>"""
>>> 
>>> from BeautifulSoup import BeautifulSoup
Traceback (most recent call last):
  File "<pyshell#58>", line 1, in <module>
    from BeautifulSoup import BeautifulSoup
ImportError: No module named 'BeautifulSoup'
>>> from bs4 import BeautifulSoup
>>> soup = BeautifulSoup(''.join(a))
>>> print(soup.prettify())
<html>
 <body>
  <div class="contentContainer">
   <table cellpadding="0" cellspacing="0" class="raceResults" summary="">
    <tr>
     <th>
      Pos
     </th>
     <th>
      Driver
     </th>
     <th>
      Nationality
     </th>
     <th>
      Team
     </th>
     <th>
      Points
     </th>
    </tr>
    <tr>
     <td>
      1
     </td>
     <td>
      <a href="/results/driver/2014/809.html">
       Nico Rosberg
      </a>
     </td>
     <td>
      German
     </td>
     <td>
      <a href="/results/team/2014/2996.html">
       Mercedes
      </a>
     </td>
     <td>
      25
     </td>
    </tr>
    <tr>
     <td>
      2
     </td>
     <td>
      <a href="/results/driver/2014/899.html">
       Kevin Magnussen
      </a>
     </td>
     <td>
      Danish
     </td>
     <td>
      <a href="/results/team/2014/2999.html">
       McLaren-Mercedes
      </a>
     </td>
     <td>
      18
     </td>
    </tr>
    <tr>
     <td>
      3
     </td>
     <td>
      <a href="/results/driver/2014/6.html">
       Jenson Button
      </a>
     </td>
     <td>
      British
     </td>
     <td>
      <a href="/results/team/2014/2999.html">
       McLaren-Mercedes
      </a>
     </td>
     <td>
      15
     </td>
    </tr>
    <tr>
     <td>
      4
     </td>
     <td>
      <a href="/results/driver/2014/30.html">
       Fernando Alonso
      </a>
     </td>
     <td>
      Spanish
     </td>
     <td>
      <a href="/results/team/2014/2997.html">
       Ferrari
      </a>
     </td>
     <td>
      12
     </td>
    </tr>
    <tr>
     <td>
      5
     </td>
     <td>
      <a href="/results/driver/2014/865.html">
       Valtteri  Bottas
      </a>
     </td>
     <td>
      Finnish
     </td>
     <td>
      <a href="/results/team/2014/3003.html">
       Williams-Mercedes
      </a>
     </td>
     <td>
      10
     </td>
    </tr>
    <tr>
     <td>
      6
     </td>
     <td>
      <a href="/results/driver/2014/840.html">
       Nico Hulkenberg
      </a>
     </td>
     <td>
      German
     </td>
     <td>
      <a href="/results/team/2014/3000.html">
       Force India-Mercedes
      </a>
     </td>
     <td>
      8
     </td>
    </tr>
    <tr>
     <td>
      7
     </td>
     <td>
      <a href="/results/driver/2014/12.html">
       Kimi Räikkönen
      </a>
     </td>
     <td>
      Finnish
     </td>
     <td>
      <a href="/results/team/2014/2997.html">
       Ferrari
      </a>
     </td>
     <td>
      6
     </td>
    </tr>
    <tr>
     <td>
      8
     </td>
     <td>
      <a href="/results/driver/2014/870.html">
       Jean-Eric Vergne
      </a>
     </td>
     <td>
      French
     </td>
     <td>
      <a href="/results/team/2014/3002.html">
       STR-Renault
      </a>
     </td>
     <td>
      4
     </td>
    </tr>
    <tr>
     <td>
      9
     </td>
     <td>
      <a href="/results/driver/2014/906.html">
       Daniil Kvyat
      </a>
     </td>
     <td>
      Russian
     </td>
     <td>
      <a href="/results/team/2014/3002.html">
       STR-Renault
      </a>
     </td>
     <td>
      2
     </td>
    </tr>
    <tr>
     <td>
      10
     </td>
     <td>
      <a href="/results/driver/2014/867.html">
       Sergio Perez
      </a>
     </td>
     <td>
      Mexican
     </td>
     <td>
      <a href="/results/team/2014/3000.html">
       Force India-Mercedes
      </a>
     </td>
     <td>
      1
     </td>
    </tr>
    <tr>
     <td>
      11
     </td>
     <td>
      <a href="/results/driver/2014/818.html">
       Adrian Sutil
      </a>
     </td>
     <td>
      German
     </td>
     <td>
      <a href="/results/team/2014/3001.html">
       Sauber-Ferrari
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      12
     </td>
     <td>
      <a href="/results/driver/2014/854.html">
       Esteban Gutierrez
      </a>
     </td>
     <td>
      Mexican
     </td>
     <td>
      <a href="/results/team/2014/3001.html">
       Sauber-Ferrari
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      13
     </td>
     <td>
      <a href="/results/driver/2014/887.html">
       Max Chilton
      </a>
     </td>
     <td>
      British
     </td>
     <td>
      <a href="/results/team/2014/3004.html">
       Marussia-Ferrari
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      14
     </td>
     <td>
      <a href="/results/driver/2014/850.html">
       Jules Bianchi
      </a>
     </td>
     <td>
      French
     </td>
     <td>
      <a href="/results/team/2014/3004.html">
       Marussia-Ferrari
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      15
     </td>
     <td>
      <a href="/results/driver/2014/838.html">
       Romain Grosjean
      </a>
     </td>
     <td>
      French
     </td>
     <td>
      <a href="/results/team/2014/2998.html">
       Lotus-Renault
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      16
     </td>
     <td>
      <a href="/results/driver/2014/869.html">
       Pastor Maldonado
      </a>
     </td>
     <td>
      Venezuelan
     </td>
     <td>
      <a href="/results/team/2014/2998.html">
       Lotus-Renault
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      17
     </td>
     <td>
      <a href="/results/driver/2014/862.html">
       Marcus Ericsson
      </a>
     </td>
     <td>
      Swedish
     </td>
     <td>
      <a href="/results/team/2014/3005.html">
       Caterham-Renault
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      18
     </td>
     <td>
      <a href="/results/driver/2014/822.html">
       Sebastian Vettel
      </a>
     </td>
     <td>
      German
     </td>
     <td>
      <a href="/results/team/2014/2995.html">
       Red Bull Racing-Renault
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      19
     </td>
     <td>
      <a href="/results/driver/2014/828.html">
       Lewis Hamilton
      </a>
     </td>
     <td>
      British
     </td>
     <td>
      <a href="/results/team/2014/2996.html">
       Mercedes
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      20
     </td>
     <td>
      <a href="/results/driver/2014/18.html">
       Felipe Massa
      </a>
     </td>
     <td>
      Brazilian
     </td>
     <td>
      <a href="/results/team/2014/3003.html">
       Williams-Mercedes
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      21
     </td>
     <td>
      <a href="/results/driver/2014/837.html">
       Kamui Kobayashi
      </a>
     </td>
     <td>
      Japanese
     </td>
     <td>
      <a href="/results/team/2014/3005.html">
       Caterham-Renault
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
    <tr>
     <td>
      22
     </td>
     <td>
      <a href="/results/driver/2014/857.html">
       Daniel Ricciardo
      </a>
     </td>
     <td>
      Australian
     </td>
     <td>
      <a href="/results/team/2014/2995.html">
       Red Bull Racing-Renault
      </a>
     </td>
     <td>
      0
     </td>
    </tr>
   </table>
  </div>
 </body>
</html>
>>> table = soup.find('table')
>>> rows = table.findAll('tr')
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text+"|",)
  print

  
<built-in function print>
1|
 Nico Rosberg|
German|
 Mercedes|
25|
<built-in function print>
2|
 Kevin Magnussen|
Danish|
 McLaren-Mercedes|
18|
<built-in function print>
3|
 Jenson Button|
British|
 McLaren-Mercedes|
15|
<built-in function print>
4|
 Fernando Alonso|
Spanish|
 Ferrari|
12|
<built-in function print>
5|
 Valtteri  Bottas|
Finnish|
 Williams-Mercedes|
10|
<built-in function print>
6|
 Nico Hulkenberg|
German|
 Force India-Mercedes|
8|
<built-in function print>
7|
 Kimi Räikkönen|
Finnish|
 Ferrari|
6|
<built-in function print>
8|
 Jean-Eric Vergne|
French|
 STR-Renault|
4|
<built-in function print>
9|
 Daniil Kvyat|
Russian|
 STR-Renault|
2|
<built-in function print>
10|
 Sergio Perez|
Mexican|
 Force India-Mercedes|
1|
<built-in function print>
11|
 Adrian Sutil|
German|
 Sauber-Ferrari|
0|
<built-in function print>
12|
 Esteban Gutierrez|
Mexican|
 Sauber-Ferrari|
0|
<built-in function print>
13|
 Max Chilton|
British|
 Marussia-Ferrari|
0|
<built-in function print>
14|
 Jules Bianchi|
French|
 Marussia-Ferrari|
0|
<built-in function print>
15|
 Romain Grosjean|
French|
 Lotus-Renault|
0|
<built-in function print>
16|
 Pastor Maldonado|
Venezuelan|
 Lotus-Renault|
0|
<built-in function print>
17|
 Marcus Ericsson|
Swedish|
 Caterham-Renault|
0|
<built-in function print>
18|
 Sebastian Vettel|
German|
 Red Bull Racing-Renault|
0|
<built-in function print>
19|
 Lewis Hamilton|
British|
 Mercedes|
0|
<built-in function print>
20|
 Felipe Massa|
Brazilian|
 Williams-Mercedes|
0|
<built-in function print>
21|
 Kamui Kobayashi|
Japanese|
 Caterham-Renault|
0|
<built-in function print>
22|
 Daniel Ricciardo|
Australian|
 Red Bull Racing-Renault|
0|
<built-in function print>
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text+"|",)

      
1|
 Nico Rosberg|
German|
 Mercedes|
25|
2|
 Kevin Magnussen|
Danish|
 McLaren-Mercedes|
18|
3|
 Jenson Button|
British|
 McLaren-Mercedes|
15|
4|
 Fernando Alonso|
Spanish|
 Ferrari|
12|
5|
 Valtteri  Bottas|
Finnish|
 Williams-Mercedes|
10|
6|
 Nico Hulkenberg|
German|
 Force India-Mercedes|
8|
7|
 Kimi Räikkönen|
Finnish|
 Ferrari|
6|
8|
 Jean-Eric Vergne|
French|
 STR-Renault|
4|
9|
 Daniil Kvyat|
Russian|
 STR-Renault|
2|
10|
 Sergio Perez|
Mexican|
 Force India-Mercedes|
1|
11|
 Adrian Sutil|
German|
 Sauber-Ferrari|
0|
12|
 Esteban Gutierrez|
Mexican|
 Sauber-Ferrari|
0|
13|
 Max Chilton|
British|
 Marussia-Ferrari|
0|
14|
 Jules Bianchi|
French|
 Marussia-Ferrari|
0|
15|
 Romain Grosjean|
French|
 Lotus-Renault|
0|
16|
 Pastor Maldonado|
Venezuelan|
 Lotus-Renault|
0|
17|
 Marcus Ericsson|
Swedish|
 Caterham-Renault|
0|
18|
 Sebastian Vettel|
German|
 Red Bull Racing-Renault|
0|
19|
 Lewis Hamilton|
British|
 Mercedes|
0|
20|
 Felipe Massa|
Brazilian|
 Williams-Mercedes|
0|
21|
 Kamui Kobayashi|
Japanese|
 Caterham-Renault|
0|
22|
 Daniel Ricciardo|
Australian|
 Red Bull Racing-Renault|
0|
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text, end='')

      
1 Nico RosbergGerman Mercedes252 Kevin MagnussenDanish McLaren-Mercedes183 Jenson ButtonBritish McLaren-Mercedes154 Fernando AlonsoSpanish Ferrari125 Valtteri  BottasFinnish Williams-Mercedes106 Nico HulkenbergGerman Force India-Mercedes87 Kimi RäikkönenFinnish Ferrari68 Jean-Eric VergneFrench STR-Renault49 Daniil KvyatRussian STR-Renault210 Sergio PerezMexican Force India-Mercedes111 Adrian SutilGerman Sauber-Ferrari012 Esteban GutierrezMexican Sauber-Ferrari013 Max ChiltonBritish Marussia-Ferrari014 Jules BianchiFrench Marussia-Ferrari015 Romain GrosjeanFrench Lotus-Renault016 Pastor MaldonadoVenezuelan Lotus-Renault017 Marcus EricssonSwedish Caterham-Renault018 Sebastian VettelGerman Red Bull Racing-Renault019 Lewis HamiltonBritish Mercedes020 Felipe MassaBrazilian Williams-Mercedes021 Kamui KobayashiJapanese Caterham-Renault022 Daniel RicciardoAustralian Red Bull Racing-Renault0
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text)

      
1
 Nico Rosberg
German
 Mercedes
25
2
 Kevin Magnussen
Danish
 McLaren-Mercedes
18
3
 Jenson Button
British
 McLaren-Mercedes
15
4
 Fernando Alonso
Spanish
 Ferrari
12
5
 Valtteri  Bottas
Finnish
 Williams-Mercedes
10
6
 Nico Hulkenberg
German
 Force India-Mercedes
8
7
 Kimi Räikkönen
Finnish
 Ferrari
6
8
 Jean-Eric Vergne
French
 STR-Renault
4
9
 Daniil Kvyat
Russian
 STR-Renault
2
10
 Sergio Perez
Mexican
 Force India-Mercedes
1
11
 Adrian Sutil
German
 Sauber-Ferrari
0
12
 Esteban Gutierrez
Mexican
 Sauber-Ferrari
0
13
 Max Chilton
British
 Marussia-Ferrari
0
14
 Jules Bianchi
French
 Marussia-Ferrari
0
15
 Romain Grosjean
French
 Lotus-Renault
0
16
 Pastor Maldonado
Venezuelan
 Lotus-Renault
0
17
 Marcus Ericsson
Swedish
 Caterham-Renault
0
18
 Sebastian Vettel
German
 Red Bull Racing-Renault
0
19
 Lewis Hamilton
British
 Mercedes
0
20
 Felipe Massa
Brazilian
 Williams-Mercedes
0
21
 Kamui Kobayashi
Japanese
 Caterham-Renault
0
22
 Daniel Ricciardo
Australian
 Red Bull Racing-Renault
0
>>> import urllib2
Traceback (most recent call last):
  File "<pyshell#73>", line 1, in <module>
    import urllib2
ImportError: No module named 'urllib2'
>>> import urllib
>>> response = urllib.urlopen('http://www.formula1.com/results/driver/')
Traceback (most recent call last):
  File "<pyshell#75>", line 1, in <module>
    response = urllib.urlopen('http://www.formula1.com/results/driver/')
AttributeError: 'module' object has no attribute 'urlopen'
>>> import urllib.request
>>> with urllib.request.urlopen('http://www.formula1.com/results/driver/') as url:
	s = url.read()

	
print(s)

>>> print(s)
b'\r\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\r\n<head id="ctl00_Head1">\r\n<title>Formula 1\xc2\xae - The Official F1\xc2\xae Website</title>\r\n<meta http-equiv="X-UA-Compatible" content="IE=edge">\r\n<script type="text/javascript">\r\n\tdocument.getElementsByTagName(\'html\')[0].className = \'jsEnabled\';\r\n</script>\r\n\r\n<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />\r\n\r\n<link href="/css/global.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/navigation.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/modules.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/slimbox.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/videobox.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/f1_forms.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/cookiepolicybanner.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/print.css" rel="stylesheet" type="text/css" media="print" />\r\n<link rel="shortcut icon" type="image/x-icon" href="http://www.formula1.com/favicon.ico" />\r\n<link rel="apple-touch-icon-precomposed" href="http://www.formula1.com/desktopfavicon.png"/>\r\n\r\n<link href="/assets/fragment/css/dynamic.css" rel="stylesheet" type="text/css" media="screen" />\r\n\r\n<!--[if lt IE 7]>\r\n    <link href="/css/ie6.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 7]>\r\n    <link href="/css/ie7.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 8]>\r\n    <link href="/css/ie8.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 9]>\r\n    <link href="/css/ie9.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<script src="http://code.jquery.com/jquery-1.7.2.min.js" type="text/javascript"></script>\r\n<script type="text/javascript" src="/js/AC_OETags.js"></script>\r\n<script type="text/javascript" src="/js/swfobject2.js"></script>\r\n<script type="text/javascript" src="/js/cookiepolicybanner.js"></script>\r\n<script type="text/javascript" src="/js/modernizr.min.js"></script>\r\n<script type="text/javascript" src="/js/rolex_clock/listofdates.js"></script>\n<script type="text/javascript" src="/js/rolex_clock/timezones.js"></script>\n\r\n\r\n\r\n\r\n    <script type="text/javascript" src="/js/BrowserDetect.js"></script>\r\n    <script type="text/javascript" src="/js/mootools.js"></script>\r\n    <script type="text/javascript" src="/js/cookies.js"></script>\r\n    <script type="text/javascript" src="/js/global.js"></script>\r\n    <script type="text/javascript" src="/js/menunavigation.js"></script>\r\n    <script type="text/javascript" src="/js/navigation.js"></script>\r\n    <script type="text/javascript" src="/js/slimbox.js"></script>\r\n    <script type="text/javascript" src="/js/galleryRollover.js"></script>\r\n    <script type="text/javascript" src="/js/slideshow.js"></script>\r\n    <script type="text/javascript" src="/js/image_right_click.js"></script>\r\n    <script type="text/javascript" src="/js/LiveTimingPopup.js"></script>\r\n    \r\n    <script type="text/javascript" src="/js/time.js"></script>\r\n    <script type="text/javascript" src="/js/webservice.js"></script>\r\n\r\n    <script type="text/javascript" src="/js/f1_forms.js"></script>\r\n    <script type="text/javascript" src="/js/f1_detect.js"></script>    \r\n\r\n\r\n\r\n    <script type="text/javascript" src="/js/dom-drag.js"></script>\r\n\r\n\r\n\r\n\r\n<!--[if lt IE 7]>\r\n    <script defer type="text/javascript" src="/js/unitpngfix.js"></script>\r\n<![endif]-->\r\n\r\n\r\n<noscript>\r\n<style type="text/css">\r\n    div#tertiaryNav div.tertiaryNavItem{\r\n        display: block;        \r\n    }     \r\n</style>\r\n<style type="text/css">\r\n\t#bannerWrapper{margin-bottom: 10px;}\r\n</style>\r\n</noscript>\r\n\r\n\r\n<script type="text/javascript">\r\n    fncFesDisableContextMenuForImages();\r\n</script>    \r\n\r\n    \r\n    <!-- Google Analytics -->\r\n\r\n    <script type="text/javascript">\r\n        var _gaq = _gaq || [];\r\n        _gaq.push([\'_setAccount\', \'UA-4466993-1\']);\r\n        _gaq.push([\'_setDomainName\', \'formula1.com\']);\r\n        _gaq.push([\'_trackPageview\']);\r\n\r\n        (function() {\r\n            var ga = document.createElement(\'script\');\r\n            ga.type = \'text/javascript\';\r\n            ga.async = true;\r\n            ga.src = (\'https:\' == document.location.protocol ? \'https://ssl\' : \'http://www\') + \'.google-analytics.com/ga.js\';\r\n            var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(ga, s);\r\n        })();\r\n    </script>\r\n\r\n    <!-- Google Analytics -->\r\n\r\n<title>\r\n\tDriver Results\r\n</title></head>\r\n<body>\r\n    \r\n    <div id="identHomePage" style="display: none">\r\n        <div id="identDiv" class="identBg">\r\n        </div>\r\n        <div id="ident" class="ident">\r\n            <div id="identHolder">\r\n            </div>\r\n        </div>\r\n\r\n        <script type="text/javascript">\r\n            if (!SkipIdentAlways() && isRootPage()) {\r\n                $(\'identDiv\').setStyle(\'height\', \'100%\');\r\n                $(\'ident\').setStyle(\'height\', getWinHeight() + \'px\');\r\n\r\n                var flashvars = {};\r\n                var params = { wmode: "transparent", quality: "autolow" };\r\n\r\n                if (BrowserDetect.browser == "Firefox")\r\n                    params = { quality: "autolow" };\r\n\r\n                swfobject.embedSWF("/flash/homepage/ident/identPreloader.swf", "identHolder", "100%", "100%", "9.0.0", "/js/expressInstall.swf", flashvars, params);\r\n            }  \t      \r\n        </script>\r\n\r\n    </div>\r\n    <div id="wrapperHeading">\r\n\r\n        <script type="text/javascript" language="javascript">            \r\n            if (GetSwfVer()!="-1" && !SkipIdentAlways() && isRootPage() && (isExternalRequest() || isIdentCookieExpired())) {\r\n                $(\'wrapperHeading\').setStyle(\'visibility\', \'hidden\');\r\n            }\r\n            else {\r\n                $(\'wrapperHeading\').setStyle(\'visibility\', \'visible\');\r\n            }\r\n        </script>\r\n\r\n        <div id="wrapperContent">\r\n            <a name="top"></a>\r\n            \r\n\r\n<h1>\r\n    <a href="/default.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Header\',\'F1_Logo\'])">\r\n        <img id="blackImage" src="/img/heading/logo_f1.png" alt="Home - The Official Formula 1 Website" />\r\n        <img id="whiteImage" src="/img/heading/logo_f1_wte.gif" alt="Home - The Official Formula 1 Website" style="display: none;" />\r\n    </a> \r\n    <a id="skipNav" href="#content">Skip to content</a>\r\n</h1>\r\n            \r\n            <div id="nav">\r\n                \r\n\t\t<ul id="primaryNav">\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navNEWS navNEWS_en\'><a href="/news/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'News\');return false;">NEWS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navNEWS_HEADLINES navNEWS_HEADLINES_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/headlines/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Headlines\');return false;">HEADLINES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_FEATURES navNEWS_FEATURES_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/features/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Features\');return false;">FEATURES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_TECHNICAL navNEWS_TECHNICAL_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/technical/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Technical\');return false;">TECHNICAL</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_INTERVIEWS navNEWS_INTERVIEWS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/interviews/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Interviews\');return false;">INTERVIEWS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_FEEDS navNEWS_FEEDS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/feeds.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Feeds\');return false;">FEEDS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_SEARCHRESULTS navNEWS_SEARCHRESULTS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navRACES navRACES_en\'><a href="/races/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Races\');return false;">RACES</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navRACES_INDETAIL navRACES_INDETAIL_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/in_detail/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'In_Detail\');return false;">IN DETAIL</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRACES_2014CALENDAR navRACES_2014CALENDAR_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/calendar.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'L2\',\'2014_Calendar\'])">2014 CALENDAR</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRACES_DOWNLOADS navRACES_DOWNLOADS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/downloads/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Downloads\');return false;">DOWNLOADS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\t<li class=\'current navRESULTS navRESULTS_en\'><span><a href="/results/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Results\');return false;">RESULTS</a></span>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navRESULTS_SEASON navRESULTS_SEASON_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/results/season/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Season\');return false;">SEASON</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRESULTS_TEAM navRESULTS_TEAM_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/results/team/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Team\');return false;">TEAM</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRESULTS_DRIVER navRESULTS_DRIVER_en\'>\r\n\t\t\t\t<span><a href="/results/driver/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Driver\');return false;">DRIVER</a></span>\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navGALLERY navGALLERY_en\'><a href="/gallery/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Gallery\');return false;">GALLERY</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navGALLERY_RACE navGALLERY_RACE_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/race/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Race\');return false;">RACE</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navGALLERY_TESTING navGALLERY_TESTING_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/testing/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Testing\');return false;">TESTING</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navGALLERY_LAUNCHES navGALLERY_LAUNCHES_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/launches/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Launches\');return false;">LAUNCHES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navGALLERY_OTHER navGALLERY_OTHER_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/other/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Other\');return false;">OTHER</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navTEAMSDRIVERS navTEAMSDRIVERS_en\'><a href="/teams_and_drivers/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Teams_And_Drivers\');return false;">TEAMS &AMP; DRIVERS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navTEAMSDRIVERS_TEAMS navTEAMSDRIVERS_TEAMS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/teams/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Teams\');return false;">TEAMS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navTEAMSDRIVERS_DRIVERS navTEAMSDRIVERS_DRIVERS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/drivers/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Drivers\');return false;">DRIVERS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navTEAMSDRIVERS_HALLOFFAME navTEAMSDRIVERS_HALLOFFAME_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/hall_of_fame/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Hall_Of_Fame\');return false;">HALL OF FAME</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navINSIDEF1 navINSIDEF1_en\'><a href="/inside_f1/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Inside_F1\');return false;">INSIDE F1</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_RULESREGULATIONS navINSIDEF1_RULESREGULATIONS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/rules_and_regulations/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Rules_And_Regulations\');return false;">RULES &AMP; REGULATIONS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_UNDERSTANDINGF1RACING navINSIDEF1_UNDERSTANDINGF1RACING_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/understanding_the_sport/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Understanding_The_Sport\');return false;">UNDERSTANDING F1 RACING</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_SAFETY navINSIDEF1_SAFETY_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/safety/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Safety\');return false;">SAFETY</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_THEF1BRAND navINSIDEF1_THEF1BRAND_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/f1brand.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'F1brand\');return false;">THE F1 BRAND</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_GLOSSARY navINSIDEF1_GLOSSARY_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/glossary.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Glossary\');return false;">GLOSSARY</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_FAQ navINSIDEF1_FAQ_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/faq.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Faq\');return false;">FAQ</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_SEARCHRESULTS navINSIDEF1_SEARCHRESULTS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navLIVETIMING navLIVETIMING_en\'><a href="/live_timing/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Live_Timing\');return false;">LIVE TIMING</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navVIDEO navVIDEO_en\'><a href="/video/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Video\');return false;">VIDEO</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navVIDEO_RACEEDITS navVIDEO_RACEEDITS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/video/race_edits/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Race_Edits\');return false;">RACE EDITS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navVIDEO_ONBOARD navVIDEO_ONBOARD_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/video/onboard/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Onboard\');return false;">ONBOARD</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navTICKETS navTICKETS_en\'><a href="/tickets_and_travel/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Tickets\');return false;">TICKETS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navF1STORE navF1STORE_en\'><a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&CMP=PSC-CHMHGTFG" target="_blank" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'F1_Store\');return false;">F1 STORE</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navAPP navAPP_en\'><a href="/app/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'App\');return false;">APP</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t</ul>\r\n\t\r\n            </div>\r\n            <div id="content">\r\n                \r\n                \r\n<!-- Hide when on Home -->\r\n\r\n    <div id="tertiaryNav">\r\n        <div class="tertiaryNavItem">\r\n            <ul>\r\n                \r\n                        \r\n<li class="listheader"><span><a href="/results/driver/2014/">\r\n    2014<img src="/img/decals/nav_arrow_ltbg.gif" /></a></span>\r\n    \r\n            <ul>\r\n        \r\n            <li>\r\n                <a class="L3Selected" href="/results/driver/2014/">2014</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2013/">2013</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2012/">2012</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2011/">2011</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2010/">2010</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2009/">2009</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2008/">2008</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2007/">2007</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2006/">2006</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2005/">2005</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2004/">2004</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2003/">2003</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2002/">2002</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2001/">2001</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2000/">2000</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1999/">1999</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1998/">1998</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1997/">1997</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1996/">1996</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1995/">1995</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1994/">1994</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1993/">1993</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1992/">1992</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1991/">1991</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1990/">1990</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1989/">1989</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1988/">1988</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1987/">1987</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1986/">1986</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1985/">1985</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1984/">1984</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1983/">1983</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1982/">1982</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1981/">1981</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1980/">1980</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1979/">1979</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1978/">1978</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1977/">1977</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1976/">1976</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1975/">1975</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1974/">1974</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1973/">1973</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1972/">1972</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1971/">1971</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1970/">1970</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1969/">1969</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1968/">1968</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1967/">1967</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1966/">1966</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1965/">1965</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1964/">1964</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1963/">1963</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1962/">1962</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1961/">1961</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1960/">1960</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1959/">1959</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1958/">1958</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1957/">1957</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1956/">1956</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1955/">1955</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1954/">1954</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1953/">1953</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1952/">1952</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1951/">1951</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/1950/">1950</a></li>\r\n        \r\n            </ul>\r\n        \r\n</li>\r\n\r\n                    \r\n                        \r\n<li class="listheader"><span><a href="/results/driver/2014/">\r\n    ALL DRIVERS<img src="/img/decals/nav_arrow_ltbg.gif" /></a></span>\r\n    \r\n            <ul>\r\n        \r\n            <li>\r\n                <a class="L3Selected" href="/results/driver/2014/">ALL DRIVERS</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/30.html">ALONSO, FERNANDO</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/850.html">BIANCHI, JULES</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/865.html">BOTTAS, VALTTERI </a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/6.html">BUTTON, JENSON</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/887.html">CHILTON, MAX</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/862.html">ERICSSON, MARCUS</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/838.html">GROSJEAN, ROMAIN</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/854.html">GUTIERREZ, ESTEBAN</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/828.html">HAMILTON, LEWIS</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/840.html">HULKENBERG, NICO</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/837.html">KOBAYASHI, KAMUI</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/906.html">KVYAT, DANIIL</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/899.html">MAGNUSSEN, KEVIN</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/869.html">MALDONADO, PASTOR</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/18.html">MASSA, FELIPE</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/867.html">PEREZ, SERGIO</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/12.html">R\xc3\x84IKK\xc3\x96NEN, KIMI</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/857.html">RICCIARDO, DANIEL</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/809.html">ROSBERG, NICO</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/818.html">SUTIL, ADRIAN</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/870.html">VERGNE, JEAN-ERIC</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/driver/2014/822.html">VETTEL, SEBASTIAN</a></li>\r\n        \r\n            </ul>\r\n        \r\n</li>\r\n\r\n                    \r\n            </ul>\r\n        </div>\r\n    </div>\r\n\r\n\r\n                  <div id="contentMain">\r\n                    <!-- content modules here -->\r\n                    \r\n    \r\n\r\n\r\n        <div class="contentContainer">\r\n            <table class="raceResults" cellpadding="0" cellspacing="0" summary="">\r\n                <tr>\r\n                    <th>Pos</th>\r\n                    <th>Driver</th>\r\n                    <th>Nationality</th>\r\n                    <th>Team</th>\r\n                    <th>Points</th>\r\n                </tr>\r\n    \r\n        <tr>\r\n            <td>1</td>\r\n            <td><a href="/results/driver/2014/809.html"> Nico Rosberg</a></td>\r\n            <td>German</td>\r\n            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>\r\n            <td>25</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>2</td>\r\n            <td><a href="/results/driver/2014/899.html"> Kevin Magnussen</a></td>\r\n            <td>Danish</td>\r\n            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>\r\n            <td>18</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>3</td>\r\n            <td><a href="/results/driver/2014/6.html"> Jenson Button</a></td>\r\n            <td>British</td>\r\n            <td><a href="/results/team/2014/2999.html"> McLaren-Mercedes</a></td>\r\n            <td>15</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>4</td>\r\n            <td><a href="/results/driver/2014/30.html"> Fernando Alonso</a></td>\r\n            <td>Spanish</td>\r\n            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>\r\n            <td>12</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>5</td>\r\n            <td><a href="/results/driver/2014/865.html"> Valtteri  Bottas</a></td>\r\n            <td>Finnish</td>\r\n            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>\r\n            <td>10</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>6</td>\r\n            <td><a href="/results/driver/2014/840.html"> Nico Hulkenberg</a></td>\r\n            <td>German</td>\r\n            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>\r\n            <td>8</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>7</td>\r\n            <td><a href="/results/driver/2014/12.html"> Kimi R\xc3\xa4ikk\xc3\xb6nen</a></td>\r\n            <td>Finnish</td>\r\n            <td><a href="/results/team/2014/2997.html"> Ferrari</a></td>\r\n            <td>6</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>8</td>\r\n            <td><a href="/results/driver/2014/870.html"> Jean-Eric Vergne</a></td>\r\n            <td>French</td>\r\n            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>\r\n            <td>4</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>9</td>\r\n            <td><a href="/results/driver/2014/906.html"> Daniil Kvyat</a></td>\r\n            <td>Russian</td>\r\n            <td><a href="/results/team/2014/3002.html"> STR-Renault</a></td>\r\n            <td>2</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>10</td>\r\n            <td><a href="/results/driver/2014/867.html"> Sergio Perez</a></td>\r\n            <td>Mexican</td>\r\n            <td><a href="/results/team/2014/3000.html"> Force India-Mercedes</a></td>\r\n            <td>1</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>11</td>\r\n            <td><a href="/results/driver/2014/818.html"> Adrian Sutil</a></td>\r\n            <td>German</td>\r\n            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>12</td>\r\n            <td><a href="/results/driver/2014/854.html"> Esteban Gutierrez</a></td>\r\n            <td>Mexican</td>\r\n            <td><a href="/results/team/2014/3001.html"> Sauber-Ferrari</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>13</td>\r\n            <td><a href="/results/driver/2014/887.html"> Max Chilton</a></td>\r\n            <td>British</td>\r\n            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>14</td>\r\n            <td><a href="/results/driver/2014/850.html"> Jules Bianchi</a></td>\r\n            <td>French</td>\r\n            <td><a href="/results/team/2014/3004.html"> Marussia-Ferrari</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>15</td>\r\n            <td><a href="/results/driver/2014/838.html"> Romain Grosjean</a></td>\r\n            <td>French</td>\r\n            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>16</td>\r\n            <td><a href="/results/driver/2014/869.html"> Pastor Maldonado</a></td>\r\n            <td>Venezuelan</td>\r\n            <td><a href="/results/team/2014/2998.html"> Lotus-Renault</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>17</td>\r\n            <td><a href="/results/driver/2014/862.html"> Marcus Ericsson</a></td>\r\n            <td>Swedish</td>\r\n            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>18</td>\r\n            <td><a href="/results/driver/2014/822.html"> Sebastian Vettel</a></td>\r\n            <td>German</td>\r\n            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>19</td>\r\n            <td><a href="/results/driver/2014/828.html"> Lewis Hamilton</a></td>\r\n            <td>British</td>\r\n            <td><a href="/results/team/2014/2996.html"> Mercedes</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>20</td>\r\n            <td><a href="/results/driver/2014/18.html"> Felipe Massa</a></td>\r\n            <td>Brazilian</td>\r\n            <td><a href="/results/team/2014/3003.html"> Williams-Mercedes</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>21</td>\r\n            <td><a href="/results/driver/2014/837.html"> Kamui Kobayashi</a></td>\r\n            <td>Japanese</td>\r\n            <td><a href="/results/team/2014/3005.html"> Caterham-Renault</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>22</td>\r\n            <td><a href="/results/driver/2014/857.html"> Daniel Ricciardo</a></td>\r\n            <td>Australian</td>\r\n            <td><a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a></td>\r\n            <td>0</td>           \r\n        </tr>\r\n    \r\n            </table>\r\n         </div>\r\n    \r\n\r\n\r\n\r\n                    </div>\r\n                <div id="contentSub">\r\n                    <!-- subModules here -->\r\n                    \r\n\r\n<!-- Advertising Panel START-->\r\n\r\n<style type="text/css">\r\n#adHoldLeft {\r\n\t-webkit-transition: all 250ms ease;\r\n\t-moz-transition: all 250ms ease;\r\n\t-ms-transition: all 250ms ease;\r\n\t-o-transition: all 250ms ease;\r\n\ttransition: all 250ms ease;\r\n}\r\n</style>\r\n<script type="text/javascript">\r\n    var now = new Date();\r\n    var unique = "unique=" + now.getTime();\r\n    var adHoldLeftHeight = 409;\r\n    function sbaSize(toBe){\r\n        document.getElementById("adHoldRightCol").style.height = toBe + "px";\r\n        $(\'adHoldRightCol\').setStyle(\'overflow\', \'hidden\');\r\n        if (toBe > 0)\r\n        {\r\n            $(\'adHoldRightCol\').setStyle(\'padding\', \'0 0 5px 0\');\r\n        }\r\n        else\r\n        {\r\n            $(\'adHoldRightCol\').setStyle(\'padding\', \'0 0 0 0\');\r\n        }\r\n    }\r\n    \r\n    function sbaHide(){\r\n        document.getElementById("adHoldLeftCol").style.zIndex = "-1000";\r\n        document.getElementById("adHoldLeftCol").style.height = "0px";\r\n        document.getElementById("adHoldLeft").style.height = adHoldLeftHeight;\r\n        document.getElementById("adHoldLeft").style.overflow = "hidden";\r\n    }\r\n    \r\n    function sbaShow(){\r\n        document.getElementById("adHoldLeftCol").style.zIndex = "1000";\r\n        document.getElementById("adHoldLeftCol").style.height = adHoldLeftHeight + "px";\r\n        document.getElementById("adHoldLeft").style.height = adHoldLeftHeight + "px";\r\n    }\r\n    \r\n    var sbaLoadRightCalled = false;\r\n    function sbaLoadRight()\r\n    {\r\n        if (sbaLoadRightCalled)\r\n        {\r\n            return;\r\n        }\r\n            \r\n        sbaLoadRightCalled = true;\r\n        \r\n        sbaHide();\r\n        \r\n\t\tvar flashvars = false;\r\n\t\tvar attributes = {id: "adHoldRight"};\r\n\t\tvar params = { allowScriptAccess: "always", quality: "high", wmode: "transparent", FlashVars: unique + "&home=" + (window.location.pathname == \'/\') + "&xmlUrl=/xml/advertising/sidebar/site.xml&artDir=promos&typeArray=D,D&nameArray=tata,emirates&weightArray=35,65" };\r\n\t\tswfobject.embedSWF("/flash/advertising/side_bar/adHoldRight.swf", "adHoldRightFlash", "235", "600", "9.0.0","/js/expressInstall.swf", flashvars, params, attributes);\r\n    }\r\n\r\n    window.addEvent(\'domready\', function(){\r\n        // create adHoldLeftCol container DIV and insert in contentMain DIV\r\n\t     var oDiv = new Element(\'div\', {\r\n\t     \'id\':\'adHoldLeftCol\',\r\n\t     \'styles\':{\'position\':\'absolute\',\'margin-left\':\'0px\',\'margin-top\':\'0px\',\'zIndex\':\'-1000\',\'height\':\'0\'}\r\n\t     });\r\n\t     \t     \r\n\t  \toDiv.injectTop($(\'contentMain\'));\r\n\t  \t\r\n        var oFlashDiv = new Element(\'div\', {\r\n        \'id\':\'adHoldLeftFlash\'\r\n        });\r\n        \r\n        oFlashDiv.inject(oDiv);\r\n\r\n\t\tvar flashvars = false;\r\n\t\tvar attributes = {id: "adHoldLeft"};\r\n\t\tvar params = { allowScriptAccess: "always", quality: "high", wmode: "transparent", FlashVars: unique + "&home=" + (window.location.pathname == \'/\') + "&xmlUrl=/xml/advertising/sidebar/site.xml&artDir=rollpanels&typeArray=D,D&nameArray=tata,emirates&weightArray=35,65" };\r\n\t\tif ( (swfobject.getFlashPlayerVersion()).major > 0 )\r\n\t\t{\r\n\t\t    swfobject.embedSWF("/flash/advertising/side_bar/adHoldLeft.swf", "adHoldLeftFlash", "715", adHoldLeftHeight, "9.0.0","/js/expressInstall.swf", flashvars, params, attributes);\r\n\t\t}\r\n\t\telse\r\n\t\t{\r\n    \t\tvar htmlAdModule = new HtmlAdModule({\r\n\t\t\t\tflashVars: params.FlashVars\r\n\t\t\t});\r\n\t\t\thtmlAdModule.selectAdvert(); \r\n\t\t}\r\n});\r\n\r\n</script>\r\n\r\n<div id="adHoldRightCol" style="z-index: 1; display: block; height:0; padding: 0px 0 0px 0;">\r\n<div id="adHoldRightFlash"></div>\r\n</div>\r\n<script type="text/javascript" src="/js/htmlAdModule.js"></script>\r\n\r\n\r\n\r\n                    \r\n    \r\n\r\n<div class="subModule">\r\n    <A class=rhsPromoButton title="Play Video" onclick="if (window.pageTracker) { pageTracker._trackPageview(\'/Buttons/RHP/Video_Promo_Button\'); }" href="/video/"></A>\r\n</div>\r\n    \r\n    <div class="subModule">\r\n        <img src="/photos/results/results_promo.jpg" alt="Results" />\r\n    </div>\r\n\r\n    \r\n    \r\n\r\n<!-- White buttons -->\r\n    \r\n\r\n\r\n\r\n\r\n\r\n\r\n<!-- Black buttons -->\r\n\r\n\r\n<!-- Black buttons -->\r\n<div class="subModule">\r\n    <div class="button blackButton">   \r\n        <a href="/live_timing/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Live_Timing\'])">LIVE TIMING</a>\r\n    </div>\r\n    <div class="button blackButton">\r\n        <a href="/video/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Video\'])">VIDEO</a>\r\n    </div>\r\n    \r\n    <div class="button blackButton">\r\n        <a href="/tickets_and_travel/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Tickets\'])">TICKETS</a>\r\n    </div>\r\n    <div class="button blackButton">\r\n        <a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&CMP=PSC-CHMHGTFG" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'F1_Store\'])" target="_blank">F1 STORE</a>\r\n    </div>    \r\n    <div class="button buttonLast blackButton">\r\n        <a href="/app/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'App\'])" >APP</a>\r\n    </div>\r\n</div>\r\n\r\n                </div>\r\n                <div style="clear:both">&nbsp;</div>\r\n            </div>\r\n            <!-- END content -->\r\n            <!-- Start Footer -->\r\n                        \r\n            \r\n\r\n<div id="footer">\r\n    <div class="footerF1Logo">\r\n        <a href="/default.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'F1_Logo\'])">\r\n\t            <img src="/img/footer/footer_f1_logo.png" alt="Formula1.com" />\r\n\t    </a>\r\n\t</div>\r\n    <div class="footerDiv">\r\n        <img src="/img/footer/footer_div.png" />\r\n    </div>\r\n    <div class="footerMenu">\r\n        <ul class="mainNav">\r\n            <li><a href="/live_timing/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Live_Timing\'])">LIVE TIMING</a></li>\r\n\t        <li><a href="/video/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Video\'])">VIDEO</a></li>\r\n            <li><a href="/tickets_and_travel/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Tickets\'])">TICKETS</a></li>\r\n            <li><a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&CMP=PSC-CHMHGTFG" target="_blank" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'F1store\'])">F1 STORE</a></li>\r\n            <li><a href="http://mobile.formula1.com/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Advert\'])">MOBILE</a></li>\r\n        </ul>\r\n        <ul class="subNav">\r\n    \t    <li><a href="/privacypolicy.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Privacy_Policy\'])">PRIVACY POLICY</a></li>\r\n            <li><a href="/termsandconditions.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Legal_Notices\'])">LEGAL NOTICES</a></li>\r\n            <li><a href="/trademarkguidelines.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Guidelines\'])">GUIDELINES</a></li>\r\n            \r\n\t        \r\n            <li><a href="/contacts.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Contacts\'])">CONTACTS</a></li>\r\n            \r\n\t\t        <li><a href="/reg/viewdetails" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'My_Details\'])">MY DETAILS</a></li>\r\n        </ul>\r\n        <ul class="copyright">\r\n            <li>&copy; 2003-2014 Formula One World Championship Limited</li>\r\n        </ul>       \r\n    </div>\r\n    <div class="footerDiv">\r\n        <img src="/img/footer/footer_div.png" />\r\n    </div>\r\n    <div class="footerTataLogo">\r\n\t    <a href="http://www.tatacommunications.com" target="_blank" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Tata\'])">\r\n\t        <img src="/img/footer/footer_tata_logo.png" alt="TATA COMMUNICATIONS - Official web hosting and content delivery network provider of Formula1.com" />\r\n\t    </a>\r\n    </div>\r\n    \r\n    <!-- /******* HTML Code for cookie drop down text start ******/ -->\r\n    \r\n        <div id="cookiebnr" class="notification sticky visible setWidth">\r\n          <div class="wrapperAboutCookie">\r\n              <div class="aboutCookieContent">\r\n                    <p>Formula1.com uses cookies to help give you the best possible user experience. By continuing to browse this site you give consent for cookies to be used. To find out more about cookies and how to manage them, <a href="/privacypolicy.html#cookiepolicy">click here</a></p>\r\n              </div>\r\n              <div class="btn-close"><a onclick="SetCookie(\'SkipCookieLegislation\', \'true\')" href="javascript:" class="closecookiebnr">\r\n                <img alt="close button" src="/img/cookiepolicybanner/icon-close.png" class="close-button" /></a>\r\n              </div>\r\n          </div>\r\n        </div>\r\n    \r\n    <!-- /******* HTML Code for cookie drop down text end ******/ -->       \r\n</div>\r\n\r\n\r\n\r\n    <!--[if lt IE 7]>\r\n\t    <script defer type="text/javascript" src="/js/pngfix.js"></script>\r\n    <![endif]-->\r\n\r\n            \r\n            <!-- End Footer -->            \r\n        </div>\r\n        <!-- END wrapperContent -->\r\n        \r\n    </div>\r\n    \r\n    \r\n</body>\r\n</html>\r\n'
>>> soup = BeautifulSoup(''.join(s))
Traceback (most recent call last):
  File "<pyshell#81>", line 1, in <module>
    soup = BeautifulSoup(''.join(s))
TypeError: sequence item 0: expected str instance, int found
>>> table = soup.find('table')
>>> rows = table.findAll('tr')
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      
SyntaxError: multiple statements found while compiling a single statement
>>> table = s.find('table')
Traceback (most recent call last):
  File "<pyshell#83>", line 1, in <module>
    table = s.find('table')
TypeError: Type str doesn't support the buffer API
>>> BeautifulSoup(''.join(s))
Traceback (most recent call last):
  File "<pyshell#84>", line 1, in <module>
    BeautifulSoup(''.join(s))
TypeError: sequence item 0: expected str instance, int found
>>> soup = BeautifulSoup(''.join(str(s)))
>>> table = soup.find('table')
>>> rows = table.findAll('tr')
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text)

      
1
 Nico Rosberg
German
 Mercedes
25
2
 Kevin Magnussen
Danish
 McLaren-Mercedes
18
3
 Jenson Button
British
 McLaren-Mercedes
15
4
 Fernando Alonso
Spanish
 Ferrari
12
5
 Valtteri  Bottas
Finnish
 Williams-Mercedes
10
6
 Nico Hulkenberg
German
 Force India-Mercedes
8
7
 Kimi R\xc3\xa4ikk\xc3\xb6nen
Finnish
 Ferrari
6
8
 Jean-Eric Vergne
French
 STR-Renault
4
9
 Daniil Kvyat
Russian
 STR-Renault
2
10
 Sergio Perez
Mexican
 Force India-Mercedes
1
11
 Adrian Sutil
German
 Sauber-Ferrari
0
12
 Esteban Gutierrez
Mexican
 Sauber-Ferrari
0
13
 Max Chilton
British
 Marussia-Ferrari
0
14
 Jules Bianchi
French
 Marussia-Ferrari
0
15
 Romain Grosjean
French
 Lotus-Renault
0
16
 Pastor Maldonado
Venezuelan
 Lotus-Renault
0
17
 Marcus Ericsson
Swedish
 Caterham-Renault
0
18
 Sebastian Vettel
German
 Red Bull Racing-Renault
0
19
 Lewis Hamilton
British
 Mercedes
0
20
 Felipe Massa
Brazilian
 Williams-Mercedes
0
21
 Kamui Kobayashi
Japanese
 Caterham-Renault
0
22
 Daniel Ricciardo
Australian
 Red Bull Racing-Renault
0
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text[0], text[1], text[2], text[3], text[4])

      
Traceback (most recent call last):
  File "<pyshell#92>", line 5, in <module>
    print(text[0], text[1], text[2], text[3], text[4])
IndexError: string index out of range
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text[0], text[1])

      
Traceback (most recent call last):
  File "<pyshell#94>", line 5, in <module>
    print(text[0], text[1])
IndexError: string index out of range
>>> with urllib.request.urlopen('http://www.formula1.com/results/team/') as url:
	s = url.read()

	
>>> soup = BeautifulSoup(''.join(str(s)))
>>> table = soup.find('table')
>>> for tr in rows:
  cols = tr.findAll('td')
  for td in cols:
      text = ''.join(td.find(text=True))
      print(text)

      
1
 Nico Rosberg
German
 Mercedes
25
2
 Kevin Magnussen
Danish
 McLaren-Mercedes
18
3
 Jenson Button
British
 McLaren-Mercedes
15
4
 Fernando Alonso
Spanish
 Ferrari
12
5
 Valtteri  Bottas
Finnish
 Williams-Mercedes
10
6
 Nico Hulkenberg
German
 Force India-Mercedes
8
7
 Kimi R\xc3\xa4ikk\xc3\xb6nen
Finnish
 Ferrari
6
8
 Jean-Eric Vergne
French
 STR-Renault
4
9
 Daniil Kvyat
Russian
 STR-Renault
2
10
 Sergio Perez
Mexican
 Force India-Mercedes
1
11
 Adrian Sutil
German
 Sauber-Ferrari
0
12
 Esteban Gutierrez
Mexican
 Sauber-Ferrari
0
13
 Max Chilton
British
 Marussia-Ferrari
0
14
 Jules Bianchi
French
 Marussia-Ferrari
0
15
 Romain Grosjean
French
 Lotus-Renault
0
16
 Pastor Maldonado
Venezuelan
 Lotus-Renault
0
17
 Marcus Ericsson
Swedish
 Caterham-Renault
0
18
 Sebastian Vettel
German
 Red Bull Racing-Renault
0
19
 Lewis Hamilton
British
 Mercedes
0
20
 Felipe Massa
Brazilian
 Williams-Mercedes
0
21
 Kamui Kobayashi
Japanese
 Caterham-Renault
0
22
 Daniel Ricciardo
Australian
 Red Bull Racing-Renault
0
>>> with urllib.request.urlopen('http://www.formula1.com/results/team/') as url:
	s = url.read()

	
>>> print(s)
b'\r\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\r\n<head id="ctl00_Head1">\r\n<title>Formula 1\xc2\xae - The Official F1\xc2\xae Website</title>\r\n<meta http-equiv="X-UA-Compatible" content="IE=edge">\r\n<script type="text/javascript">\r\n\tdocument.getElementsByTagName(\'html\')[0].className = \'jsEnabled\';\r\n</script>\r\n\r\n<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />\r\n\r\n<link href="/css/global.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/navigation.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/modules.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/slimbox.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/videobox.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/f1_forms.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/cookiepolicybanner.css" rel="stylesheet" type="text/css" media="screen" />\r\n<link href="/css/print.css" rel="stylesheet" type="text/css" media="print" />\r\n<link rel="shortcut icon" type="image/x-icon" href="http://www.formula1.com/favicon.ico" />\r\n<link rel="apple-touch-icon-precomposed" href="http://www.formula1.com/desktopfavicon.png"/>\r\n\r\n<link href="/assets/fragment/css/dynamic.css" rel="stylesheet" type="text/css" media="screen" />\r\n\r\n<!--[if lt IE 7]>\r\n    <link href="/css/ie6.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 7]>\r\n    <link href="/css/ie7.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 8]>\r\n    <link href="/css/ie8.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 9]>\r\n    <link href="/css/ie9.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<script src="http://code.jquery.com/jquery-1.7.2.min.js" type="text/javascript"></script>\r\n<script type="text/javascript" src="/js/AC_OETags.js"></script>\r\n<script type="text/javascript" src="/js/swfobject2.js"></script>\r\n<script type="text/javascript" src="/js/cookiepolicybanner.js"></script>\r\n<script type="text/javascript" src="/js/modernizr.min.js"></script>\r\n<script type="text/javascript" src="/js/rolex_clock/listofdates.js"></script>\n<script type="text/javascript" src="/js/rolex_clock/timezones.js"></script>\n\r\n\r\n\r\n\r\n    <script type="text/javascript" src="/js/BrowserDetect.js"></script>\r\n    <script type="text/javascript" src="/js/mootools.js"></script>\r\n    <script type="text/javascript" src="/js/cookies.js"></script>\r\n    <script type="text/javascript" src="/js/global.js"></script>\r\n    <script type="text/javascript" src="/js/menunavigation.js"></script>\r\n    <script type="text/javascript" src="/js/navigation.js"></script>\r\n    <script type="text/javascript" src="/js/slimbox.js"></script>\r\n    <script type="text/javascript" src="/js/galleryRollover.js"></script>\r\n    <script type="text/javascript" src="/js/slideshow.js"></script>\r\n    <script type="text/javascript" src="/js/image_right_click.js"></script>\r\n    <script type="text/javascript" src="/js/LiveTimingPopup.js"></script>\r\n    \r\n    <script type="text/javascript" src="/js/time.js"></script>\r\n    <script type="text/javascript" src="/js/webservice.js"></script>\r\n\r\n    <script type="text/javascript" src="/js/f1_forms.js"></script>\r\n    <script type="text/javascript" src="/js/f1_detect.js"></script>    \r\n\r\n\r\n\r\n    <script type="text/javascript" src="/js/dom-drag.js"></script>\r\n\r\n\r\n\r\n\r\n<!--[if lt IE 7]>\r\n    <script defer type="text/javascript" src="/js/unitpngfix.js"></script>\r\n<![endif]-->\r\n\r\n\r\n<noscript>\r\n<style type="text/css">\r\n    div#tertiaryNav div.tertiaryNavItem{\r\n        display: block;        \r\n    }     \r\n</style>\r\n<style type="text/css">\r\n\t#bannerWrapper{margin-bottom: 10px;}\r\n</style>\r\n</noscript>\r\n\r\n\r\n<script type="text/javascript">\r\n    fncFesDisableContextMenuForImages();\r\n</script>    \r\n\r\n    \r\n    <!-- Google Analytics -->\r\n\r\n    <script type="text/javascript">\r\n        var _gaq = _gaq || [];\r\n        _gaq.push([\'_setAccount\', \'UA-4466993-1\']);\r\n        _gaq.push([\'_setDomainName\', \'formula1.com\']);\r\n        _gaq.push([\'_trackPageview\']);\r\n\r\n        (function() {\r\n            var ga = document.createElement(\'script\');\r\n            ga.type = \'text/javascript\';\r\n            ga.async = true;\r\n            ga.src = (\'https:\' == document.location.protocol ? \'https://ssl\' : \'http://www\') + \'.google-analytics.com/ga.js\';\r\n            var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(ga, s);\r\n        })();\r\n    </script>\r\n\r\n    <!-- Google Analytics -->\r\n\r\n<title>\r\n\tTeam Results\r\n</title></head>\r\n<body>\r\n    \r\n    <div id="identHomePage" style="display: none">\r\n        <div id="identDiv" class="identBg">\r\n        </div>\r\n        <div id="ident" class="ident">\r\n            <div id="identHolder">\r\n            </div>\r\n        </div>\r\n\r\n        <script type="text/javascript">\r\n            if (!SkipIdentAlways() && isRootPage()) {\r\n                $(\'identDiv\').setStyle(\'height\', \'100%\');\r\n                $(\'ident\').setStyle(\'height\', getWinHeight() + \'px\');\r\n\r\n                var flashvars = {};\r\n                var params = { wmode: "transparent", quality: "autolow" };\r\n\r\n                if (BrowserDetect.browser == "Firefox")\r\n                    params = { quality: "autolow" };\r\n\r\n                swfobject.embedSWF("/flash/homepage/ident/identPreloader.swf", "identHolder", "100%", "100%", "9.0.0", "/js/expressInstall.swf", flashvars, params);\r\n            }  \t      \r\n        </script>\r\n\r\n    </div>\r\n    <div id="wrapperHeading">\r\n\r\n        <script type="text/javascript" language="javascript">            \r\n            if (GetSwfVer()!="-1" && !SkipIdentAlways() && isRootPage() && (isExternalRequest() || isIdentCookieExpired())) {\r\n                $(\'wrapperHeading\').setStyle(\'visibility\', \'hidden\');\r\n            }\r\n            else {\r\n                $(\'wrapperHeading\').setStyle(\'visibility\', \'visible\');\r\n            }\r\n        </script>\r\n\r\n        <div id="wrapperContent">\r\n            <a name="top"></a>\r\n            \r\n\r\n<h1>\r\n    <a href="/default.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Header\',\'F1_Logo\'])">\r\n        <img id="blackImage" src="/img/heading/logo_f1.png" alt="Home - The Official Formula 1 Website" />\r\n        <img id="whiteImage" src="/img/heading/logo_f1_wte.gif" alt="Home - The Official Formula 1 Website" style="display: none;" />\r\n    </a> \r\n    <a id="skipNav" href="#content">Skip to content</a>\r\n</h1>\r\n            \r\n            <div id="nav">\r\n                \r\n\t\t<ul id="primaryNav">\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navNEWS navNEWS_en\'><a href="/news/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'News\');return false;">NEWS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navNEWS_HEADLINES navNEWS_HEADLINES_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/headlines/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Headlines\');return false;">HEADLINES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_FEATURES navNEWS_FEATURES_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/features/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Features\');return false;">FEATURES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_TECHNICAL navNEWS_TECHNICAL_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/technical/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Technical\');return false;">TECHNICAL</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_INTERVIEWS navNEWS_INTERVIEWS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/interviews/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Interviews\');return false;">INTERVIEWS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_FEEDS navNEWS_FEEDS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/feeds.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Feeds\');return false;">FEEDS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navNEWS_SEARCHRESULTS navNEWS_SEARCHRESULTS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navRACES navRACES_en\'><a href="/races/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Races\');return false;">RACES</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navRACES_INDETAIL navRACES_INDETAIL_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/in_detail/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'In_Detail\');return false;">IN DETAIL</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRACES_2014CALENDAR navRACES_2014CALENDAR_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/calendar.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'L2\',\'2014_Calendar\'])">2014 CALENDAR</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRACES_DOWNLOADS navRACES_DOWNLOADS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/downloads/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Downloads\');return false;">DOWNLOADS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\t<li class=\'current navRESULTS navRESULTS_en\'><span><a href="/results/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Results\');return false;">RESULTS</a></span>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navRESULTS_SEASON navRESULTS_SEASON_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/results/season/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Season\');return false;">SEASON</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRESULTS_TEAM navRESULTS_TEAM_en\'>\r\n\t\t\t\t<span><a href="/results/team/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Team\');return false;">TEAM</a></span>\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navRESULTS_DRIVER navRESULTS_DRIVER_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/results/driver/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Driver\');return false;">DRIVER</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navGALLERY navGALLERY_en\'><a href="/gallery/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Gallery\');return false;">GALLERY</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navGALLERY_RACE navGALLERY_RACE_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/race/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Race\');return false;">RACE</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navGALLERY_TESTING navGALLERY_TESTING_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/testing/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Testing\');return false;">TESTING</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navGALLERY_LAUNCHES navGALLERY_LAUNCHES_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/launches/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Launches\');return false;">LAUNCHES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navGALLERY_OTHER navGALLERY_OTHER_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/other/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Other\');return false;">OTHER</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navTEAMSDRIVERS navTEAMSDRIVERS_en\'><a href="/teams_and_drivers/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Teams_And_Drivers\');return false;">TEAMS &AMP; DRIVERS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navTEAMSDRIVERS_TEAMS navTEAMSDRIVERS_TEAMS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/teams/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Teams\');return false;">TEAMS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navTEAMSDRIVERS_DRIVERS navTEAMSDRIVERS_DRIVERS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/drivers/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Drivers\');return false;">DRIVERS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navTEAMSDRIVERS_HALLOFFAME navTEAMSDRIVERS_HALLOFFAME_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/hall_of_fame/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Hall_Of_Fame\');return false;">HALL OF FAME</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navINSIDEF1 navINSIDEF1_en\'><a href="/inside_f1/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Inside_F1\');return false;">INSIDE F1</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_RULESREGULATIONS navINSIDEF1_RULESREGULATIONS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/rules_and_regulations/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Rules_And_Regulations\');return false;">RULES &AMP; REGULATIONS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_UNDERSTANDINGF1RACING navINSIDEF1_UNDERSTANDINGF1RACING_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/understanding_the_sport/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Understanding_The_Sport\');return false;">UNDERSTANDING F1 RACING</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_SAFETY navINSIDEF1_SAFETY_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/safety/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Safety\');return false;">SAFETY</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_THEF1BRAND navINSIDEF1_THEF1BRAND_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/f1brand.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'F1brand\');return false;">THE F1 BRAND</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_GLOSSARY navINSIDEF1_GLOSSARY_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/glossary.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Glossary\');return false;">GLOSSARY</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_FAQ navINSIDEF1_FAQ_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/faq.html" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Faq\');return false;">FAQ</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navINSIDEF1_SEARCHRESULTS navINSIDEF1_SEARCHRESULTS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navLIVETIMING navLIVETIMING_en\'><a href="/live_timing/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Live_Timing\');return false;">LIVE TIMING</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navVIDEO navVIDEO_en\'><a href="/video/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Video\');return false;">VIDEO</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class=\'navVIDEO_RACEEDITS navVIDEO_RACEEDITS_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/video/race_edits/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Race_Edits\');return false;">RACE EDITS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class=\'navVIDEO_ONBOARD navVIDEO_ONBOARD_en\'>\r\n\t\t\t\t\r\n\t\t\t\t<a href="/video/onboard/" onClick="delayedEvent(this, \'Navigation\',\'L2\',\'Onboard\');return false;">ONBOARD</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navTICKETS navTICKETS_en\'><a href="/tickets_and_travel/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'Tickets\');return false;">TICKETS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navF1STORE navF1STORE_en\'><a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&CMP=PSC-CHMHGTFG" target="_blank" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'F1_Store\');return false;">F1 STORE</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class=\'navAPP navAPP_en\'><a href="/app/" onClick="delayedEvent(this, \'Navigation\',\'L1\',\'App\');return false;">APP</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t</ul>\r\n\t\r\n            </div>\r\n            <div id="content">\r\n                \r\n                \r\n<!-- Hide when on Home -->\r\n\r\n    <div id="tertiaryNav">\r\n        <div class="tertiaryNavItem">\r\n            <ul>\r\n                \r\n                        \r\n<li class="listheader"><span><a href="/results/team/2014/">\r\n    2014<img src="/img/decals/nav_arrow_ltbg.gif" /></a></span>\r\n    \r\n            <ul>\r\n        \r\n            <li>\r\n                <a class="L3Selected" href="/results/team/2014/">2014</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2013/">2013</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2012/">2012</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2011/">2011</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2010/">2010</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2009/">2009</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2008/">2008</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2007/">2007</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2006/">2006</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2005/">2005</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2004/">2004</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2003/">2003</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2002/">2002</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2001/">2001</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2000/">2000</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1999/">1999</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1998/">1998</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1997/">1997</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1996/">1996</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1995/">1995</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1994/">1994</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1993/">1993</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1992/">1992</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1991/">1991</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1990/">1990</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1989/">1989</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1988/">1988</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1987/">1987</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1986/">1986</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1985/">1985</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1984/">1984</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1983/">1983</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1982/">1982</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1981/">1981</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1980/">1980</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1979/">1979</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1978/">1978</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1977/">1977</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1976/">1976</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1975/">1975</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1974/">1974</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1973/">1973</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1972/">1972</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1971/">1971</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1970/">1970</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1969/">1969</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1968/">1968</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1967/">1967</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1966/">1966</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1965/">1965</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1964/">1964</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1963/">1963</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1962/">1962</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1961/">1961</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1960/">1960</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1959/">1959</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1958/">1958</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1957/">1957</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1956/">1956</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1955/">1955</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1954/">1954</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1953/">1953</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1952/">1952</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1951/">1951</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/1950/">1950</a></li>\r\n        \r\n            </ul>\r\n        \r\n</li>\r\n\r\n                    \r\n                        \r\n<li class="listheader"><span><a href="/results/team/2014/">\r\n    ALL TEAMS<img src="/img/decals/nav_arrow_ltbg.gif" /></a></span>\r\n    \r\n            <ul>\r\n        \r\n            <li>\r\n                <a class="L3Selected" href="/results/team/2014/">ALL TEAMS</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/2999.html">MCLAREN-MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/2996.html">MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/2997.html">FERRARI</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/3003.html">WILLIAMS-MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/3000.html">FORCE INDIA-MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/3002.html">STR-RENAULT</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/3001.html">SAUBER-FERRARI</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/3004.html">MARUSSIA-FERRARI</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/2998.html">LOTUS-RENAULT</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/3005.html">CATERHAM-RENAULT</a></li>\r\n        \r\n            <li>\r\n                <a  href="/results/team/2014/2995.html">RED BULL RACING-RENAULT</a></li>\r\n        \r\n            </ul>\r\n        \r\n</li>\r\n\r\n                    \r\n            </ul>\r\n        </div>\r\n    </div>\r\n\r\n\r\n                  <div id="contentMain">\r\n                    <!-- content modules here -->\r\n                    \r\n    \r\n\r\n\r\n        <div class="contentContainer">\r\n            <table class="raceResults" cellpadding="0" cellspacing="0" summary="">\r\n                <tr>\r\n                    <th>Pos</th>\r\n                    <th>Team</th>\r\n                    <th>Points</th>\r\n                </tr>\r\n    \r\n        <tr>\r\n            <td>1</td>\r\n            <td><a href="/results/team/2014/2999.html">McLaren-Mercedes</a></td>\r\n            <td>33</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>2</td>\r\n            <td><a href="/results/team/2014/2996.html">Mercedes</a></td>\r\n            <td>25</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>3</td>\r\n            <td><a href="/results/team/2014/2997.html">Ferrari</a></td>\r\n            <td>18</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>4</td>\r\n            <td><a href="/results/team/2014/3003.html">Williams-Mercedes</a></td>\r\n            <td>10</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>5</td>\r\n            <td><a href="/results/team/2014/3000.html">Force India-Mercedes</a></td>\r\n            <td>9</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>6</td>\r\n            <td><a href="/results/team/2014/3002.html">STR-Renault</a></td>\r\n            <td>6</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>7</td>\r\n            <td><a href="/results/team/2014/3001.html">Sauber-Ferrari</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>8</td>\r\n            <td><a href="/results/team/2014/3004.html">Marussia-Ferrari</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>9</td>\r\n            <td><a href="/results/team/2014/2998.html">Lotus-Renault</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>10</td>\r\n            <td><a href="/results/team/2014/3005.html">Caterham-Renault</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>11</td>\r\n            <td><a href="/results/team/2014/2995.html">Red Bull Racing-Renault</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n            </table>\r\n         </div>\r\n    \r\n\r\n\r\n\r\n\r\n\r\n                    </div>\r\n                <div id="contentSub">\r\n                    <!-- subModules here -->\r\n                    \r\n\r\n<!-- Advertising Panel START-->\r\n\r\n<style type="text/css">\r\n#adHoldLeft {\r\n\t-webkit-transition: all 250ms ease;\r\n\t-moz-transition: all 250ms ease;\r\n\t-ms-transition: all 250ms ease;\r\n\t-o-transition: all 250ms ease;\r\n\ttransition: all 250ms ease;\r\n}\r\n</style>\r\n<script type="text/javascript">\r\n    var now = new Date();\r\n    var unique = "unique=" + now.getTime();\r\n    var adHoldLeftHeight = 409;\r\n    function sbaSize(toBe){\r\n        document.getElementById("adHoldRightCol").style.height = toBe + "px";\r\n        $(\'adHoldRightCol\').setStyle(\'overflow\', \'hidden\');\r\n        if (toBe > 0)\r\n        {\r\n            $(\'adHoldRightCol\').setStyle(\'padding\', \'0 0 5px 0\');\r\n        }\r\n        else\r\n        {\r\n            $(\'adHoldRightCol\').setStyle(\'padding\', \'0 0 0 0\');\r\n        }\r\n    }\r\n    \r\n    function sbaHide(){\r\n        document.getElementById("adHoldLeftCol").style.zIndex = "-1000";\r\n        document.getElementById("adHoldLeftCol").style.height = "0px";\r\n        document.getElementById("adHoldLeft").style.height = adHoldLeftHeight;\r\n        document.getElementById("adHoldLeft").style.overflow = "hidden";\r\n    }\r\n    \r\n    function sbaShow(){\r\n        document.getElementById("adHoldLeftCol").style.zIndex = "1000";\r\n        document.getElementById("adHoldLeftCol").style.height = adHoldLeftHeight + "px";\r\n        document.getElementById("adHoldLeft").style.height = adHoldLeftHeight + "px";\r\n    }\r\n    \r\n    var sbaLoadRightCalled = false;\r\n    function sbaLoadRight()\r\n    {\r\n        if (sbaLoadRightCalled)\r\n        {\r\n            return;\r\n        }\r\n            \r\n        sbaLoadRightCalled = true;\r\n        \r\n        sbaHide();\r\n        \r\n\t\tvar flashvars = false;\r\n\t\tvar attributes = {id: "adHoldRight"};\r\n\t\tvar params = { allowScriptAccess: "always", quality: "high", wmode: "transparent", FlashVars: unique + "&home=" + (window.location.pathname == \'/\') + "&xmlUrl=/xml/advertising/sidebar/site.xml&artDir=promos&typeArray=D,D&nameArray=tata,emirates&weightArray=35,65" };\r\n\t\tswfobject.embedSWF("/flash/advertising/side_bar/adHoldRight.swf", "adHoldRightFlash", "235", "600", "9.0.0","/js/expressInstall.swf", flashvars, params, attributes);\r\n    }\r\n\r\n    window.addEvent(\'domready\', function(){\r\n        // create adHoldLeftCol container DIV and insert in contentMain DIV\r\n\t     var oDiv = new Element(\'div\', {\r\n\t     \'id\':\'adHoldLeftCol\',\r\n\t     \'styles\':{\'position\':\'absolute\',\'margin-left\':\'0px\',\'margin-top\':\'0px\',\'zIndex\':\'-1000\',\'height\':\'0\'}\r\n\t     });\r\n\t     \t     \r\n\t  \toDiv.injectTop($(\'contentMain\'));\r\n\t  \t\r\n        var oFlashDiv = new Element(\'div\', {\r\n        \'id\':\'adHoldLeftFlash\'\r\n        });\r\n        \r\n        oFlashDiv.inject(oDiv);\r\n\r\n\t\tvar flashvars = false;\r\n\t\tvar attributes = {id: "adHoldLeft"};\r\n\t\tvar params = { allowScriptAccess: "always", quality: "high", wmode: "transparent", FlashVars: unique + "&home=" + (window.location.pathname == \'/\') + "&xmlUrl=/xml/advertising/sidebar/site.xml&artDir=rollpanels&typeArray=D,D&nameArray=tata,emirates&weightArray=35,65" };\r\n\t\tif ( (swfobject.getFlashPlayerVersion()).major > 0 )\r\n\t\t{\r\n\t\t    swfobject.embedSWF("/flash/advertising/side_bar/adHoldLeft.swf", "adHoldLeftFlash", "715", adHoldLeftHeight, "9.0.0","/js/expressInstall.swf", flashvars, params, attributes);\r\n\t\t}\r\n\t\telse\r\n\t\t{\r\n    \t\tvar htmlAdModule = new HtmlAdModule({\r\n\t\t\t\tflashVars: params.FlashVars\r\n\t\t\t});\r\n\t\t\thtmlAdModule.selectAdvert(); \r\n\t\t}\r\n});\r\n\r\n</script>\r\n\r\n<div id="adHoldRightCol" style="z-index: 1; display: block; height:0; padding: 0px 0 0px 0;">\r\n<div id="adHoldRightFlash"></div>\r\n</div>\r\n<script type="text/javascript" src="/js/htmlAdModule.js"></script>\r\n\r\n\r\n\r\n                    \r\n    \r\n\r\n<div class="subModule">\r\n    <A class=rhsPromoButton title="Play Video" onclick="if (window.pageTracker) { pageTracker._trackPageview(\'/Buttons/RHP/Video_Promo_Button\'); }" href="/video/"></A>\r\n</div>\r\n    \r\n    <div class="subModule">\r\n        <img src="/photos/results/results_promo.jpg" alt="Results" />\r\n    </div>\r\n\r\n    \r\n    \r\n\r\n<!-- White buttons -->\r\n    \r\n\r\n\r\n\r\n\r\n\r\n\r\n<!-- Black buttons -->\r\n\r\n\r\n<!-- Black buttons -->\r\n<div class="subModule">\r\n    <div class="button blackButton">   \r\n        <a href="/live_timing/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Live_Timing\'])">LIVE TIMING</a>\r\n    </div>\r\n    <div class="button blackButton">\r\n        <a href="/video/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Video\'])">VIDEO</a>\r\n    </div>\r\n    \r\n    <div class="button blackButton">\r\n        <a href="/tickets_and_travel/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Tickets\'])">TICKETS</a>\r\n    </div>\r\n    <div class="button blackButton">\r\n        <a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&CMP=PSC-CHMHGTFG" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'F1_Store\'])" target="_blank">F1 STORE</a>\r\n    </div>    \r\n    <div class="button buttonLast blackButton">\r\n        <a href="/app/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'App\'])" >APP</a>\r\n    </div>\r\n</div>\r\n\r\n                </div>\r\n                <div style="clear:both">&nbsp;</div>\r\n            </div>\r\n            <!-- END content -->\r\n            <!-- Start Footer -->\r\n                        \r\n            \r\n\r\n<div id="footer">\r\n    <div class="footerF1Logo">\r\n        <a href="/default.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'F1_Logo\'])">\r\n\t            <img src="/img/footer/footer_f1_logo.png" alt="Formula1.com" />\r\n\t    </a>\r\n\t</div>\r\n    <div class="footerDiv">\r\n        <img src="/img/footer/footer_div.png" />\r\n    </div>\r\n    <div class="footerMenu">\r\n        <ul class="mainNav">\r\n            <li><a href="/live_timing/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Live_Timing\'])">LIVE TIMING</a></li>\r\n\t        <li><a href="/video/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Video\'])">VIDEO</a></li>\r\n            <li><a href="/tickets_and_travel/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Tickets\'])">TICKETS</a></li>\r\n            <li><a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&CMP=PSC-CHMHGTFG" target="_blank" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'F1store\'])">F1 STORE</a></li>\r\n            <li><a href="http://mobile.formula1.com/" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Advert\'])">MOBILE</a></li>\r\n        </ul>\r\n        <ul class="subNav">\r\n    \t    <li><a href="/privacypolicy.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Privacy_Policy\'])">PRIVACY POLICY</a></li>\r\n            <li><a href="/termsandconditions.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Legal_Notices\'])">LEGAL NOTICES</a></li>\r\n            <li><a href="/trademarkguidelines.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Guidelines\'])">GUIDELINES</a></li>\r\n            \r\n\t        \r\n            <li><a href="/contacts.html" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Contacts\'])">CONTACTS</a></li>\r\n            \r\n\t\t        <li><a href="/reg/viewdetails" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'My_Details\'])">MY DETAILS</a></li>\r\n        </ul>\r\n        <ul class="copyright">\r\n            <li>&copy; 2003-2014 Formula One World Championship Limited</li>\r\n        </ul>       \r\n    </div>\r\n    <div class="footerDiv">\r\n        <img src="/img/footer/footer_div.png" />\r\n    </div>\r\n    <div class="footerTataLogo">\r\n\t    <a href="http://www.tatacommunications.com" target="_blank" onClick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Tata\'])">\r\n\t        <img src="/img/footer/footer_tata_logo.png" alt="TATA COMMUNICATIONS - Official web hosting and content delivery network provider of Formula1.com" />\r\n\t    </a>\r\n    </div>\r\n    \r\n    <!-- /******* HTML Code for cookie drop down text start ******/ -->\r\n    \r\n        <div id="cookiebnr" class="notification sticky visible setWidth">\r\n          <div class="wrapperAboutCookie">\r\n              <div class="aboutCookieContent">\r\n                    <p>Formula1.com uses cookies to help give you the best possible user experience. By continuing to browse this site you give consent for cookies to be used. To find out more about cookies and how to manage them, <a href="/privacypolicy.html#cookiepolicy">click here</a></p>\r\n              </div>\r\n              <div class="btn-close"><a onclick="SetCookie(\'SkipCookieLegislation\', \'true\')" href="javascript:" class="closecookiebnr">\r\n                <img alt="close button" src="/img/cookiepolicybanner/icon-close.png" class="close-button" /></a>\r\n              </div>\r\n          </div>\r\n        </div>\r\n    \r\n    <!-- /******* HTML Code for cookie drop down text end ******/ -->       \r\n</div>\r\n\r\n\r\n\r\n    <!--[if lt IE 7]>\r\n\t    <script defer type="text/javascript" src="/js/pngfix.js"></script>\r\n    <![endif]-->\r\n\r\n            \r\n            <!-- End Footer -->            \r\n        </div>\r\n        <!-- END wrapperContent -->\r\n        \r\n    </div>\r\n    \r\n    \r\n</body>\r\n</html>\r\n'
>>> class aha:
	def __init__(self, requested_page):
		self.req_page = requested_page
		with urllib.request.urlopen(self.req_page) as url:
			s = url.read()

		soup = BeautifulSoup(''.join(str(s)))
		table = soup.find('table')
		for tr in rows:
			cols = tr.findAll('td')
			for td in cols:
				text = ''.join(td.find(text=True))
				print(text)

				
>>> aha('http://www.formula1.com/results/team/')
1
 Nico Rosberg
German
 Mercedes
25
2
 Kevin Magnussen
Danish
 McLaren-Mercedes
18
3
 Jenson Button
British
 McLaren-Mercedes
15
4
 Fernando Alonso
Spanish
 Ferrari
12
5
 Valtteri  Bottas
Finnish
 Williams-Mercedes
10
6
 Nico Hulkenberg
German
 Force India-Mercedes
8
7
 Kimi R\xc3\xa4ikk\xc3\xb6nen
Finnish
 Ferrari
6
8
 Jean-Eric Vergne
French
 STR-Renault
4
9
 Daniil Kvyat
Russian
 STR-Renault
2
10
 Sergio Perez
Mexican
 Force India-Mercedes
1
11
 Adrian Sutil
German
 Sauber-Ferrari
0
12
 Esteban Gutierrez
Mexican
 Sauber-Ferrari
0
13
 Max Chilton
British
 Marussia-Ferrari
0
14
 Jules Bianchi
French
 Marussia-Ferrari
0
15
 Romain Grosjean
French
 Lotus-Renault
0
16
 Pastor Maldonado
Venezuelan
 Lotus-Renault
0
17
 Marcus Ericsson
Swedish
 Caterham-Renault
0
18
 Sebastian Vettel
German
 Red Bull Racing-Renault
0
19
 Lewis Hamilton
British
 Mercedes
0
20
 Felipe Massa
Brazilian
 Williams-Mercedes
0
21
 Kamui Kobayashi
Japanese
 Caterham-Renault
0
22
 Daniel Ricciardo
Australian
 Red Bull Racing-Renault
0
<__main__.aha object at 0x7fafeac3d7d0>
>>> # import urllib.request, from bs4 import BeautifulSoup
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(''.join(str(self.s)))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                print(text)

                
>>> aha('http://www.formula1.com/results/driver/')
1
 Nico Rosberg
German
 Mercedes
25
2
 Kevin Magnussen
Danish
 McLaren-Mercedes
18
3
 Jenson Button
British
 McLaren-Mercedes
15
4
 Fernando Alonso
Spanish
 Ferrari
12
5
 Valtteri  Bottas
Finnish
 Williams-Mercedes
10
6
 Nico Hulkenberg
German
 Force India-Mercedes
8
7
 Kimi R\xc3\xa4ikk\xc3\xb6nen
Finnish
 Ferrari
6
8
 Jean-Eric Vergne
French
 STR-Renault
4
9
 Daniil Kvyat
Russian
 STR-Renault
2
10
 Sergio Perez
Mexican
 Force India-Mercedes
1
11
 Adrian Sutil
German
 Sauber-Ferrari
0
12
 Esteban Gutierrez
Mexican
 Sauber-Ferrari
0
13
 Max Chilton
British
 Marussia-Ferrari
0
14
 Jules Bianchi
French
 Marussia-Ferrari
0
15
 Romain Grosjean
French
 Lotus-Renault
0
16
 Pastor Maldonado
Venezuelan
 Lotus-Renault
0
17
 Marcus Ericsson
Swedish
 Caterham-Renault
0
18
 Sebastian Vettel
German
 Red Bull Racing-Renault
0
19
 Lewis Hamilton
British
 Mercedes
0
20
 Felipe Massa
Brazilian
 Williams-Mercedes
0
21
 Kamui Kobayashi
Japanese
 Caterham-Renault
0
22
 Daniel Ricciardo
Australian
 Red Bull Racing-Renault
0
Traceback (most recent call last):
  File "<pyshell#113>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
TypeError: __repr__ returned non-string (type NoneType)
>>> BeautifulSoup(str(s))
<html><body><p>b'\r\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN">
r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"&gt;\r\n\r\n</p>\r\n<title>Formula 1\xc2\xae - The Official F1\xc2\xae Website</title>\r\n<meta content="IE=edge" http-equiv="X-UA-Compatible"/>\r\n<script type="text/javascript">\r\n\tdocument.getElementsByTagName(\'html\')[0].className = \'jsEnabled\';\r\n</script>\r\n\r\n<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>\r\n\r\n<link href="/css/global.css" media="screen" rel="stylesheet" type="text/css"/>\r\n<link href="/css/navigation.css" media="screen" rel="stylesheet" type="text/css"/>\r\n<link href="/css/modules.css" media="screen" rel="stylesheet" type="text/css"/>\r\n<link href="/css/slimbox.css" media="screen" rel="stylesheet" type="text/css"/>\r\n<link href="/css/videobox.css" media="screen" rel="stylesheet" type="text/css"/>\r\n<link href="/css/f1_forms.css" media="screen" rel="stylesheet" type="text/css"/>\r\n<link href="/css/cookiepolicybanner.css" media="screen" rel="stylesheet" type="text/css"/>\r\n<link href="/css/print.css" media="print" rel="stylesheet" type="text/css"/>\r\n<link href="http://www.formula1.com/favicon.ico" rel="shortcut icon" type="image/x-icon"/>\r\n<link href="http://www.formula1.com/desktopfavicon.png" rel="apple-touch-icon-precomposed"/>\r\n\r\n<link href="/assets/fragment/css/dynamic.css" media="screen" rel="stylesheet" type="text/css"/>\r\n\r\n<!--[if lt IE 7]>\r\n    <link href="/css/ie6.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 7]>\r\n    <link href="/css/ie7.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 8]>\r\n    <link href="/css/ie8.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<!--[if IE 9]>\r\n    <link href="/css/ie9.css" rel="stylesheet" type="text/css" media="screen" />\r\n<![endif]-->\r\n<script src="http://code.jquery.com/jquery-1.7.2.min.js" type="text/javascript"></script>\r\n<script src="/js/AC_OETags.js" type="text/javascript"></script>\r\n<script src="/js/swfobject2.js" type="text/javascript"></script>\r\n<script src="/js/cookiepolicybanner.js" type="text/javascript"></script>\r\n<script src="/js/modernizr.min.js" type="text/javascript"></script>\r\n<script src="/js/rolex_clock/listofdates.js" type="text/javascript"></script>\n<script src="/js/rolex_clock/timezones.js" type="text/javascript"></script>\n\r\n\r\n\r\n\r\n    <script src="/js/BrowserDetect.js" type="text/javascript"></script>\r\n    <script src="/js/mootools.js" type="text/javascript"></script>\r\n    <script src="/js/cookies.js" type="text/javascript"></script>\r\n    <script src="/js/global.js" type="text/javascript"></script>\r\n    <script src="/js/menunavigation.js" type="text/javascript"></script>\r\n    <script src="/js/navigation.js" type="text/javascript"></script>\r\n    <script src="/js/slimbox.js" type="text/javascript"></script>\r\n    <script src="/js/galleryRollover.js" type="text/javascript"></script>\r\n    <script src="/js/slideshow.js" type="text/javascript"></script>\r\n    <script src="/js/image_right_click.js" type="text/javascript"></script>\r\n    <script src="/js/LiveTimingPopup.js" type="text/javascript"></script>\r\n    \r\n    <script src="/js/time.js" type="text/javascript"></script>\r\n    <script src="/js/webservice.js" type="text/javascript"></script>\r\n\r\n    <script src="/js/f1_forms.js" type="text/javascript"></script>\r\n    <script src="/js/f1_detect.js" type="text/javascript"></script>    \r\n\r\n\r\n\r\n    <script src="/js/dom-drag.js" type="text/javascript"></script>\r\n\r\n\r\n\r\n\r\n<!--[if lt IE 7]>\r\n    <script defer type="text/javascript" src="/js/unitpngfix.js"></script>\r\n<![endif]-->\r\n\r\n\r\n<noscript>\r\n<style type="text/css">\r\n    div#tertiaryNav div.tertiaryNavItem{\r\n        display: block;        \r\n    }     \r\n</style>\r\n<style type="text/css">\r\n\t#bannerWrapper{margin-bottom: 10px;}\r\n</style>\r\n</noscript>\r\n\r\n\r\n<script type="text/javascript">\r\n    fncFesDisableContextMenuForImages();\r\n</script>    \r\n\r\n    \r\n    <!-- Google Analytics -->\r\n\r\n    <script type="text/javascript">\r\n        var _gaq = _gaq || [];\r\n        _gaq.push([\'_setAccount\', \'UA-4466993-1\']);\r\n        _gaq.push([\'_setDomainName\', \'formula1.com\']);\r\n        _gaq.push([\'_trackPageview\']);\r\n\r\n        (function() {\r\n            var ga = document.createElement(\'script\');\r\n            ga.type = \'text/javascript\';\r\n            ga.async = true;\r\n            ga.src = (\'https:\' == document.location.protocol ? \'https://ssl\' : \'http://www\') + \'.google-analytics.com/ga.js\';\r\n            var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(ga, s);\r\n        })();\r\n    </script>\r\n\r\n    <!-- Google Analytics -->\r\n\r\n<title>\r\n\tTeam Results\r\n</title>\r\n\r\n    \r\n    <div id="identHomePage" style="display: none">\r\n        <div class="identBg" id="identDiv">\r\n        </div>\r\n        <div class="ident" id="ident">\r\n            <div id="identHolder">\r\n            </div>\r\n        </div>\r\n\r\n        <script type="text/javascript">\r\n            if (!SkipIdentAlways() && isRootPage()) {\r\n                $(\'identDiv\').setStyle(\'height\', \'100%\');\r\n                $(\'ident\').setStyle(\'height\', getWinHeight() + \'px\');\r\n\r\n                var flashvars = {};\r\n                var params = { wmode: "transparent", quality: "autolow" };\r\n\r\n                if (BrowserDetect.browser == "Firefox")\r\n                    params = { quality: "autolow" };\r\n\r\n                swfobject.embedSWF("/flash/homepage/ident/identPreloader.swf", "identHolder", "100%", "100%", "9.0.0", "/js/expressInstall.swf", flashvars, params);\r\n            }  \t      \r\n        </script>\r\n\r\n    </div>\r\n    <div id="wrapperHeading">\r\n\r\n        <script language="javascript" type="text/javascript">            \r\n            if (GetSwfVer()!="-1" && !SkipIdentAlways() && isRootPage() && (isExternalRequest() || isIdentCookieExpired())) {\r\n                $(\'wrapperHeading\').setStyle(\'visibility\', \'hidden\');\r\n            }\r\n            else {\r\n                $(\'wrapperHeading\').setStyle(\'visibility\', \'visible\');\r\n            }\r\n        </script>\r\n\r\n        <div id="wrapperContent">\r\n            <a name="top"></a>\r\n            \r\n\r\n<h1>\r\n    <a href="/default.html" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Header\',\'F1_Logo\'])">\r\n        <img alt="Home - The Official Formula 1 Website" id="blackImage" src="/img/heading/logo_f1.png"/>\r\n        <img alt="Home - The Official Formula 1 Website" id="whiteImage" src="/img/heading/logo_f1_wte.gif" style="display: none;"/>\r\n    </a> \r\n    <a href="#content" id="skipNav">Skip to content</a>\r\n</h1>\r\n            \r\n            <div id="nav">\r\n                \r\n\t\t<ul id="primaryNav">\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navNEWS" navnews_en=""><a href="/news/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'News\');return false;">NEWS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class="\'navNEWS_HEADLINES" navnews_headlines_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/headlines/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Headlines\');return false;">HEADLINES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navNEWS_FEATURES" navnews_features_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/features/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Features\');return false;">FEATURES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navNEWS_TECHNICAL" navnews_technical_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/technical/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Technical\');return false;">TECHNICAL</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navNEWS_INTERVIEWS" navnews_interviews_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/interviews/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Interviews\');return false;">INTERVIEWS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navNEWS_FEEDS" navnews_feeds_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/news/feeds.html" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Feeds\');return false;">FEEDS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navNEWS_SEARCHRESULTS" navnews_searchresults_en="">\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navRACES" navraces_en=""><a href="/races/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Races\');return false;">RACES</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class="\'navRACES_INDETAIL" navraces_indetail_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/in_detail/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'In_Detail\');return false;">IN DETAIL</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navRACES_2014CALENDAR" navraces_2014calendar_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/calendar.html" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'L2\',\'2014_Calendar\'])">2014 CALENDAR</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navRACES_DOWNLOADS" navraces_downloads_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/races/downloads/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Downloads\');return false;">DOWNLOADS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\t<li class="\'current" navresults="" navresults_en=""><span><a href="/results/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Results\');return false;">RESULTS</a></span>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class="\'navRESULTS_SEASON" navresults_season_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/results/season/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Season\');return false;">SEASON</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navRESULTS_TEAM" navresults_team_en="">\r\n\t\t\t\t<span><a href="/results/team/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Team\');return false;">TEAM</a></span>\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navRESULTS_DRIVER" navresults_driver_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/results/driver/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Driver\');return false;">DRIVER</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navGALLERY" navgallery_en=""><a href="/gallery/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Gallery\');return false;">GALLERY</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class="\'navGALLERY_RACE" navgallery_race_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/race/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Race\');return false;">RACE</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navGALLERY_TESTING" navgallery_testing_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/testing/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Testing\');return false;">TESTING</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navGALLERY_LAUNCHES" navgallery_launches_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/launches/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Launches\');return false;">LAUNCHES</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navGALLERY_OTHER" navgallery_other_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/gallery/other/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Other\');return false;">OTHER</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navTEAMSDRIVERS" navteamsdrivers_en=""><a href="/teams_and_drivers/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Teams_And_Drivers\');return false;">TEAMS &amp;AMP; DRIVERS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class="\'navTEAMSDRIVERS_TEAMS" navteamsdrivers_teams_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/teams/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Teams\');return false;">TEAMS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navTEAMSDRIVERS_DRIVERS" navteamsdrivers_drivers_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/drivers/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Drivers\');return false;">DRIVERS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navTEAMSDRIVERS_HALLOFFAME" navteamsdrivers_halloffame_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/teams_and_drivers/hall_of_fame/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Hall_Of_Fame\');return false;">HALL OF FAME</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navINSIDEF1" navinsidef1_en=""><a href="/inside_f1/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Inside_F1\');return false;">INSIDE F1</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class="\'navINSIDEF1_RULESREGULATIONS" navinsidef1_rulesregulations_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/rules_and_regulations/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Rules_And_Regulations\');return false;">RULES &amp;AMP; REGULATIONS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navINSIDEF1_UNDERSTANDINGF1RACING" navinsidef1_understandingf1racing_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/understanding_the_sport/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Understanding_The_Sport\');return false;">UNDERSTANDING F1 RACING</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navINSIDEF1_SAFETY" navinsidef1_safety_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/safety/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Safety\');return false;">SAFETY</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navINSIDEF1_THEF1BRAND" navinsidef1_thef1brand_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/f1brand.html" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'F1brand\');return false;">THE F1 BRAND</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navINSIDEF1_GLOSSARY" navinsidef1_glossary_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/glossary.html" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Glossary\');return false;">GLOSSARY</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navINSIDEF1_FAQ" navinsidef1_faq_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/inside_f1/faq.html" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Faq\');return false;">FAQ</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navINSIDEF1_SEARCHRESULTS" navinsidef1_searchresults_en="">\r\n\t\t\t\t\r\n\t\t\t\t\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navLIVETIMING" navlivetiming_en=""><a href="/live_timing/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Live_Timing\');return false;">LIVE TIMING</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navVIDEO" navvideo_en=""><a href="/video/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Video\');return false;">VIDEO</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t\t<li class="\'navVIDEO_RACEEDITS" navvideo_raceedits_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/video/race_edits/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Race_Edits\');return false;">RACE EDITS</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t\t<li class="\'navVIDEO_ONBOARD" navvideo_onboard_en="">\r\n\t\t\t\t\r\n\t\t\t\t<a href="/video/onboard/" onclick="delayedEvent(this, \'Navigation\',\'L2\',\'Onboard\');return false;">ONBOARD</a>\r\n\t\t\t\t</li>\r\n\t\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navTICKETS" navtickets_en=""><a href="/tickets_and_travel/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'Tickets\');return false;">TICKETS</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navF1STORE" navf1store_en=""><a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&amp;CMP=PSC-CHMHGTFG" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'F1_Store\');return false;" target="_blank">F1 STORE</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t\r\n\t\t\r\n\t\t\t<li class="\'navAPP" navapp_en=""><a href="/app/" onclick="delayedEvent(this, \'Navigation\',\'L1\',\'App\');return false;">APP</a>\r\n\t\t\t<ul>\r\n\t\t\r\n\t\t\r\n\t\t\t</ul>\r\n\t\t</li>\r\n\t\r\n\t\t</ul>\r\n\t\r\n            </div>\r\n            <div id="content">\r\n                \r\n                \r\n<!-- Hide when on Home -->\r\n\r\n    <div id="tertiaryNav">\r\n        <div class="tertiaryNavItem">\r\n            <ul>\r\n                \r\n                        \r\n<li class="listheader"><span><a href="/results/team/2014/">\r\n    2014<img src="/img/decals/nav_arrow_ltbg.gif"/></a></span>\r\n    \r\n            <ul>\r\n        \r\n            <li>\r\n                <a class="L3Selected" href="/results/team/2014/">2014</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2013/">2013</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2012/">2012</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2011/">2011</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2010/">2010</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2009/">2009</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2008/">2008</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2007/">2007</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2006/">2006</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2005/">2005</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2004/">2004</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2003/">2003</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2002/">2002</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2001/">2001</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2000/">2000</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1999/">1999</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1998/">1998</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1997/">1997</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1996/">1996</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1995/">1995</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1994/">1994</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1993/">1993</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1992/">1992</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1991/">1991</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1990/">1990</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1989/">1989</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1988/">1988</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1987/">1987</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1986/">1986</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1985/">1985</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1984/">1984</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1983/">1983</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1982/">1982</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1981/">1981</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1980/">1980</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1979/">1979</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1978/">1978</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1977/">1977</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1976/">1976</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1975/">1975</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1974/">1974</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1973/">1973</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1972/">1972</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1971/">1971</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1970/">1970</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1969/">1969</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1968/">1968</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1967/">1967</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1966/">1966</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1965/">1965</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1964/">1964</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1963/">1963</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1962/">1962</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1961/">1961</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1960/">1960</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1959/">1959</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1958/">1958</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1957/">1957</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1956/">1956</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1955/">1955</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1954/">1954</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1953/">1953</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1952/">1952</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1951/">1951</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/1950/">1950</a></li>\r\n        \r\n            </ul>\r\n        \r\n</li>\r\n\r\n                    \r\n                        \r\n<li class="listheader"><span><a href="/results/team/2014/">\r\n    ALL TEAMS<img src="/img/decals/nav_arrow_ltbg.gif"/></a></span>\r\n    \r\n            <ul>\r\n        \r\n            <li>\r\n                <a class="L3Selected" href="/results/team/2014/">ALL TEAMS</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/2999.html">MCLAREN-MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/2996.html">MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/2997.html">FERRARI</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/3003.html">WILLIAMS-MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/3000.html">FORCE INDIA-MERCEDES</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/3002.html">STR-RENAULT</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/3001.html">SAUBER-FERRARI</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/3004.html">MARUSSIA-FERRARI</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/2998.html">LOTUS-RENAULT</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/3005.html">CATERHAM-RENAULT</a></li>\r\n        \r\n            <li>\r\n                <a href="/results/team/2014/2995.html">RED BULL RACING-RENAULT</a></li>\r\n        \r\n            </ul>\r\n        \r\n</li>\r\n\r\n                    \r\n            </ul>\r\n        </div>\r\n    </div>\r\n\r\n\r\n                  <div id="contentMain">\r\n                    <!-- content modules here -->\r\n                    \r\n    \r\n\r\n\r\n        <div class="contentContainer">\r\n            <table cellpadding="0" cellspacing="0" class="raceResults" summary="">\r\n                <tr>\r\n                    <th>Pos</th>\r\n                    <th>Team</th>\r\n                    <th>Points</th>\r\n                </tr>\r\n    \r\n        <tr>\r\n            <td>1</td>\r\n            <td><a href="/results/team/2014/2999.html">McLaren-Mercedes</a></td>\r\n            <td>33</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>2</td>\r\n            <td><a href="/results/team/2014/2996.html">Mercedes</a></td>\r\n            <td>25</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>3</td>\r\n            <td><a href="/results/team/2014/2997.html">Ferrari</a></td>\r\n            <td>18</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>4</td>\r\n            <td><a href="/results/team/2014/3003.html">Williams-Mercedes</a></td>\r\n            <td>10</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>5</td>\r\n            <td><a href="/results/team/2014/3000.html">Force India-Mercedes</a></td>\r\n            <td>9</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>6</td>\r\n            <td><a href="/results/team/2014/3002.html">STR-Renault</a></td>\r\n            <td>6</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>7</td>\r\n            <td><a href="/results/team/2014/3001.html">Sauber-Ferrari</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>8</td>\r\n            <td><a href="/results/team/2014/3004.html">Marussia-Ferrari</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>9</td>\r\n            <td><a href="/results/team/2014/2998.html">Lotus-Renault</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>10</td>\r\n            <td><a href="/results/team/2014/3005.html">Caterham-Renault</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n        <tr>\r\n            <td>11</td>\r\n            <td><a href="/results/team/2014/2995.html">Red Bull Racing-Renault</a></td>\r\n            <td>0</td>\r\n        </tr>\r\n    \r\n            </table>\r\n         </div>\r\n    \r\n\r\n\r\n\r\n\r\n\r\n                    </div>\r\n                <div id="contentSub">\r\n                    <!-- subModules here -->\r\n                    \r\n\r\n<!-- Advertising Panel START-->\r\n\r\n<style type="text/css">\r\n#adHoldLeft {\r\n\t-webkit-transition: all 250ms ease;\r\n\t-moz-transition: all 250ms ease;\r\n\t-ms-transition: all 250ms ease;\r\n\t-o-transition: all 250ms ease;\r\n\ttransition: all 250ms ease;\r\n}\r\n</style>\r\n<script type="text/javascript">\r\n    var now = new Date();\r\n    var unique = "unique=" + now.getTime();\r\n    var adHoldLeftHeight = 409;\r\n    function sbaSize(toBe){\r\n        document.getElementById("adHoldRightCol").style.height = toBe + "px";\r\n        $(\'adHoldRightCol\').setStyle(\'overflow\', \'hidden\');\r\n        if (toBe > 0)\r\n        {\r\n            $(\'adHoldRightCol\').setStyle(\'padding\', \'0 0 5px 0\');\r\n        }\r\n        else\r\n        {\r\n            $(\'adHoldRightCol\').setStyle(\'padding\', \'0 0 0 0\');\r\n        }\r\n    }\r\n    \r\n    function sbaHide(){\r\n        document.getElementById("adHoldLeftCol").style.zIndex = "-1000";\r\n        document.getElementById("adHoldLeftCol").style.height = "0px";\r\n        document.getElementById("adHoldLeft").style.height = adHoldLeftHeight;\r\n        document.getElementById("adHoldLeft").style.overflow = "hidden";\r\n    }\r\n    \r\n    function sbaShow(){\r\n        document.getElementById("adHoldLeftCol").style.zIndex = "1000";\r\n        document.getElementById("adHoldLeftCol").style.height = adHoldLeftHeight + "px";\r\n        document.getElementById("adHoldLeft").style.height = adHoldLeftHeight + "px";\r\n    }\r\n    \r\n    var sbaLoadRightCalled = false;\r\n    function sbaLoadRight()\r\n    {\r\n        if (sbaLoadRightCalled)\r\n        {\r\n            return;\r\n        }\r\n            \r\n        sbaLoadRightCalled = true;\r\n        \r\n        sbaHide();\r\n        \r\n\t\tvar flashvars = false;\r\n\t\tvar attributes = {id: "adHoldRight"};\r\n\t\tvar params = { allowScriptAccess: "always", quality: "high", wmode: "transparent", FlashVars: unique + "&home=" + (window.location.pathname == \'/\') + "&xmlUrl=/xml/advertising/sidebar/site.xml&artDir=promos&typeArray=D,D&nameArray=tata,emirates&weightArray=35,65" };\r\n\t\tswfobject.embedSWF("/flash/advertising/side_bar/adHoldRight.swf", "adHoldRightFlash", "235", "600", "9.0.0","/js/expressInstall.swf", flashvars, params, attributes);\r\n    }\r\n\r\n    window.addEvent(\'domready\', function(){\r\n        // create adHoldLeftCol container DIV and insert in contentMain DIV\r\n\t     var oDiv = new Element(\'div\', {\r\n\t     \'id\':\'adHoldLeftCol\',\r\n\t     \'styles\':{\'position\':\'absolute\',\'margin-left\':\'0px\',\'margin-top\':\'0px\',\'zIndex\':\'-1000\',\'height\':\'0\'}\r\n\t     });\r\n\t     \t     \r\n\t  \toDiv.injectTop($(\'contentMain\'));\r\n\t  \t\r\n        var oFlashDiv = new Element(\'div\', {\r\n        \'id\':\'adHoldLeftFlash\'\r\n        });\r\n        \r\n        oFlashDiv.inject(oDiv);\r\n\r\n\t\tvar flashvars = false;\r\n\t\tvar attributes = {id: "adHoldLeft"};\r\n\t\tvar params = { allowScriptAccess: "always", quality: "high", wmode: "transparent", FlashVars: unique + "&home=" + (window.location.pathname == \'/\') + "&xmlUrl=/xml/advertising/sidebar/site.xml&artDir=rollpanels&typeArray=D,D&nameArray=tata,emirates&weightArray=35,65" };\r\n\t\tif ( (swfobject.getFlashPlayerVersion()).major > 0 )\r\n\t\t{\r\n\t\t    swfobject.embedSWF("/flash/advertising/side_bar/adHoldLeft.swf", "adHoldLeftFlash", "715", adHoldLeftHeight, "9.0.0","/js/expressInstall.swf", flashvars, params, attributes);\r\n\t\t}\r\n\t\telse\r\n\t\t{\r\n    \t\tvar htmlAdModule = new HtmlAdModule({\r\n\t\t\t\tflashVars: params.FlashVars\r\n\t\t\t});\r\n\t\t\thtmlAdModule.selectAdvert(); \r\n\t\t}\r\n});\r\n\r\n</script>\r\n\r\n<div id="adHoldRightCol" style="z-index: 1; display: block; height:0; padding: 0px 0 0px 0;">\r\n<div id="adHoldRightFlash"></div>\r\n</div>\r\n<script src="/js/htmlAdModule.js" type="text/javascript"></script>\r\n\r\n\r\n\r\n                    \r\n    \r\n\r\n<div class="subModule">\r\n    <a class="rhsPromoButton" href="/video/" onclick="if (window.pageTracker) { pageTracker._trackPageview(\'/Buttons/RHP/Video_Promo_Button\'); }" title="Play Video"></a>\r\n</div>\r\n    \r\n    <div class="subModule">\r\n        <img alt="Results" src="/photos/results/results_promo.jpg"/>\r\n    </div>\r\n\r\n    \r\n    \r\n\r\n<!-- White buttons -->\r\n    \r\n\r\n\r\n\r\n\r\n\r\n\r\n<!-- Black buttons -->\r\n\r\n\r\n<!-- Black buttons -->\r\n<div class="subModule">\r\n    <div class="button blackButton">   \r\n        <a href="/live_timing/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Live_Timing\'])">LIVE TIMING</a>\r\n    </div>\r\n    <div class="button blackButton">\r\n        <a href="/video/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Video\'])">VIDEO</a>\r\n    </div>\r\n    \r\n    <div class="button blackButton">\r\n        <a href="/tickets_and_travel/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'Tickets\'])">TICKETS</a>\r\n    </div>\r\n    <div class="button blackButton">\r\n        <a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&amp;CMP=PSC-CHMHGTFG" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'F1_Store\'])" target="_blank">F1 STORE</a>\r\n    </div>    \r\n    <div class="button buttonLast blackButton">\r\n        <a href="/app/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'RHP\',\'App\'])">APP</a>\r\n    </div>\r\n</div>\r\n\r\n                </div>\r\n                <div style="clear:both"> </div>\r\n            </div>\r\n            <!-- END content -->\r\n            <!-- Start Footer -->\r\n                        \r\n            \r\n\r\n<div id="footer">\r\n    <div class="footerF1Logo">\r\n        <a href="/default.html" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'F1_Logo\'])">\r\n\t            <img alt="Formula1.com" src="/img/footer/footer_f1_logo.png"/>\r\n\t    </a>\r\n\t</div>\r\n    <div class="footerDiv">\r\n        <img src="/img/footer/footer_div.png"/>\r\n    </div>\r\n    <div class="footerMenu">\r\n        <ul class="mainNav">\r\n            <li><a href="/live_timing/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Live_Timing\'])">LIVE TIMING</a></li>\r\n\t        <li><a href="/video/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Video\'])">VIDEO</a></li>\r\n            <li><a href="/tickets_and_travel/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Tickets\'])">TICKETS</a></li>\r\n            <li><a href="http://f1store.formula1.com/stores/f1/default.aspx?portal=CHMHGTFG&amp;CMP=PSC-CHMHGTFG" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'F1store\'])" target="_blank">F1 STORE</a></li>\r\n            <li><a href="http://mobile.formula1.com/" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Advert\'])">MOBILE</a></li>\r\n        </ul>\r\n        <ul class="subNav">\r\n    \t    <li><a href="/privacypolicy.html" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Privacy_Policy\'])">PRIVACY POLICY</a></li>\r\n            <li><a href="/termsandconditions.html" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Legal_Notices\'])">LEGAL NOTICES</a></li>\r\n            <li><a href="/trademarkguidelines.html" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Guidelines\'])">GUIDELINES</a></li>\r\n            \r\n\t        \r\n            <li><a href="/contacts.html" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Contacts\'])">CONTACTS</a></li>\r\n            \r\n\t\t        <li><a href="/reg/viewdetails" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'My_Details\'])">MY DETAILS</a></li>\r\n        </ul>\r\n        <ul class="copyright">\r\n            <li>© 2003-2014 Formula One World Championship Limited</li>\r\n        </ul>       \r\n    </div>\r\n    <div class="footerDiv">\r\n        <img src="/img/footer/footer_div.png"/>\r\n    </div>\r\n    <div class="footerTataLogo">\r\n\t    <a href="http://www.tatacommunications.com" onclick="_gaq.push([\'_trackEvent\', \'Navigation\',\'Footer\',\'Tata\'])" target="_blank">\r\n\t        <img alt="TATA COMMUNICATIONS - Official web hosting and content delivery network provider of Formula1.com" src="/img/footer/footer_tata_logo.png"/>\r\n\t    </a>\r\n    </div>\r\n    \r\n    <!-- /******* HTML Code for cookie drop down text start ******/ -->\r\n    \r\n        <div class="notification sticky visible setWidth" id="cookiebnr">\r\n          <div class="wrapperAboutCookie">\r\n              <div class="aboutCookieContent">\r\n                    <p>Formula1.com uses cookies to help give you the best possible user experience. By continuing to browse this site you give consent for cookies to be used. To find out more about cookies and how to manage them, <a href="/privacypolicy.html#cookiepolicy">click here</a></p>\r\n              </div>\r\n              <div class="btn-close"><a class="closecookiebnr" href="javascript:" onclick="SetCookie(\'SkipCookieLegislation\', \'true\')">\r\n                <img alt="close button" class="close-button" src="/img/cookiepolicybanner/icon-close.png"/></a>\r\n              </div>\r\n          </div>\r\n        </div>\r\n    \r\n    <!-- /******* HTML Code for cookie drop down text end ******/ -->       \r\n</div>\r\n\r\n\r\n\r\n    <!--[if lt IE 7]>\r\n\t    <script defer type="text/javascript" src="/js/pngfix.js"></script>\r\n    <![endif]-->\r\n\r\n            \r\n            <!-- End Footer -->            \r\n        </div>\r\n        <!-- END wrapperContent -->\r\n        \r\n    </div>\r\n    \r\n    \r\n\r\n\r\n'</body></html>

>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                print(text)
#aha('http://www.formula1.com/results/driver/')

                
>>> aha('http://www.formula1.com/results/driver/')
1
 Nico Rosberg
German
 Mercedes
25
2
 Kevin Magnussen
Danish
 McLaren-Mercedes
18
3
 Jenson Button
British
 McLaren-Mercedes
15
4
 Fernando Alonso
Spanish
 Ferrari
12
5
 Valtteri  Bottas
Finnish
 Williams-Mercedes
10
6
 Nico Hulkenberg
German
 Force India-Mercedes
8
7
 Kimi R\xc3\xa4ikk\xc3\xb6nen
Finnish
 Ferrari
6
8
 Jean-Eric Vergne
French
 STR-Renault
4
9
 Daniil Kvyat
Russian
 STR-Renault
2
10
 Sergio Perez
Mexican
 Force India-Mercedes
1
11
 Adrian Sutil
German
 Sauber-Ferrari
0
12
 Esteban Gutierrez
Mexican
 Sauber-Ferrari
0
13
 Max Chilton
British
 Marussia-Ferrari
0
14
 Jules Bianchi
French
 Marussia-Ferrari
0
15
 Romain Grosjean
French
 Lotus-Renault
0
16
 Pastor Maldonado
Venezuelan
 Lotus-Renault
0
17
 Marcus Ericsson
Swedish
 Caterham-Renault
0
18
 Sebastian Vettel
German
 Red Bull Racing-Renault
0
19
 Lewis Hamilton
British
 Mercedes
0
20
 Felipe Massa
Brazilian
 Williams-Mercedes
0
21
 Kamui Kobayashi
Japanese
 Caterham-Renault
0
22
 Daniel Ricciardo
Australian
 Red Bull Racing-Renault
0
Traceback (most recent call last):
  File "<pyshell#118>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
TypeError: __repr__ returned non-string (type NoneType)
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = td.find('')
                print(text)

                
>>> aha('http://www.formula1.com/results/driver/')
None
<a href="/results/driver/2014/809.html"> Nico Rosberg</a>
None
<a href="/results/team/2014/2996.html"> Mercedes</a>
None
None
<a href="/results/driver/2014/899.html"> Kevin Magnussen</a>
None
<a href="/results/team/2014/2999.html"> McLaren-Mercedes</a>
None
None
<a href="/results/driver/2014/6.html"> Jenson Button</a>
None
<a href="/results/team/2014/2999.html"> McLaren-Mercedes</a>
None
None
<a href="/results/driver/2014/30.html"> Fernando Alonso</a>
None
<a href="/results/team/2014/2997.html"> Ferrari</a>
None
None
<a href="/results/driver/2014/865.html"> Valtteri  Bottas</a>
None
<a href="/results/team/2014/3003.html"> Williams-Mercedes</a>
None
None
<a href="/results/driver/2014/840.html"> Nico Hulkenberg</a>
None
<a href="/results/team/2014/3000.html"> Force India-Mercedes</a>
None
None
<a href="/results/driver/2014/12.html"> Kimi R\xc3\xa4ikk\xc3\xb6nen</a>
None
<a href="/results/team/2014/2997.html"> Ferrari</a>
None
None
<a href="/results/driver/2014/870.html"> Jean-Eric Vergne</a>
None
<a href="/results/team/2014/3002.html"> STR-Renault</a>
None
None
<a href="/results/driver/2014/906.html"> Daniil Kvyat</a>
None
<a href="/results/team/2014/3002.html"> STR-Renault</a>
None
None
<a href="/results/driver/2014/867.html"> Sergio Perez</a>
None
<a href="/results/team/2014/3000.html"> Force India-Mercedes</a>
None
None
<a href="/results/driver/2014/818.html"> Adrian Sutil</a>
None
<a href="/results/team/2014/3001.html"> Sauber-Ferrari</a>
None
None
<a href="/results/driver/2014/854.html"> Esteban Gutierrez</a>
None
<a href="/results/team/2014/3001.html"> Sauber-Ferrari</a>
None
None
<a href="/results/driver/2014/887.html"> Max Chilton</a>
None
<a href="/results/team/2014/3004.html"> Marussia-Ferrari</a>
None
None
<a href="/results/driver/2014/850.html"> Jules Bianchi</a>
None
<a href="/results/team/2014/3004.html"> Marussia-Ferrari</a>
None
None
<a href="/results/driver/2014/838.html"> Romain Grosjean</a>
None
<a href="/results/team/2014/2998.html"> Lotus-Renault</a>
None
None
<a href="/results/driver/2014/869.html"> Pastor Maldonado</a>
None
<a href="/results/team/2014/2998.html"> Lotus-Renault</a>
None
None
<a href="/results/driver/2014/862.html"> Marcus Ericsson</a>
None
<a href="/results/team/2014/3005.html"> Caterham-Renault</a>
None
None
<a href="/results/driver/2014/822.html"> Sebastian Vettel</a>
None
<a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a>
None
None
<a href="/results/driver/2014/828.html"> Lewis Hamilton</a>
None
<a href="/results/team/2014/2996.html"> Mercedes</a>
None
None
<a href="/results/driver/2014/18.html"> Felipe Massa</a>
None
<a href="/results/team/2014/3003.html"> Williams-Mercedes</a>
None
None
<a href="/results/driver/2014/837.html"> Kamui Kobayashi</a>
None
<a href="/results/team/2014/3005.html"> Caterham-Renault</a>
None
None
<a href="/results/driver/2014/857.html"> Daniel Ricciardo</a>
None
<a href="/results/team/2014/2995.html"> Red Bull Racing-Renault</a>
None
Traceback (most recent call last):
  File "<pyshell#121>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
TypeError: __repr__ returned non-string (type NoneType)
>>> from tempfile import NamedTemporaryFile
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                with NamedTemporaryFile('w+t', delete=False) as f:
			f.write(text)
			return f.name
#aha('http://www.formula1.com/results/driver/')
		
SyntaxError: inconsistent use of tabs and spaces in indentation
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                with NamedTemporaryFile('w+t', delete=False) as f:
                    f.write(text)
                    return f.name

                
>>> aha('http://www.formula1.com/results/driver/')
/tmp/tmpkkudr7
>>> with open('/tmp/tmpkkudr7', 'rt') as f"
SyntaxError: EOL while scanning string literal
>>> with open('/tmp/tmpkkudr7', 'rt') as f:
	print(f.read())

	
1
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                self.text += text
                with NamedTemporaryFile('w+t', delete=False) as f:
                    f.write(self.text)
                    return f.name

                
>>> with open('/tmp/tmpkkudr7', 'rt') as f:
	print(f.read())

	
1
>>> aha('http://www.formula1.com/results/driver/')
Traceback (most recent call last):
  File "<pyshell#135>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
  File "/usr/lib/python3.3/idlelib/rpc.py", line 614, in displayhook
    text = repr(value)
  File "<pyshell#132>", line 14, in __repr__
    self.text += text
AttributeError: 'aha' object has no attribute 'text'
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                self.text += text
        with NamedTemporaryFile('w+t', delete=False) as f:
            f.write(self.text)
            return f.name

        
>>> aha('http://www.formula1.com/results/driver/')
Traceback (most recent call last):
  File "<pyshell#138>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
  File "/usr/lib/python3.3/idlelib/rpc.py", line 614, in displayhook
    text = repr(value)
  File "<pyshell#137>", line 14, in __repr__
    self.text += text
AttributeError: 'aha' object has no attribute 'text'
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        with NamedTemporaryFile('w+t', delete=False) as f:
                    f.write('')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                self.text += text
                with open(f.name, 'a+t') as fa:
                    fa.write(self.text)
                    #return f.name

                    
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        with NamedTemporaryFile('w+t', delete=False) as f:
                    f.write('')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                #self.text += text
                with open(f.name, 'a+t') as fa:
                    fa.write(text)

                    
>>> aha('http://www.formula1.com/results/driver/')
Traceback (most recent call last):
  File "<pyshell#143>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
TypeError: __repr__ returned non-string (type NoneType)
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        with open('/tmp/f1dr.txt', 'w+t', delete=False) as f:
                    f.write('')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                #self.text += text
                with open('/tmp/f1dr.txt', 'a+t') as fa:
                    fa.write(text)

                    
>>> aha('http://www.formula1.com/results/driver/')
Traceback (most recent call last):
  File "<pyshell#146>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
  File "/usr/lib/python3.3/idlelib/rpc.py", line 614, in displayhook
    text = repr(value)
  File "<pyshell#145>", line 10, in __repr__
    with open('/tmp/f1dr.txt', 'w+t', delete=False) as f:
TypeError: 'delete' is an invalid keyword argument for this function
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        with open('/tmp/f1dr.txt', 'wt') as f:
                    f.write('')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                #self.text += text
                with open('/tmp/f1dr.txt', 'a') as fa:
                    fa.write(text)
        with open('/tmp/f1dr.txt', 'rt') as f:
		f.read()
		
SyntaxError: inconsistent use of tabs and spaces in indentation
>>> 
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        with open('/tmp/f1dr.txt', 'wt') as f:
                    f.write('')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                #self.text += text
                with open('/tmp/f1dr.txt', 'a') as fa:
                    fa.write(text)
        with open('/tmp/f1dr.txt', 'rt') as f:
            f.read()

            
>>> aha('http://www.formula1.com/results/driver/')
Traceback (most recent call last):
  File "<pyshell#153>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
TypeError: __repr__ returned non-string (type NoneType)
>>> class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(str(self.s))
        table = soup.find('table')
        rows = table.findAll('tr')
        with open('/tmp/f1dr.txt', 'wt') as f:
                    f.write('')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                #self.text += text
                with open('/tmp/f1dr.txt', 'a') as fa:
                    fa.write(text)
        with open('/tmp/f1dr.txt', 'rt') as f:
            print(f.read())

            
>>> aha('http://www.formula1.com/results/driver/')
1 Nico RosbergGerman Mercedes252 Kevin MagnussenDanish McLaren-Mercedes183 Jenson ButtonBritish McLaren-Mercedes154 Fernando AlonsoSpanish Ferrari125 Valtteri  BottasFinnish Williams-Mercedes106 Nico HulkenbergGerman Force India-Mercedes87 Kimi R\xc3\xa4ikk\xc3\xb6nenFinnish Ferrari68 Jean-Eric VergneFrench STR-Renault49 Daniil KvyatRussian STR-Renault210 Sergio PerezMexican Force India-Mercedes111 Adrian SutilGerman Sauber-Ferrari012 Esteban GutierrezMexican Sauber-Ferrari013 Max ChiltonBritish Marussia-Ferrari014 Jules BianchiFrench Marussia-Ferrari015 Romain GrosjeanFrench Lotus-Renault016 Pastor MaldonadoVenezuelan Lotus-Renault017 Marcus EricssonSwedish Caterham-Renault018 Sebastian VettelGerman Red Bull Racing-Renault019 Lewis HamiltonBritish Mercedes020 Felipe MassaBrazilian Williams-Mercedes021 Kamui KobayashiJapanese Caterham-Renault022 Daniel RicciardoAustralian Red Bull Racing-Renault0
Traceback (most recent call last):
  File "<pyshell#156>", line 1, in <module>
    aha('http://www.formula1.com/results/driver/')
TypeError: __repr__ returned non-string (type NoneType)
>>> 
