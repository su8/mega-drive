#!/usr/bin/python2
#import os
#import shutil
#import getpass
from gi.repository import Gtk


class encrypt_decrypt_gui:

    def on_comboboxtext1_changed(self, widget):
        print("")

    def __init__(self):
        intf = Gtk.Builder()
        intf.add_from_file('distro2usb.glade')
        intf.connect_signals(self)
        window = intf.get_object("window1")
        self.combobox = intf.get_object("comboboxtext1")
        self.file_chooser = intf.get_object("filechooserbutton1")
        self.filt = Gtk.FileFilter()
        self.filt.add_pattern("*.img")
        self.filt.add_pattern("*.iso")
        self.file_chooser.set_filter(self.filt)
        #self.combobox.set_sensitive(False)
        window.connect("delete-event", Gtk.main_quit)
        window.show_all()

if __name__ == '__main__':
    encrypt_decrypt_gui()
    Gtk.main()