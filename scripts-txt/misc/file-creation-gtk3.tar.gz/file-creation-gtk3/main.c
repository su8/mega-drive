/*   gcc -Wall -Wextra -O2 -o test main.c `pkg-config --cflags --libs gtk+-3.0`   */


#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <gtk/gtk.h>
#include "custom_header.h"

void on_ok_button_clicked(void);
void bring_warning(const char *, const char *);

GtkWidget *window, *entry;

int main(int argc, char **argv)
{
    GtkWidget *grid, *entry_label, *ok_button;

    gtk_init(&argc, &argv);

    window       = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), PROG_TITLE);
    gtk_container_set_border_width(GTK_CONTAINER(window), 6);
    gtk_window_set_default_size(GTK_WINDOW(window), 200, 20);

    /* decorate the app with CSS

    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider, APP_CSS, -1, NULL);
    GdkScreen *screen = gtk_widget_get_screen(GTK_WIDGET(window));
    gtk_style_context_add_provider_for_screen(screen,
                                              GTK_STYLE_PROVIDER(provider),
                                              GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    }
    */

    grid         = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 7);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_container_set_border_width(GTK_CONTAINER(grid), 2);
    gtk_container_add(GTK_CONTAINER(window), grid);

    entry_label  = gtk_label_new(ENTER_TXT);
    gtk_grid_attach(GTK_GRID(grid), entry_label, POS_LEFT, 1, 1, 1);

    entry        = gtk_entry_new();
    gtk_entry_set_width_chars(GTK_ENTRY(entry), 1);
    gtk_entry_set_text(GTK_ENTRY(entry), "");
    gtk_entry_set_max_length(GTK_ENTRY(entry), 50);
    gtk_grid_attach(GTK_GRID(grid), entry, POS_RIGHT, 1, 1, 1);

    ok_button = gtk_button_new_with_label(OK_BUT);
    g_signal_connect(G_OBJECT(ok_button), "clicked", G_CALLBACK(on_ok_button_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), ok_button, POS_RIGHT, 2, 1, 1);

    g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(window);
    gtk_main();

    return EXIT_SUCCESS;
}

void on_ok_button_clicked(void)
{
    const gchar *file_to_w = gtk_entry_get_text(GTK_ENTRY(entry));
    FILE *fp;
    bool err1 = false, err2 = false;

    fp = fopen(file_to_w, "r");

    if (NULL == fp) {
        fp = fopen(file_to_w, "w");
        if (NULL == fp)
            err1 = true;
    }

    else {
        bring_warning("Hold on!", "This file already exists");
        err2 = true;
    }

    if (err1)
        bring_warning("Warning", "Write permission ?");

    else {
        if (!err2) {
            fclose(fp);
            gtk_main_quit();
        }
    }
}


void bring_warning(const char *str1, const char *str2)
{
    GtkWidget *warning = gtk_message_dialog_new(GTK_WINDOW(window),
                                                    GTK_DIALOG_MODAL,
                                                    GTK_MESSAGE_WARNING,
                                                    GTK_BUTTONS_OK,
                                                    "%s", str1);
    gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(warning), "%s", str2);
    gtk_dialog_run(GTK_DIALOG(warning));
    gtk_widget_destroy(warning);
}
