#!/bin/sh

rm -rf work
mkdir work

