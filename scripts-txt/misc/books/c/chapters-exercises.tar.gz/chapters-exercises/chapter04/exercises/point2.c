/* write a program that requests your first name
and does the following with it:
a. prints it enclosed in double quatation marks
b. prints it in a 20 characters wide, with a whole field in quotes
and the name at the right end of the field
c. prints it at the left of a field 20 characters wide, with whole field
enclosed in quotes
d. prints it in a field three characters wider than the name */
#include <stdio.h>
#include <string.h>
int main(void)
{
    char name[20];
    short wide = 20;

    printf("Please enter your first name.\n");
    scanf("%s", name);
    short len_name = strlen(name);

    printf("\"%s\"\n", name);
    printf("\"%*s\"\n", wide, name);
    printf("\"%*s\"\n", -wide, name);
    printf("%*s\n", len_name + 3, name);

    return 0;
}
