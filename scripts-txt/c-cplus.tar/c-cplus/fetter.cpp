/* Compile with:
g++ -Wall -g -w -c fetter.cpp -o fetter.o
g++ -o fetter fetter.o
chmod +x fetter
./fetter -d arch
./fetter -s arch.png
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <sys/utsname.h>
#include <unistd.h>
using namespace std;


int printhelp ()
{
  cout << " usage:\n";
  cout << " fetter -d <distro>\n";
  cout << " fetter -s <filename>\n";
  cout << "\n\n";
  cout << " options: ";
  cout << "\n";
  cout << " -d <distro>     The type of distro banner\n";
  cout << " -s              Take a screenshot\n";
  cout << "\n\n";
  cout << " distro options:";
  cout << " \n";
  cout << " arch\n";
  cout << " manjaro\n";
  cout << " chakra\n";
  cout << " archbang\n";
  cout << " antergos\n";
  cout << " bridge\n";
  cout << " linux\n";
  cout << "\n\n";
  return 0;
}

int screenshot ( string filename )
{
  std::stringstream systemcall;
  systemcall << "import -window root " << filename;
  system(systemcall.str().c_str());
  return 0;
}



int main ( int argc, char *argv[] )
{

  //parses command line arguments
  if ( argc <= 2 ) {
    printhelp();
    return 1;
  }
  string flag(argv[1]);
  string parameter(argv[2]);

  if ( flag == "-s" )
  {
    screenshot( parameter );
    return 1;
  }

  if ( ( parameter != "arch" && parameter != "manjaro" && parameter != "chakra" && parameter != "archbang" && parameter != "antergos" && parameter != "cinnarch" && parameter != "bridge" && parameter != "linux" ) || flag != "-d" )
  {
    printhelp();
    return 1;
  }

  //finds your CPU information
  char* search = "model name";
  int Offset;
  string Cpu;
  ifstream CpuInfo;
  CpuInfo.open ("/proc/cpuinfo");

  if(CpuInfo.is_open())
  {
    while(!CpuInfo.eof())
    {
      getline(CpuInfo,Cpu);
      if ((Offset = Cpu.find(search, 0)) != string::npos)
      {
         break;
      }
    }
    CpuInfo.close();
  }
  Cpu.replace (0,13,"");

  string RemoveMultipleWhiteSpaces( Cpu );
  {
    string search = "  ";
    size_t index;

    while( (index = Cpu.find(search)) != string::npos )
    {
      Cpu.erase(index,1);
    }
  }

  //display's kernel information
  struct utsname KernelRelease;
  uname(&KernelRelease);

  //finds your hostname
  struct utsname KernelNodename;
  uname(&KernelNodename);


  //finds the system uptime
  FILE * uptimefile;
  char uptime_chr[28];
  long UptimeSeconds = 0;

  if((uptimefile = fopen("/proc/uptime", "r")) == NULL)
  perror("supt"), exit(EXIT_FAILURE);

  fgets(uptime_chr, 12, uptimefile);
  fclose(uptimefile);

  long UptimeMinutes;
  long UptimeHours;
  long UptimeDays;
  long UptimeSecondsReal;
  UptimeSeconds = strtol(uptime_chr, NULL, 10);
  UptimeDays = UptimeSeconds / 60 / 60 / 24;
  UptimeHours = (UptimeSeconds / 60 / 60) % 24;
  UptimeMinutes = (UptimeSeconds / 60) % 60;
  UptimeSecondsReal = UptimeSeconds % 60;

  //generates the banner

  if ( parameter == "arch" )
  {
    cout << "\n";
    cout << "   ___           _         " << getenv("USER") << "@" << KernelNodename.nodename << "\n";
    cout << "  / _ \\         | |        OS: Arch Linux \n";
    cout << " / /_\\ \\_ __ ___| |__      Kernel: " << KernelRelease.release << "\n";
    cout << " |  _  | '__/ __| '_ \\     CPU: " << Cpu << "\n";
    cout << " | | | | | | (__| | | |    Uptime: " << UptimeDays << " D, " << UptimeHours << " H, " << UptimeMinutes << " M, " << UptimeSecondsReal << " S " << "\n";
    cout << " \\_| |_/_|  \\___|_| |_|    \n\n";
  }
  else if ( parameter == "manjaro" )
  {
    cout << "\n";
    cout << "  __  __             _                     " << getenv("USER") << "@" << KernelNodename.nodename << "\n";
    cout << " |  \\/  |           (_)                    OS: Manjaro Linux\n";
    cout << " | \\  / | __ _ _ __  _  __ _ _ __ ___      Kernel: " << KernelRelease.release << "\n";
    cout << " | |\\/| |/ _` | '_ \\| |/ _` | '__/ _ \\     CPU: " << Cpu << "\n";
    cout << " | |  | | (_| | | | | | (_| | | | (_) |    Uptime: " << UptimeDays << " D, " << UptimeHours << " H, " << UptimeMinutes << " M, " << UptimeSecondsReal << " S " << "\n";
    cout << " |_|  |_|\\__,_|_| |_| |\\__,_|_|  \\___/     \n";
    cout << "                   _/ |                    \n";
    cout << "                  |__/                     \n";
    cout << "                                           \n";
  }
  else if ( parameter == "chakra" )
  {
    cout << "\n";
    cout << "   ___ _           _                  " << getenv("USER") << "@" << KernelNodename.nodename << "\n";
    cout << "  / __\\ |__   __ _| | ___ __ __ _     OS: Chakra Linux \n";
    cout << " / /  | '_ \\ / _` | |/ / '__/ _` |    Kernel: " << KernelRelease.release << "\n";
    cout << "/ /___| | | | (_| |   <| | | (_| |    CPU: " << Cpu << "\n";
    cout << "\\____/|_| |_|\\__,_|_|\\_\\_|  \\__,_|    Uptime: " << UptimeDays << " D, " << UptimeHours << " H, " << UptimeMinutes << " M, " << UptimeSecondsReal << " S " << "\n";
    cout << "                                      \n";
  }
  else if ( parameter == "archbang" )
  {
    cout << "                    _       \n";
    cout << "                   | |      \n";
    cout << "      __ _ _ __ ___| |__    \n";
    cout << "     / _` | '__/ __| '_ \\   " << getenv("USER") << "@" << KernelNodename.nodename << "\n";
    cout << " _  | (_| | | | (__| | | |  OS: ArchBang Linux \n";
    cout << "| |  \\__,_|_|  \\___|_| |_|  Kernel:" << KernelRelease.release << "\n";
    cout << "| |__   __ _ _ __   __ _    CPU:" << Cpu << "\n";
    cout << "| '_ \\ / _` | '_ \\ / _` |   Uptime:" << UptimeDays << " D, " << UptimeHours << " H, " << UptimeMinutes << " M, " << UptimeSecondsReal << " S " << "\n";
    cout << "| |_) | (_| | | | | (_| |   \n";
    cout << "|_.__/ \\__,_|_| |_|\\__, |   \n";
    cout << "                    __/ |   \n";
    cout << "                   |___/    \n";
    cout << "\n";
  }
  else if ( parameter == "antergos" )
  {
    cout << "              _                              \n";
    cout << "   __ _ _ __ | |_ ___ _ __ __ _  ___  ___    " << getenv("USER") << "@" << KernelNodename.nodename << "\n";
    cout << "  / _` | '_ \\| __/ _ \\ '__/ _` |/ _ \\/ __|   OS: Antergos Linux \n";
    cout << " | (_| | | | | ||  __/ | | (_| | (_) \\__ \\   Kernel: " << KernelRelease.release << "\n";
    cout << "  \\__,_|_| |_|\\__\\___|_|  \\__, |\\___/|___/   CPU: " << Cpu << "\n";
    cout << "                          |___/              Uptime: " << UptimeDays << " D, " << UptimeHours << " H, " << UptimeMinutes << " M, " << UptimeSecondsReal << " S " << "\n";
    cout << "                                             \n";
  }
  else if ( parameter == "bridge" )
  {
    cout << " _          _     _               \n";
    cout << "| |__  _ __(_) __| | __ _  ___    " << getenv("USER") << "@" << KernelNodename.nodename << "\n";
    cout << "| '_ \\| '__| |/ _` |/ _` |/ _ \\   OS: Bridge Linux \n";
    cout << "| |_) | |  | | (_| | (_| |  __/   Kernel: " << KernelRelease.release << "\n";
    cout << "|_.__/|_|  |_|\\__,_|\\__, |\\___|   CPU: " << Cpu << "\n";
    cout << "                    |___/         Uptime: " << UptimeDays << " D, " << UptimeHours << " H, " << UptimeMinutes << " M, " << UptimeSecondsReal << " S " << "\n";
    cout << "                                \n";
  }
  else if ( parameter == "linux" )
  {
cout << " _     _                     \n";
cout << "| |   (_)                    " << getenv("USER") << "@" << KernelNodename.nodename << "\n";
cout << "| |    _ _ __  _   ___  __   OS: Linux \n";
cout << "| |   | | '_ \\| | | \\ \\/ /   Kernel: " << KernelRelease.release << "\n";
cout << "| |___| | | | | |_| |>  <    Cpu: " << Cpu << "\n";
cout << "\\_____/_|_| |_|\\__,_/_/\\_\\   Uptime: " << UptimeDays << " D, " << UptimeHours << " H, " << UptimeMinutes << " M, " << UptimeSecondsReal << " S " << "\n";
cout << "                                   \n";
  }
  return 0;
}
