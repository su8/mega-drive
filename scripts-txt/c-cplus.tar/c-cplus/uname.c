/* uname.c -- my 'uname' implementation */
#include <stdio.h>
#include <stdlib.h>
#include <sys/utsname.h>

int main(void)
{

    struct utsname info;
    uname(&info);

    printf("%s %s %s %s %s", info.sysname, info.nodename, info.release, info.version, info.machine);

    return EXIT_SUCCESS;
}