Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> import os
>>> import shutil
>>> import zipfile
>>> class ZipProcessor(object):
	def __init__(self, zipname):
		self.zipname = zipname
		self.temp_directory = "unzipped-{}".format(
			zipname[:-4])
	def _full_filename(self, filename):
		return os.path.join(self.temp_directory, filename)
	def process_zip(self):
		self.unzip_files()
		self.process_files()
		self.zip_files()
	def unzip_files(self):
		os.mkdir(self.temp_directory)
		zipp = zipfile.ZipFile(self.zipname)
		try:
			zipp.extractall(self.temp_directory)
		finally:
			zipp.close()
	def zip_files(self):
		filee = zipfile.ZipFile(self.zipname, 'w')
		for filename in os.listdir(self.temp_directory):
			filee.write(self._full_filename(
				filename), filename)
		shutil.rmtree(self.temp_directory)

		
>>> # save it as zip_processor.py
>>> '''
from zip_processor import ZipProcess
import sys
import os
class ZipReplace(ZipProcessor):
    def __init__(self, filename, searching_string, replace_string):
        super().__init__(filename)
        self.search_string = search_string
        self.replace_string = replace_string
    def process_files(self):
        #perform a search and replace on all files in the temporary directory
        for filename in os.listdir(self.temp_directory):
            with open(self._full_filename(filename)) as file:
                contents = file.read()
            contents = contents.replace(
                self.search_string, self.replace_string)
            with open(
                self._full_filename(filename), "w") as filee:
                    filee.write(contents)
if __name__ == '__main__':
    ZipReplace(*sys.argv[1:4]).process.zip()'''
'\nfrom zip_processor import ZipProcess\nimport sys\nimport os\nclass ZipReplace(ZipProcessor):\n    def __init__(self, filename, searching_string, replace_string):\n        super().__init__(filename)\n        self.search_string = search_string\n        self.replace_string = replace_string\n    def process_files(self):\n        #perform a search and replace on all files in the temporary directory\n        for filename in os.listdir(self.temp_directory):\n            with open(self._full_filename(filename)) as file:\n                contents = file.read()\n            contents = contents.replace(\n                self.search_string, self.replace_string)\n            with open(\n                self._full_filename(filename), "w") as filee:\n                    filee.write(contents)\nif __name__ == \'__main__\':\n    ZipReplace(*sys.argv[1:4]).process.zip()'
>>> 
