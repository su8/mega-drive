#include <stdio.h>
int sum_squares(int high);
int main(void)
{
    int result = sum_squares(1024*1024*1024);
    printf("%d\nHello World", result);

    return 0;
}

int sum_squares(int high)
{
    int acc = 0;
    int limit = high + 1;
    int i;
    
    for (i = 0; i < limit; i++)
    {
        int a = i*i;
        acc += a;
    }
    
    return acc;

}
