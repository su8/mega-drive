#ifndef _MODULE_H
#define _MODULE_H 1

#define MODULE_SCREENSHOT_INDEX 0
#define MODULE_SCREENSHOT modulelist[MODULE_SCREENSHOT_INDEX]
#define MODULE_SCREENSHOT_ENTRY { MODULE_SCREENSHOT_INDEX, MODULE_STOPPED, module_screenshot_start }
void *module_screenshot_start(void *args);

#define MODULE_DEVICE_INDEX 1
#define MODULE_DEVICE modulelist[MODULE_DEVICE_INDEX]
#define MODULE_DEVICE_ENTRY { MODULE_DEVICE_INDEX, MODULE_STOPPED, module_device_start }
void *module_device_start(void *args);

#define MODULE_APPLICATION_INDEX 2
#define MODULE_APPLICATION modulelist[MODULE_APPLICATION_INDEX]
#define MODULE_APPLICATION_ENTRY { MODULE_APPLICATION_INDEX, MODULE_STOPPED, module_application_start }
void *module_application_start(void *args);

#define MODULE_POSITION_INDEX 3
#define MODULE_POSITION modulelist[MODULE_POSITION_INDEX]
#define MODULE_POSITION_ENTRY { MODULE_POSITION_INDEX, MODULE_STOPPED, module_position_start }
void *module_position_start(void *args);

#define MODULE_STOPPED  0
#define MODULE_STARTED  1
#define MODULE_STOPPING 2
#define MODULE_STARTING 3

typedef struct {
   int module_id;
   int status;
   void *(*start)(void *);
} module_t;

extern module_t modulelist[];

#endif /* _MODULE_H */
