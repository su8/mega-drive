#ifndef events_h_
#define events_h_

extern void Events_SetCallbacks (void) ;
extern void Events_Loop () ;

#endif /* events_h_ */
