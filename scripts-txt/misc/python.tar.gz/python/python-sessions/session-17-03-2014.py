Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> # 12.5 locking with deadlock avoidance
>>> import threading
>>> from contextlib import contextmanager
>>> _local = threading.local()
>>> @contextmanager
def acquire(*locks):
	# sort locks by object identifier
	locks = sorted(locks, key=lambda x: id(x))
	# Make sure lock order of previously acquired locks is not violated
	acquired = getattr(_local, 'acquired', list())
	if acquired and max(id(lock) for lock in acquired) >= id(locks[0]):
		raise RuntimeError('Lock oreder violation')
	# acquire all of the locks
	acquired.extend(locks)
	_local.acquired = acquired
	try:
		for lock in locks:
			lock.acquire()
		yield
	finally:
		# release locks in reverse order of acquisition
		for lock in reversed(locks):
			lock.release()
		del acquired[-len(locks):]

		
>>> # 12.6 storing thread-specific state
>>> # from recipe 8.3
>>> from socket import socket, AF_INET, SOCK_STREAM
>>> import threading
>>> 
>>> class LazyConnection:
	def __init__(self, address, family=AF_INET, type=SOCK_STREAM):
		self.address = address
		self.family = AF_INET
		self.type = SOCK_STREAM
		self.local = threading.local()
	def __enter__(self):
		if hasattr(self.local, 'sock'):
			raise RuntimeError('Already connected')
		self.local.sock = socket(self.family, self.type)
		self.local.sock.connect(self.address)
		return self.local.sock
	def __exit__(self, exc_ty, exc_val, tb):
		self.local.sock.close()
		del self.local.sock

		
>>> from functools import partial
>>> def test(conn):
	with conn as s:
		s.send(b'GET /index.html HTTP/1.0\r\n')
		s.send(b'Host: www.python.org\r\n')
		s.send(b'\r\n')
		resp = b''.join(iter(partial(s.recv 8192), b''))
		
SyntaxError: invalid syntax
>>> def test(conn):
	with conn as s:
		s.send(b'GET /index.html HTTP/1.0\r\n')
		s.send(b'Host: www.python.org\r\n')
		s.send(b'\r\n')
		resp = b''.join(iter(partial(s.recv, 8192), b''))
	print('Got {} bytes'.format(len(resp)))

	
>>> if __name__ == '__main__':
	conn = Lazyconnection(('www.python.org', 80))
	t1 = threading.Thread(target=test, args=(conn,))
	t2 = threading.Thread(target=test, args=(conn,))
	t1.start()
	t2.start()
	t1.join()
	t2.join()

	
Traceback (most recent call last):
  File "<pyshell#47>", line 2, in <module>
    conn = Lazyconnection(('www.python.org', 80))
NameError: name 'Lazyconnection' is not defined
>>> if __name__ == '__main__':
	conn = LazyConnection(('www.python.org', 80))
	t1 = threading.Thread(target=test, args=(conn,))
	t2 = threading.Thread(target=test, args=(conn,))
	t1.start()
	t2.start()
	t1.join()
	t2.join()

	
Exception in thread Thread-1:
Traceback (most recent call last):
  File "/usr/lib/python3.3/threading.py", line 901, in _bootstrap_inner
    self.run()
  File "/usr/lib/python3.3/threading.py", line 858, in run
    self._target(*self._args, **self._kwargs)
  File "<pyshell#38>", line 2, in test
  File "<pyshell#26>", line 11, in __enter__
socket.gaierror: [Errno -2] Name or service not known

Exception in thread Thread-2:
Traceback (most recent call last):
  File "/usr/lib/python3.3/threading.py", line 901, in _bootstrap_inner
    self.run()
  File "/usr/lib/python3.3/threading.py", line 858, in run
    self._target(*self._args, **self._kwargs)
  File "<pyshell#38>", line 2, in test
  File "<pyshell#26>", line 11, in __enter__
socket.gaierror: [Errno -2] Name or service not known

>>> # got no internet
>>> # 12.7 creating  a thread pool
>>> from concurrent.futures import ThreadPoolExecutor
>>> import urllib.request
>>> def fetch_url(url):
	u = urllib.request.urlopen(url)
	data = u.read()
	return data

>>> pool = ThreadPoolExecutor(10)
>>> # submit work to the pool
>>> a = pool.submit(fetch_url, 'http://www.python.org')
>>> b = pool.submit(fetch_url, 'http://www.pyp.org')
>>> # get the results back
>>> x = a.result()
Traceback (most recent call last):
  File "/usr/lib/python3.3/urllib/request.py", line 1248, in do_open
    h.request(req.get_method(), req.selector, req.data, headers)
  File "/usr/lib/python3.3/http/client.py", line 1065, in request
    self._send_request(method, url, body, headers)
  File "/usr/lib/python3.3/http/client.py", line 1103, in _send_request
    self.endheaders(body)
  File "/usr/lib/python3.3/http/client.py", line 1061, in endheaders
    self._send_output(message_body)
  File "/usr/lib/python3.3/http/client.py", line 906, in _send_output
    self.send(msg)
  File "/usr/lib/python3.3/http/client.py", line 844, in send
    self.connect()
  File "/usr/lib/python3.3/http/client.py", line 822, in connect
    self.timeout, self.source_address)
  File "/usr/lib/python3.3/socket.py", line 417, in create_connection
    for res in getaddrinfo(host, port, 0, SOCK_STREAM):
socket.gaierror: [Errno -2] Name or service not known

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<pyshell#65>", line 1, in <module>
    x = a.result()
  File "/usr/lib/python3.3/concurrent/futures/_base.py", line 392, in result
    return self.__get_result()
  File "/usr/lib/python3.3/concurrent/futures/_base.py", line 351, in __get_result
    raise self._exception
  File "/usr/lib/python3.3/concurrent/futures/thread.py", line 54, in run
    result = self.fn(*self.args, **self.kwargs)
  File "<pyshell#59>", line 2, in fetch_url
    u = urllib.request.urlopen(url)
  File "/usr/lib/python3.3/urllib/request.py", line 156, in urlopen
    return opener.open(url, data, timeout)
  File "/usr/lib/python3.3/urllib/request.py", line 469, in open
    response = self._open(req, data)
  File "/usr/lib/python3.3/urllib/request.py", line 487, in _open
    '_open', req)
  File "/usr/lib/python3.3/urllib/request.py", line 447, in _call_chain
    result = func(*args)
  File "/usr/lib/python3.3/urllib/request.py", line 1274, in http_open
    return self.do_open(http.client.HTTPConnection, req)
  File "/usr/lib/python3.3/urllib/request.py", line 1251, in do_open
    raise URLError(err)
urllib.error.URLError: <urlopen error [Errno -2] Name or service not known>
>>> # no internet :D
>>> # virtual memory
>>> threading.stack_size(65536)
0
>>> 
