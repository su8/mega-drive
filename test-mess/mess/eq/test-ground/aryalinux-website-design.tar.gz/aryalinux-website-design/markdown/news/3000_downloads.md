
---

Over 3000 downloads of the builder DVD happened in the past two days.

We thank all our users for the support. Your support has helped us achieve more that what we had anticipated.

Few users have also communicated with us but mostly we never came to know, how many users actually tried building their own Linux from Scratch.

If you use some other distro, are from the LFS camp, were looking for some sort of an ALFS, a non-linux user or just a casual open source user and observer, we would love to hear from you either what your build experiences were like or what you anticipated and found in return or what you would like to see in maybe a future release, so that we can improve upon, correct our mistakes and come up with a better AryaLinux in the forthcoming releases.


Write to us at aryalinux11@gmail.com or post your experiences in [this] LinuxQuestions.org thread.

[this]: http://www.linuxquestions.org/questions/aryalinux-120/please-share-your-building-experiences-4175579574/
