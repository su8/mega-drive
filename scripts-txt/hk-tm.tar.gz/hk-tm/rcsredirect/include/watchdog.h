
/* $Id: watchdog.h 790 2009-08-03 14:34:04Z alor $ */

#ifndef __WATCHDOG_H
#define __WATCHDOG_H


void watchdog_init(void);

#endif

/* EOF */

// vim:ts=3:expandtab

