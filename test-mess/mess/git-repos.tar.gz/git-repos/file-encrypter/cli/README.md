<img src="img/overview.png" alt="" />
Avoid spaces in the file names, example:
this is file.txt

Replace those spaces with - or _ ,

Example 2

file name: z g r.txt


    python2 encrypt_decrypt.py e /home/frost/z\ g\ r.txt

    python2 encrypt_decrypt.py d /home/frost/z\ g\ r.txt


The file name has white spaces, but it works.