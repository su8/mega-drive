/* arg_parser2.c --  */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <getopt.h>

int main(int argc, char **argv)
{

    bool manual = false, logo = true, portrait = false;
    bool verbose = false, screenshot = false;

    struct option options[] =
    {
        { "manual", no_argument, 0, 'm' },
        { "verbose", no_argument, 0, 'v' },
        { "no-logo", no_argument, 0, 'n' },
        { "screenshot", no_argument, 0, 's' },
        { "distro", required_argument, 0, 'D' },
        { "suppress-errors", no_argument, 0, 'E' },
        { "portrait", no_argument, 0, 'p'},
        { "version", no_argument, 0, 'V' },
        { "help", no_argument, 0, 'h' },
        { "logo-only", required_argument, 0, 'L' },
        { 0, 0, 0, 0 }
    };

    signed char c;
    int index = 0;
    while ((c = getopt_long(argc, argv, "mvns:EpVh:", options, &index)) != -1)
    {
        switch (c)
        {
            case 'm':
                manual = true;
                break;
            case 'v':
                verbose = true;
                break;
            case 'n':
                logo = false;
                break;
            case 's':
                screenshot = true;
                break;
            case 'E':
                printf("%c called\n", c);
                break;
            case 'p':
                portrait = true;
                break;
            case 'V':
                printf("%c called\n", c);
                return EXIT_SUCCESS;
            case 'h':
                printf("%c called\n", c);
                break;
            default:
                return EXIT_FAILURE;
        }
    }

    return EXIT_SUCCESS;
}