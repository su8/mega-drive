/* 13. Define a function that takes an int argument and that returns, as a long , the square of
that value.
*/
#include <stdio.h>
int func(int ret_val);

int main(void)
{
    int i = 66000;
    
    long f;
    
    f = func(i);
    
    printf("%ld", f);
    
    return 0;
}

int func(int ret_val)
{
    int i;
    for (i = 0; i < ret_val; i++)
    {
    }
        
    return (long)(ret_val * ret_val);
}
