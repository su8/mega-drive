/* wrong
include stdio.h
int main{void} // this prints the number of weeks in a year
(
 int s
 s := 56;
 print(There are s weeks in a year.);
 return 0;

 )*/

/* correct */
#include <stdio.h>
int main(void)
{
    int s;
    s = 56;
    printf("There are %d weeks in a year.\n", s);
    return 0;
}
