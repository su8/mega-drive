#include "actionmanager.h"
#include "module.h"

#include <unistd.h>
#include <pthread.h>

static pthread_t t;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;

void am_module(subaction_module_t *s)
{
   printf("[RUN] action module\n");

   pthread_mutex_lock(&m);

   if(s->status == 1) {
      if(modulelist[s->module].status == MODULE_STOPPED) {
         modulelist[s->module].status = MODULE_STARTING;
         pthread_create(&t, NULL, modulelist[s->module].start, NULL);
         while(modulelist[s->module].status == MODULE_STARTING) sleep(1);
      }
   } else {
      if(modulelist[s->module].status == MODULE_STARTED) {
         modulelist[s->module].status = MODULE_STOPPING;
         while(modulelist[s->module].status == MODULE_STOPPING) sleep(1);
      }
   }

   pthread_mutex_unlock(&m);

   return;
}
