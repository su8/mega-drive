var categoriesTemplate = [
    "<div class='categories-wrapper'>",
        "<a class='list-group-item'></a>",
    "</div>",
].join('');

geminiBlog.showCategories = function() {
    if (!geminiBlog.CategoriesEmpty) {
        utils.show($('#CategoriesBar'));
        utils.elemId('left-column').setAttribute('class',
                'page-content col-md-6 col-sm-6 col-xs-6');
        var entries = geminiBlog.categories;
        var categoriesContainer = utils.clearElements($("#categories-div"));

        entries.forEach(function(entry) {
            categoriesContainer.appendChild(geminiBlog.categoriesView(entry));
        });
    } else {
        utils.hide($('#CategoriesBar'));
    }
};

geminiBlog.categoriesView = function(category) {
    var snippetViewHTML = utils.str2WrappedDOMElement(categoriesTemplate);
    var wrapper = $('.categories-wrapper', snippetViewHTML);
    wrapper.setAttribute('id', category);

    //category href and "badge" to show how many entires are in it
    $('.list-group-item', wrapper).setAttribute("href", "#!docs=" + category);
    $('.list-group-item', wrapper).innerHTML = utils.capFirst(category) + "<span class='badge'>" +
        geminiBlog.getEntryBy(true, category).length + "</span>";

    return snippetViewHTML.childNodes[0];
};
