import re
from glob import glob
#class pacman(object):
def search_package(second):
#for line in glob("/var/log/Xorg.0.*"):
#for x in open("{0}".format(line)):
    #if re.match("(.*)fglrx(.*)", x):
	    #print(x)
	second_2 = second[0].capitalize()
	second_3 = second[0]
	second_4 = second[1:]
	
	for line in glob("/var/log/pacman.*"):
	    for line2 in open(line, "r"):
		    if re.match("(.*)({0}|{1}){2}(.*)".format(second_2, second_3, second_4), line2):
			    print(line2)
			    #print(re.findall(r"\w+-\w+\-\w+", line2))
search_package("kde-base-artwork")
#value = "[2014-01-11 09:28 16:59]"
#re.findall(r'2014-01-15', value)
#re.findall(r"\w+-\w+\-\w+", value)

def search_package(date, first, second):
#for line in glob("/var/log/Xorg.0.*"):
#for x in open("{0}".format(line)):
    #if re.match("(.*)fglrx(.*)", x):
	    #print(x)
	second_2 = second[0].capitalize()
	second_3 = second[0]
	second_4 = second[1:]
	
	for line in glob("/var/log/pacman.*"):
	    for line2 in open(line, "r"):
		    if re.match("(.*){0} ({1}|{2}){3}(.*)".format(first, second_2, second_3, second_4), line2) and re.match("(.*){0}(.*)".format(date), line2):
			    print(line2)
			    #print(re.findall(r"\w+-\w+\-\w+", line2))
#search_advanced("2014-01-11", "installed", "kde")


def search_date(first):
	for line in glob("/var/log/pacman.*"):
	    #print("file:", line)
	    for line2 in open(line, "r"):
		    if re.match("(.*){0}(.*)".format(first), line2):
			    print(line2)
			    #print(re.findall(r"\w+-\w+\-\w+", line2))
#search_date("2014-01-11")