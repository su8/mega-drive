#!/usr/bin/env python

# example treeviewdnd.py

from gi.repository import Gtk, Gdk

class TreeViewDnDExample:

    def drag_data_received_data(self, treeview, context, x, y, selection,
                                info, etime):
        model = treeview.get_model()
        data = selection.get_data().decode("utf-8")
        drop_info = treeview.get_dest_row_at_pos(x, y)
        files = data.rstrip('\n').split('\n')
        for fn in files:
           a = fn.split('file://',1)[-1]
           ab = a.replace("file://", "")
           print(ab)
            #print fn
            #self.add_file(fn)
       # self.place_items()
        #print files
        if drop_info:
            path, position = drop_info
            iter = model.get_iter(path)
            if (position == Gtk.TreeViewDropPosition.BEFORE
                or position == Gtk.TreeViewDropPosition.BEFORE):
                model.insert_before(iter, [ab])
            else:
                model.insert_after(iter, [ab])
        else:
            model.append([ab])
        if context.get_actions() == Gdk.DragAction.MOVE:
            context.finish(True, True, etime)
        return

    TARGETS = [
        ('MY_TREE_MODEL_ROW', Gtk.TargetFlags.SAME_WIDGET, 0),
        ('text/plain', 0, 1),
        ('TEXT', 0, 2),
        ('STRING', 0, 3),
        ]
    # close the window and quit
    def delete_event(self, widget, event, data=None):
        Gtk.main_quit()
        return False

    def clear_selected(self, button):
        selection = self.treeview.get_selection()
        model, iter = selection.get_selected()
        if iter:
            model.remove(iter)
            #if self.liststore.get_iter_first() == None:
                #self.liststore.append(['Drag & Drop on me some folder or file'])
        return



    def clear_liststore(self, widget):
        self.liststore.clear()
        #self.liststore.append(['Drag & Drop on me some folder or file'])

    def __init__(self):
        # Create a new window
        self.window = Gtk.Window()

        self.window.set_name("Backup")

        self.window.set_size_request(400, 400)

        self.window.connect("delete_event", self.delete_event)
        #style_provider = Gtk.CssProvider()

        #css = """
        ##Backup {
            #background-color: #404040;
        #}
        #"""

        #style_provider.load_from_data(css)

        #Gtk.StyleContext.add_provider_for_screen(
            #Gdk.Screen.get_default(),
            #style_provider,
            #Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        #)
        self.scrolledwindow = Gtk.ScrolledWindow()
        self.vbox = Gtk.VBox()
        self.hbox = Gtk.HButtonBox()
        self.vbox.pack_start(self.scrolledwindow, True, True, 0)
        self.vbox.pack_start(self.hbox, False, True, 0)
        self.b0 = Gtk.Button('Clear All')
        #self.b0.set_size_request(30, 30)
        self.b1 = Gtk.Button('Clear Selected')
        #self.b1.set_size_request(30, 30)
        self.load_profile = Gtk.Button('Load Profile')
        #self.b2.set_size_request(30, 30)
        self.backup = Gtk.Button('BACKUP')
        #self.b3.set_size_request(30, 30)
        self.expander = Gtk.Expander(label="More options")
        self.expander.set_resize_toplevel(True)
        self.hbox.pack_start(self.b0, True, True, 0)
        self.hbox.pack_start(self.b1, True, True, 0)
        self.hbox.pack_start(self.load_profile, True, True, 0)
        self.hbox.pack_start(self.backup, True, True, 0)
        self.vbox.pack_start(self.expander, False, False, 10)
        self.random_button = Gtk.Button(label="Button")
        self.random_button.set_size_request(20, 20)
        self.builder = Gtk.Builder()
        self.builder.add_from_file('bb.ui')
        self.builder.connect_signals(self)
        self.grid = self.builder.get_object('grid1')
        self.expander.add(self.grid)

        # create a liststore with one string column to use as the model
        self.liststore = Gtk.ListStore(str)

        # create the TreeView using liststore
        self.treeview = Gtk.TreeView(self.liststore)

       # create a CellRenderer to render the data
        self.cell = Gtk.CellRendererText()

        # create the TreeViewColumns to display the data
        self.tvcolumn = Gtk.TreeViewColumn('Drag & Drop on me some folder or file', self.cell, text=0)

        # add columns to treeview
        self.treeview.append_column(self.tvcolumn)
        #self.liststore.insert(1, None)
        #self.liststore.append(['Drag & Drop on me some folder or file'])
        self.b0.connect('clicked', self.clear_liststore)
        self.b1.connect('clicked', self.clear_selected)
        # make treeview searchable
        self.treeview.set_search_column(0)

        # Allow sorting on the column
        self.tvcolumn.set_sort_column_id(0)

        # Allow enable drag and drop of rows including row move
        self.treeview.enable_model_drag_source( Gdk.ModifierType.BUTTON1_MASK,
                                                self.TARGETS,
                                                Gdk.DragAction.DEFAULT|
                                                Gdk.DragAction.MOVE)
        self.treeview.enable_model_drag_dest(self.TARGETS,
                                             Gdk.DragAction.DEFAULT)
        self.treeview.drag_dest_add_text_targets()
        self.treeview.drag_source_add_text_targets()

        self.treeview.connect("drag_data_received",
                              self.drag_data_received_data)
        self.screen = Gdk.Screen.get_default()
        self.css_provider = Gtk.CssProvider()
        self.css_provider.load_from_path('style.css')
        self.priority = Gtk.STYLE_PROVIDER_PRIORITY_USER
        self.context = Gtk.StyleContext()
        self.context.add_provider_for_screen(self.screen, self.css_provider, self.priority)

        self.scrolledwindow.add(self.treeview)
        self.window.add(self.vbox)
        self.window.show_all()

def main():
    Gtk.main()

if __name__ == "__main__":
    treeviewdndex = TreeViewDnDExample()
    main()
