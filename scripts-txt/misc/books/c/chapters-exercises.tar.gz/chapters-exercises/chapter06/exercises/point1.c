/* 1. Write a program that creates an array with 26 elements and stores the 26 lowercase
letters in it. Also have it show the array contents. 
#include <stdio.h>
int main(void)
{
    const int CHARS = 26;
    char ch;

    for (ch = 'a'; ch < ('a' + CHARS); ch++)
        printf("%c", ch);
    printf("\n");

    return 0;
}
*/
#include <stdio.h>
#define SIZE 26
int main( void )
{
    char lcase[SIZE];
    int i;
    
    for (i = 0; i < SIZE; i++)
        lcase[i] = 'a' + i;
    for (i = 0; i < SIZE; i++)
        printf("%c", lcase[i]);
    printf("\n");        

    return 0;
}
