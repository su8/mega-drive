<?php

// We'll run tshwctl --cputemp, which returns a string value like:
// "cputemp_millicelsius=40000".
try {
  $ret = exec("tshwctl --cputemp");
  $millicelsius = (int)substr($ret, strpos($ret, '=') + 1);
  $temperature = (int)$millicelsius / 1000;
  echo $temperature;
}
catch (Exception $e) {
  header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500); 
}
