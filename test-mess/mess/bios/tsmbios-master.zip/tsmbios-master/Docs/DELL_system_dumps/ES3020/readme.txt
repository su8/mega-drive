this is a PE2600 in disguise.
