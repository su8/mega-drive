Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> random_keys = dict()
>>> random_keys[25.2] = "float work too"
>>> random_keys[('abc',123)] = 'so do tuples'
>>> random_keys
{('abc', 123): 'so do tuples', 25.2: 'float work too'}
>>> random_keys.get('abc')
>>> class AnObject(object):
	def __init__(self, value):
		self.value = value

		
>>> my_object = AnObject(14)
>>> random_keys[my_object] = my_object
>>> random_keys
{('abc', 123): 'so do tuples', 25.2: 'float work too', <__main__.AnObject object at 0x7fde9532d278>: <__main__.AnObject object at 0x7fde9532d278>}
>>> random_keys[my_object]
<__main__.AnObject object at 0x7fde9532d278>
>>> random_keys[my_object].value
14
>>> from collections import defaultdict
>>> def letter_frequency(sentence):
	frequencies = defaultdict(int)
	for letter in sentence:
		frequencies[letter] += 1
	return frequencies

>>> letter_frequency("float work too")
defaultdict(<class 'int'>, {'o': 4, 'l': 1, 'w': 1, 't': 2, ' ': 2, 'f': 1, 'k': 1, 'a': 1, 'r': 1})
>>> num_items = 0
>>> def tuple_container():
	global num_items
	num_items += 1
	return (num_items, list())

>>> d = defaultdict(tuple_container)
>>> d['a'][1].append('hello')
>>> d['b'][1].append('world')
>>> d
defaultdict(<function tuple_container at 0x7fde94e27400>, {'a': (1, ['hello']), 'b': (2, ['world'])})
>>> d['a']
(1, ['hello'])
>>> import string
>>> CHARACTERS = list(string.ascii_letters) + [" "]
>>> def letter_frequency(sentence):
	frequencies = [(c, 0) for c in CHARACTERS]
	for letter in sentence:
		index = CHARACTERS.index(letter)
		frequencies[index] = (letter, frequencies[index][1] + 1)
	return frequencies

>>> string.ascii_letters
'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
>>> string.ascii_letters + [" "]
Traceback (most recent call last):
  File "<pyshell#44>", line 1, in <module>
    string.ascii_letters + [" "]
TypeError: Can't convert 'list' object to str implicitly
>>> list(string.ascii_letters) + [" "]
['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' ']
>>> list(string.ascii_letters)
['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
>>> 
