The folder goes to ~/.mozilla/firefox/NUMBER.default/

This way you can restore/export old/new bookmarks