#!/usr/bin/python2
import shlex
import subprocess
import os

os.chdir('/home/frost/Documents/blog/')
process = subprocess.Popen(shlex.split('python2 build.py'))
process.communicate()