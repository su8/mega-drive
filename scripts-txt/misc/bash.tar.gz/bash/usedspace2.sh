#!/bin/bash
partition=sda3
percent=80
hdd=`df -h |grep $partition | awk '{ print $5 }' | cut -d'%' -f1`
if [ $hdd -gt $percent ]; then
echo -e "\e[93mUsed space in %: \e[31m$hdd"
echo -e "\033[0m"
else
echo -e "\e[40;38;5;82mUsed space in %: \e[44m$hdd"
echo -e "\033[0m" 
fi
