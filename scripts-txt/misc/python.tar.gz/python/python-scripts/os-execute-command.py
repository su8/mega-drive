import os
import signal
import sys

keeper = 1
while keeper == 1:
    def signal_handler(signal, frame):
        print("\nbye")
        sys.exit(0)
    signal.signal(signal.SIGINT, signal_handler)
    while True:
        pass
        command = raw_input('>')
        os.system(command)
        



