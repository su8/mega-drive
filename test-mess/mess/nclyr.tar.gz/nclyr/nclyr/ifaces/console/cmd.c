
#include "common.h"

#include "console.h"
#include "cmd.h"
#include "debug.h"

void console_cmd_handle(const char *cmd)
{

}
