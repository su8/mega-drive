Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> # executingg code with local side effects
>>> a = 13
>>> exec('b = a + 1')
>>> print(b)
14
>>> # now try the same experiment inside a function
>>> def test():
	a = 13
	exec('b = a + 1')
	print(b)

	
>>> test()
14
>>> # it should fail here but dunno why it didn't
>>> def test():
	a = 13
	loc = locals()
	exec('b = a + 1')
	b = loc['b']
	print(b)

	
>>> test()
14
>>> 
