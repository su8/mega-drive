/* 

2. Devise a function chline(ch,i,j) that prints the requested character in columns i
through j . Test it in a simple driver.

*/
#include <stdio.h>
#include <stdlib.h>
int main(void)
{

    return EXIT_SUCCESS;
}