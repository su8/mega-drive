#!/bin/bash
gksudo kate /etc/locale.conf
#LANG=en_US.UTF-8
#LANG=bg_BG.UTF-8