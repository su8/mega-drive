/* Write a program that asks you to enter
ASCII code value (integer type) and then
prints the character having that ASCII code */
#include <stdio.h>
int main(void)
{
    int int_to_ascii;

    printf("Enter a integer value, e.g(98): ");
    scanf("%d", &int_to_ascii);
    printf("The integer %d represents %c in ascii code.\n",
            int_to_ascii, int_to_ascii);

    return 0;
}
