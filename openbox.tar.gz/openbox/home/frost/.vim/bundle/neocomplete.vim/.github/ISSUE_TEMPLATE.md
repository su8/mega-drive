# Problems summary


## Expected


## Environment Information
 * OS:
 * Vim version:


## Provide a minimal .vimrc with less than 50 lines (Required!)

```vim
" Your minimal .vimrc
set runtimepath+=~/path/to/neocomplete.nvim/
let g:neocomplete#enable_at_startup = 1
```


## The reproduce ways from Vim starting (Required!)

 1. foo
 2. bar
 3. baz


## Screen shot (if possible)


## Upload the log messages by `:redir` and `:message`
