Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class a:
	def __init__(self):
		self.elo = ['elo','belo','melo']
	def __contains__(self, g):
		return g in self.elo

	
>>> b = a()
>>> 'elo' in b
True
>>> class a:
	def __init__(self):
		self.elo = ['elo','belo','melo']
	def __contains__(self, g):
		raise Exception('not permitted')

	
>>> 'elo' in a()
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    'elo' in a()
  File "<pyshell#7>", line 5, in __contains__
    raise Exception('not permitted')
Exception: not permitted
>>> dir(list)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> help(list.__add__)
Help on wrapper_descriptor:

__add__(self, value, /)
    Return self+value.

>>> # dictionary that remembers the order in which keys were inserted
>>> from collections import KeysView, ItemsView, ValuesView
>>> class DictSorted(dict):
	def __new__(*args, **kwargs):
		new_dict = dict.__new__(*args, **kwargs)
		new_dict.ordered_keys = list()
		return new_dict
	def __setitem__(self, key, value):
		'''self[key] = value syntax'''
		if key not in self.ordered_keys:
			self.ordered_keys.append(key)
		super().__setitem__(key, value)
	def setdefault(self, key, value):
		if key not in self.ordered_keys:
			self.ordered_keys.append(key)
		return super().setdefault(key, value) # super()[key] = value
	def keys(self):
		return KeysView(self)
	def values(self):
		return ValuesView(self)
	def items(self):
		return ItemsView(self)
	def __iter__(self):
		'''for x in self syntax'''
		return self.ordered_keys.__iter__()

	
>>> ds = DictSorted()
>>> d = dict()
>>> ds['a'] = 1
>>> ds['b'] = 2
>>> ds.setdefault('c', 3)
3
>>> d['a'] = 1
>>> d['b'] = 2
>>> d.setdefault('c', 3)
3
>>> for k,v in ds.items():
	print(k,v)

	
a 1
b 2
c 3
>>> for k,v in d.items():
	print(k,v)

	
b 2
a 1
c 3
>>> from collections import OrderedDict
>>> help(OrderedDict)
Help on class OrderedDict in module collections:

class OrderedDict(builtins.dict)
 |  Dictionary that remembers insertion order
 |  
 |  Method resolution order:
 |      OrderedDict
 |      builtins.dict
 |      builtins.object
 |  
 |  Methods defined here:
 |  
 |  __delitem__(self, key, dict_delitem=<slot wrapper '__delitem__' of 'dict' objects>)
 |      od.__delitem__(y) <==> del od[y]
 |  
 |  __eq__(self, other)
 |      od.__eq__(y) <==> od==y.  Comparison to another OD is order-sensitive
 |      while comparison to a regular mapping is order-insensitive.
 |  
 |  __init__(self, *args, **kwds)
 |      Initialize an ordered dictionary.  The signature is the same as
 |      regular dictionaries, but keyword arguments are not recommended because
 |      their insertion order is arbitrary.
 |  
 |  __iter__(self)
 |      od.__iter__() <==> iter(od)
 |  
 |  __ne__(self, other)
 |  
 |  __reduce__(self)
 |      Return state information for pickling
 |  
 |  __repr__(self)
 |      od.__repr__() <==> repr(od)
 |  
 |  __reversed__(self)
 |      od.__reversed__() <==> reversed(od)
 |  
 |  __setitem__(self, key, value, dict_setitem=<slot wrapper '__setitem__' of 'dict' objects>, proxy=<built-in function proxy>, Link=<class 'collections._Link'>)
 |      od.__setitem__(i, y) <==> od[i]=y
 |  
 |  __sizeof__(self)
 |  
 |  clear(self)
 |      od.clear() -> None.  Remove all items from od.
 |  
 |  copy(self)
 |      od.copy() -> a shallow copy of od
 |  
 |  items(self)
 |      D.items() -> a set-like object providing a view on D's items
 |  
 |  keys(self)
 |      D.keys() -> a set-like object providing a view on D's keys
 |  
 |  move_to_end(self, key, last=True)
 |      Move an existing element to the end (or beginning if last==False).
 |      
 |      Raises KeyError if the element does not exist.
 |      When last=True, acts like a fast version of self[key]=self.pop(key).
 |  
 |  pop(self, key, default=<object object at 0x7fa0e6467070>)
 |      od.pop(k[,d]) -> v, remove specified key and return the corresponding
 |      value.  If key is not found, d is returned if given, otherwise KeyError
 |      is raised.
 |  
 |  popitem(self, last=True)
 |      od.popitem() -> (k, v), return and remove a (key, value) pair.
 |      Pairs are returned in LIFO order if last is true or FIFO order if false.
 |  
 |  setdefault(self, key, default=None)
 |      od.setdefault(k[,d]) -> od.get(k,d), also set od[k]=d if k not in od
 |  
 |  update(*args, **kwds)
 |      D.update([E, ]**F) -> None.  Update D from mapping/iterable E and F.
 |      If E present and has a .keys() method, does:     for k in E: D[k] = E[k]
 |      If E present and lacks .keys() method, does:     for (k, v) in E: D[k] = v
 |      In either case, this is followed by: for k, v in F.items(): D[k] = v
 |  
 |  values(self)
 |      D.values() -> an object providing a view on D's values
 |  
 |  ----------------------------------------------------------------------
 |  Class methods defined here:
 |  
 |  fromkeys(iterable, value=None) from builtins.type
 |      OD.fromkeys(S[, v]) -> New ordered dictionary with keys from S.
 |      If not specified, the value defaults to None.
 |  
 |  ----------------------------------------------------------------------
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  ----------------------------------------------------------------------
 |  Data and other attributes defined here:
 |  
 |  __hash__ = None
 |  
 |  ----------------------------------------------------------------------
 |  Methods inherited from builtins.dict:
 |  
 |  __contains__(self, key, /)
 |      True if D has a key k, else False.
 |  
 |  __ge__(...)
 |      __ge__=($self, value, /)
 |      --
 |      
 |      Return self>=value.
 |  
 |  __getattribute__(self, name, /)
 |      Return getattr(self, name).
 |  
 |  __getitem__(...)
 |      x.__getitem__(y) <==> x[y]
 |  
 |  __gt__(self, value, /)
 |      Return self>value.
 |  
 |  __le__(self, value, /)
 |      Return self<=value.
 |  
 |  __len__(self, /)
 |      Return len(self).
 |  
 |  __lt__(self, value, /)
 |      Return self<value.
 |  
 |  __new__(*args, **kwargs) from builtins.type
 |      Create and return a new object.  See help(type) for accurate signature.
 |  
 |  get(...)
 |      D.get(k[,d]) -> D[k] if k in D, else d.  d defaults to None.

>>> from urllib.request import urlopen
>>> from urllib.parse import urlparse
>>> import re
>>> import sys
>>> LINK_REGEX = re.compile("< a [^>]*href=['\"]([^'\"+)['\"][^>]*>")
Traceback (most recent call last):
  File "<pyshell#57>", line 1, in <module>
    LINK_REGEX = re.compile("< a [^>]*href=['\"]([^'\"+)['\"][^>]*>")
  File "/usr/lib/python3.4/re.py", line 219, in compile
    return _compile(pattern, flags)
  File "/usr/lib/python3.4/re.py", line 288, in _compile
    p = sre_compile.compile(pattern, flags)
  File "/usr/lib/python3.4/sre_compile.py", line 465, in compile
    p = sre_parse.parse(p, flags)
  File "/usr/lib/python3.4/sre_parse.py", line 748, in parse
    p = _parse_sub(source, pattern, 0)
  File "/usr/lib/python3.4/sre_parse.py", line 360, in _parse_sub
    itemsappend(_parse(source, state))
  File "/usr/lib/python3.4/sre_parse.py", line 698, in _parse
    raise error("unbalanced parenthesis")
sre_constants.error: unbalanced parenthesis
>>> LINK_REGEX = re.compile("<a [^>]*href=['\"]([^'\"+)['\"][^>]*>")
Traceback (most recent call last):
  File "<pyshell#58>", line 1, in <module>
    LINK_REGEX = re.compile("<a [^>]*href=['\"]([^'\"+)['\"][^>]*>")
  File "/usr/lib/python3.4/re.py", line 219, in compile
    return _compile(pattern, flags)
  File "/usr/lib/python3.4/re.py", line 288, in _compile
    p = sre_compile.compile(pattern, flags)
  File "/usr/lib/python3.4/sre_compile.py", line 465, in compile
    p = sre_parse.parse(p, flags)
  File "/usr/lib/python3.4/sre_parse.py", line 748, in parse
    p = _parse_sub(source, pattern, 0)
  File "/usr/lib/python3.4/sre_parse.py", line 360, in _parse_sub
    itemsappend(_parse(source, state))
  File "/usr/lib/python3.4/sre_parse.py", line 698, in _parse
    raise error("unbalanced parenthesis")
sre_constants.error: unbalanced parenthesis
>>> LINK_REGEX = re.compile("<a [^>]*href=['\"]([^'\"]+)['\"][^>]*>")
>>> class LinkCollector(object):
	def __init__(self, url):
		self.url = "http://" + urlparse(url).netloc
	def collect_links(self, path="/"):
		full_url = self.url + path
		page = str(urlopen(full_url).read())
		links = LINK_REGEX.findall(page)
		print(links)

		
>>> '''if __name__ == "__main__":
    LinkCollector(sys.argv[1]).collect_links()'''
'if __name__ == "__main__":\n    LinkCollector(sys.argv[1]).collect_links()'
>>> LinkCollector('http://localhost:8000').collect_links()
['.backup/', '.classpath', '.directory', '.idea/', '.png', '.project', '.txtd', '1.png', '12.png', '13.png', '14.png', '177-Python%203%20Object%20Oriented%20Programming%20%282010%29.pdf', '20.png', '23.png', '24.png', '50-Linux%20%26%20Open%20Source%20Genius%20Guide%20-%20Volume%203%2C%202013.pdf', '66-Linux%20User%20%26%20Developer%20-%20Issue%20No.%20137.pdf', 'bin32-firefox/', 'bin32-firefox.tar.gz', 'bt-wifix-master.zip', 'cfg-yoimnotpro.py', 'chromium-bookmarks_04.05.14.html', 'chromium-bookmarks_3_5_14.html', 'cla.py', 'cvlc-picture-taking.txt', 'domain-parser-master.zip', 'F1_2014.jpg', 'flappy-master.zip', 'from-template-3.txt', 'Grub2-themes-master.zip', 'https---github_com-manjaro-manjaro-welcome-pull-2-files.pdf', 'https---github_com-manjaro-manjaro-welcome-pull-3-files.pdf', 'imd.py', 'imdb.py', 'initialization%20-%20Set%20attributes%20from%20dictionary%20in%20python%20-%20Stack%20Overflow.html', 'kristut20.py', 'Linux%20Journal%20April%202014.pdf', 'Linux%20User%20%26%20Developer%20-%20Issue%20No.%20138.pdf', 'locale-langs.sh', 'manjaro-welcome-development/', 'manjaro-welcome-development.zip', 'multiproc.py', 'pivaders-master/', 'pivaders-master.zip', 'plymouth-0.8.8.tar.bz2', 'plymouth-theme-paw-arch.tar.gz', 'pys.py', 'Python%20101%20%20Reading%20and%20Writing%20CSV%20Files%20%20%20Javalobby.html', 'Python%20Bytecode%20%20Fun%20with%20dis%20-%20Of%20Interest.html', 'Python%20Concurrency%20%20An%20Intro%20to%20Threads%20%20%20Python%20Zone.html', 'python-3.3.4-docs-html/', 'python-pics/', 'python-sessions/', 'setup.py', 'skype.desktop', 'snapshot1.png', 'snapshot11.png', 'snapshot2.png', 'snapshot4.png', 'snapshot8.png', 'test.html', 'Text%20File', 'Text%20File%201', 'thanks_for_watching.png', 'Torchlight%20II.desktop', 'Xilisoft%20Video%20Converter%20Ultimate.desktop', 'Xilisoft%20Video%20Converter.desktop']
>>> LinkCollector('http://localhost:8000/test.html').collect_links()
['.backup/', '.classpath', '.directory', '.idea/', '.png', '.project', '.txtd', '1.png', '12.png', '13.png', '14.png', '177-Python%203%20Object%20Oriented%20Programming%20%282010%29.pdf', '20.png', '23.png', '24.png', '50-Linux%20%26%20Open%20Source%20Genius%20Guide%20-%20Volume%203%2C%202013.pdf', '66-Linux%20User%20%26%20Developer%20-%20Issue%20No.%20137.pdf', 'bin32-firefox/', 'bin32-firefox.tar.gz', 'bt-wifix-master.zip', 'cfg-yoimnotpro.py', 'chromium-bookmarks_04.05.14.html', 'chromium-bookmarks_3_5_14.html', 'cla.py', 'cvlc-picture-taking.txt', 'domain-parser-master.zip', 'F1_2014.jpg', 'flappy-master.zip', 'from-template-3.txt', 'Grub2-themes-master.zip', 'https---github_com-manjaro-manjaro-welcome-pull-2-files.pdf', 'https---github_com-manjaro-manjaro-welcome-pull-3-files.pdf', 'imd.py', 'imdb.py', 'initialization%20-%20Set%20attributes%20from%20dictionary%20in%20python%20-%20Stack%20Overflow.html', 'kristut20.py', 'Linux%20Journal%20April%202014.pdf', 'Linux%20User%20%26%20Developer%20-%20Issue%20No.%20138.pdf', 'locale-langs.sh', 'manjaro-welcome-development/', 'manjaro-welcome-development.zip', 'multiproc.py', 'pivaders-master/', 'pivaders-master.zip', 'plymouth-0.8.8.tar.bz2', 'plymouth-theme-paw-arch.tar.gz', 'pys.py', 'Python%20101%20%20Reading%20and%20Writing%20CSV%20Files%20%20%20Javalobby.html', 'Python%20Bytecode%20%20Fun%20with%20dis%20-%20Of%20Interest.html', 'Python%20Concurrency%20%20An%20Intro%20to%20Threads%20%20%20Python%20Zone.html', 'python-3.3.4-docs-html/', 'python-pics/', 'python-sessions/', 'setup.py', 'skype.desktop', 'snapshot1.png', 'snapshot11.png', 'snapshot2.png', 'snapshot4.png', 'snapshot8.png', 'test.html', 'Text%20File', 'Text%20File%201', 'thanks_for_watching.png', 'Torchlight%20II.desktop', 'Xilisoft%20Video%20Converter%20Ultimate.desktop', 'Xilisoft%20Video%20Converter.desktop']
>>> def normalize_url(self, path, link):
	if link.startswith('http://'):
		return link
	elif link.startswith('/'):
		return self.url + link
	else:
		return self.url + path.rpartition('/')[0] + '/' + link

	
>>> 
