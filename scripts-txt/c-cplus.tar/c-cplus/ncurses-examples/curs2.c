/* curs.c --  */
/* gcc -Wall -O2 curs.c -o main -lncurses */
#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
int main(void)
{
    int ch;
    initscr(); /* start curses mode*/
    raw(); /* line buffering disabled */
    keypad(stdscr, TRUE); /* We get F1, F2 etc...*/
    noecho(); /* Do not echo() while we do getch */

    printw("Type any character to see it in bold\n"); /* printf hello world*/
    ch = getch(); /* if raw() hadn't been called we have
                    to press enter before it gets to the
                    program */

    if (ch == KEY_F(2))            /* Without keypad enabled
                                    this will not get us */
        printw("F2 Key pressed"); /* either. Without noecho()
                                    some ugly escape characters
                                    might have been printed on
                                    screen */
    else
    {
        printw("The pressed key is ");
        attron(A_BOLD);
        printw("%c", ch);
        attroff(A_BOLD);
    }


    refresh(); /* print it on to the real screen */
    getch(); /* wait for user input */
    endwin(); /* end curses mode */

    return EXIT_SUCCESS;
}