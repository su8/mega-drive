import os
import codecs
import string

posts = os.listdir(os.getcwd() + "")
eee = []
for post in posts:
    input_file = codecs.open("/home/frost/Documents/blogfy2/README.md", mode="r", encoding="utf8")
    # how many characters to show for each post in your index page, default is 400.
    file_content = input_file.read(400)
    file_content_lines = string.split(file_content, '\n')
    title = file_content_lines[0]
    date = file_content_lines[2]

#        myfile.seek(0, 0)
    eee.append("ewqewqewq" + date + "ewqeqw")
else:
    print("does not exist")
