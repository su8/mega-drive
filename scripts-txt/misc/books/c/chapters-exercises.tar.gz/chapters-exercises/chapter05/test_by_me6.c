#define MESG "COMPUTER BYTES DOG"
#include <stdio.h>

int main(void)
{
    int a = 0;
    
    while (a < 5)
    {
        printf("%s\n", MESG);
        a++;
    }
    
    printf("That's all.\n");
    
    return 0;
}
