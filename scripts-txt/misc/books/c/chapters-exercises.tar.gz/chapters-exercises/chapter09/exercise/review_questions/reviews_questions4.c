/* reviews_questions1.c --  */
#include <stdio.h>
#include <stdlib.h>

int sum(int x, int z);

int main(void)
{
    int x = 4, z = 6;

    printf("The sum of x and z is %d\n", sum(x,z));

    return EXIT_SUCCESS;
}

int sum(int x, int z)
{
    return x+z;
}