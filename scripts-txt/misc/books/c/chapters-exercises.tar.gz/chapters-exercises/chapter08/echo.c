/* echo.c -- repeat input */
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    char ch;

    while ((ch = getchar()) != '#')
        putchar(ch);

    return EXIT_SUCCESS;
}