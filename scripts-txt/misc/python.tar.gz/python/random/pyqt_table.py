from PyQt4.QtCore import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys

my_array = [['00','01','02','03','04'],
            ['10','11','12','13','14'],
            ['20','21','22','23','24'],
            ['30','31','32','33','34'],
            ['40','41','42','43','44']]

def main():
    app = QApplication(sys.argv)
    w = MyWindow()
    w.show()
    sys.exit(app.exec_())

class MyWindow(QTableView):
    def __init__(self, *args):
        QTableView.__init__(self, *args)

        tablemodel = MyTableModel(my_array, self)
        self.setModel(tablemodel)

class MyTableModel(QAbstractTableModel):
    def __init__(self, datain, parent=None, *args):
        QAbstractTableModel.__init__(self, parent, *args)
        self.arraydata = datain

    def rowCount(self, parent):
        return len(self.arraydata)

    def columnCount(self, parent):
        return len(self.arraydata[0])

    def data(self, index, role):
        if not index.isValid():
            return QVariant()
        # vvvv this is the magic part
        elif role == Qt.BackgroundRole:
            if index.row() % 2 == 0:
                return QBrush(Qt.yellow)
            else:
                return QBrush(Qt.red)
        # ^^^^ this is the magic part
        elif role != Qt.DisplayRole:
            return QVariant()
        return QVariant(self.arraydata[index.row()][index.column()])

if __name__ == "__main__":
    main()