/* reviews_questions1.c --  */
/* 1. What is the difference between an actual argument and a formal parameter? */

/* actual argument is the value passed from the calling function to the called function, e.g dolly(x) transmits the value of variable x to the dolly function */

/* formal parameter is variable with a type declared in the function header/prototype, e.g:  void who_am_i(int var), think of it as function argument */