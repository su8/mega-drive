import urllib2

page = urllib2.urlopen('http://0.arenabg.com')
print page.info()