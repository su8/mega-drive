Contributed by [lasers](https://github.com/lasers), the module can be found [here](https://github.com/lasers/py3status/blob/newmodule-pinkybar/py3status/modules/pinkybar.py)

[It is licensed under the same license as py3status](https://github.com/ultrabug/py3status/blob/master/LICENSE).
