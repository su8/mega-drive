/* fgets1.c -- using fgets() and fputs() */
#include <stdio.h>
#include <stdlib.h>
#define STRLEN 14
int main(void)
{
    char words[STRLEN];

    puts("Enter a string, please.");
    fgets(words, STRLEN, stdin);

    printf("Your string twice (puts(), then fputs()):\n");
    puts(words);
    fputs(words, stdout);
    puts("Enter another string, please.");

    fgets(words, STRLEN, stdin);

    printf("Your string twice (puts(), then fputs()):\n");
    puts(words);
    fputs(words, stdout);

    puts("Done.");

    return EXIT_SUCCESS;
}