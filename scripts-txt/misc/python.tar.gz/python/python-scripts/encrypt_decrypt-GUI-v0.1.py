#!/usr/bin/python
# if used on python 3 , remove the first 2 imports without # and uncomment the # 2 below this message.
# from tkinter import *
# from tkinter.filedialog import askopenfilename
from Tkinter import *
from tkFileDialog import askopenfilename
import shlex
import subprocess
import shutil
import os

def encrypt():
    filename = askopenfilename()
    process = subprocess.Popen(shlex.split('gpg -o encrypted-file.gpg --cipher-algo AES256 --symmetric ' + filename))
    process.communicate()
    if os.path.isfile('encrypted-file.gpg'):
        shutil.move('encrypted-file.gpg', filename)
    else:
        print("")

def decrypt():
    filename = askopenfilename()
    shutil.move(filename, filename + '.gpg')
    process = subprocess.Popen(shlex.split('gpg ' + filename + '.gpg'))
    process.communicate()
    os.remove(filename + '.gpg')

root = Tk()
root.title('Encrypt & Decrypt files easily')
Button(root, text='Encrypt file', command=encrypt).pack(side=LEFT)
Button(root, text='Decrypt file', command=decrypt).pack(side=RIGHT)
root.mainloop()