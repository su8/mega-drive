/* Write a program that converts time in minutes to time in hours
 * and minutes. Use define or const to create a symbolic constat for
 * 60. Use a while loop to allow the user to enter values repeatedly
 * and terminate the loop if a value for the time of 0 or less is
 * entered */
#include <stdio.h>
#define MIN_PER_HOUR 60
int main(void)
{
    int minutes, hour, left;

    printf("Convert minutes to hours and minutes!\n");
    printf("Enter the number of seconds (<=0 to quit):\n");

    while (minutes > 0)
    {
        scanf("%d", &minutes);
        hour = minutes / MIN_PER_HOUR;  // truncate number of hours
        left = minutes % MIN_PER_HOUR; // number of seconds left over

        printf("%d minutes is %d hour, %d minutes.\n",
               minutes, hour, left);
        printf("Enter the next value (<=0 to quit):\n");

    }
    printf("Done!\n");

    return 0;
}

