import sys
import gtk

class MainWindow(gtk.Window):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.set_title("Virtual Machine Monitor")
        self.set_position(gtk.WIN_POS_CENTER)
        self.set_default_size(640, 600)
        self.set_geometry_hints(min_width=640, min_height=600)
        self.set_icon_from_file("/home/frost/Desktop/icon.png")
        self.connect("destroy", self.window_destroy)

        box = gtk.VBox()
        button = gtk.Button("Test Button")
        box.pack_start(button, False)
        self.add(box)

        self.show_all()

    def window_destroy(self,widget):
        self.hide_all()

class TrayIcon(gtk.StatusIcon):
    def __init__(self):
        gtk.StatusIcon.__init__(self)

        # using a stock icon, load your pixmap here
        self.set_from_stock(gtk.STOCK_FIND)
        self.set_tooltip('Tracker Desktop Search')
        self.set_visible(True)

        self.menu = menu = gtk.Menu()

        window_item = gtk.MenuItem("Show Window")
        window_item.connect("activate", self.show_window, "about")
        menu.append(window_item)

        quit_item = gtk.MenuItem("Quit")
        quit_item.connect("activate", self.quit, "file.quit")
        menu.append(quit_item)
        menu.show_all()

        self.connect("activate", self.show_window)
        self.connect('popup-menu', self.icon_clicked)

    def show_window(self, widget, event=None):
        MainWindow()    

    def icon_clicked(self, status, button, time):
        self.menu.popup(None, None, None, button, time)

    def quit(self, widget, event=None):
        sys.exit(0)

if __name__ == "__main__":
    TrayIcon() 
    gtk.main()