pdf2img written in C
=======
<img src="img/preview1.png" alt="" /> <img src="img/preview2.png" alt="" />

This is the C version of pdf2img. C is new language to me and I'm really interested to master it fully like python. 

The program will be decorated by your gtk theme unless you type **--enable-custom-css**.

## Installation

    ./bootstrap && ./configure --prefix=/usr --enable-button-images
    make && sudo make install

Please translate **po/en_GB.po** in other languages. Open up pull request or issue and I'll merge it.

## Requirements

* gcc - compiler
* gtk3 - gui toolkit
* glibc / libc - standard C libs
* gettext - internationalization lib
* intltool - internationalization tools
* autoconf - gnu build system
* pkg-config - will locate the gtk libs
* ghostscript - pdf processing