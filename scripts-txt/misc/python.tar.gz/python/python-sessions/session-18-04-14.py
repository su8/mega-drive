Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class AudioFile:
	def __init__(self, filename):
		if not filename.endswith(self.ext):
			raise Exception('Invalid file format')
		self.filename = filename

		
>>> class MP3File(AudioFile):
	ext = "mp3"
	def play(self):
		print('playing {} as mp3'.format(self.filename))

		
>>> class WavFile(AudioFile):
	ext = "wav"
	def play(self):
		print('playing {} as wav'.format(self.filename))

		
>>> class OggFile(AudioFile):
	ext = "ogg"
	def play(self):
		print('playing {} as ogg'.format(self.filename))

		
>>> ogg = OggFile('myfile.ogg')
>>> ogg.play()
playing myfile.ogg as ogg
>>> mp3 = MP3File('myfile.mp3')
>>> mp3.play()
playing myfile.mp3 as mp3
>>> not_an_mp3 = MP3File('myfile.ogg')
Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    not_an_mp3 = MP3File('myfile.ogg')
  File "<pyshell#5>", line 4, in __init__
    raise Exception('Invalid file format')
Exception: Invalid file format
>>> #rental program
>>> class Property:
	def __init__(self, square_feet=str(), beds=str(), baths=str(), **kwargs):
		super().__init__(**kwargs):
			
SyntaxError: invalid syntax
>>> class Property:
	def __init__(self, square_feet=str(), beds=str(), baths=str(), **kwargs):
		super().__init__(**kwargs)
		self.square_feet = square_feet
		self.num_bedrooms = beds
		self.num_baths = baths
	def display(self):
		print('PROPERY DETAILS')
		print('===============')
		print('square footage: {}'.format(self.square_feet))
		print('bedrooms: {}'.format(self.num_bedrooms))
		print('bathrooms: {}'.format(self.num_baths))
	def prompt_init():
		return dict(square_feet=input('Enter the square feet: '),
			    beds=input("Enter number of bedrooms: "),
			    baths=input('Enter number of baths: '))
	prompt_init = staticmethod(prompt_init)

	
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does"
					
SyntaxError: EOL while scanning string literal
>>> 

>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries)))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies)))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	prompt_init = staticmethod(prompt_init)

	
Traceback (most recent call last):
  File "<pyshell#81>", line 1, in <module>
    class Apartment(Property):
  File "<pyshell#81>", line 32, in Apartment
    prompt_init = staticmethod(prompt_init)
NameError: name 'prompt_init' is not defined
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries)))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies)))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	prompt_init = staticmethod(prompt_init)

	
Traceback (most recent call last):
  File "<pyshell#83>", line 1, in <module>
    class Apartment(Property):
  File "<pyshell#83>", line 32, in Apartment
    prompt_init = staticmethod(prompt_init)
NameError: name 'prompt_init' is not defined
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	prompt_init = staticmethod(prompt_init)
				
SyntaxError: invalid syntax
>>> 
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries)))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies)))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony})
		return parent_initprompt_init = staticmethod(prompt_init)
	
SyntaxError: invalid syntax
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries)))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies)))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	prompt_init = staticmethod(prompt_init)

	
Traceback (most recent call last):
  File "<pyshell#88>", line 1, in <module>
    class Apartment(Property):
  File "<pyshell#88>", line 32, in Apartment
    prompt_init = staticmethod(prompt_init)
NameError: name 'prompt_init' is not defined
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries)))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies)))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	#prompt_init = staticmethod(prompt_init)

	
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries)))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies)))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	prompt_init = staticmethod(parent_init)

	
Traceback (most recent call last):
  File "<pyshell#92>", line 1, in <module>
    class Apartment(Property):
  File "<pyshell#92>", line 32, in Apartment
    prompt_init = staticmethod(parent_init)
NameError: name 'parent_init' is not defined
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
		parent_init = Property.prompt_init()
		laundry = str()
		while laundry.lower() not in\
		      Apartment.valid_laundries:
			laundry = input('What laundry facilities does'
					'the property have ? ({})'.format(
						", ".join(Apartment.valid_laundries)))
		balcony = str()
		while balcony.lower not in \
			Apartment.valid_balconies:
			balcony = input(
				'Does the property have a balcony ?'
				'({})'.format(
					', '.join(Apartment.valid_balconies)))
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	#prompt_init = staticmethod(prompt_init)

	
>>> def get_valid_input(input_string, valid_options):
	input_string += " ({}) ".format(", ".join(valid_options))
	response = input(input_string)
	while response.lower() not in valid_options:
		response = input(input_string)
	return response

>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
	def prompt_init():
		parent_init = Property.prompt_init()
		laundry = get_valid_input(
			'What laundry facilities does'
			' the property have ?',
			Apartment.valid_laundries)
		balcony = get_valid_input(
			'Does the property have a balcony ?",
			
SyntaxError: EOL while scanning string literal
>>> class Apartment(Property):
	valid_laundries = ('coin', 'ensuite', 'none')
	valid_balconies = ('yes', 'no', 'solarium')
	def __init__(self, balcony=str(), laundry=str(), **kwargs):
		super().__init__(**kwargs)
		self.balcony = balcony
		self.laundry = laundry
	def display(self):
		super().display()
		print('APARTMENT DETAILS')
		print('laundry: {}'.format(self.laundry))
		print('has balcony: {}'.format(self.balcony))
	def prompt_init():
		parent_init = Property.prompt_init()
		laundry = get_valid_input(
			'What laundry facilities does'
			' the property have ?',
			Apartment.valid_laundries)
		balcony = get_valid_input(
			'Does the property have a balcony ?',
			Apartment.valid_balconies)
		parent_init.update({
			"laundry": laundry,
			"balcony": balcony
			})
		return parent_init
	prompt_init = staticmethod(prompt_init)

	
>>> class House(Property):
	valid_garage = ('attached', 'detached', 'none')
	valid_fenced = ('yes', 'no')
	def __init__(self, num_stories=str(),
		     garage=str(), fenced=str(), **kwargs):
		super().__init__(**kwargs)
		self.garage = garage
		self.fenced = fenced
		self.num_stories = num_stories
	def display(self):
		super().display()
		print('House details')
		print('# of stories: {}'.format(self.garage))

		

>>> class House(Property):
	valid_garage = ('attached', 'detached', 'none')
	valid_fenced = ('yes', 'no')
	def __init__(self, num_stories=str(),
		     garage=str(), fenced=str(), **kwargs):
		super().__init__(**kwargs)
		self.garage = garage
		self.fenced = fenced
		self.num_stories = num_stories
	def display(self):
		super().display()
		print('House details')
		print('# of stories: {}'.format(self.num_stories))
		print('garage: {}'.format(self.garage))
		print('fenced yard: {}'.format(self.fenced))
	def prompt_init():
		parent_init = Property.prompt_init()
		fenced = get_valid_input('Is the yard fenced ?',
					 House.valid_fenced)
		garage = get_valid_input('Is there a garage ? ',
					 House.valid_garage)
		num_stories = input('How many stories')
		parent_init.update('fenced': fenced,
				   
SyntaxError: invalid syntax
>>> class House(Property):
	valid_garage = ('attached', 'detached', 'none')
	valid_fenced = ('yes', 'no')
	def __init__(self, num_stories=str(),
		     garage=str(), fenced=str(), **kwargs):
		super().__init__(**kwargs)
		self.garage = garage
		self.fenced = fenced
		self.num_stories = num_stories
	def display(self):
		super().display()
		print('House details')
		print('# of stories: {}'.format(self.num_stories))
		print('garage: {}'.format(self.garage))
		print('fenced yard: {}'.format(self.fenced))
	def prompt_init():
		parent_init = Property.prompt_init()
		fenced = get_valid_input('Is the yard fenced ?',
					 House.valid_fenced)
		garage = get_valid_input('Is there a garage ? ',
					 House.valid_garage)
		num_stories = input('How many stories')
		parent_init.update({'fenced': fenced,
				    'garage': garage,
				    'num_stories': num_stories
				    })
		return parent_init
	prompt_init = staticmethod(prompt_init)

	
>>> class Purchase:
	def __init__(self, price=str(), taxes=str(), **kwargs):
		super().__init__(**kwargs)
		self.price = price
		self.taxes = taxes
	def display(self):
		super().display()
		print('PURCHASE DETAILS')
		print('selling price: {}'.format(self.price))
		print('estimated taxes: {}'.format(self.taxes))
	def prompt_init():
		return dict(
			price=input('What is the selling proce ?'),
			taxes=input('What are the estimated taxes ?'))
	prompt_init = staticmethod(prompt_init)

	
>>> class Rental:
	def __init__(self, furnished=str(), utilities=str(),
		     rent=str(), **kwargs):
		super().__init__(**kwargs)
		self.furnished = furnished
		self.rent = rent
		self.utilities = utilities
	def display(self):
		super().display()
		print('Rental details')
		print('rent: {}'.format(self.rent))
		print('estimated utilities: {}'.format(
			self.utilities))
		print('furnished: {}'.format(self.furnished))
	def prompt_init():
		return dict(
			rent=input('What is the monthly rent ?'),
			utilities=input(
				'What are the estimated utilities ?'),
			furnished= get_valid_input(
				'Is the property furnished ?',
				('yes', 'no')))
	prompt_init = staticmethod(prompt_init)

	
>>> class HouseRental(Rental, House):
	def prompt_init():
		init = House.prompt_init()
		init.update(Rental.prompt_init())
		return init
	prompt_init = staticmethod(prompt_init)

	
>>> init = HouseRental.prompt_init()
Enter the square feet: 1
Enter number of bedrooms: 2
Enter number of baths: 
Is the yard fenced ? (yes, no) no
Is there a garage ?  (attached, detached, none) attached
How many stories2
What is the monthly rent ?5
What are the estimated utilities ?6
Is the property furnished ? (yes, no) no
>>> house = HouseRental(**init)
>>> house.display()
PROPERY DETAILS
===============
square footage: 1
bedrooms: 2
bathrooms: 
House details
# of stories: 2
garage: attached
fenced yard: no
Rental details
rent: 5
estimated utilities: 6
furnished: no
>>> 
