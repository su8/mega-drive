#!/usr/bin/env python2
import os
from sys import argv
from subprocess import call

class Backup(object):

    def __init__(self, obj):
        given_obj = (obj if not obj.endswith(os.sep) else obj[:-1])
        ''' Type gpg --keyid-format long --list-keys your@email.null
        and replace the pub key below '''
        pub_key = '148A94F9AA92AE64'

        self.encrypt(given_obj, pub_key)

    def encrypt(self, obj, key):
        if os.path.isfile(obj):
            call('gpg --hidden-recipient {pub_key_id} \
                    --encrypt "{obj_to_encrypt}"'
                        .format(
                            pub_key_id=key, obj_to_encrypt=obj), shell=True)
        else:
            call(
                'XZ_OPT=-9e tar cJf - -C "{dir}" . | \
                    gpg -z 9 --batch --yes --encrypt \
                    --hidden-recipient {pub_key_id}\
                     --output "{encrypted_file}"'
                        .format(dir=obj, pub_key_id=key,
                            encrypted_file=obj + '.tar.xz.gpg'), shell=True)

if __name__ == '__main__':
    Backup(''.join(argv[1:]))