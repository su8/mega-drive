/*
 * module to include the modules
 */

config_require(etherlike-mib/data_access/dot3stats)
config_require(etherlike-mib/dot3StatsTable/dot3StatsTable)
config_require(etherlike-mib/dot3StatsTable/dot3StatsTable_data_get)
config_require(etherlike-mib/dot3StatsTable/dot3StatsTable_data_set)
config_require(etherlike-mib/dot3StatsTable/dot3StatsTable_data_access)
config_require(etherlike-mib/dot3StatsTable/dot3StatsTable_interface)

