/* 4. Use nested loops to produce the following pattern:
A
BC
DEF
GHIJ
KLMNO
PQRSTU
If your system doesn’t encode letters in numeric order, see the suggestion in
programming exercise 3. 
#include <stdio.h>
int main(void)
{
    int CHARS = 6;
    int row;
    char ch;
    char lets[27] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
    for (row = 0; row != CHARS; row++)
    {
        for (ch='A'+row; ch < ('A'+CHARS); ch++)
        {
            printf("%c", ch);
        }
        printf("\n");
    }
    
    return 0;
}
*/
#include <stdio.h>
#define ROW 6
int main(void)
{
    char let = 'A';
    char start;
    char end;
    int row;
    
    for (end = let; end <= 'U'; end++)
    {
        for (start = let; start <= end; start++)
            printf("%c", start);
        printf("\n");
    }
    
    return 0;
}
