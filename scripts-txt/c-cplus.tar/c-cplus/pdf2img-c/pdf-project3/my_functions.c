/*
   my_functions.c
 
   Copyright 12/18/2014 Aaron Caffrey https://github.com/wifiextender
 
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
   MA 02110-1301, USA.
*/

#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "my_constants.h"
#include "my_functions.h"


/*
   external definitions referring 
   to the defining declarations in main.c
*/
extern GtkWidget *window, *spinbutton1, *spinbutton2, *chooser_dialog;
extern GtkWidget *entry, *about_button, *sdev_combo, *warn_dialog;
extern GtkWidget *about_dialog, *image_combo, *reversed_nums, *response;
extern GtkFileFilter *filter_pdf;


/* About dialog */
void on_about_clicked(void)
{

    /*
         The difference between 'gtk_about_dialog_new' and
         'gtk_show_about_dialog' is that in the first case
         you can't map any parent, but in same time it's needed.
    */

    /* about_dialog = gtk_about_dialog_new();
    gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG(about_dialog),ABOUT_PROG_NAME);
    gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(about_dialog),ABOUT_COMMENTS);
    gtk_about_dialog_set_website(GTK_ABOUT_DIALOG(about_dialog),ABOUT_WEBSITE);
    gtk_about_dialog_set_website_label(GTK_ABOUT_DIALOG(about_dialog),ABOUT_WEBSITE_LABEL);
    gtk_about_dialog_set_license_type(GTK_ABOUT_DIALOG(about_dialog),GTK_LICENSE_GPL_3_0);
    gtk_dialog_run(GTK_DIALOG(about_dialog));
    gtk_widget_destroy(about_dialog); */

    gtk_show_about_dialog(GTK_WINDOW(window),
                         "program-name", ABOUT_PROG_NAME,
                         "comments", ABOUT_COMMENTS,
                         "website", ABOUT_WEBSITE,
                         "website-label", ABOUT_WEBSITE_LABEL,
                         "license-type", GTK_LICENSE_GPL_3_0, NULL);
}


/* sdevice combobox changed */
void on_sdevice_combo(void)
{
    char *active = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(sdev_combo));

    if ((0 == strcmp(active,PNG16M)) || (0 == strcmp(active,PNGALPHA)) || (0 == strcmp(active,PNGGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 0);

    if ((0 == strcmp(active,JPEG)) || (0 == strcmp(active,JPEGCMYK)) || (0 == strcmp(active,JPEGGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 1);

    if ((0 == strcmp(active,BMP16M)) || (0 == strcmp(active,BMPGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 2);

    if ((0 == strcmp(active,TIFF24NC)) || (0 == strcmp(active,TIFFGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 3);
}


/* image format combobox changed */
void on_image_combo(void)
{
    char *active = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(image_combo));

    if (0 == strcmp(active,PNG))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 0);

    if (0 == strcmp(active,JPG))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 3);

    if (0 == strcmp(active,BMP))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 6);

    if (0 == strcmp(active,TIFF))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 8);
}


/* File chooser dialog */
void on_button1_clicked(void)
{

    int spin1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
    int spin2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));

    if (spin1 > spin2)
    {
        char warn_str[70];
        sprintf(warn_str, "From page %d To %d = OK\nFrom page %d To %d = Not working", spin2, spin1, spin1, spin2);
        RaiseWarning(REVERSED, warn_str);

    }
    else
    {
        char *filename;
        chooser_dialog = gtk_file_chooser_dialog_new(SELECT_PDF_LBL,
                                                     GTK_WINDOW(window),
                                                     GTK_FILE_CHOOSER_ACTION_OPEN,
                                                     CANCEL_BTN,
                                                     GTK_RESPONSE_CANCEL,
                                                     CONVERT_BTN,
                                                     GTK_RESPONSE_ACCEPT, NULL);
        
        filter_pdf = gtk_file_filter_new();
        gtk_file_filter_set_name(GTK_FILE_FILTER(filter_pdf),PDF_FILTER);
        gtk_file_filter_add_pattern(GTK_FILE_FILTER(filter_pdf),PDF_PATTERN);
        gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(chooser_dialog),GTK_FILE_FILTER(filter_pdf));

        if (gtk_dialog_run(GTK_DIALOG(chooser_dialog)) == GTK_RESPONSE_ACCEPT)
        {
            filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(chooser_dialog));
            pdf_to_img(filename);
        }
        gtk_widget_destroy(chooser_dialog);
    }
}


/* 
   In gtk2 the yellow warning icon is
   displayed but not in gtk3, weird.
*/
void RaiseWarning(char *str_to_warn1, char *str_to_warn2)
{
    warn_dialog = gtk_message_dialog_new(GTK_WINDOW(window),
                                         GTK_DIALOG_MODAL,
                                         GTK_MESSAGE_WARNING,
                                         GTK_BUTTONS_OK, str_to_warn1);
    gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(warn_dialog), str_to_warn2);
    gtk_dialog_run(GTK_DIALOG(warn_dialog));
    gtk_widget_destroy(warn_dialog);
}


/* 
   Remove the '.pdf' extension, 'gs' the formal parameter
   'filename' and rename the converted images to match the 
   'from' and 'to' page range.
*/
void pdf_to_img(char *filename)
{
    char pdfname[400], params[600], ren1[400], ren2[400];
    int spin1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
    int spin2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));
    char *im_combo = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(image_combo));

    int small_range = (spin2 - spin1) + 2;
    int big_range = spin1;
    int x;

    strncpy(pdfname, filename, strlen(filename)-4);
    pdfname[strlen(filename)-4] = '\0';

    sprintf(params, "gs -dBATCH -dNOPAUSE -dFirstPage=%d -dLastPage=%d -sOutputFile=\"%s\"_pAge_%%01d.%s -sDEVICE=%s -r%s \"%s\"",
        spin1, spin2, pdfname, im_combo,
        gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(sdev_combo)),
        gtk_entry_get_text(GTK_ENTRY(entry)), filename);
    system(params);

    for (x = 1; x < small_range; x++, big_range++)
    {
        sprintf(ren1, "%s_pAge_%d.%s", pdfname, x, im_combo);
        sprintf(ren2, "%s_page_%d.%s", pdfname, big_range, im_combo);

        rename(ren1, ren2);
    }
}