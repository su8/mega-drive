class Settings:
    site_name = "blogfy"
    archive_page_name = "Archive"
    site_root = "http://linux.sytes.net/"
    github_account_name = "wifiextender"
    site_description = "A simple static generator"
    footer_text = """<div id="content">This website is powered by <a href="https://github.com/wifiextender/blogfy" target="_blank">blogfy</a> &amp; <a href="https://github.com/" target="_blank">GitHub</a> <br /> Theme by <a href="http://www.luiszuno.com" >luiszuno.com</a> </div>"""
    number_of_posts_on_front_page = 5
    number_of_recent_posts = 12
    website_template = "template1"
    limit_characters_for_posts_in_index_page = 400
    disqus_shortname = "linuxnews"

# Make sure that the website address or the ip ends with forwardlash !
# http://123.456.789.000/ , http://example.com/ , http://google.com/

# If you don't have github account
# make github_account_name = "" so the github sidebar will disappear

# If you created your own disqus page then replace linuxnews
# with your shortname. To find out your shortname go to: http://disqus.com/admin/settings/
# and look for " Site Identity "