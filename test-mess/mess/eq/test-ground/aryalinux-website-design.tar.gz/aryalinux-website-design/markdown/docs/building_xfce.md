
---

This article outlines the process of building the Mate desktop environment on top of the base system created using the first stage of scripts. 

### Chrooting into the base system

It is assumed that if you are going to follow the steps outlined here, you must already have build a system already and you could have booted into it. The system built using the first stage of scripts is a CLI based system. In case you want to create a server-like system, you may not want to install a Desktop Enviornment on it. But if you are a desktop/laptop user and you want to use AryaLinux as your desktop for activities like playing music, browsing and watching videos etc, then you might want to put a GUI skin right on top of the system we just built. This article outlines the process of build-installing the xorg-server and Mate desktop environment which would provide GUI capabilities to the GNU/Linux system we just created.

First of all we need to chroot into the system we have created so that we can build stuff from inside it. So boot using your Builder Disk, connect to the internet using the network icon at the top right corner and execute the following commands: 


```bash
sudo su
cd /root
cd scripts
```

Now choot into the system by entering: 

```bash
./enteral.sh
```

You would be asked to provide the partition name for the base system, the swap and home partition. Provide the partition names like /dev/sda3 or /dev/sda5 or whatever you gave while building initially. This would put you inside the chrooted environment. Now you need to log in as the user that was built towards the end of the previous stage. I created a user called aryalinux so I would be executing the following command(Replace aryalinux with your username): 

```bash
su - aryalinux
```

You should notice the prompt turning green. In case it does, well, we are good to go. 

### Installing some basic packages

One of the objectives of AryaLinux right from the beginning was to provide a way to carry out build-install process in a very simple manner similar to the way apt-get and rpm works. Thus we ended up building alps(AryaLinux Packaging System). More about alps here. Alps got installed while we we building the base-system. First Update alps and the build scripts to fetch any fixes that might have been submitted online: 

```bash
sudo alps updatescripts
sudo alps selfupdate
```

If updatescripts fails, then edit the version in the /etc/lsb-release file and change it to 2016.04. You may do that by entering the following command: 

```bash
sudo sed -i "s@DISTRIB_RELEASE@#DISTRIB_OLD_RELEASE@g" /etc/lsb-release
echo "DISTRIB_RELEASE=2016.04" | sudo tee -a /etc/lsb-release
```

Now lets use alps to install some basic packages:

```bash
alps install profile nano openssl general_which wget cacerts python2 python3 ntfs-3g fuse lvm2 parted gptfdisk shadow
su -c "alps install sudo"
alps install usbutils pciutils openssh gobject-introspection
```

### Building the X server

Installing the X server involves installing a lot of components that make X-Server run. But before we install all of them lets install ccache and configure to use it. This is not a necessary step but greatly reduces the compilation time of llvm that is one the components that we are about to build.
Few things dont play well with ccache. Lets install them first. While installing shared-mime-info as in the command below, alps might fail because shared-mime-info does not play well with make on multiple processors. If that happens simply re-run the command and it should work just as fine. 

```bash
alps install libxml2 desktop-file-utils shared-mime-info
```

Now install and enable ccache: 

```bash
alps install ccache
export CC="ccache gcc"
export CXX="ccache g++"
export CCACHE_CPP2=yes
```

Now lets begin installing the components of x-server. Before proceeding, do the following sed so that the build of xorg-server does not fail due to a missing patch file in the BLFS book. : 

```bash
sudo sed -i "s@patch -Np1@#patch -Np1@g" /var/cache/alps/scripts/xorg-server.sh
alps install xserver-meta
sudo rm /etc/X11/xorg.conf.d/*
```

### Building XFCE deskop environment

Build XFCE desktop environment by executing the following commands: 

```bash
alps install xfce-desktop-environment
```

This would install XFCE on the x server. In case you want to put on the XFCE customizations that we have put on XFCE in our live disk or as seen in the screenshots, you have to execute: 

```bash
alps install aryalinux-themes aryalinux-icons aryalinux-wallpapers aryalinux-fonts aryalinux-xfce-customizations
```

This would essentially put the following things in place: 


* Vivacious and Vibrancy Icons by Ravenfinity

* Ambiance and Radiance GTK themes by Ravenfinity

* Few selected Google fonts

* The aryalinux branded wallpaper

* All of the above applied to the current user

If you want to enable bluetooth support install blueman which in turn installs bluez and a host of other things: 


```bash
alps install blueman
```

The XFCE desktop that gets installed above is very basic with very few applications. In case you want audio-video codecs: 

```bash
alps install audio-video-plugins
```

For Printing and scanning support install: 

```bash
alps install cups cups-filters sane simple-scan
```

Other applications that can be installed at this stage are: firefox-bin, thunderbird-bin, pidgin, transmission, xchat, gimp, epdfview, libreoffice, simple-screen-recorder, vlc, audacious 
