Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> 'not installed'[4:11]
'install'
>>> # 12.10 defining an actor task
>>> from queue import Queue
>>> from threading import Thread, Event
>>> class ActorExit(Exception):
	pass

>>> class Actor:
	def __init__(self):
		self._mailbox = Queue()
	def send(self, msg):
		'''
send a message to the actor'''
		self._mailbox.put(msg)
	def recv(self):
		'''
receive an incoming message'''
		msg = self._mailbox.get()
		if msg is ActorExit:
			raise ActorExit()
		return msg
	def close(self):
		'''
close the actor, thus shutting it down'''
		self.send(ActorExit)
	def start(self):
		'''start concurrent execution'''
		self._terminated = Event()
		t = thread(target=self._bootstrap)
		t.daemon = True
		t.start()
	def _bootstrap(self):
		try:
			self.run()
		except ActorExit:
			pass
		finally:
			self._terminated.set()
	def join(self):
		self._terminated.wait()
	def run(self):
		'''run method to be implemented by the user'''
		while True:
			msg = self.recv()

>>> # sample ActorTask
>>> class PrintActor(Actor):
	def run(self):
		while True:
			msg = self.recv()
			print('Got:', msg)

			
>>> p = PrintActor()
>>> p.start()
Traceback (most recent call last):
  File "<pyshell#53>", line 1, in <module>
    p.start()
  File "<pyshell#44>", line 22, in start
    t = thread(target=self._bootstrap)
NameError: global name 'thread' is not defined
>>> class Actor:
	def __init__(self):
		self._mailbox = Queue()
	def send(self, msg):
		'''
send a message to the actor'''
		self._mailbox.put(msg)
	def recv(self):
		'''
receive an incoming message'''
		msg = self._mailbox.get()
		if msg is ActorExit:
			raise ActorExit()
		return msg
	def close(self):
		'''
close the actor, thus shutting it down'''
		self.send(ActorExit)
	def start(self):
		'''start concurrent execution'''
		self._terminated = Event()
		t = Thread(target=self._bootstrap)
		t.daemon = True
		t.start()
	def _bootstrap(self):
		try:
			self.run()
		except ActorExit:
			pass
		finally:
			self._terminated.set()
	def join(self):
		self._terminated.wait()
	def run(self):
		'''run method to be implemented by the user'''
		while True:
			msg = self.recv()

			
>>> class PrintActor(Actor):
	def run(self):
		while True:
			msg = self.recv()
			print('Got:', msg)

			
>>> p = PrintActor()
>>> p.start()
>>> p.send('hello')
Got:
>>>  hello
p.send('World')
Got:
>>>  World
p.close()
>>> p.join()
>>> class TaggedActor(Actor):
	def run(self):
		while True:
			tag, *payload = self.recv()
			getattr(self, 'do_'+tag)(*payload)
	# method corresponding to different message tags
	def do_A(self, x):
		print("Running A", x)
	def do_B(self, x, y):
		print("Running B", x, y)

		
>>> a = TaggedActor()
>>> a.start()
>>> a.send(('A', 1))
Running A
>>>  1
a.send(('B', '2', '3'))
Running B
>>>  2 3
a.close()
>>> from threading import Event
>>> class Result:
	def __init__(self):
		self._evt = Event()
		self._result = None
	def set_result(self, value):
		self._result = value
		self._evt.set()
	def result(self):
		self._evt.wait()
		return self._result

	
>>> class Worker(Actor):
	def subtim(self, func, *args, **kwargs):
		r = Result()
		self.send((func, args, kwargs, r))
		return r
	def run(self):
		while True:
			func, args, kwargs, r = self.recv()
			r.set_result(func(*args, **kwargs))

			
>>> worker = Worker()
>>> worker.start()
>>> r = worker.submit(pow, 2, 3)
Traceback (most recent call last):
  File "<pyshell#104>", line 1, in <module>
    r = worker.submit(pow, 2, 3)
AttributeError: 'Worker' object has no attribute 'submit'
>>> r = worker.subtim(pow, 2, 3)
>>> print(r.result())
8
>>> 
