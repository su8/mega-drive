Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> from functools import wraps, partial
>>> import logging
>>> def attach_wrapper(obj, func=None):
	if func is None:
		return partial(attach_wrapper, obj)
	setattr(obj, func.__name__, func)
	return func

>>> def logged(level, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name.
'''
	def decorate(func):
		logname = name if name else func.__module__
		log = logging.getLoger(logname)
		logmsg = message if message else func.__name___
		@wraps(func)
		def wrapper(*args, **kwargs):
			log.log(level, logmsg)
			return func(*args, **kwargs)
		@attach_wrapper(wrapper)
		def set_level(newlevel):
			nonlocal level
			level = newlevel
		@attach_wrapper(wrapper)
		def set_message(newmsg):
			nonlocal logmsg
			logmsg = newmsg
		return wrapper
	return decorate

>>> @logged(logging.DEBUG)
def add(x, y):
	return x + y

Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    @logged(logging.DEBUG)
  File "<pyshell#34>", line 11, in decorate
    log = logging.getLoger(logname)
AttributeError: 'module' object has no attribute 'getLoger'
>>> def logged(level, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name.
'''
	def decorate(func):
		logname = name if name else func.__module__
		log = logging.getLogger(logname)
		logmsg = message if message else func.__name___
		@wraps(func)
		def wrapper(*args, **kwargs):
			log.log(level, logmsg)
			return func(*args, **kwargs)
		@attach_wrapper(wrapper)
		def set_level(newlevel):
			nonlocal level
			level = newlevel
		@attach_wrapper(wrapper)
		def set_message(newmsg):
			nonlocal logmsg
			logmsg = newmsg
		return wrapper
	return decorate

>>> @logged(logging.DEBUG)
def add(x, y):
	return x + y

Traceback (most recent call last):
  File "<pyshell#42>", line 1, in <module>
    @logged(logging.DEBUG)
  File "<pyshell#40>", line 12, in decorate
    logmsg = message if message else func.__name___
AttributeError: 'function' object has no attribute '__name___'
>>> def logged(level, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name.
'''
	def decorate(func):
		logname = name if name else func.__module__
		log = logging.getLogger(logname)
		logmsg = message if message else func.__name__
		@wraps(func)
		def wrapper(*args, **kwargs):
			log.log(level, logmsg)
			return func(*args, **kwargs)
		@attach_wrapper(wrapper)
		def set_level(newlevel):
			nonlocal level
			level = newlevel
		@attach_wrapper(wrapper)
		def set_message(newmsg):
			nonlocal logmsg
			logmsg = newmsg
		return wrapper
	return decorate

>>> @logged(logging.DEBUG)
def add(x, y):
	return x + y

>>> @logged(logging.CRITICAL, 'example')
def spam():
	print('SPAM BABY!')

	
>>> spam()
spam
SPAM BABY!
>>> logging.basicConfing(level=logging.DEBUG)
Traceback (most recent call last):
  File "<pyshell#52>", line 1, in <module>
    logging.basicConfing(level=logging.DEBUG)
AttributeError: 'module' object has no attribute 'basicConfing'
>>> import logging
>>> logging.basicConfing(level=logging.DEBUG)
Traceback (most recent call last):
  File "<pyshell#54>", line 1, in <module>
    logging.basicConfing(level=logging.DEBUG)
AttributeError: 'module' object has no attribute 'basicConfing'
>>> logging.basicConfig(level=logging.DEBUG)
>>> add(2, 3)
DEBUG:__main__:add
5
>>> add.set_message('Add called')
>>> add(2, 3)
DEBUG:__main__:Add called
5
>>> def logged(level, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name.
'''
	def decorate(func=None, *, level=logging.DEBUG, name=None, message=None):
		if func is None:
			return partial(logged, level=logging.DEBUG, name=None, message=None)
		logname = name if name else func.__module__
		log = logging.getLogger(logname)
		logmsg = message if message else func.__name__
		@wraps(func)
		def wrapper(*args, **kwargs):
			log.log(level, logmsg)
			return func(*args, **kwargs)
		return wrapper
	return decorate

>>> @logged
def add(x, y):
	return x + y

>>> add(2, 3)
Traceback (most recent call last):
  File "<pyshell#65>", line 1, in <module>
    add(2, 3)
TypeError: decorate() takes from 0 to 1 positional arguments but 2 were given
>>> def logged(level, name=None, message=Nonefunc=None, *, level=logging.DEBUG, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name. If no arguments are supplied
it uses the defauls - DEBUG
'''
	if func is None:
		return partial(logged, level=logging.DEBUG, name=None, message=None)
	logname = name if name else func.__module__
	log = logging.getLogger(logname)
	logmsg = message if message else func.__name__		@wraps(func)
	def wrapper(*args, **kwargs):
		log.log(level, logmsg)
			return func(*args, **kwargs)
	return wrapper
return decorate
SyntaxError: invalid syntax
>>> def logged(level, name=None, message=Nonefunc=None, *, level=logging.DEBUG, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name. If no arguments are supplied
it uses the defauls - DEBUG
'''
	if func is None:
		return partial(logged, level=logging.DEBUG, name=None, message=None)
	logname = name if name else func.__module__
	log = logging.getLogger(logname)
	logmsg = message if message else func.__name__		@wraps(func)
	def wrapper(*args, **kwargs):
		log.log(level, logmsg)
			return func(*args, **kwargs)
	return wrapper
SyntaxError: invalid syntax
>>> 
>>> def logged(level, name=None, message=Nonefunc=None, *, level=logging.DEBUG, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name. If no arguments are supplied
it uses the defauls - DEBUG
'''
	if func is None:
		return partial(logged, level=logging.DEBUG, name=None, message=None)
	logname = name if name else func.__module__
	log = logging.getLogger(logname)
	logmsg = message if message else func.__name__
	@wraps(func)
	def wrapper(*args, **kwargs):
		log.log(level, logmsg)
			return func(*args, **kwargs)
	return wrapper
SyntaxError: invalid syntax
>>> def logged(func=None, *, level=logging.DEBUG, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name. If no arguments are supplied
it uses the defauls - DEBUG
'''
	if func is None:
		return partial(logged, level=logging.DEBUG, name=None, message=None)
	logname = name if name else func.__module__
	log = logging.getLogger(logname)
	logmsg = message if message else func.__name__
	@wraps(func)
	def wrapper(*args, **kwargs):
		log.log(level, logmsg)
			return func(*args, **kwargs)
	return wrapper
SyntaxError: unexpected indent
>>> def logged(func=None, *, level=logging.DEBUG, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name. If no arguments are supplied
it uses the defauls - DEBUG
'''
	if func is None:
		return partial(logged, level=logging.DEBUG, name=None, message=None)
	logname = name if name else func.__module__
	log = logging.getLogger(logname)
	logmsg = message if message else func.__name__
	@wraps(func)
	def wrapper(*args, **kwargs):
		log.log(level, logmsg)
		return func(*args, **kwargs)
	return wrapper

>>> @logged
def add(x, y):
	return x + y

>>> add(2,3)
DEBUG:__main__:add
5
>>> @logged(level=logging.CRITICAl, name='example')
def spam():
	print('SPAMMMMM!')

	
Traceback (most recent call last):
  File "<pyshell#81>", line 1, in <module>
    @logged(level=logging.CRITICAl, name='example')
AttributeError: 'module' object has no attribute 'CRITICAl'
>>> @logged(level=logging.CRITICAL, name='example')
def spam():
	print('SPAMMMMM!')

	
>>> spam()
DEBUG:__main__:spam
SPAMMMMM!
>>> # forgot to set the 'level=level' !!!!!11
>>> def logged(func=None, *, level=logging.DEBUG, name=None, message=None):
	'''
Add logging to a function. level is the logging
level, name is the logger name, and the message
is the log message. If name and message aren't
specified, they default to the function's
module and name. If no arguments are supplied
it uses the defauls - DEBUG
'''
	if func is None:
		return partial(logged, level=level, name=None, message=None)
	logname = name if name else func.__module__
	log = logging.getLogger(logname)
	logmsg = message if message else func.__name__
	@wraps(func)
	def wrapper(*args, **kwargs):
		log.log(level, logmsg)
		return func(*args, **kwargs)
	return wrapper

>>> @logged(level=logging.CRITICAL, name='example')
def spam():
	print('SPAMMMMM!')

	
>>> spam()
CRITICAL:__main__:spam
SPAMMMMM!
>>> @logged(level=logging.WARNING, name='example')
def spam():
	print('SPAMMMMM!')

	
>>> spam()
WARNING:__main__:spam
SPAMMMMM!
>>> 
