#include "params.h"

struct params bps = {
                      VERSION,
                      "EMp7Ca7-fpOBIr\0\0",
                      "LINUX",
                      "01234567890123456789",
                      "WfClq6HxbSaOuJGaH5kWXr7dQgjYNSNg",
                      "6uo_E0S4w_FD0j9NEhW2UpFw9rwy90LY",
                      "ANgs9oGFnEL_vxTxe9eIyBx5lZxfd6QZ"
                    };
