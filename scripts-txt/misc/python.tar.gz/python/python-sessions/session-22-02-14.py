Python 3.3.3 (default, Nov 26 2013, 13:33:18) 
[GCC 4.8.2] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class LoggedMappingMixin:
	'''
add logging to get/set/delete operations for debugging.
'''
	__slots__ = ()
	def __getitem__(self, key):
		print('Getting ' + str(key))
		return super().__getitem__(key)
	def __setitem__(self, key, value):
		print('Setting {} = {!r}'.format(key, value))
		return super().__setitem__(key, value)
	def __delitem__(self, key):
		print('Deleting ' + str(key))
		return super().__delitem__(key)

	
>>> class SetOnceMappingMixin:
	''' Only allow a key to be set once '''
	__slots__ = ()
	def __setitem__(self, key, value):
		if key in self:
			raise KeyError(str(key) + ' already set')
		return super().__setitem__(key, value)

	
>>> class StringKeysMappingMixin:
	# Restrict keys to strings only
	__slots__ = ()
	def __setitem__(self, key, value):
		if not isinstance(key, str):
			raise TypeError('keys must be strings')
		return super().__setitem__(key, value)

	
>>> class LoggedDict(LoggedMappingMixin, dict):
	pass

>>> d = LoggedDict()
>>> d['z'] = 24
Setting z = 24
>>> d['z']
Getting z
24
>>> del d['z']
Deleting z
>>> from collections import defaultdict
>>> class SetOnceDefaultDict(SetOnceMappingMixin, defaultdict):
	pass

>>> d = SetOnceDefaultDict(list)
>>> d['z'].append(2)
>>> d['x'].append(2)
>>> d['z'].append(10)
>>> d['x'] = 2
Traceback (most recent call last):
  File "<pyshell#19>", line 1, in <module>
    d['x'] = 2
  File "<pyshell#3>", line 6, in __setitem__
    raise KeyError(str(key) + ' already set')
KeyError: 'x already set'
>>> d['a'] = 2
>>> from collections import OrderedDict
>>> class StringOrderedDict(StringKeysMappingMixin,
			SetOnceMappingMixin,
			OrderedDict):
	pass

>>> d = StringOrderedDict()
>>> d['x'] = 23
>>> d[42] = 10
Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    d[42] = 10
  File "<pyshell#5>", line 6, in __setitem__
    raise TypeError('keys must be strings')
TypeError: keys must be strings
>>> d['x'] = 42
Traceback (most recent call last):
  File "<pyshell#27>", line 1, in <module>
    d['x'] = 42
  File "<pyshell#5>", line 7, in __setitem__
    return super().__setitem__(key, value)
  File "<pyshell#3>", line 6, in __setitem__
    raise KeyError(str(key) + ' already set')
KeyError: 'x already set'
>>> class Connection:
	def __init__(self):
		self.new_state(ClosedConnection)
	def new_state(self, newstate):
		self.__class__ = newstate
	def read(self):
		raise NotImplementedError()
	def write(self, data):
		raise NotImplementedError()
	def open(self):
		raise NotImplementedError()
	def close(self):
		raise NotImplementedError()

	
>>> class ClosedConnection(Connection):
	def read(self):
		raise RuntimeError('Not open')
	def write(self, data):
		raise RuntimeError('Not open')
	def open(self):
		self.new_state(OpenConnection)
	def close(self):
		raise RuntimeError('Already closed')

	
>>> class OpenConnection(Connection):
	def read(self):
		print("reading")
	def write(self, data):
		print('writing', data)
	def open(self):
		raise RuntimeError('Already open')
	def close(self):
		self.new_state(ClosedConnection)

		
>>> c = Connection()
>>> c
<__main__.ClosedConnection object at 0x7fb29c0caf10>
>>> c.read()
Traceback (most recent call last):
  File "<pyshell#64>", line 1, in <module>
    c.read()
  File "<pyshell#51>", line 3, in read
    raise RuntimeError('Not open')
RuntimeError: Not open
>>> c.open()
>>> c.read()
reading
>>> c
<__main__.OpenConnection object at 0x7fb29c0caf10>
>>> c.write("eqweq")
writing eqweq
>>> c.close()
>>> c
<__main__.ClosedConnection object at 0x7fb29c0caf10>
>>> c.read()
Traceback (most recent call last):
  File "<pyshell#72>", line 1, in <module>
    c.read()
  File "<pyshell#51>", line 3, in read
    raise RuntimeError('Not open')
RuntimeError: Not open
>>> c.open()
>>> c.close()
>>> c.write('ewqeq')
Traceback (most recent call last):
  File "<pyshell#75>", line 1, in <module>
    c.write('ewqeq')
  File "<pyshell#51>", line 5, in write
    raise RuntimeError('Not open')
RuntimeError: Not open
>>> c.close()
Traceback (most recent call last):
  File "<pyshell#76>", line 1, in <module>
    c.close()
  File "<pyshell#51>", line 9, in close
    raise RuntimeError('Already closed')
RuntimeError: Already closed
>>> c.open()
>>> c.open()
Traceback (most recent call last):
  File "<pyshell#78>", line 1, in <module>
    c.open()
  File "<pyshell#61>", line 7, in open
    raise RuntimeError('Already open')
RuntimeError: Already open
>>> with open('eq.txt', 'wt') as f:
	f.write('qewewqewq')
	f.write('eqwewqewqaa')
	f.write('13231qewewqew!#!#!')
	f.write('1323123qweqEQWEVQEVWQ')

	
9
11
18
21
>>> def az():
	with open('eq.txt', 'rt') as f:
		return f.read()

	
>>> az()
'qewewqewqeqwewqewqaa13231qewewqew!#!#!1323123qweqEQWEVQEVWQ'
>>> 
