Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class Contact:
	all_contacts = list()
	def __init__(self, name, email):
		self.name = name
		self.email = email
		Contact.all_contacts.append(self)

		
>>> #Contact('John Doe', '555-444-333-222')
>>> class Supplier(Contact):
	def order(self, order):
		print('if there was a real system we would send {} order to {}'.format(order, self.name))

		
>>> c = Contact('Sombe Body', 'somebody@example.net')
>>> s = Supplier('Sup Plier', 'supplier@example.net')
>>> print(c.name, c.email, s.name, s.email)
Sombe Body somebody@example.net Sup Plier supplier@example.net
>>> s.order('I need pliers')
if there was a real system we would send I need pliers order to Sup Plier
>>> class ContactList(list):
	def search(self, name):
		'''return all contacts that contain the search vale in their name'''
		matching_contacts = list()
		for contact in self:
			if name in contact.name:
				matching_contacts.append(contact)
		return matching_contacts

	
>>> class Contact:
	all_contacts = ContactList()
	def __init__(self, name, email):
		self.name = name
		self.email = email
		self.all_contacts.append(self)

		
>>> c1 = Contact('John A', 'johna@example.net')
>>> c2 = Contact('John B', 'johnb@example.net')
>>> c3 = Contact('John C', 'jennac@example.net')
>>> [c.name for c in Contact.all_contacts.search('John')]
['John A', 'John B', 'John C']
>>> class LongNameDict(dict):
	def longest_key(self):
		longest = None
		for key in self:
			if not longest or len(key) > len(longest):
				longest = key
		return longest

	
>>> longkeys = LongNameDict()
>>> longkeys['hello'] = 1
>>> longkeys['longest yet'] = 4
>>> longkeys['hello2'] = 'world'
>>> longkeys.longest_key()
'longest yet'
>>> 
