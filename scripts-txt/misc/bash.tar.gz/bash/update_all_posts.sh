#!/bin/bash
cd /home/frost/blog/
python2 build.py
