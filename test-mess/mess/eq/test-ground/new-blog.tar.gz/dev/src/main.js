(function(w) {
    'use strict';
    var metaLen = Object.keys(metaPool).length;
    var blog = {
        reverse: metaLen,
        reverseNum: metaLen,
        shortMeta: [],
        categories: [],
        cats_clean: [],
        cats_num: 0,
        start: '',
        end: '',
        cats: ''
    };

    // "Mustache" templates
    blog.entriesTemplate = [
        "{% for (var x=0; x < 10; x++) { %}",
            "<h4 class='entry-title'>",
                "<a href='{%=o[x][0]%}' class='snippet-title text-muted'>",
                    "{%=blog.trimTitle(o[x][1])%}",
                "</a>",
            "</h4>",
            "<hr>",
        "{% } %}"
    ];
    blog.archiveTemplate = [
        "{% for (var x=0; x < blog.reverse; x++) { %}",
            "<div class='page-header'>",
                "<h4 class='post-title'>",
                    "<a href='{%=o[x][0]%}' class='post-title-url text-muted'>",
                        "{%=blog.trimTitle(o[x][1])%}",
                    "</a>",
                "</h4>",
                "<p class='meta text-muted'>",
                    "<span class='archive-post-separator'> » </span>",
                    "<span class='post-date label label-default'>",
                        "{%=o[x][2]%}",
                    "</span>",
                "</p>",
            "</div>",
        "{% } %}"
    ];
    blog.recentPostsTemplate = [
        "{% for (var x=0; x < 6; x++) { %}",
            "<div>",
                "<a href='{%=o[x][0]%}' class='list-group-item'>",
                    "{%=o[x][1]%}",
                "</a>",
            "</div>",
        "{% } %}"
    ];
    blog.categoriesTemplate = [
        "{% for (var x=0; x < o.length; x++) { %}",
            "<div>",
                "<a href='{%=o[x]%}' class='list-group-item'>",
                    "{%=blog.capFirst(o[x])%}",
                    "<span class='badge'>",
                        "{%=blog.categoriesMatchNum(o[x])%}",
                    "</span>",
                "</a>",
            "</div>",
        "{% } %}"
    ];

    blog.trimTitle = function(text) {
        return text.length > 35 ? text.slice(0, 35) + '...' : text;
    };
    blog.capFirst = function(text) {
        return text.charAt(0).toUpperCase() +
            text.slice(1).toLowerCase();
    };
    blog.categoriesMatchNum = function(category) {
        var x,
            tagged_entries = [];

        for (x in metaPool) {
            if (metaPool[x][3].toLowerCase()
                    .indexOf(category) !== - 1) {
                tagged_entries.push(metaPool[x][3]);
            }
        }
        return tagged_entries.length;
    };
    var innerData = function(partialTemplate, data, id) {
        var template = [
            "<div>",
                partialTemplate.join(''),
            "</div>"
        ].join('');
        document.getElementById(id).innerHTML =
            tmpl(template, data);
    };
    var generateEntriesMeta = function(isIndexPage) {
        blog.start = blog.reverse;
        blog.end = blog.start - 10;
        while (isIndexPage ?
                (blog.start-- > blog.end) :
                (blog.start--)) {
            blog.shortMeta.push(metaPool[blog.start]);
        }
    };

    while (blog.reverseNum--) {
        // categories
        blog.cats = metaPool[blog.reverseNum][3];
        blog.cats_clean = blog.cats.toLowerCase()
            .replace(' ', '').split(',');
        blog.cats_num = blog.cats_clean.length;

        if (blog.cats && blog.cats !== '') {
            while (blog.cats_num--) {
                if (blog.categories.indexOf(
                            blog.cats_clean[blog.cats_num]) === - 1) {
                    blog.categories.push(
                            blog.cats_clean[blog.cats_num]);
                }
            }
        }
    }

    var currentPage = document.location.href.split('/')[3];
    w.blog = blog;

    if (currentPage === '' || currentPage === 'index.html') {
        generateEntriesMeta(true);
        innerData(blog.entriesTemplate, blog.shortMeta, 'entries-wrapper');

    } else if (currentPage === 'archive.html') {
        blog.reverseNum = blog.reverse;
        generateEntriesMeta(false);
        innerData(blog.archiveTemplate, blog.shortMeta, 'entries-wrapper');
    }

    // Recent Posts and Categories Sidebars
    innerData(blog.recentPostsTemplate, blog.shortMeta, 'recent-posts');
    innerData(blog.categoriesTemplate, blog.categories.sort(), 'tags-div');


    // global_stuff.js will be added below this line by `sed'

} (window));
