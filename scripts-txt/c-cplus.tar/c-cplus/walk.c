#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>

#define DEBUG 1

void walkDir(char *basedir);
int isDir(const char *file_path);

void walkDir(char *basedir)
{
    DIR *dir;
    /* char b[512]; */
    struct dirent *ent;

    dir = opendir(basedir);
    printf("\"%s\"\n", basedir);

    if (dir != NULL)
    {
        printf("\n\tWalking \"%s\"\n", basedir);
        while ((ent = readdir(dir)) != NULL)
        {
            /* do not allow "." or ".." */
            if (0 == strcmp(ent->d_name, ".") || 0 == strcmp(ent->d_name, ".."))
            {
                continue;
            }
            char entpath[] = "";
            strcat(entpath, basedir);
            /*strcat(entpath, "\\");*/
            strcat(entpath, "\\");
            strcat(entpath, ent->d_name);

            if (isDir(entpath)) /* directory */
            {
                printf("\n\tDIR: %s\n", ent->d_name);
                /* directory, walk it */
                walkDir(entpath);
            }
            else /* file */
            {
                printf("\n\tFILE: %s\n", ent->d_name);
            }
        }
        closedir(dir);
    }
    else
    {
        fprintf(stderr, "\nFailed to walk directory \"%s\"\n", basedir);
        if (DEBUG)
        {
            perror("opendir()");
        }
    }
}

int isDir(const char *file_path)
{
    struct stat s;
    stat(file_path, &s);
    return S_ISDIR(s.st_mode);
}

int main(int argc, char *argv[])
{
    printf("\nStarting walk...\n");

    //walkDir(argv[1]);
    walkDir("sxiv-master");

    printf("\nDone.\n");

    return EXIT_SUCCESS;
}