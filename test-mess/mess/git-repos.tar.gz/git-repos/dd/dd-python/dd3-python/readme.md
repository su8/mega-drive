Generate tables first, from 2004 to 2100 and then run dd.py with the ssid or it's gui version
<img src="img/4.png" alt="" /><img src="img/5.png" alt="" />