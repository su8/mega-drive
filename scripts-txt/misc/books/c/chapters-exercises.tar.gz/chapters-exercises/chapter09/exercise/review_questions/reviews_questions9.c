/*

9. Given the following output:
Please choose one of the following:
1) copy files            2) move files
3) remove files          4) quit
Enter the number of your choice:
a. Write a function that displays a menu of four numbered choices and asks you to
choose one. (The output should look like the preceding.)
b. Write a function that has two int arguments: a lower limit and an upper limit.
The function should read an integer from input. If the integer is outside the limits,
the function should print a menu again (using the function from part “a” of this
question) to reprompt the user and then get a new value. When an integer in
the proper limits is entered, the function should return that value to the calling
function. Entering a noninteger should cause the function to return the quit value
of 4 .
c. Write a minimal program using the functions from parts “a” and “b” of this
question. By minimal , we mean it need not actually perform the actions promised
by the menu; it should just show the choices and get a valid response.

*/
#include <stdio.h>
#include <stdlib.h>

void show_menu(void);
int read_choice(int lower, int upper);

int main(void)
{
    int status;
    show_menu();
    while ((status = read_choice(1, 4)) != 4)
    {
        show_menu();
        switch(status)
        {
            case 1:
                printf("1 selected\n");
                break;
            case 2:
                printf("2 selected\n");
                break;
            case 3:
                printf("3 selected\n");
                break;
            default:
                printf("Please choose option in range of 1-4.\n");
                break;
        }
    }
    printf("Have a nice day.\n");

    return EXIT_SUCCESS;
}

void show_menu(void)
{

    char menu[] = 
    "Please choose one of the following:\n"
    "1) copy files            2) move files\n"
    "3) remove files          4) quit\n"
    "Enter the number of your choice: ";

    printf("%s", menu);
}

int read_choice(int lower, int upper)
{
    int choice, status;

    while ((status = scanf("%d", &choice)) != 1 || (choice < lower || choice > upper))
    {
        if (status != 1)
            scanf("%*s");
        printf("System failure, abandon the ship\n");
    }

    return choice;
}