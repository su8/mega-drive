import os
from subprocess import call
from datetime import datetime

class Mega(object):
    def __init__(self):
        current = datetime.now()

        os.chdir(os.getenv('HOME') + os.sep + 'Documents')

        call('XZ_OPT=-9e tar -cJf mega-drive-{day}-{month}-{year}.tar.xz \
            mega-drive -g mega-drive-increment'
            .format(day=current.day,
                month=current.month, year=current.year), shell=True)
        # tar xvf archive.tar.xz
        # tar xvf archive-1.tar.xz

if __name__ == '__main__':
    Mega()