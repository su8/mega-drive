pdf2img written in C
=======
<img src="preview.png" alt="" />

This is the C version of pdf2img. C is new language to me and I'm really interested to master it fully like python. 

The program will be decorated by your gtk theme, there isn't any predefined background colour or css theming involved. My gtk theme is called **OMG** and you can find it in deviantart.

In python I can easily write object oriented and procedural oriented programs, to be platform/(python) independent and to squeeze every single horse power of the language.

I don't have internet at home and all of my knowledge in C comes from 4 books. When I stuck there isn't anyone who can help me, so I rely mainly on 'man' pages and 'info' documents like libc, gcc. I really like C despite all difficulties so I won't give up.

## Installation

    make && sudo make install

## Requirements

* gtk3
* gcc
* gcc-libs