(function(w) {
    'use strict';
    var metaLen = Object.keys(metaPool).length;
    var blog = {
        reverse: metaLen,
        reverseNum: metaLen,
        shortMeta: [],
        categories: [],
        cats_clean: [],
        cats_meta: [],
        cats_num: 0,
        start: 0,
        end: 0,
        cats: ''
    };

    // "Mustache" templates
    blog.entriesTemplate = [
        "{% for (var x=0; x < 10; x++) { %}",
            "<h4 class='entry-title'>",
                "<a href='#!post={%=o[x][0].replace('.md', '')%}' class='snippet-title text-muted'>",
                    "{%=blog.trimTitle(o[x][1])%}",
                "</a>",
            "</h4>",
            "<hr>",
        "{% } %}"
    ].join('');
    blog.archiveTemplate = function(isArchivePage) {
        var template = [
            "{% for (var x=0; x < " + (isArchivePage ?
                "blog.reverse" : "o.length") + "; x++) { %}",
                "<div class='page-header'>",
                    "<h4 class='post-title'>",
                        "<a href='#!post={%=o[x][0].replace('.md', '')%}' class='post-title-url text-muted'>",
                            "{%=blog.trimTitle(o[x][1])%}",
                        "</a>",
                    "</h4>",
                    "<p class='meta text-muted'>",
                        "<span class='archive-post-separator'> » </span>",
                        "<span class='post-date label label-default'>",
                            "{%=o[x][2]%}",
                        "</span>",
                    "</p>",
                "</div>",
            "{% } %}"
        ].join('');
        return template;
    };
    blog.recentPostsTemplate = [
        "{% for (var x=0; x < 6; x++) { %}",
            "<div>",
                "<a href='#!post={%=o[x][0].replace('.md','')%}' class='list-group-item'>",
                    "{%=o[x][1]%}",
                "</a>",
            "</div>",
        "{% } %}"
    ].join('');
    blog.categoriesTemplate = [
        "{% for (var x=0; x < o.length; x++) { %}",
            "<div>",
                "<a href='#!category={%=o[x]%}' class='list-group-item'>",
                    "{%=blog.capFirst(o[x])%}",
                    "<span class='badge'>",
                        "{%=blog.categoriesMatchNum(o[x])%}",
                    "</span>",
                "</a>",
            "</div>",
        "{% } %}"
    ].join('');

    blog.trimTitle = function(text) {
        return text.length > 35 ? text.slice(0, 35) + '...' : text;
    };
    blog.capFirst = function(text) {
        return text.charAt(0).toUpperCase() +
            text.slice(1).toLowerCase();
    };
    blog.categoriesMatchNum = function(category) {
        var x,
            tagged_entries = [];

        for (x in metaPool) {
            if (metaPool[x][3].toLowerCase()
                    .indexOf(category) !== - 1) {
                tagged_entries.push(metaPool[x][3]);
                blog.cats_meta.push(metaPool[x]);
            }
        }
        return tagged_entries.length;
    };
    var innerData = function(partialTemplate, data, id) {
        var container = document.querySelector('#' + id);
        while (container.firstChild) {
            container.removeChild(container.firstChild);
        }
        var template = document.createElement('div');
        template.innerHTML = tmpl(partialTemplate, data);
        container.appendChild(template);
    };
    var generateEntriesMeta = function(isIndexPage) {
        blog.start = blog.reverse;
        blog.end = blog.start - 10;
        while (isIndexPage ?
                (blog.start-- > blog.end) :
                (blog.start--)) {
            blog.shortMeta.push(metaPool[blog.start]);
        }
    };
    var showSideBars = function() {
        innerData(blog.recentPostsTemplate, blog.shortMeta, 'recent-posts');
        innerData(blog.categoriesTemplate, blog.categories.sort(), 'tags-div');
    };
    var matchCategory = function(category) {
        var arr = [],
            catsArr = [],
            num = blog.cats_meta.length;
        while (num--) {
            catsArr = blog.cats_meta[num][3].toLowerCase().split(',');
            if (catsArr.indexOf(category) !== -1)
                arr.push(blog.cats_meta[num]);
        }
        return arr;
    };

    // Just the categories names
    while (blog.reverseNum--) {
        blog.cats = metaPool[blog.reverseNum][3];
        blog.cats_clean = blog.cats.toLowerCase()
            .replace(' ', '').split(',');
        blog.cats_num = blog.cats_clean.length;

        if (blog.cats && blog.cats !== '') {
            while (blog.cats_num--) {
                if (blog.categories.indexOf(
                            blog.cats_clean[blog.cats_num]) === - 1) {
                    blog.categories.push(
                            blog.cats_clean[blog.cats_num]);
                }
            }
        }
    }

    blog.route = function() {
        var otherPage = document.location.hash.split('=');
        var currentPage = document.location.href.split('/')[3];

        if (currentPage === '' || currentPage === 'index.html') {
            document.title = 'Aarons Blog';
            generateEntriesMeta(true);
            innerData(blog.entriesTemplate, blog.shortMeta, 'entries-wrapper');

        } else if (currentPage === 'archive.html') {
            document.title = 'Archive';
            blog.reverseNum = blog.reverse;
            generateEntriesMeta(false);
            innerData(blog.archiveTemplate(true), blog.shortMeta, 'entries-wrapper');
        } else if (otherPage[0] === '#!post') {
            generateEntriesMeta(true);
            matchNdownload();
        } else if (otherPage[0] === '#!category') {
            document.title = 'Categories';
            generateEntriesMeta(true);
            showSideBars();
            innerData(blog.archiveTemplate(false), matchCategory(otherPage[1]), 'entries-wrapper');

        }
    };

    blog.init = function() {
        blog.route();

        // Recent Posts and Categories Sidebars
        showSideBars();
        w.addEventListener('hashchange', blog.route, false);
    };

    w.addEventListener('load', blog.init, false);
    w.blog = blog;

    // global_stuff.js will be added below this line by `sed'

} (window));
