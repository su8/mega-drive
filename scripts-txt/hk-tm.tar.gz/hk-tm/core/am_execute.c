#include "actionmanager.h"

void am_execute(subaction_execute_t *s)
{
   printf("[RUN] action execute\n");

   return;
}
