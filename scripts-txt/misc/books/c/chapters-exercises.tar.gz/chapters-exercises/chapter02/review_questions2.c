 /* point 6 */
 // which of the following are C keywords ? main, int, function, char, =
 /* answer: int, char */

 /* point 7 */
 // How would you print the values of the variables words and lines so they appear in the following form:
 // There were 3020 words and 350 lines.
 /* answer:
 int words, lines;
 words = 3020;
 lines = 350;
 printf("There are %d words and %d lines.\n", words, lines);
 */

/* point 8 */
/* Consider the following program
#include <stdio.h>
int main(void)
{
int a, b;
a = 5;
b = 2; // line 7
b = a; // line 8
a = b; // line 9
printf("%d %d\n", b, a);
return 0;
}
*/
/* answer:
line 8 overrides the previous assigment to a which is 5,
and vice versa for line 9, so both variables point to "a"
*/
