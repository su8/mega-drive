/* In the U.S. system of volume measurements,
a pint is 2 cups, a cups is 8 ounces, an ounce is
2 tablespoons and a tablespoon is 3 teaspoons.
Write a program that requires a volume in cups and
that displays the equivalent volumes in pints, ounces,
tablespoons, and teaspoons. Why does a floating-point
type make more sense for this application than an
integer type ? */
#include <stdio.h>
int main(void)
{
    int cups;

    printf("Enter some cups volume e.g(13): ");
    scanf("%d", &cups);

    float pint = cups * 0.499999999968;
    float ounces = cups * 7.99999999905;
    float tablespoons = cups * 15.9999999981;
    float teaspoons = cups * 47.9999999943;

    printf("the %d cups equivalent volume in pints is %f\n", cups, pint);
    printf("ounces is %f\ntablespoons is %f\n", ounces, tablespoons);
    printf("and teaspoons is %f\n", teaspoons);

    return 0;
}
