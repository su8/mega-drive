/* This file is part of Alienwave, a game by Alessandro Pira */

#ifndef _UTIL_H
#define _UTIL_H

int rrand(int,int);
int is_y_range(int);
int is_x_range(int);

#endif //_UTIL_H

