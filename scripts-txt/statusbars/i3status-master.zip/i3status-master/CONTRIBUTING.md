Please make sure you format the code using `clang-format -i **/*.[ch]` before sending a pull request.
