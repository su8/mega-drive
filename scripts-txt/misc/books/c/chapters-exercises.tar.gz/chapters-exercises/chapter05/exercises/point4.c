/* Write a program that asks the user to enter a height in centimeters
 * and the displays the height in centimeter and in feet and inches.
 * Fractional centimeters and inches should be allowed, and the program
 * should allow the user to continue entering heights until a nonpositive
 * values is entered. A sample run should look like this:
 * 
 * Enter a height in centimeters: 182
 * 182.0 cm = 5 feet, 11.7 inches
 */
#include <stdio.h>

int main(void)
{
    float cm, inches, remainder_inches;
    double feet;
    
    printf("Enter a height in centimeters:\n");
    scanf("%f", &cm);
    
    inches = cm / 2.54;
    feet = inches / 12;
    remainder_inches = feet - (int) feet;
    
    printf("%.1f = %d feet, %f inches",
    cm, (int) feet, remainder_inches * 12);
    
    return 0;
}
