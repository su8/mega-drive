var aboutTemplate = [
    "<div class='ola'>",
        "<div class='col-md-4'>",
            "<div class='about-side-list'></div>",
        "</div>",
        "<div class='col-md-8'>",
            "<article class='details-wrapper'>",
                "<div class='details-head'>",
                    "<div class='details-head-wrapper'>",
                        "<h4 class='details-title'></h4>",
                    "</div>",
                "</div>",
                "<div class='details-body'>",
                "</div>",
            "</article>",
        "</div>",
    "</div>"
].join('');

geminiBlog.aboutCreateDetails = function(entry) {
    var detailsViewHTML = utils.str2WrappedDOMElement(aboutTemplate);

    var head = $('.ola', detailsViewHTML);

    //set title
    $('.details-title', head).setAttribute("id", "about-id");
    $('.details-title', head).textContent = entry.title;

    //set content
    $('.details-body', detailsViewHTML).innerHTML = entry.html;

    var concatStr = '';
    for (var x in geminiBlog.about) {
        concatStr = concatStr + '<a class="list-group-item" href="#!about=' +
            geminiBlog.about[x].escaped + '"' +
            '>' + geminiBlog.about[x].title +'</a>';
    }
    $('.about-side-list', head).innerHTML = concatStr;

    return detailsViewHTML.childNodes[0];
};

geminiBlog.aboutDetailsView = function(entry) {
    document.title = entry.title;
    utils.hide($("#download-sidebar-links"));
    var container = utils.clearElements($("#entries-wrapper"));

    var aboutDetailsViewInstructions = function(entry) {
        container.appendChild(geminiBlog.aboutCreateDetails(entry));
        utils.elemId("about-id").scrollIntoView(true);
    };

    // fetch entry and process
    if (!entry.text) {
        utils.ajax({
            method: "GET",
            url: entry.url,
            mimeType: "text/plain; charset=x-user-defined",
            success: function(xhr) {
                entry.text = xhr.responseText;
                entry.html = geminiBlog.mdToHTML(xhr.responseText);

                //generate
                aboutDetailsViewInstructions(entry);

            },
            error: function() {
                console.log("err");
                return false;
            }
        });
    } else {
        //create and add details
        aboutDetailsViewInstructions(entry);
    }
};
