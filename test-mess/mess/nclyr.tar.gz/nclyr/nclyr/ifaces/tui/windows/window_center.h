#ifndef NCLYR_CURSES_WINDOW_CENTER_H
#define NCLYR_CURSES_WINDOW_CENTER_H

#include <ncurses.h>

void win_center_str(WINDOW *, const char *);

#endif
