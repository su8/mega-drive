#ifndef NCLYR_CONSOLE_CMD_H
#define NCLYR_CONSOLE_CMD_H

void console_cmd_handle(const char *cmd);

#endif
