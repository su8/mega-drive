#!/usr/bin/python
import os, subprocess, shlex
from gi.repository import Gtk

os.chdir('/home/frost/Documents/dd-my-python/dd3-python/')

def search_changed(searchentry):
    if len(searchentry.get_text()) == 6:
        process = subprocess.Popen(shlex.split('python2 /home/frost/Documents/dd-my-python/dd3-python/dd.py ' + searchentry.get_text()))
        process.communicate()
        window2 = Gtk.Window()
        window2.set_default_size(200, 200)
        window2.connect("destroy", lambda q: Gtk.main_quit())
        
        scrolledwindow = Gtk.ScrolledWindow()
        window2.add(scrolledwindow)
        
        layout = Gtk.Layout()
        layout.set_size(800, 600)
        layout.set_vexpand(True)
        layout.set_hexpand(True)
        scrolledwindow.add(layout)
        
        hadjustment = layout.get_hadjustment()
        scrolledwindow.set_hadjustment(hadjustment)
        vadjustment = layout.get_vadjustment()
        scrolledwindow.set_vadjustment(vadjustment)
        window2.show_all()

window = Gtk.Window()
window.connect("destroy", lambda q: Gtk.main_quit())

searchentry = Gtk.SearchEntry()
searchentry.connect("search-changed", search_changed)

window.add(searchentry)

window.show_all()

Gtk.main()
