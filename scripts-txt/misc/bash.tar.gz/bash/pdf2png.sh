#!/bin/bash
pdf=/home/frost/Desktop/e
for file in $pdf; do
    convert *.pdf[0] %01d.png
done
