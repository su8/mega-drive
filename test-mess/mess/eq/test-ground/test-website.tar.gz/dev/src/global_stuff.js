// Bootstrap dropdown menu without jquery
var daMenus = {

    // Navbar and dropdowns
    toggle: document.getElementsByClassName('navbar-toggle')[0],
    collapse: document.getElementsByClassName('navbar-collapse')[0],

    toggleMenu: function() { // Toggle if navbar menu is open or closed
        daMenus.collapse.classList.toggle('collapse');
    },

    // Close dropdowns when screen becomes big enough to switch to open by hover
    closeMenusOnResize: function() {
        if (document.body.clientWidth >= 768) {
            daMenus.collapse.classList.add('collapse');
        }
    },
};

// dropdown menu listeners
w.addEventListener('resize', daMenus.closeMenusOnResize);
daMenus.toggle.addEventListener('click', daMenus.toggleMenu, false);


// operating system detection
// will be shown at the very bottom of each page
var detectOS = function() {
    var detect =
    {
        mobile:  ["Android", "iPhone", "iPod", "iPad", "Symbian", "Windows Phone", "BlackBerry"],

        shorter: ["Linux", "Free", "Open", "NetBSD", "BSD", "Mac",
                  "Win", "Sun", "HP", "Play", "Web", "QNX", "BeOS", "X11", "OS/2"],

        longer:  ["Linux", "FreeBSD", "OpenBSD", "NetBSD", "BSD", "Macintosh",
                  "Windows", "SunOS", "Hewlett-Packard", "PlayStation",
                  "WebTV OS", "QNX", "BeOS", "UNIX", "OS/2"],

        foundOS: "unknown",
        itsmobile: navigator.userAgent.match(/(Android)|(iPod)|(iPad)|(Symbian)|(Phone)|(BlackBerry)/i),

        findOS: function(arr, os, mobile_bool) {
            var x = arr.length;
            while (x--) {
                if (os.indexOf(arr[x]) !== -1)
                {
                    detect.foundOS = (mobile_bool ? arr[x] : detect.longer[x]);
                    break;
                }
            }
        },
    };

    if (detect.itsmobile)
        detect.findOS(detect.mobile, navigator.userAgent, true);
    else
        detect.findOS(detect.shorter, navigator.platform, false);

    document.getElementById('detect-os').innerHTML = detect.foundOS;
};

detectOS();
