/* arg_parser.c -- 

gcc -o $pkgname $CFLAGS -DVERSION=\"$pkgver\" -DCARCH=\"$CARCH\" \
        $pkgname.c -lalpm $LDFLAGS

gcc -Wall -O3 -DVERSION=\"1.0.1\" -o test arg_parser.c


 */
#include <stdio.h>
#include <stdlib.h>

#include <argp.h>

#define CACHEDIR "/var/cache/pacman/pkg/"

const char *argp_program_version = "arg_parser "VERSION;
const char *argp_program_bug_address = "auguste@gmail.com";

static char doc[] =
    "pkgcacheclean -- a simple utility to clean pacman cache.\v"
    "For installed packages, preserve_number of versions are reserved. This\n"
    "includes the current version and the newest (preserve_number - 1) of\n"
    "the remaining. For uninstalled packages all versions are deleted.\n"
    "The default number is 2.";
static char args_doc[] = "[preserve_number]";

static struct argp_option options[] =
{
    { .doc = "" },
    { .name = "dry-run", .key = 'n', .doc = "Perform a trial run with no changes made" },
    { .name = "cachedir", .key = 'd', .arg = "PATH",
      .doc = "Set alternative (absolute) cache directory PATH. Default is "CACHEDIR },
    { .name = "all-as-installed", .key = 'k',
      .doc = "Treat not-installed packages as installed" },
    { .name = "verbose", .key = 'v', .doc = "Verbose output" },
    { .name = "quiet", .key = 'q', .doc = "Suppress output, default" },
    { .doc = NULL }
};

struct arguments
{
    int dry_run;
    int preserve;
    int keep;
    int verbose;
    char *cachedir;
};

static error_t parse_opt(int key, char *arg, struct argp_state *state)
{
    struct arguments *argument = (struct arguments *)(state -> input);

    switch (key)
    {
        case 'n':
            argument->dry_run = 1;
            break;
        case 'v':
            argument->verbose = 1;
            break;
        case 'k':
            argument->keep = 1;
        case 'q':
            argument->verbose = 0;
            break;
        case 'd':
            argument->cachedir = arg;
            break;
        case ARGP_KEY_ARG:
            if (argument->preserve)
                return ARGP_ERR_UNKNOWN;
            argument->preserve = atoi(arg);
            if (argument->preserve <= 0)
                return ARGP_ERR_UNKNOWN;
            break;
        default:
            return ARGP_ERR_UNKNOWN;
    }

    return 0;
}

int main(const int argc, char ** __restrict__ argv)
{

    struct argp arg_parser = { .options = options, .parser = parse_opt,
        .args_doc = args_doc, .doc = doc };
    struct arguments args = { .dry_run = 0, .preserve = 0, .keep = 0,
                              .verbose = 0, .cachedir = NULL };

    argp_parse(&arg_parser, argc, argv, 0, NULL, &args);

    if (!args.preserve)
        args.preserve = 2;

    return EXIT_SUCCESS;
}