/* put1.c -- prints a string without adding \n */
#include <stdio.h>
#include <stdlib.h>
void put1(const char *string) /* string not altered */
{
    while (*string) /* same as  *string != '\0' because each string has a null char marking its end, which in turn evaluates to 0 - false */
        putchar(*string++);
}