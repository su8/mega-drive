/* pnt_add.c -- pointer addition */
#include <stdio.h>
#include <stdlib.h>
#define SIZE 4
int main(void)
{
    short int dates[SIZE];
    short int *pti;
    short int index;
    double bills[SIZE];
    double *pft;

    pti = dates; /* assign address of array to pointer */
    pft = bills;

    printf("%23s %15s\n", "short", "double");

    for (index = 0; index < SIZE; index++)
        printf("pointers + %d; %10p %10p\n",
            index, pti + index, pft + index);

    return EXIT_SUCCESS;
}