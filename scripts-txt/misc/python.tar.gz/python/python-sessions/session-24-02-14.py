Python 3.3.3 (default, Nov 26 2013, 13:33:18) 
[GCC 4.8.2] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class bear:
	def __init__(self, x=None, z=None)
	
SyntaxError: invalid syntax
>>> class bear:
	def __init__(self, x=None, z=None):
		self.x = x
		self.z = z
	def _getitem__(self):
		return (self.x, self.z)

	
>>> c = bear(x=10,z=15)
>>> c.x
10
>>> c.z
15
>>> c
<__main__.bear object at 0x7fe9f91f6f50>
>>> class bear:
	def __init__(self, x=None, z=None):
		self.x = x
		self.z = z

		
>>> c = bear(x=10,z=15)
>>> c.x
10
>>> c.z
15
>>> class bear:
	def __init__(self, x=None, z=None):
		self.x = x
		self.z = z
	def __getitem__(self):
		return (self.x, self.z)

	
>>> 
>>> c = bear(x=10,z=15)
>>> c.x
10
>>> c.z
15
>>> c
<__main__.bear object at 0x7fe9f8cdbbd0>
>>> class bear:
	#def __init__(self, x=None, z=None):
		#self.x = x
		#self.z = z
	def __getitem__(self, key):
		return key

	
>>> bear(4)
Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    bear(4)
TypeError: object() takes no parameters
>>> class bear:
	def __init__(self, x=None, z=None):
		self.x = x
		self.z = z
	def __repr__(self):
		return (self.x, self.z)

	
>>> c = bear(x=10,z=15)
>>> c
Traceback (most recent call last):
  File "<pyshell#30>", line 1, in <module>
    c
TypeError: __repr__ returned non-string (type tuple)
>>> str(c)
Traceback (most recent call last):
  File "<pyshell#31>", line 1, in <module>
    str(c)
TypeError: __str__ returned non-string (type tuple)
>>> class bear:
	def __init__(self, x=None, z=None):
		self.x = x
		self.z = z
	def __repr__(self):
		return "x is {0}, z is {1}".format(self.x, self.z)

	
>>> c = bear(x=10,z=15)
>>> c
x is 10, z is 15
>>> c.z
15
>>> c.x
10
>>> c = bear(16,12)
>>> c.x
16
>>> c.z
12
>>> class LoggedMappingMixin:
	'''
add logging to get/set/delete operations for debugging.
'''
	__slots__ = ()
	def __getitem__(self, key):
		print('Getting ' + str(key))
		return super().__getitem__(key)
	def __setitem__(self, key, value):
		print('Setting {} = {!r}'.format(key, value))
		return super().__setitem__(key, value)
	def __delitem__(self, key):
		print('Deleting ' + str(key))
		return super().__delitem__(key)

	
>>> class LoggedDict(LoggedMappingMixin, list):
	pass

>>> d = LoggedDict()
>>> d.append("ewqewq")
>>> d
['ewqewq']
>>> del d['ewqewq']
Deleting ewqewq
Traceback (most recent call last):
  File "<pyshell#48>", line 1, in <module>
    del d['ewqewq']
  File "<pyshell#42>", line 14, in __delitem__
    return super().__delitem__(key)
TypeError: list indices must be integers, not str
>>> del d[0]
Deleting 0
>>> d
[]
>>> d.append('hqhq')
>>> d.append("EWQEQWEQWEQW")
>>> d
['hqhq', 'EWQEQWEQWEQW']
>>> del d[1]
Deleting 1
>>> d
['hqhq']
>>> d['hqhq']
Getting hqhq
Traceback (most recent call last):
  File "<pyshell#56>", line 1, in <module>
    d['hqhq']
  File "<pyshell#42>", line 8, in __getitem__
    return super().__getitem__(key)
TypeError: list indices must be integers, not str
>>> d[0]
Getting 0
'hqhq'
>>> d['hqhq'] = 26
Setting hqhq = 26
Traceback (most recent call last):
  File "<pyshell#58>", line 1, in <module>
    d['hqhq'] = 26
  File "<pyshell#42>", line 11, in __setitem__
    return super().__setitem__(key, value)
TypeError: list indices must be integers, not str
>>> d[0] = 27
Setting 0 = 27
>>> d[0]
Getting 0
27
>>> d
[27]
>>> del d[0]
Deleting 0
>>> d.append('apex')
>>> d
['apex']
>>> d[0]
Getting 0
'apex'
>>> from functools import total_ordering
>>> class Room:
	def __init__(self, name, length, width):
		self.name = name
		self.length = length
		self.width = width
		self.square_feet = self.length * self.width

		
>>> @total_ordering
class House:
	def __init__(self, name, style):
		self.name = name
		self.style = style
		self.rooms = list()
	@property
	def living_spsace_footage(self):
		return sum(r.square_feet for r in self.rooms)
	def add_room(self, room):
		self.rooms.append(room)
	def __str__(self):
		return '{}: {} square foot'.format(self.name,
						   self.living_space_footage,
						   self.style)
	def __eq__(self. other):
		
SyntaxError: invalid syntax
>>> @total_ordering
class House:
	def __init__(self, name, style):
		self.name = name
		self.style = style
		self.rooms = list()
	@property
	def living_spsace_footage(self):
		return sum(r.square_feet for r in self.rooms)
	def add_room(self, room):
		self.rooms.append(room)
	def __str__(self):
		return '{}: {} square foot'.format(self.name,
						   self.living_space_footage,
						   self.style)
	def __eq__(self, other):
		return self.living_space_footage == other.living.space_footage
	def __lt__(self, other):
		return self.living_space_footage < other.living.space_footage

>>> h1 = House('h1', 'Cape')
>>> h1.add_room(Room('Master Bedroom', 14, 21))
>>> h1.add_room(Room('Living Room', 18, 20))
>>> h1.add_room(Room('Kitchen', 12, 11))
>>> h2 = House('h2','Ranch')
>>> h2.add_room(Room('Master Bedroom', 14, 21))
>>> h3 = House('h3', 'Split')
>>> h3.add_room(Room('Master Bedroom', 16, 31))
>>> houses = [h1,h2,h3]
>>> print('Is h1 bigger than h2 ?', h1 > h2)
Traceback (most recent call last):
  File "<pyshell#105>", line 1, in <module>
    print('Is h1 bigger than h2 ?', h1 > h2)
  File "/usr/lib/python3.3/functools.py", line 85, in <lambda>
    '__lt__': [('__gt__', lambda self, other: not (self < other or self == other)),
  File "<pyshell#95>", line 19, in __lt__
    return self.living_space_footage < other.living.space_footage
AttributeError: 'House' object has no attribute 'living_space_footage'
>>> @total_ordering
class House:
	def __init__(self, name, style):
		self.name = name
		self.style = style
		self.rooms = list()
	@property
	def living_spsace_footage(self):
		return sum(r.square_feet for r in self.rooms)
	def add_room(self, room):
		self.rooms.append(room)
	def __str__(self):
		return '{}: {} square foot'.format(self.name,
						   self.living_space_footage,
						   self.style)
	def __eq__(self, other):
		return self.living_space_footage == other.living_space_footage
	def __lt__(self, other):
		return self.living_space_footage < other.living_space_footage

	
>>> h1 = House('h1', 'Cape')
>>> h1.add_room(Room('Master Bedroom', 14, 21))
>>> h1.add_room(Room('Living Room', 18, 20))
>>> h1.add_room(Room('Kitchen', 12, 11))
>>> h2 = House('h2','Ranch')
>>> h2.add_room(Room('Master Bedroom', 14, 21))
>>> h3 = House('h3', 'Split')
>>> h3.add_room(Room('Master Bedroom', 16, 31))
>>> houses = [h1,h2,h3]
>>> print('Is h1 bigger than h2 ?', h1 > h2)
Traceback (most recent call last):
  File "<pyshell#117>", line 1, in <module>
    print('Is h1 bigger than h2 ?', h1 > h2)
  File "/usr/lib/python3.3/functools.py", line 85, in <lambda>
    '__lt__': [('__gt__', lambda self, other: not (self < other or self == other)),
  File "<pyshell#107>", line 19, in __lt__
    return self.living_space_footage < other.living_space_footage
AttributeError: 'House' object has no attribute 'living_space_footage'
>>> @total_ordering
class House:
	def __init__(self, name, style):
		self.name = name
		self.style = style
		self.rooms = list()
	@property
	def living_space_footage(self):
		return sum(r.square_feet for r in self.rooms)
	def add_room(self, room):
		self.rooms.append(room)
	def __str__(self):
		return '{}: {} square foot'.format(self.name,
						   self.living_space_footage,
						   self.style)
	def __eq__(self, other):
		return self.living_space_footage == other.living_space_footage
	def __lt__(self, other):
		return self.living_space_footage < other.living_space_footage

	
>>> h1 = House('h1', 'Cape')
>>> h1.add_room(Room('Master Bedroom', 14, 21))
>>> h1.add_room(Room('Living Room', 18, 20))
>>> h1.add_room(Room('Kitchen', 12, 11))
>>> h2 = House('h2','Ranch')
>>> h2.add_room(Room('Master Bedroom', 14, 21))
>>> h3 = House('h3', 'Split')
>>> h3.add_room(Room('Master Bedroom', 16, 31))
>>> houses = [h1,h2,h3]
>>> print('Is h1 bigger than h2 ?', h1 > h2)
Is h1 bigger than h2 ? True
>>> print('Is h2 smaller than h3 ?', h2 < h3)
Is h2 smaller than h3 ? True
>>> print('Is h2 greater or equal to h2 ?', h2 >= h1)
Is h2 greater or equal to h2 ? False
>>> print('Which os is biggest ?' max(houses))
SyntaxError: invalid syntax
>>> print('Which os is biggest ?', max(houses))
Which os is biggest ? h1: 786 square foot
>>> print('Which os is smallest ?', min(houses))
Which os is smallest ? h2: 294 square foot
>>> 
