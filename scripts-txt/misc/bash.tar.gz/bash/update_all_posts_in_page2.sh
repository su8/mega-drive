#!/bin/bash
cd /home/frost/blog/
python2 page2.py
