/* 8. Write a program that requests two floating-point numbers and prints the value of their
difference divided by their product. Have the program loop through pairs of input values
until the user enters nonnumeric input.
#include <stdio.h>
int main(void)
{

    double num1, num2, num3;

    printf("Please enter two floating-point numbers: ");
    while (scanf("%lf%lf", &num1, &num2) == 2)
    {
        num3 = num1 - num2;
        printf("%0.5lf %0.5lf\n", num3 / num1, num3 / num2);
        printf("Please enter two floating-point numbers: ");
    } 
    printf("See you later.\n");
    
    return 0;
}
*/
#include <stdio.h>
int main(void)
{
    double n, m;
    double res;
    
    printf("Enter a pair of numbers: ");
    
    while (scanf("%lf %lf", &n, &m) == 2)
    {
        res = (n - m) / (n * m);
        printf("(%.3g - %.3g)/(%.3g*%.3g) = %.5g\n", n, m, n, m, res);
        printf("Enter next pair (non-numeric to quit): ");
    }
            
    return 0;
}
