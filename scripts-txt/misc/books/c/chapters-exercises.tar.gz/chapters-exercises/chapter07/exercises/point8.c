/* point8.c --

8. Modify assumption a. in exercise 7 so that the program presents a menu of pay rates
from which to choose. Use a switch to select the pay rate. The beginning of a run
should look something like this:
*****************************************************************
Enter the number corresponding to the desired pay rate or action:
1) $8.75/hr
2) $9.33/hr
3) $10.00/hr
4) $11.20/hr
5) quit
*****************************************************************
If choices 1 through 4 are selected, the program should request the hours worked. The
program should recycle until 5 is entered. If something other than choices 1 through 5
is entered, the program should remind the user what the proper choices are and then
recycle. Use #defined constants for the various earning rates and tax rates.

  */
#include <stdio.h>
#include <stdlib.h>
#define RATE1 0.15
#define RATE2 0.20
#define RATE3 0.25
#define OVERTIME 40
#define BREAK1 300
#define BREAK2 150
int main(void)
{
    double worked_hours, gross_pay, taxes, net_pay,x,z,c;
    int choose;
    double PAY_RATE;

    printf("*****************************************************************\n");
    printf("Enter the number corresponding to the desired pay rate or action:\n");
    printf("1) $8.75/hr %20s 2) $9.33/hr\n", " ");
    printf("3) $10.00/hr %19s 4) $11.20/hr\n", " ");
    printf("5) quit\n");
    printf("*****************************************************************\n");
    if (1 == scanf("%d", &choose))
    {
        switch (choose)
        {
            case 1:
                    PAY_RATE = 8.75;
                    break;
            case 2:
                    PAY_RATE = 9.33;
                    break;
            case 3:
                    PAY_RATE = 10.00;
                    break;
            case 4:
                    PAY_RATE = 11.20;
                    break;
            case 5:
                    break;
            default:
                    printf("Try again and choose wisely\n");
        }
    }
    else
    {
        printf("I was expecting numbers between 1-5\n");
        exit(EXIT_FAILURE);
    }

    printf("Please enter the hours worked in a week: ");
    if (1 == scanf("%lf", &worked_hours))
    {
        if (worked_hours <= OVERTIME)
            gross_pay = worked_hours * PAY_RATE;
        else
        {
            for (x = OVERTIME; x <= worked_hours; c++, x++)
                z = c;
            gross_pay = worked_hours * PAY_RATE + (z * (PAY_RATE+PAY_RATE+PAY_RATE/2));
            printf("%.1f\n\n",z);
        }

        if (gross_pay <= BREAK1)
            taxes = RATE1 * worked_hours;
        else if (gross_pay <= BREAK2)
            taxes = RATE2 * worked_hours;
        else
            taxes = RATE3 * worked_hours;

        net_pay = gross_pay - taxes;

        printf("Gross pay = $%.1f, taxes = $%.1f, net pay = $%.1f",
            gross_pay, taxes, net_pay);
    }
    else
        printf("I was expecting a number(s) only!");

    return EXIT_SUCCESS;
}