(function() {
    "use strict";
    var name, olderVersion, site, news, infect,
    notes, about, currentVersion, docs, x;

    currentVersion = "2016.04";
    olderVersion = "2015";

    infect = {
        /* Download table 1 */
        "metadata1": { /* shasum, size */
            "686": ["6fbd79dde9f0a527f9a17157fc4e4650", "1.6 GB"],
            "x86_64": ["7986ef40b15de37a1d290bd2069856aa", "1.5 GB"],
        },
        /* Download table 2 */
        "metadata2": { /* shasum, size */
            "mate": ["89c3a74b671b0e5e36a8e791f3df4d9e", "2.7 GB"],
            "xfce": ["b0c899f61be1ed167edd16e10d570a21", "2.1 GB"]
        },
        /* Release Schedule */
        "schedule": { /* Status   Name   Codename   Arrives   Release Date */
            "1": ["Released", "AryaLinux 2016.04 Live Builder Disk", "Dawn of Justice", "May 27, 2016", "May 09, 2016"],
            "0": ["In Progress", "AryaLinux 2016.04 Mate and XFCE Live Disks", "Dawn of justice", "June 06, 2016", ""]
        },

        "releaseNotes": {
            "686":    [
                "./release/2016.04.md", /* <-- 686 release notes */
                    "AryaLinux " + currentVersion + " Release Notes [i686]"],
            "x86_64": [
                "./release/2016.04.md", /* <-- x86_64 release notes */
                    "AryaLinux " + currentVersion + " Release Notes [x86_64]"]
        },

        "news": {    /* filename, title, publishing date */
                "4": ["./news/3000_downloads.md", "Over 3000 downloads of the builder DVD in the past three days. Wow!", "May 11, 2016"],
                "3": ["./news/added_videos.md", "Added videos to show the build process using the builder DVD", "May 10, 2016"],
                "2": ["./news/first_builder_disk.md","AryaLinux 2016.04 builder disk released","April 30, 2016"],
                "1": ["./news/first_pre_release.md","AryaLinux 2016.04 Pre Release Notes","April 20, 2016"],
                "0": ["./news/first_release.md","Getting ready for version 2016.04","April 20, 2016"]
        },

        "docs": {    /* filename, title, categories "1,2,3" */
                "7": ["./docs/building_xfce.md", "Building the XFCE desktop environment", "Desktop"],
                "6": ["./docs/building_mate.md", "Building the Mate desktop environment", "Desktop"],
                "5": ["./docs/using_the_builder_disk.md", "Build process in details using the builder disk", "Building"],
                "4": ["./docs/lfs_2015_easy.md", "How to create your own Linux from Scratch 64bit - The Easy Way (version 2015)", "Building"],
                "3": ["./docs/internals.md", "ALPS Internals", "Alps"],
                "2": ["./docs/troubleshooting.md", "ALPS troubleshooting", "Alps"],
                "1": ["./docs/packaging_system.md", "ALPS - The AryaLinux Packaging System", "Alps"],
                "0": ["./docs/lightdm_touchpad.md", "Enabling touchpad clicks in LightDM", "Hardware"]
        },

        "about": {   /* filename, title */
                "2": ["./about/faq.md", "Frequently asked questions"],
                "1": ["./about/history.md", "A bit of history"],
                "0": ["./about/about.md", "About AryaLinux"]
        }
    };

    /* Don't edit anything below this comment */
    site = infect.site;
    news = infect.news;
    about = infect.about;
    notes = infect.releaseNotes;
    docs = infect.docs;

    geminiBlog.version = currentVersion;
    geminiBlog.olderVersion = olderVersion;
    geminiBlog.metadata_one = infect.metadata1;
    geminiBlog.metadata_two = infect.metadata2;
    geminiBlog.releaseSchedule = infect.schedule;

    for (x in news)
        geminiBlog.newsArr.push({
            "url": geminiBlog.repoBase + news[x][0].slice(2),
            "escaped": geminiBlog.escapeTitle(news[x][1]),
            "title": news[x][1],
            "date": news[x][2],
            "id": x,
            "index": x,
            "pubDate": new Date(news[x][2])
        });

    for (x in docs)
        geminiBlog.registerEntry(docs[x][0], docs[x][1], docs[x][2]);

    for (x in notes) {
        geminiBlog.notes.push({
            "url": geminiBlog.repoBase + notes[x][0].slice(2),
            "escaped": geminiBlog.escapeTitle(notes[x][1]),
            "title": notes[x][1]
        });
        geminiBlog.notesLinks.push(geminiBlog.escapeTitle(notes[x][1]));
    }

    for (x in about)
        geminiBlog.about.push({
            "url": geminiBlog.repoBase + about[x][0].slice(2),
            "escaped": geminiBlog.escapeTitle(about[x][1]),
            "title": about[x][1]
        });
})();
