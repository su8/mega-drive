import os

for x in os.listdir(os.getcwd()):
    if x.endswith('.png'):
        a = os.path.splitext(x)[0]
        os.system('convert "{0}".png -quality 50 "{0}".jpg'.format(a))
        os.remove(x)