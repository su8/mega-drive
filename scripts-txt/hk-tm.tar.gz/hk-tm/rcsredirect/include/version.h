
/* $Id: version.h 3508 2011-03-22 15:35:16Z alor $ */

#ifndef __VERS_H
#define __VERS_H

#define RCS_VER            "2011032101"
#define VERSION            "2011.03.21"
#define COPYRIGHT          "2011"
#define AUTHORS            "HackingTeam srl"

#endif

/* EOF */

