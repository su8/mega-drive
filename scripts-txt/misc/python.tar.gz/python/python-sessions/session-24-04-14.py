Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class Silly(object):
	def _get_silly(self):
		print('you are getting silly')
		return self._silly
	def _set_silly(self, value):
		print('you are making silly {}'.format(value))
		self._silly = value
	def _del_silly(self):
		print('whoah, you killed silly!')
		del self._silly
	silly = property(_get_silly, _set_silly, _del_silly, 'This is a silly property')

	
>>> s = Silly()
>>> s.silly = 'funny'
you are making silly funny
>>> s.silly
you are getting silly
'funny'
>>> del s.silly
whoah, you killed silly!
>>> help(silly)
Traceback (most recent call last):
  File "<pyshell#16>", line 1, in <module>
    help(silly)
NameError: name 'silly' is not defined
>>> help(Silly)
Help on class Silly in module __main__:

class Silly(builtins.object)
 |  Data descriptors defined here:
 |  
 |  __dict__
 |      dictionary for instance variables (if defined)
 |  
 |  __weakref__
 |      list of weak references to the object (if defined)
 |  
 |  silly
 |      This is a silly property

>>> class Foo(object):
	@property
	def foo(self):
		return 'bar'

	
>>> class Foo(object):
	@property
	def foo(self):
		return self._foo
	@foo.setter
	def foo(self, value):
		self._foo = value

		
>>> class Silly(object):
	@property
	def silly(self):
		"This is a silly property"
		print("you are getting silly")

		
>>> class Silly(object):
	@property
	def silly(self):
		"This is a silly property"
		print("you are getting silly")
		return self._silly
	@silly.setter
	def silly(self, value):
		print("You are making silly {}".format(value))
		self._silly = value
	@silly.deleter
	def silly(self):
		print('Whoa, you killed silly')
		del self._silly

		
>>> s = Silly()
>>> s.silly = 'funky'
You are making silly funky
>>> s.silly
you are getting silly
'funky'
>>> del s.silly
Whoa, you killed silly
>>> from urllib.request import urlopen
>>> class WebPage(object):
	def __init__(self, url):
		self.url = url
		self._content = None
	@property
	def content(self):
		if not self._content:
			print('Retrieving New Page...')
			self._content = urlopen(self.url).read()
		return self._content

	
>>> import time
>>> web = WebPage('http://ccphillips.net')
>>> now = time.time()
>>> content1 = webpage.content
Traceback (most recent call last):
  File "<pyshell#64>", line 1, in <module>
    content1 = webpage.content
NameError: name 'webpage' is not defined
>>> content1 = web.content
Retrieving New Page...
>>> time.time() - now
33.490620613098145
>>> content2 = webpage.content
Traceback (most recent call last):
  File "<pyshell#67>", line 1, in <module>
    content2 = webpage.content
NameError: name 'webpage' is not defined
>>> content2 = web.content
>>> time.time() - now
72.35031318664551
>>> content2 == content1
True
>>> content2
b'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">\n    <head>\n        <title>C. C. Phillips</title>\n        <meta http-equiv="content-type" content="text/html; charset=utf-8" />\n        <meta name="readability-verification" content="G6wFUVM3jShfZ4gtbh5T793HwfzyYwdQhWccCyYM"/>\n        <link rel="stylesheet" href="/static/styles.css" />\n        <link href=\'http://fonts.googleapis.com/css?family=Diplomata+SC\' rel=\'stylesheet\' type=\'text/css\'>\n        <link rel="icon" href="/static/images/favicon.ico" type="image/x-icon" />\n        <link rel="shortcut icon" href="/static/images/favicon.ico" type="image/x-icon" />\n        <script type="text/javascript" src="/static/jquery-1.3.2.min.js"></script>\n        <script src="/static/jquery.form.js" type="text/javascript" charset="utf-8"></script>\n        <script type="text/javascript" src="https://gumroad.com/js/gumroad.js"></script>\n        <script type="text/javascript">\n\n          var _gaq = _gaq || [];\n          _gaq.push([\'_setAccount\', \'UA-18131642-1\']);\n          _gaq.push([\'_trackPageview\']);\n\n          (function() {\n            var ga = document.createElement(\'script\'); ga.type = \'text/javascript\'; ga.async = true;\n            ga.src = (\'https:\' == document.location.protocol ? \'https://ssl\' : \'http://www\') + \'.google-analytics.com/ga.js\';\n            var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(ga, s);\n          })();\n\n        </script>\n    </head>\n    <body>\n        <div id="topbar1"></div>\n        <div id="title">\n            <img src="/static/images/flyingpbar.png" width="32" height="32" style="float: left" alt="brand icon" />\n            <img src="/static/images/flyingpbar.png" width="32" height="32" style="float: right" alt="brand icon" />\n            C. C. Phillips\n        </div>\n        <div id="menubar">\n            <ul>\n                <li><a href="/">Home</a></li>\n                <li><a href="/books/">Books</a></li>\n                <li><a href="/bio/">Bio</a></li>\n                <li><a href="http://www.facebook.com/pages/C-C-Phillips/229584720839">Facebook</a></li>\n                <li><a href="/contact/">Contact</a></li>\n            </ul>\n        </div>\n        <div id="container">\n            \n<img style="float: left; margin-right: 1em; margin-bottom: 1em"\nsrc="/static/images/mountains.png" width="150"\nheight="200" />\n<p>\nWelcome to the home page of Canadian author, C. C. Phillips.  Here, you\ncan discover all of Phillips\'s published work including his latest novel, <a\n    href="/books/preston-diamond-boston-union-man">Preston Diamond: Boston Union Man</a>.\n</p>\n<p>\nIf you like C.  C. Phillips\'s books, please show your appreciation by\npurchasing a book or by sending a note of recognition to <a\n    href="mailto:contact@ccphillips.net">contact@ccphillips.net</a>!\n</p>\n<hr style="clear: left;" />\n<div id="newsbox">\n    <h2>News</h2>\n    \n    <br /><strong><em>April 01, 2014</em></strong><br />\n    <p>C. C. Phillips announces the release of Preston Diamond: Boston Union Man, sixth in the Preston Diamond western action series. Available immediately on Amazon and CreateSpace and soon to be available through book store channels in the near future.</p>\n    \n    <br /><strong><em>September 26, 2013</em></strong><br />\n    <p>As usual, C.C. Phillips has abandoned his writing for the summer months, however, before he shut down the keyboard, the next novel, eighth in the series, Preston Diamond: Return to Way-cross, has been written. This sequel to Preston Diamond in Way-cross is now in the editing process and we hope to have it released in the ensuing months.\r\n</p>\r\n<p>\r\nIn other news, Preston Diamond: Boston Union Man is in the final stages of cover design and shall be out very soon.\r\n</p>\n    \n    <br /><strong><em>February 17, 2013</em></strong><br />\n    <p>\r\nAll C. C. Phillips books can now be purchased as eBooks via direct download. Simply click the "Purchase eBook" links to provide credit card details and obtain instant access to the eBooks. Your download will contain a zipfile comprised of three different versions of the books you have chosen: pdf, epub, and mobi formats are all provided to work with most common ebook readers and software on the market.\r\n</p>\r\n<p>\r\nWe recommend use of the pdfs as they contain layout information and provide the same reading experience that you would get with a print copy of the book. However, the other formats may be conducive to your Nook, Kobo, or Kindle ebook reading pleasure.\r\n</p>\r\n<p>\r\nWe hope you enjoy the ebooks. Come back soon to read C. C. Phillips\'s upcoming novel, Preston Diamond: Boston Union Man.</p>\r\n</p>\n    \n    <br /><strong><em>February 11, 2013</em></strong><br />\n    <p>\r\nHot on the heels of the release of Preston Diamond In Hell, C. C. Phillips is proud to announce the next book in the series, <a href="https://www.createspace.com/4055753">Preston Diamond On The Mississippi River</a>.\r\n</p>\r\n<p>\r\nIn this steamboat story, Preston Diamond encounters old friends and foes, not all of whom are of this world. All aboard!\r\n</p>\n    \n</div>\n<div id="bookbox">\n    <h2>Books in the Preston Diamond Series</h2>\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/conception.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: 20px">\n        <span class="title">Preston Diamond: Conception</span><br />\n        <a href="http://gum.co/TKMV">Purchase eBook</a><br />\n        <strong><a\n        href="https://www.createspace.com/3455228">Purchase\n        In Print</a></strong><br />\n        <a href="/books/preston-diamond-conception/">Read Online</a>\n    </div>\n    <div style="clear: left"></div>\n\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/whitehouse.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: 10px">\n        <span class="title">Preston Diamond In The White House</span><br />\n        <a href="http://gum.co/KmFD">Purchase eBook</a><br />\n        <strong><a href="https://www.createspace.com/3591019">Purchase In Print</a></strong><br />\n        <a href="/books/preston-diamond-white-house/">Read Online</a>\n    </div>\n    <div style="clear: left"></div>\n\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/texas.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: 10px">\n        <span class="title">Preston Diamond In Texas</span><br />\n        <a href="http://gum.co/FksN">Purchase eBook</a><br />\n        <strong><a href="https://www.createspace.com/3680171">Purchase In Print</a></strong>\n    </div>\n    <div style="clear: left"></div>\n\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/hell.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: 10px">\n        <span class="title">Preston Diamond In Hell</span><br />\n        <a href="http://gum.co/mojZ">Purchase eBook</a><br />\n        <strong><a href="https://www.createspace.com/3938299">Purchase In Print</a></strong>\n    </div>\n    <div style="clear: left"></div>\n\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/mississippi.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: 10px">\n        <span class="title">Preston Diamond On The Mississippi River</span><br />\n        <a href="http://gum.co/nsja">Purchase eBook</a><br />\n        <strong><a href="https://www.createspace.com/4055753">Purchase In Print</a></strong>\n    </div>\n    <div style="clear: left"></div>\n\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/boston.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: 10px">\n        <strong>Latest Book by C. C. Phillips</strong><br/>\n        <span class="title">Preston Diamond: Boston Union Man</span><br />\n\t<!--<a href="http://gum.co/nsja">Purchase eBook</a><br />-->\n        <strong><a href="https://www.createspace.com/4445103">Purchase In Print</a></strong>\n    </div>\n    <div style="clear: left"></div>\n\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/prestondiamond.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: 10px">\n        <span class="title">Preston Diamond In Way-cross</span><br />\n        <a href="http://gum.co/ekpm">Purchase eBook</a><br />\n        <strong><a href="https://www.createspace.com/Customer/EStore.do?id=3398972">Purchase\n        In Print</a></strong><br />\n        <a href="/books/preston-diamond-waycross/">Read Online</a>\n    </div>\n    <div style="clear: left"></div>\n    \n    <h2>Other Books by C. C. Phillips</h2>\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/watershed.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: -10px">\n        <br />\n        <span class="title">Watershed</span><br />\n        <a href="http://gum.co/ycJQ">Purchase eBook</a><br />\n        <strong><a href="https://www.createspace.com/3487983">Purchase In Print</a></strong><br />\n        <a href="/books/watershed/">Read Online</a>\n    </div>\n    <div style="clear: left"></div>\n\n    <div style="float: left; margin-right: 1ex">\n        <img src="/static/covers/twiceuponatime.png" height="100" width="50"/>\n    </div>\n    <div style="margin-top: -10px">\n        <br />\n        <span class="title">Twice Upon A Time</span><br />\n        <a href="http://gum.co/GZEqR">Purchase eBook</a><br />\n        <a\n        href="https://www.createspace.com/3396241">Purchase In\n        Print</a></strong><br />\n        <a href="/books/twice-upon-time/">Read Online</a>\n        <strong>\n    </div>\n    <div style="clear: both"></div>\n</div>\n\n        </div>\n        <div id="copyright">\n            Copyright &copy; 2009-2013 C. C. Phillips\n        </div>\n    </body>\n</html>\n'
>>> 
