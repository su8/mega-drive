import urllib.request
from bs4 import BeautifulSoup # python-beautifulsoup4
class aha:
    def __init__(self, requested_page):
        self.req_page = requested_page
        with urllib.request.urlopen(self.req_page) as url:
            self.s = url.read()
    def __repr__(self):
        soup = BeautifulSoup(''.join(str(self.s)))
        table = soup.find('table')
        rows = table.findAll('tr')
        for tr in rows:
            cols = tr.findAll('td')
            for td in cols:
                text = ''.join(td.find(text=True))
                print(text)

aha('http://www.formula1.com/results/driver/')