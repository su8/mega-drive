/* Find out what your system does with integer overflow,
floating-point overflow and floating-point underflow
by using the experimental approach; that is,
write programshaving these problems. */
#include <stdio.h>
int main(void)
{
    int i_overflow = 2147483647;
    float f_overflow = 3.4E38 * 100.0f,
    f_underflow = 2.0e20 + 1.0;

    printf("Float overflow %e\n", f_overflow);
    printf("Float underflow %f\n", f_underflow - 2.0e20);
    printf("Integer overflow %d\n", i_overflow + 92138);

    return 0;
}
