import os
from sys import argv

for filenames in (Suffix for Suffix in os.listdir('.') if Suffix.endswith(argv[1])):
    new_name, newname_extension = os.path.splitext(filenames)
    os.rename(filenames, new_name + argv[2])

