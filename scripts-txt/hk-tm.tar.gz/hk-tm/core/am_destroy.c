#include "actionmanager.h"

void am_destroy(subaction_destroy_t *s)
{
   printf("[RUN] action destroy\n");

   return;
}
