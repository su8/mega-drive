from gi.repository import Gtk, GdkPixbuf


        #fix = Gtk.Fixed()
        #fix.put(image, 110, 10)
        #vbox.add(fix)
        grid = Gtk.Grid()
        grid.set_row_spacing(1)
        grid.set_column_spacing(1)
        vbox.add(grid)

        im = GdkPixbuf.Pixbuf.new_from_file_at_size("/home/frost/Desktop/bg.jpg", 602, 388)
        image = Gtk.Image()
        image.set_from_pixbuf(im)
        vbox2.add(image) 
