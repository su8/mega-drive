/* write a program to print your name and address */
#include <stdio.h>
int main(void)
{
    char my_name[] = "Aaron Caffrey";
    char email_address[] = "user@example.com";

    printf("My name is %s and my email address is %s", my_name, email_address);
    return 0;
}
