#!/usr/bin/env python2
import getpass
import os
import subprocess

# getting your username and adding it to the /home/xxxx/blogfy , so it automatically updates your posts
# without the need to type "python blogfy" anymore, just "blogfy" from now on
# if you store blogfy on other directory then specify it below, also make sure that if you make any
# changes to build.py to add them to that file, or just add all the changes in this file
userz = getpass.getuser()
os.chdir("/home/" + userz + "/blog/")
params = ['python2', 'build.py']
subprocess.check_call(params)

