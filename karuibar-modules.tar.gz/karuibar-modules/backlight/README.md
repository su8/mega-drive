karuibar:backlight
==================

This module displays the percentage of the screen's physical backlight
brightness in comparison with the maximum brightness.

![backlight.gif](scrot/backlight.gif)

X resource                  | Description
:---------------------------|:-----------------------------------------------------------------
`karuibar.backlight.device` | Battery device in `/sys/class/backlight` (default: `acpi_video0`)

Module       | `backlight`
:------------|:-------------------------------------------------
Author       | Tinu Weber ([ayekat](https://github.com/ayekat/))
Dependencies | none
Callbacks    | `init`, `react`, `term`
License      | GPLv3
