/* Write a program that asks for your first name,
your last name, and then prints the names in the
format last, first. */
#include <stdio.h>
int main(void)
{
    char first[20], last[20];

    printf("Please enter your first name followed by your last name\n");
    scanf("%s %s", first, last);
    printf("%s %s\n", last, first);

    return 0;
}
