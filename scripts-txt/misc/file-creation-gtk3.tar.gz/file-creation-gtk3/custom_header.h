#ifndef CUSTOM_HEADER_H_
#define CUSTOM_HEADER_H_

#define POS_LEFT 1
#define POS_RIGHT 2
#define ENTER_TXT "Filename:"
#define OK_BUT "OK"
#define PROG_TITLE "Create New File"

#define APP_CSS "GtkWindow {"\
            "color: #ec7c45;"\
            "background: black;"\
        "}"\
        "GtkGrid {"\
            "background: black;"\
        "}"\
        "GtkEntry {"\
            "background: darkgrey;"\
            "border-radius: 10px;"\
            "border: none;"\
            "color: black;"\
        "}"\
        "GtkEntry:hover {"\
            "color: white;"\
            "box-shadow: 0 0 13px #333 inset;"\
        "}"\
        "GtkEntry:focused {"\
            "background: silver;"\
        "}"\
        "GtkButton {"\
            "color: black;"\
            "border-radius: 10px;"\
            "border: none;"\
         "}"\
        "GtkButton:hover {"\
            "background: grey;"\
            "color: white;"\
            "box-shadow: 0 0 13px #333 inset;"\
            "transition: 400ms linear;"\
        "}"

#endif
