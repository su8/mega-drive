/* 8. Given the input Go west, young man! , what would each of the following programs
produce for output? (The ! follows the space character in the ASCII sequence.)

a.
#include <stdio.h>
int main(void)
{
    char ch;
    scanf("%c", &ch);
    while ( ch != 'g' )
    {
        printf("%c", ch);
        scanf("%c", &ch);
    }
    return 0;

}
b.
#include <stdio.h>
int main(void)
{
    char ch;
    scanf("%c", &ch);
    while ( ch != 'g' )
    {
        printf("%c", ++ch);
        scanf("%c", &ch);
    }
    return 0;

}

c.
#include <stdio.h>
int main(void)
{
    char ch;
    do {
        scanf("%c", &ch);
        printf("%c", ch);
    } while (ch != 'g');
    return 0;
}

d.
#include <stdio.h>
int main(void)
{
    char ch;
    
    scanf("%c", &ch);
    for (ch = '$'; ch != 'g'; scanf("%c", &ch))
    {
        printf("%c", ch);
    }
    
    return 0;
}
*/

/* a. The program reads all of the "Go west, young man!" input
 * and when it reaches the 'g' character it causes the while loop
 * to stop and cut the rest of the input because the loop has met
 * the wanted condition and turns into Fail rather than True.
 * Also if the 
*/

/* b. same as 'a.' but this time each of the input chars
 * in the printf statement gets prefix update with the next char
 * which causes to print "Hp!xftu-!zpvo"
*/

/* c. Whatever happens, the do while loop always runs at least once,
 * so the input this time reaches "Go west, yong" and stops right there
 * because the next attempt of the while loop to iterate again Fails
 * since it has Failed for the expected condition of "while input chars are different than g"
*/

/* d. same as 'a.' but this time after the scanf
 * in the for loop initiliazation we have assigned '$' to ch
 * which causes the first input if correct/wrong to print the first
 * input character to be with replaced value of $
*/
