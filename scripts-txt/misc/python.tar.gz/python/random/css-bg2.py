from gi.repository import Gtk, Gdk

def focus_in(*args):
    print 'focus_in called'

def focus_out(*args):
    print 'focus_out called'

window = Gtk.Window()
window.connect('destroy', Gtk.main_quit)
screen = Gdk.Screen.get_default()
css_provider = Gtk.CssProvider()
css_provider.load_from_path('style.css')
priority = Gtk.STYLE_PROVIDER_PRIORITY_USER
context = Gtk.StyleContext()
context.add_provider_for_screen(screen, css_provider, priority)
fname = Gtk.Entry(text='First Name')
lname = Gtk.Entry(text='Last Name')
button = Gtk.Button('Submit')
fname.connect('focus-in-event', focus_in)
fname.connect('focus-out-event', focus_out)
vbox = Gtk.VBox()
vbox.add(fname)
vbox.add(lname)
vbox.add(button)
window.add(vbox)
window.show_all()
Gtk.main() 
