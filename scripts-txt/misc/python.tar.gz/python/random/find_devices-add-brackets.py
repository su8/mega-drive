from subprocess import Popen,PIPE
import shlex


list2 = Popen(shlex.split("python2 /home/frost/Desktop/usb-imagewriter-0.1.99/usb-imagewriter-0.1.99/lib/find_devices.py"), stdout=PIPE).communicate()[0]
list2 = list2.strip().split('\n')
for item in list2:
    name, path = item.split(',')
    print name+' ('+path.lstrip()+')'
