/* proto.c -- uses a function prototy */
#include <stdio.h>
#include <stdlib.h>

int imax(int, int); /* prototype */

int main(void)
{

    printf("The maximum of %d and %d is %d.\n",
        3, 5, imax(3, 5));
    
    printf("The maximum of %d and %d is %d.\n",
        3, 5, imax(3.0, 5.0));

    return EXIT_SUCCESS;
}

int imax(int n, int m)
{
    return (n > m ? n : m);
}