#ifndef NCLYR_IFACES_TUI_TUI_MAIN_H
#define NCLYR_IFACES_TUI_TUI_MAIN_H

#include "iface.h"

void tui_main_loop(struct nclyr_iface *iface, struct nclyr_pipes *pipes);

#endif
