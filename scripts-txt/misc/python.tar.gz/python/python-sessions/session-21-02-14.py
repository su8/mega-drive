Python 3.3.3 (default, Nov 26 2013, 13:33:18) 
[GCC 4.8.2] on linux
Type "copyright", "credits" or "license()" for more information.
>>> import sqlite3
>>> sqlite3.version
'2.6.0'
>>> sqlite3.sqlite_version
'3.8.3'
>>> sqlite3 test.db
SyntaxError: invalid syntax
>>> import sys
>>> con = None
>>> try:
	con = sqlite3.connect('test.db')
	cur = con.cursor()
	cur.execute('SELECT SQLITE_VERSION()')
	data = cur.fetchone()
	print("SQLITE version {version}".format(version=data))
except sqlite3.Error, e:
	
SyntaxError: invalid syntax
>>> try:
	con = sqlite3.connect('test.db')
	cur = con.cursor()
	cur.execute('SELECT SQLITE_VERSION()')
	data = cur.fetchone()
	print("SQLITE version {version}".format(version=data))
except sqlite3.Error as e:
	print("Error {0}:".format(e.args[0]))
	sys.exit(1)

	
<sqlite3.Cursor object at 0x7effc7e35f80>
SQLITE version ('3.8.3',)
>>> 
>>> 
>>> try:
	con = sqlite3.connect('test.db')
	cur = con.cursor()
	cur.execute('SELECT SQLITE_VERSION()')
	data = cur.fetchone()
	print("SQLITE version {version}".format(version=data))
except sqlite3.Error as e:
	print("Error {0}:".format(e.args[0]))
	sys.exit(1)
finally:
	if con:
		con.close()

		
<sqlite3.Cursor object at 0x7effc7e35f10>
SQLITE version ('3.8.3',)
>>> try:
	con = sqlite3.connect('teste.db')
	cur = con.cursor()
	cur.execute('SELECT SQLITE_VERSION()')
	data = cur.fetchone()
	print("SQLITE version {version}".format(version=data))
except sqlite3.Error as e:
	print("Error {0}:".format(e.args[0]))
	sys.exit(1)
finally:
	if con:
		con.close()

		
<sqlite3.Cursor object at 0x7effc7e35f80>
SQLITE version ('3.8.3',)
>>> try:
	con = sqlite3.connect('tesqeqwt.db')
	cur = con.cursor()
	cur.execute('SELECT SQLITE_VERSION()')
	data = cur.fetchone()
	print("SQLITE version {version}".format(version=data))
except sqlite3.Error as e:
	print("Error {0}:".format(e.args[0]))
	sys.exit(1)
finally:
	if con:
		con.close()

		
<sqlite3.Cursor object at 0x7effc7e35f10>
SQLITE version ('3.8.3',)
>>> con = lite.connect('test.db')
Traceback (most recent call last):
  File "<pyshell#29>", line 1, in <module>
    con = lite.connect('test.db')
NameError: name 'lite' is not defined
>>> con = sqlite3.connect('test.db')
>>> with con:
    
    cur = con.cursor()    
    cur.execute('SELECT SQLITE_VERSION()')
    
    data = cur.fetchone()
    
    print("SQLITE version {0}".format(data))

    
<sqlite3.Cursor object at 0x7effcd0aab90>
SQLITE version ('3.8.3',)
>>> with con:
    
    cur = con.cursor()    
    cur.execute("CREATE TABLE Cars(Id INT, Name TEXT, Price INT)")
    cur.execute("INSERT INTO Cars VALUES(1,'Audi',52642)")
    cur.execute("INSERT INTO Cars VALUES(2,'Mercedes',57127)")
    cur.execute("INSERT INTO Cars VALUES(3,'Skoda',9000)")
    cur.execute("INSERT INTO Cars VALUES(4,'Volvo',29000)")
    cur.execute("INSERT INTO Cars VALUES(5,'Bentley',350000)")
    cur.execute("INSERT INTO Cars VALUES(6,'Citroen',21000)")
    cur.execute("INSERT INTO Cars VALUES(7,'Hummer',41400)")
    cur.execute("INSERT INTO Cars VALUES(8,'Volkswagen',21600)")

    
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
<sqlite3.Cursor object at 0x7effc7e35f10>
>>> cars = (
    (1, 'Audi', 52642),
    (2, 'Mercedes', 57127),
    (3, 'Skoda', 9000),
    (4, 'Volvo', 29000),
    (5, 'Bentley', 350000),
    (6, 'Hummer', 41400),
    (7, 'Volkswagen', 21600)
)
>>> 
>>> with con:
    
    cur = con.cursor()    
    
    cur.execute("DROP TABLE IF EXISTS Cars")
    cur.execute("CREATE TABLE Cars(Id INT, Name TEXT, Price INT)")
    cur.executemany("INSERT INTO Cars VALUES(?, ?, ?)", cars)

    
<sqlite3.Cursor object at 0x7effcd0aab90>
<sqlite3.Cursor object at 0x7effcd0aab90>
<sqlite3.Cursor object at 0x7effcd0aab90>
>>> con = lite.connect(':memory:')
Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    con = lite.connect(':memory:')
NameError: name 'lite' is not defined
>>> con = sqlite3.connect(':memory:')
>>> with con:
    
    cur = con.cursor()    
    cur.execute("CREATE TABLE Friends(Id INTEGER PRIMARY KEY, Name TEXT);")
    cur.execute("INSERT INTO Friends(Name) VALUES ('Tom');")
    cur.execute("INSERT INTO Friends(Name) VALUES ('Rebecca');")
    cur.execute("INSERT INTO Friends(Name) VALUES ('Jim');")
    cur.execute("INSERT INTO Friends(Name) VALUES ('Robert');")
        
    lid = cur.lastrowid
    print("The last Id of the inserted row is" , lid)

    
<sqlite3.Cursor object at 0x7effcd0aab20>
<sqlite3.Cursor object at 0x7effcd0aab20>
<sqlite3.Cursor object at 0x7effcd0aab20>
<sqlite3.Cursor object at 0x7effcd0aab20>
<sqlite3.Cursor object at 0x7effcd0aab20>
The last Id of the inserted row is 4
>>> with con:    
    
    cur = con.cursor()    
    cur.execute("SELECT * FROM Cars")

    rows = cur.fetchall()

    for row in rows:
        print row
        
SyntaxError: invalid syntax
>>> with con:    
    
    cur = con.cursor()    
    cur.execute("SELECT * FROM Cars")

    rows = cur.fetchall()

    for row in rows:
        print(row)

        
Traceback (most recent call last):
  File "<pyshell#46>", line 4, in <module>
    cur.execute("SELECT * FROM Cars")
sqlite3.OperationalError: no such table: Cars
>>> con = sqlite3.connect('test.db')
>>> with con:    
    
    cur = con.cursor()    
    cur.execute("SELECT * FROM Cars")

    rows = cur.fetchall()

    for row in rows:
        print(row)

        
<sqlite3.Cursor object at 0x7effcd0aac00>
(1, 'Audi', 52642)
(2, 'Mercedes', 57127)
(3, 'Skoda', 9000)
(4, 'Volvo', 29000)
(5, 'Bentley', 350000)
(6, 'Hummer', 41400)
(7, 'Volkswagen', 21600)
>>> a, b, c = (1, 'Audi', 52642)
>>> a
1
>>> b
'Audi'
>>> c
52642
>>> with con:
    
    cur = con.cursor()    
    cur.execute("SELECT * FROM Cars")

    while True:
      
        row = cur.fetchone()
        
        if row == None:
            break
            
        print(row[0], row[1], row[2])

        
<sqlite3.Cursor object at 0x7effc7e35f10>
1 Audi 52642
2 Mercedes 57127
3 Skoda 9000
4 Volvo 29000
5 Bentley 350000
6 Hummer 41400
7 Volkswagen 21600
>>> with con:
    
    cur = con.cursor()    
    cur.execute("SELECT * FROM Cars")

    while True:
      
        row = cur.fetchone()
        
        if row == None:
            break
            
        return row[0], row[1], row[2]
SyntaxError: 'return' outside function
>>> def az():
	with con:
    
	    cur = con.cursor()    
	    cur.execute("SELECT * FROM Cars")

	    while True:
      
		row = cur.fetchone()
        
		if row == None:
		    break
            
		return row[0], row[1], row[2]
	
SyntaxError: inconsistent use of tabs and spaces in indentation
>>> def az():
    with con:
    
        cur = con.cursor()    
        cur.execute("SELECT * FROM Cars")

        while True:
      
            row = cur.fetchone()
        
            if row == None:
                break
            
            return row[0], row[1], row[2]

        
>>> az()
(1, 'Audi', 52642)
>>> az()
(1, 'Audi', 52642)
>>> with con:
    
    cur = con.cursor()    
    cur.execute("SELECT * FROM Cars")

    while True:
      
        row = cur.fetchone()
        
        if row == None:
            break
            
        print(row[0], row[1], row[2])

        
<sqlite3.Cursor object at 0x7effcd0aac00>
1 Audi 52642
2 Mercedes 57127
3 Skoda 9000
4 Volvo 29000
5 Bentley 350000
6 Hummer 41400
7 Volkswagen 21600
>>> with con:
    
    con.row_factory = sqlite3.Row
       
    cur = con.cursor() 
    cur.execute("SELECT * FROM Cars")

    rows = cur.fetchall()

    for row in rows:
        print("{} {} {}".format((row["Id"], row["Name"], row["Price"])))

        
<sqlite3.Cursor object at 0x7effc7e35f10>
Traceback (most recent call last):
  File "<pyshell#67>", line 11, in <module>
    print("{} {} {}".format((row["Id"], row["Name"], row["Price"])))
IndexError: tuple index out of range
>>> with con:
    
    con.row_factory = sqlite3.Row
       
    cur = con.cursor() 
    cur.execute("SELECT * FROM Cars")

    rows = cur.fetchall()

    for row in rows:
        print("{} {} {}".format(row["Id"], row["Name"], row["Price"]))

        
<sqlite3.Cursor object at 0x7effcd0aac00>
1 Audi 52642
2 Mercedes 57127
3 Skoda 9000
4 Volvo 29000
5 Bentley 350000
6 Hummer 41400
7 Volkswagen 21600
>>> with con:

    cur = con.cursor()    

    cur.execute("UPDATE Cars SET Price=? WHERE Id=?", (62300, 1))        
    con.commit()
    
    print("Number of rows updated:",cur.rowcount)

    
<sqlite3.Cursor object at 0x7effc7e35f10>
Number of rows updated: 1
>>> with con:
    
    cur = con.cursor()    
    cur.execute("SELECT * FROM Cars")

    while True:
      
        row = cur.fetchone()
        
        if row == None:
            break
            
        print(row[0], row[1], row[2])

        
<sqlite3.Cursor object at 0x7effcd0aac00>
1 Audi 62300
2 Mercedes 57127
3 Skoda 9000
4 Volvo 29000
5 Bentley 350000
6 Hummer 41400
7 Volkswagen 21600
>>> uID = 4
>>> with con:

    cur = con.cursor()    

    cur.execute("SELECT Name, Price FROM Cars WHERE Id=:Id", 
        {"Id": uID})        
    con.commit()
    
    row = cur.fetchone()
    print(row[0], row[1])

    
<sqlite3.Cursor object at 0x7effc7e35f10>
Volvo 29000
>>> with con:

    cur = con.cursor()    

    cur.execute("SELECT Name, Price FROM Cars WHERE Id=:(?)", 
        (uID))        
    con.commit()
    
    row = cur.fetchone()
    print(row[0], row[1])

    
Traceback (most recent call last):
  File "<pyshell#78>", line 6, in <module>
    (uID))
sqlite3.OperationalError: unrecognized token: ":"
>>> with con:

    cur = con.cursor()    

    cur.execute("SELECT Name, Price FROM Cars WHERE Id=(?)", 
        (uID))        
    con.commit()
    
    row = cur.fetchone()
    print(row[0], row[1])

    
Traceback (most recent call last):
  File "<pyshell#80>", line 6, in <module>
    (uID))
ValueError: parameters are of unsupported type
>>> with con:

    cur = con.cursor()    

    cur.execute("SELECT Name, Price FROM Cars WHERE Id=:(?)", 
        (uID,))        
    con.commit()
    
    row = cur.fetchone()
    print(row[0], row[1])

    
Traceback (most recent call last):
  File "<pyshell#82>", line 6, in <module>
    (uID,))
sqlite3.OperationalError: unrecognized token: ":"
>>> with con:

    cur = con.cursor()    

    cur.execute("SELECT Name, Price FROM Cars WHERE Id=(?)", 
        (uID,))        
    con.commit()
    
    row = cur.fetchone()
    print(row[0], row[1])

    
<sqlite3.Cursor object at 0x7effcd0aab90>
Volvo 29000
>>> class Proxy:
	def __init__(self, obj):
		self.obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			return setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name, value)
		else:
			print('delattr:',name)
			return delattr(self._obj,name)

		
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)

		
>>> s = Spam(2)
>>> s
<__main__.Spam object at 0x7effcd0bdd90>
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)
	def __repr__(self):
		return self.x

	
>>> class Proxy:
	def __init__(self, obj):
		self.obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			return setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name, value)
		else:
			print('delattr:',name)
			return delattr(self._obj,name)
	def __repr__(self):
		return self.obj

	
>>> s = Spam(2)
>>> s
Traceback (most recent call last):
  File "<pyshell#117>", line 1, in <module>
    s
TypeError: __repr__ returned non-string (type int)
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)
	def __repr__(self):
		return str(self.x)

	
>>> class Proxy:
	def __init__(self, obj):
		self.obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			return setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name, value)
		else:
			print('delattr:',name)
			return delattr(self._obj,name)
	def __repr__(self):
		return str(self.obj)

	
>>> s = Spam(2)
>>> s
2
>>> p = Proxy(s)
setattr: obj 2
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr:Traceback (most recent call last):
  File "<pyshell#124>", line 1, in <module>
    p = Proxy(s)
  File "<pyshell#121>", line 3, in __init__
    self.obj = obj
  File "<pyshell#121>", line 12, in __setattr__
    return setattr(self._obj,name,value)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#121>", line 5, in __getattr__
    print('getattr:',name)
  File "/usr/lib/python3.3/idlelib/PyShell.py", line 1336, in write
    return self.shell.write(s, self.tags)
KeyboardInterrupt
>>> class Proxy:
	def __init__(self, obj):
		self.obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			return setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name, value)
		else:
			print('delattr:',name)
			return delattr(self._obj,name)

		
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)

		
>>> s = Spam(2)
>>> p = Proxy(s)
setattr: obj <__main__.Spam object at 0x7effc711c850>
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr:
 _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: Traceback (most recent call last):
  File "<pyshell#130>", line 1, in <module>
    p = Proxy(s)
  File "<pyshell#126>", line 3, in __init__
    self.obj = obj
  File "<pyshell#126>", line 12, in __setattr__
    return setattr(self._obj,name,value)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#126>", line 5, in __getattr__
    print('getattr:',name)
    return self.shell.write(s, self.tags)
KeyboardInterrupt
>>> class Proxy:
	def __init__(self, obj):
		self.obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name, value)
		else:
			print('delattr:',name)
			delattr(self._obj,name)
	def __repr__(self):
		return str(self.obj)

	
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)
	def __repr__(self):
		return str(self.x)

	
>>> s = Spam(2)
>>> p = Proxy(s)
setattr: obj 2
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
Traceback (most recent call last):
  File "<pyshell#136>", line 1, in <module>
    p = Proxy(s)
  File "<pyshell#132>", line 3, in __init__
    self.obj = obj
  File "<pyshell#132>", line 12, in __setattr__
    setattr(self._obj,name,value)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#132>", line 5, in __getattr__
    print('getattr:',name)
  File "/usr/lib/python3.3/idlelib/PyShell.py", line 1336, in write
    return self.shell.write(s, self.tags)
KeyboardInterrupt
>>> class Proxy:
	def __init__(self, obj):
		self.obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name, value)
		else:
			print('delattr:',name)
			delattr(self._obj,name)

			
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)

		
>>> Proxy(Spam(2))
setattr: obj <__main__.Spam object at 0x7effcd0bdd10>
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
getattr: _obj
Traceback (most recent call last):
  File "<pyshell#141>", line 1, in <module>
    Proxy(Spam(2))
  File "<pyshell#138>", line 3, in __init__
    self.obj = obj
  File "<pyshell#138>", line 12, in __setattr__
    setattr(self._obj,name,value)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 6, in __getattr__
    return getattr(self._obj,name)
  File "<pyshell#138>", line 5, in __getattr__
    print('getattr:',name)
  File "/usr/lib/python3.3/idlelib/PyShell.py", line 1336, in write
    return self.shell.write(s, self.tags)
KeyboardInterrupt
>>> class Proxy:
	def __init__(self, obj):
		self.obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name)
		else:
			print('delattr:',name)
			delattr(self._obj,name)

>>> 
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)

>>> s = Spam(2)
>>> class Proxy:
	def __init__(self, obj):
		self._obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name)
		else:
			print('delattr:',name)
			delattr(self._obj,name)

			
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)

		
>>> s = Spam(2)
>>> p = Proxy(s)
>>> p
<__main__.Proxy object at 0x7effc7e328d0>
>>> 	def __repr__(self):
		return self.x
	
SyntaxError: unexpected indent
>>> class Proxy:
	def __init__(self, obj):
		self._obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name)
		else:
			print('delattr:',name)
			delattr(self._obj,name)
	def __repr__(self):
		return self._obj

	
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)
	def __repr__(self):
		return self.x

	
>>> s = Spam(2)
>>> p = Proxy(s)
>>> s
Traceback (most recent call last):
  File "<pyshell#162>", line 1, in <module>
    s
TypeError: __repr__ returned non-string (type int)
>>> p
Traceback (most recent call last):
  File "<pyshell#163>", line 1, in <module>
    p
TypeError: __repr__ returned non-string (type Spam)
>>> class Proxy:
	def __init__(self, obj):
		self._obj = obj
	def __getattr__(self, name):
		print('getattr:',name)
		return getattr(self._obj,name)
	def __setattr__(self, name, value):
		if name.startswith('_'):
			super().__setattr__(name, value)
		else:
			print('setattr:',name,value)
			setattr(self._obj,name,value)
	def __delattr__(self, name):
		if name.startswith('_'):
			super().__delattr__(name)
		else:
			print('delattr:',name)
			delattr(self._obj,name)
	def __repr__(self):
		return str(self._obj)

	
>>> class Spam:
	def __init__(self, x):
		self.x = x
	def bar(self, y):
		print("Spam.bar:", self.x, y)
	def __repr__(self):
		return str(self.x)

	
>>> s = Spam(2)
>>> p = Proxy(s)
>>> s
2
>>> p
2
>>> p.x
getattr: x
2
>>> print(p.x)
getattr: x
2
>>> p.y
getattr: y
Traceback (most recent call last):
  File "<pyshell#175>", line 1, in <module>
    p.y
  File "<pyshell#165>", line 6, in __getattr__
    return getattr(self._obj,name)
AttributeError: 'Spam' object has no attribute 'y'
>>> p.bar
getattr: bar
<bound method Spam.bar of 2>
>>> p.bar(3)
getattr: bar
Spam.bar: 2 3
>>> getattr: bar

>>> getattr: bar
p.bar("ew")
getattr: bar
Spam.bar: 2 ew
>>> p.x = 47
setattr: x 47
>>> p.x
getattr: x
47
>>> p.x = 45
setattr: x 45
>>> p.x
getattr: x
45
>>> import time
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return cls(r.tm_year, t.tm_mon, t.tm_mday)

	
>>> Date(2012, 12, 21)
<__main__.Date object at 0x7effc7135390>
>>> Date.today()
Traceback (most recent call last):
  File "<pyshell#196>", line 1, in <module>
    Date.today()
  File "<pyshell#194>", line 9, in today
    return cls(r.tm_year, t.tm_mon, t.tm_mday)
NameError: global name 'r' is not defined
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return cls(t.tm_year, t.tm_mon, t.tm_mday)

	
>>> Date.today()
<__main__.Date object at 0x7effc7135510>
>>> class NewDate(Date):
	pass

>>> NewDate.today()
<__main__.NewDate object at 0x7effc7135590>
>>> time.localtime()
time.struct_time(tm_year=2014, tm_mon=2, tm_mday=21, tm_hour=16, tm_min=45, tm_sec=53, tm_wday=4, tm_yday=52, tm_isdst=0)
>>> t = time.localtime()
>>> print((t.tm_year, t.tm_mon, t.tm_mday))
(2014, 2, 21)
>>> print(t.tm_year, t.tm_mon, t.tm_mday)
2014 2 21
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday

	
>>> Date.today()
(2014, 2, 21)
>>> class NewDate(Date):
	pass

>>> NewDate.today()
(2014, 2, 21)
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return (t.tm_year, t.tm_mon, t.tm_mday)

	
>>> Date.today()
(2014, 2, 21)
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return self.year, self.month, self.day

	
>>> Date(2014, 2, 21)
Traceback (most recent call last):
  File "<pyshell#221>", line 1, in <module>
    Date(2014, 2, 21)
TypeError: __repr__ returned non-string (type tuple)
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year, self.month, self.day)

	
>>> Date(2014, 2, 21)
Traceback (most recent call last):
  File "<pyshell#224>", line 1, in <module>
    Date(2014, 2, 21)
  File "/usr/lib/python3.3/idlelib/rpc.py", line 614, in displayhook
    text = repr(value)
  File "<pyshell#223>", line 11, in __repr__
    return str(self.year, self.month, self.day)
TypeError: str() argument 2 must be str, not int
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year), str(self.month), str(self.day)

	
>>> Date(2014, 2, 21)
Traceback (most recent call last):
  File "<pyshell#227>", line 1, in <module>
    Date(2014, 2, 21)
TypeError: __repr__ returned non-string (type tuple)
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year) + str(self.month) + str(self.day)

	
>>> Date(2014, 2, 21)
2014221
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year), str(self.month), str(self.day), sep=" "
	
SyntaxError: invalid syntax
>>> print("1,2,3,4,5", sep="0")
1,2,3,4,5
>>> print("1,2","3,4","5", sep="sep")
1,2sep3,4sep5
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return (str(self.year), str(self.month), str(self.day), sep=" ")
	
SyntaxError: invalid syntax
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year)

	
>>> Date(2014, 2, 21)
2014
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year) + " " + \str(self.month) + str(self.day)
	
SyntaxError: unexpected character after line continuation character
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year) + " " + /str(self.month) + str(self.day)
	
SyntaxError: invalid syntax
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		t = time.localtime()
		return t.tm_year, t.tm_mon, t.tm_mday
	def __repr__(self):
		return str(self.year) + " " + str(self.month) + " " + str(self.day)

	
>>> Date(2014, 2, 21)
2014 2 21
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day

		
>>> Date.__new__(year)
Traceback (most recent call last):
  File "<pyshell#247>", line 1, in <module>
    Date.__new__(year)
NameError: name 'year' is not defined
>>> Date.__new__(Date)
<__main__.Date object at 0x7effc71405d0>
>>> d = Date.__new__(Date)
>>> d
<__main__.Date object at 0x7effc7140290>
>>> Date()
Traceback (most recent call last):
  File "<pyshell#251>", line 1, in <module>
    Date()
TypeError: __init__() missing 3 required positional arguments: 'year', 'month', and 'day'
>>> data = {'year':2012,'month':8,'day':29}
>>> for key, value in data.items():
	setattr(d, key, value)

	
>>> data.items()
dict_items([('month', 8), ('year', 2012), ('day', 29)])
>>> data['month']
8
>>> 'year' in data
True
>>> 'sex' in data
False
>>> d.year
2012
>>> d.month
8
>>> d.day
29
>>> for key, value in data.items():
	print(key, value)

	
month 8
year 2012
day 29
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		d = cls.__new__(cls)
		t = time.localtime()
		d.year = t.tm_year
		d.month = t.tm_mon
		d.day = t.tm_mday
		return d
	def __repr__(self):
		return str(self.year) + " " + str(self.month) + " " + str(self.day)

	
>>> Date(2014, 2, 21)
2014 2 21
>>> Date.today()
2014 2 21
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		d = cls.__new__(cls)
		t = time.localtime()
		d.year = t.tm_year
		d.month = t.tm_mon
		d.day = t.tm_mday
		return d
	def __repr__(self):
		return str(self.year) + " " + str(self.month) + " " + str(self.day)

	
>>> Date.today()
2014 2 21
>>> class Date:
	def __init__(self, year, month, day):
		self.year = year
		self.month = month
		self.day = day
	@classmethod
	def today(cls):
		d = cls.__new__(cls)
		t = time.localtime()
		d.year = t.tm_year
		d.month = t.tm_mon
		d.day = t.tm_mday
		print(d.year,d.month,d.day, sep=" ")
		return d
	def __repr__(self):
		return str(self.year) + " " + str(self.month) + " " + str(self.day)

	
>>> Date.today()
2014 2 21
2014 2 21
>>> 
