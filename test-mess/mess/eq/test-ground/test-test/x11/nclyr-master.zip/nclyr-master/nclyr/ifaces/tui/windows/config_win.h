#ifndef NCLYR_CURSES_CONFIG_WIN_H
#define NCLYR_CURSES_CONFIG_WIN_H

#include "window.h"
#include "line_win.h"

struct nclyr_win *config_win_new(void);

#endif
