/* 12. You want to write a function that returns a long value. What should your definition of
the function include?
*/
#include <stdio.h>
int func(long ret_val);

int main(void)
{
    long i = 66000;
    
    long f;
    
    f = func(i);
    
    printf("%ld", f);
    
    return 0;
}

int func(long ret_val)
{
    long i;
    for (i = 0; i < ret_val; i++)
    {
    }
        
    return i + ret_val;
}
