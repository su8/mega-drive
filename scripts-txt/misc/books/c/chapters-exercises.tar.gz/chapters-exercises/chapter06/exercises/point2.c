/* 2. Use nested loops to produce the following pattern: */
#include <stdio.h>
#define CHARS 6
int main(void)
{
    int row;
    char ch;
    const char dolla = '$';

    for (row = 6; row != 0; row--)
    {
        for (ch = row; ch < CHARS; ch++)
        {
            printf("%c", dolla);
        }
        printf("\n");
    }

    return 0;
}
