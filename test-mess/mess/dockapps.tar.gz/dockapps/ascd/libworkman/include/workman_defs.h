#ifndef WORKMAN_DEFS_H
#define WORKMAN_DEFS_H
/*
 * $Id: workman_defs.h,v 1.4 1999/02/14 09:50:47 dirk Exp $
 *
 * This file is part of WorkMan, the civilized CD player program
 * (c) 1991-1997 by Steven Grimm (original author)
 * (c) by Dirk F�rsterling (current 'author' = maintainer)
 * The maintainer can be contacted by his e-mail address:
 * milliByte@DeathsDoor.com 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * #defined CONSTANTS
 * 
 * Too bad this file seems to be so empty...
 *
 */

#include "wm_version.h"

#endif /* WORKMAN_DEFS_H */
