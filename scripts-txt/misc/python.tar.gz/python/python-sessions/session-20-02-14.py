Python 3.3.3 (default, Nov 26 2013, 13:33:18) 
[GCC 4.8.2] on linux
Type "copyright", "credits" or "license()" for more information.
>>> import pls
>>> for x in pls.last.upgrade():
	print(x)

	
-> Nothing to upgrade for 2014-02-20 ::
-> Nothing to upgrade for 2014-02-17 ::
-> Nothing to upgrade for 2014-02-16 ::
-> You haven't upgraded your system for at least 4 days ::
-> Always keep your system up-to-date ! ::
>>> pls.last.access()
'Thu Feb 20 10:02:41 2014'
>>> setattr("d","b")
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    setattr("d","b")
TypeError: setattr expected 3 arguments, got 2
>>> setattr("d","b",'g')
Traceback (most recent call last):
  File "<pyshell#6>", line 1, in <module>
    setattr("d","b",'g')
AttributeError: 'str' object has no attribute 'b'
>>> import numbers, collections
>>> isinstance('3.4', numbers.Real)
False
>>> isinstance(3.4, numbers.Real)
True
>>> isinstance('3', numbers.Real)
False
>>> isinstance('3.4', collections.Sequence)
True
>>> isinstance('3.4', collections.Iterable)
True
>>> isinstance('3.4', collections.Sized)
True
>>> isinstance('3.4', collections.Mapping)
False
>>> isinstance(('3.4'), collections.Mapping)
False
>>> class Descriptor:
	def __init__(self, name=None, **opts):
		self.name = name
		for key, value in opts.items():
			setattr(self, key, value)
	def __set__(self, instance, value):
		instance.__dict__[self.name] = value

		
>>> class Typed(Descriptor):
	expected_type = type(None)
	def __set__(self, instance, value):
		if not isinstance(value, self.expected_type):
			raise TypeError('expected ' + str(self.expected_type))
		super().__set__(instance, value)

		
>>> class Unsigned(Descriptor):
	def __set__(self, instance, value):
		if value < 0:
			raise ValueError('Expected >= 0')
		super().__set__(instance, value)

		
>>> class MaxSized(Descriptor):
	def __init__(self, name=None, **opts):
		if 'size' not in opts:
			raise TypeError('missing size option')
		super().__init__(name, **opts)
	def __set__(self, instance, value):
		if len(value) >= self.size:
			raise ValueError('size mut be < ' + str(self.size))
		super().__set__(instance, value)

		
>>> class Integer(Typed):
	expected_type = int

	
>>> class UnsignedInteger(Integer, Unsigned):
	pass

>>> class UnsignedFloat(Float, Unsigned):
	pass

Traceback (most recent call last):
  File "<pyshell#56>", line 1, in <module>
    class UnsignedFloat(Float, Unsigned):
NameError: name 'Float' is not defined
>>> class UnsignedInteger(Integer, Unsigned):
	pass

>>> class Float(Typed):
	expected_type = float

	
>>> class UnsignedFloat(Float, Unsigned):
	pass

>>> class String(Typed):
	expected_type = str

	
>>> class SizedString(String, MaxSized):
	pass

>>> class Stock:
	name = SizedString('name', size=8)
	shares = UnsignedInteger('shares')
	price = UnsignedFloat('price')
	def __init__(self, name, shares, price):
		self.name = name
		self.shares = shares
		self.price = price

		
>>> s = Stock("ACME", 50, 91.1)
>>> s.name
'ACME'
>>> s.shares
50
>>> s.price
91.1
>>> s.1
SyntaxError: invalid syntax
>>> s.a
Traceback (most recent call last):
  File "<pyshell#86>", line 1, in <module>
    s.a
AttributeError: 'Stock' object has no attribute 'a'
>>> s.shares = 423
>>> s.shares
423
>>> s.shares = -1
Traceback (most recent call last):
  File "<pyshell#89>", line 1, in <module>
    s.shares = -1
  File "<pyshell#30>", line 6, in __set__
    super().__set__(instance, value)
  File "<pyshell#36>", line 4, in __set__
    raise ValueError('Expected >= 0')
ValueError: Expected >= 0
>>> s.price = 'a lot'
Traceback (most recent call last):
  File "<pyshell#90>", line 1, in <module>
    s.price = 'a lot'
  File "<pyshell#30>", line 5, in __set__
    raise TypeError('expected ' + str(self.expected_type))
TypeError: expected <class 'float'>
>>> str(float)
"<class 'float'>"
>>> type(float)
<class 'type'>
>>> s.name = '12345678'
Traceback (most recent call last):
  File "<pyshell#93>", line 1, in <module>
    s.name = '12345678'
  File "<pyshell#30>", line 6, in __set__
    super().__set__(instance, value)
  File "<pyshell#47>", line 8, in __set__
    raise ValueError('size mut be < ' + str(self.size))
ValueError: size mut be < 8
>>> s.name = '1234567'
>>> s.name
'1234567'
>>> s.shares = -1
Traceback (most recent call last):
  File "<pyshell#96>", line 1, in <module>
    s.shares = -1
  File "<pyshell#30>", line 6, in __set__
    super().__set__(instance, value)
  File "<pyshell#36>", line 4, in __set__
    raise ValueError('Expected >= 0')
ValueError: Expected >= 0
>>> s.shares = 1
>>> s.shares
1
>>> s.name, s.shares, s.price
('1234567', 1, 91.1)
>>> stock("ACME", 50, 91.1)
Traceback (most recent call last):
  File "<pyshell#100>", line 1, in <module>
    stock("ACME", 50, 91.1)
NameError: name 'stock' is not defined
>>> Stock("ACME", 50, 91.1)
<__main__.Stock object at 0x7f9a6af430d0>
>>> 
