Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> from urllib.parse import urlparse
>>> from urllib.request import urlopen
>>> import re
>>> LINK_REGEX = re.compile("<a [^>]*href=['\"]([^'\"]+)['\"][^>]*>")
>>> class LinkCollector(object):
	def __init__(self, url):
		self.url = "http://+" + urlparse(url).netloc
		self.collected_links = set()
		self.visited_links = set()
	def collect_links(self, path="/"):
		full_url = self.url + path
		self.visited_links.add(full_url)
		page = str(urlopen(full_url).read())
		links = {self.normalize_url(path, link
					    ) for link in links}
		self.collected_links = links.union(self.collected_links)
		unvisited_links = links.difference(self.visited_links)
		print(links, self.visited_links, self.collected_links, unvisited_links)
		for link in unvisited_links:
			if link.startswith(self.url):
				self.collect_links(urlparse(link).path)

				
>>> # if __name__ == '__main__':
>>> collector = LinkCollector('http://en.wikipedia.org/wiki/Cavalier_King_Charles_Spaniel')
>>> collector.collect_links()
Traceback (most recent call last):
  File "/usr/lib/python3.4/urllib/request.py", line 1235, in do_open
    h.request(req.get_method(), req.selector, req.data, headers)
  File "/usr/lib/python3.4/http/client.py", line 1066, in request
    self._send_request(method, url, body, headers)
  File "/usr/lib/python3.4/http/client.py", line 1104, in _send_request
    self.endheaders(body)
  File "/usr/lib/python3.4/http/client.py", line 1062, in endheaders
    self._send_output(message_body)
  File "/usr/lib/python3.4/http/client.py", line 907, in _send_output
    self.send(msg)
  File "/usr/lib/python3.4/http/client.py", line 842, in send
    self.connect()
  File "/usr/lib/python3.4/http/client.py", line 820, in connect
    self.timeout, self.source_address)
  File "/usr/lib/python3.4/socket.py", line 491, in create_connection
    for res in getaddrinfo(host, port, 0, SOCK_STREAM):
  File "/usr/lib/python3.4/socket.py", line 530, in getaddrinfo
    for res in _socket.getaddrinfo(host, port, family, type, proto, flags):
socket.gaierror: [Errno -2] Name or service not known

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<pyshell#24>", line 1, in <module>
    collector.collect_links()
  File "<pyshell#21>", line 9, in collect_links
    page = str(urlopen(full_url).read())
  File "/usr/lib/python3.4/urllib/request.py", line 153, in urlopen
    return opener.open(url, data, timeout)
  File "/usr/lib/python3.4/urllib/request.py", line 455, in open
    response = self._open(req, data)
  File "/usr/lib/python3.4/urllib/request.py", line 473, in _open
    '_open', req)
  File "/usr/lib/python3.4/urllib/request.py", line 433, in _call_chain
    result = func(*args)
  File "/usr/lib/python3.4/urllib/request.py", line 1261, in http_open
    return self.do_open(http.client.HTTPConnection, req)
  File "/usr/lib/python3.4/urllib/request.py", line 1238, in do_open
    raise URLError(err)
urllib.error.URLError: <urlopen error [Errno -2] Name or service not known>
>>> # for link in collector.collected_links:
>>> #    print(link)
>>> 
