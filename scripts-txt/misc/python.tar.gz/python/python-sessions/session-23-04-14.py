Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class User(object):
	def __init__(self, username, password):
		'''Create a new user object. The password will be encrypted before storing'''
		self.username = username
		self.password = self._encrypt_pw(password)
		self.is_logged_in = False
	def _encrypt_pw(self, password):
		'''Encrypt the password with the username and return the sha digest.'''
		hash_string = (self.username + password)
		hash_string = hash_string.encode('utf-8')
		return hashlib.sha256(hash_string).hexdigest()
	def check_password(self, password):
		'''Return True if the password is valid for this user, false otherwise'''
		encrypted = self._encrypt_pw(password)
		return encrypted == self.password

>>> class AuthException(Exception):
	def __init__(self, username, user=None):
		super().__init__(username, user)
		self.username = username
		self.user = user

		
>>> class UsernameAlreadyExists(AuthException):
	pass

>>> class PasswordTooShort(AuthException):
	pass

>>> class Authenticator(object):
	def __init__(self):
		'''Construct an authenticator to manage user logging in and out'''
		self.users = dict()
	def add_user(self, username, password):
		if username in self.users:
			raise UsernameAlreadyExists(username)
		if len(password) < 6:
			raise PasswordTooShort(username)
		self.users[username] = User(username, password)

		
>>> class InvalidUsername(AuthException):
	pass

>>> class InvalidPassword(AuthException):
	pass

>>> def login(self, username, password):
	try:
		user = self.users[username]
	except KeyError:
		raise InvalidUsername(username)
	if not user.check_password(password):
		raise InvalidPassword(username, user)
	user.is_logged_in = True
	return True

>>> def is_logged_in(self, username):
	if username in self.users:
		return self.users[username].is_logged_in
	return False

>>> authenticator = Authenticator()
>>> 
>>> class Authorizor(object):
	def __init__(self, authenticator):
		self.authenticator = authenticator
		self.permissions = dict()
	def add_permission(self, perm_name):
		'''create a new permission that users can be added to'''
		try:
			perm_set = self.permissions[perm_name]
		except KeyError:
			self.permissions[perm_name] = set()
		else:
			raise PermissionError("Permission Exists")
	def permit_user(self, perm_name, username):
		'''grant the given permission to the user'''
		try:
			perm_set = self.permissions[perm_name]
		except KeyError:
			raise PermissionError("Permission does not exists")
		else:
			if username not in self.authenticator.users:
				raise InvalidUsername(username)
			perm_set.add(username)

			
>>> class PermissionError(Exception):
	pass

>>> def check_permission(self, perm_name, username):
	if not self.authenticator.is_logged_in(username):
		raise NotLoggedInError(username)
	try:
		perm_set = self.permissions[perm_name]
	except KeyError:
		raise PermissionError("Permission does not exists")
	else:
		if username not in perm_set:
			raise NotPermittedError(username)
		else:
			return True

		
>>> class NotLoggedInError(AuthException):
	pass

>>> class NotPermittedError(AuthException):
	pass

>>> authorizor = Authorizor(authenticator)
>>> 
>>> authenticator.add_user('joe', 'joepassword')
Traceback (most recent call last):
  File "<pyshell#31>", line 1, in <module>
    authenticator.add_user('joe', 'joepassword')
  File "<pyshell#8>", line 10, in add_user
    self.users[username] = User(username, password)
  File "<pyshell#0>", line 5, in __init__
    self.password = self._encrypt_pw(password)
  File "<pyshell#0>", line 11, in _encrypt_pw
    return hashlib.sha256(hash_string).hexdigest()
NameError: name 'hashlib' is not defined
>>> import hashlib
>>> authenticator.add_user('joe', 'joepassword')
>>> authorizor.add_permission('paint')
>>> authorizor.check_permission('pain', 'joe')
Traceback (most recent call last):
  File "<pyshell#35>", line 1, in <module>
    authorizor.check_permission('pain', 'joe')
AttributeError: 'Authorizor' object has no attribute 'check_permission'
>>> authenticator.is_logged_in('joe')
Traceback (most recent call last):
  File "<pyshell#36>", line 1, in <module>
    authenticator.is_logged_in('joe')
AttributeError: 'Authenticator' object has no attribute 'is_logged_in'
>>> authenticator.login('joe', 'joepassword')
Traceback (most recent call last):
  File "<pyshell#37>", line 1, in <module>
    authenticator.login('joe', 'joepassword')
AttributeError: 'Authenticator' object has no attribute 'login'
>>> authenticator.check_permission('paint','joe')
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    authenticator.check_permission('paint','joe')
AttributeError: 'Authenticator' object has no attribute 'check_permission'
>>> authorizor.check_permission('paint','joe')
Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    authorizor.check_permission('paint','joe')
AttributeError: 'Authorizor' object has no attribute 'check_permission'
>>> authorizor.permit_user('mix','joe')
Traceback (most recent call last):
  File "<pyshell#20>", line 16, in permit_user
    perm_set = self.permissions[perm_name]
KeyError: 'mix'

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "<pyshell#40>", line 1, in <module>
    authorizor.permit_user('mix','joe')
  File "<pyshell#20>", line 18, in permit_user
    raise PermissionError("Permission does not exists")
PermissionError: Permission does not exists
>>> #basic menu interface that allows certain users to change or test a program
>>> #authenticator.add_user('joe', 'joepassword')
>>> #authorizor.add_permission('test program')
>>> #authorizor.add_permission('change program')
>>> #authorizor.permit_user('test program', 'joe')
>>> class Editor(object):
	def __init__(self):
		self.username = None
		self.menu_map = {
			"login": self.login,
			'test': self.test,
			'change': self.change,
			'quit': self.quit
			}
	def login(self):
		logged_in = False
		while not logged_in:
			username = input('username: ')
			password = input('password: ')
			try:
				logged_in = authenticator.login(
					username, password)
			except InvalidUsername:
				print('Sorry, that username does not exists')
			except InvalidPassword:
				print('Sorry, incorrect Password')
			else:
				self.username = username
	def is_permitted(self, permission):
		try:
			authorizor.check_permission(
				permission, self.username)
		except NotLoggedInError as e:
			print('{} is not logged in'.format(e.username))
		except NotPermittedError as e:
			print('{} cannot {}'.format(
				e.username, permission))
			return False
		else:
			return True
	def test(self):
		if self.is_permitted('test program'):
			print('Testing program now')
	def change(self):
		if self.is_permitted('change program')"
		
SyntaxError: EOL while scanning string literal
>>> class Editor(object):
	def __init__(self):
		self.username = None
		self.menu_map = {
			"login": self.login,
			'test': self.test,
			'change': self.change,
			'quit': self.quit
			}
	def login(self):
		logged_in = False
		while not logged_in:
			username = input('username: ')
			password = input('password: ')
			try:
				logged_in = authenticator.login(
					username, password)
			except InvalidUsername:
				print('Sorry, that username does not exists')
			except InvalidPassword:
				print('Sorry, incorrect Password')
			else:
				self.username = username
	def is_permitted(self, permission):
		try:
			authorizor.check_permission(
				permission, self.username)
		except NotLoggedInError as e:
			print('{} is not logged in'.format(e.username))
		except NotPermittedError as e:
			print('{} cannot {}'.format(
				e.username, permission))
			return False
		else:
			return True
	def test(self):
		if self.is_permitted('test program'):
			print('Testing program now')
	def change(self):
		if self.is_permitted('change program')"
		
SyntaxError: EOL while scanning string literal
>>> class Editor(object):
	def __init__(self):
		self.username = None
		self.menu_map = {
			"login": self.login,
			'test': self.test,
			'change': self.change,
			'quit': self.quit
			}
	def login(self):
		logged_in = False
		while not logged_in:
			username = input('username: ')
			password = input('password: ')
			try:
				logged_in = authenticator.login(
					username, password)
			except InvalidUsername:
				print('Sorry, that username does not exists')
			except InvalidPassword:
				print('Sorry, incorrect Password')
			else:
				self.username = username
	def is_permitted(self, permission):
		try:
			authorizor.check_permission(
				permission, self.username)
		except NotLoggedInError as e:
			print('{} is not logged in'.format(e.username))
		except NotPermittedError as e:
			print('{} cannot {}'.format(
				e.username, permission))
			return False
		else:
			return True
	def test(self):
		if self.is_permitted('test program'):
			print('Testing program now')
	def change(self):
		if self.is_permitted('change program'):
			print('Changing program now...')
	def quit(self):
		raise SystemExit()
	def menu(self):
		try:
			answer = str()
			while True:
				print("""
Please Enter a command:
\tLoging\tLogin
\ttest\tTest the program
\tchange\tChange the program
\tquit\tQuit
""")
				answer = input('enter a command: ').lower()
				try:
					func = self.menu_map[answer]
				except KeyError:
					print('{} is not a valid option'.format(
						answer))
				else:
					func()
			finally:
				
SyntaxError: invalid syntax
>>> class Editor(object):
	def __init__(self):
		self.username = None
		self.menu_map = {
			"login": self.login,
			'test': self.test,
			'change': self.change,
			'quit': self.quit
			}
	def login(self):
		logged_in = False
		exit = ['quit', 'exit']
		while not logged_in:
			username = input('username: ')
			if username in exit:
				self.quit()
			password = input('password: ')
			if password in exit:
				self.quit()
			try:
				logged_in = authenticator.login(
					username, password)
			except InvalidUsername:
				print('Sorry, that username does not exists')
			except InvalidPassword:
				print('Sorry, incorrect Password')
			else:
				self.username = username
	def is_permitted(self, permission):
		try:
			authorizor.check_permission(
				permission, self.username)
		except NotLoggedInError as e:
			print('{} is not logged in'.format(e.username))
		except NotPermittedError as e:
			print('{} cannot {}'.format(
				e.username, permission))
			return False
		else:
			return True
	def test(self):
		if self.is_permitted('test program'):
			print('Testing program now')
	def change(self):
		if self.is_permitted('change program'):
			print('Changing program now...')
	def quit(self):
		raise SystemExit()
	def menu(self):
		try:
			answer = str()
			while True:
				print("""
Please Enter a command:
\tLoging\tLogin
\ttest\tTest the program
\tchange\tChange the program
\tquit\tQuit
""")
				answer = input('enter a command: ').lower()
				try:
					func = self.menu_map[answer]
				except KeyError:
					print('{} is not a valid option'.format(
						answer))
				else:
					func()
			finally:
				
SyntaxError: invalid syntax
>>> class Editor(object):
	def __init__(self):
		self.username = None
		self.menu_map = {
			"login": self.login,
			'test': self.test,
			'change': self.change,
			'quit': self.quit
			}
	def login(self):
		logged_in = False
		while not logged_in:
			username = input('username: ')
			password = input('password: ')
			try:
				logged_in = authenticator.login(
					username, password)
			except InvalidUsername:
				print('Sorry, that username does not exists')
			except InvalidPassword:
				print('Sorry, incorrect Password')
			else:
				self.username = username
	def is_permitted(self, permission):
		try:
			authorizor.check_permission(
				permission, self.username)
		except NotLoggedInError as e:
			print('{} is not logged in'.format(e.username))
		except NotPermittedError as e:
			print('{} cannot {}'.format(
				e.username, permission))
			return False
		else:
			return True
	def test(self):
		if self.is_permitted('test program'):
			print('Testing program now')
	def change(self):
		if self.is_permitted('change program'):
			print('Changing program now...')
	def quit(self):
		raise SystemExit()
	def menu(self):
		try:
			answer = str()
			while True:
				print("""
Please Enter a command:
\tLoging\tLogin
\ttest\tTest the program
\tchange\tChange the program
\tquit\tQuit
""")
				answer = input('enter a command: ').lower()
				try:
					func = self.menu_map[answer]
				except KeyError:
					print('{} is not a valid option'.format(
						answer))
				else:
					func()
			finally:
					print('Thank you for testing the auth module')
					
SyntaxError: invalid syntax
>>> 
>>> class Editor(object):
	def __init__(self):
		self.username = None
		self.menu_map = {
			"login": self.login,
			'test': self.test,
			'change': self.change,
			'quit': self.quit
			}
	def login(self):
		logged_in = False
		while not logged_in:
			username = input('username: ')
			password = input('password: ')
			try:
				logged_in = authenticator.login(
					username, password)
			except InvalidUsername:
				print('Sorry, that username does not exists')
			except InvalidPassword:
				print('Sorry, incorrect Password')
			else:
				self.username = username
	def is_permitted(self, permission):
		try:
			authorizor.check_permission(
				permission, self.username)
		except NotLoggedInError as e:
			print('{} is not logged in'.format(e.username))
		except NotPermittedError as e:
			print('{} cannot {}'.format(
				e.username, permission))
			return False
		else:
			return True
	def test(self):
		if self.is_permitted('test program'):
			print('Testing program now')
	def change(self):
		if self.is_permitted('change program'):
			print('Changing program now...')
	def quit(self):
		raise SystemExit()
	def menu(self):
		try:
			answer = str()
			while True:
				print("""
Please Enter a command:
\tLoging\tLogin
\ttest\tTest the program
\tchange\tChange the program
\tquit\tQuit
""")
				answer = input('enter a command: ').lower()
				try:
					func = self.menu_map[answer]
				except KeyError:
					print('{} is not a valid option'.format(
						answer))
				else:
					func()
		finally:
			print('Thank you for testing the auth module')

			
>>> Editor().menu()

Please Enter a command:
	Loging	Login
	test	Test the program
	change	Change the program
	quit	Quit

enter a command: quit
Thank you for testing the auth module
>>> square = [(1,1), (1,2), (2,2), (2,1)]
>>> import math
>>> def distance(p1, p2):
	return math.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)

>>> def perimeter(polygon):
	perimeter = 0

	
>>> 


>>> def perimeter(polygon):
	perimeter = 0
	points = polygon + [polygon[0]]
	for x in range(len(polygon)):
		perimeter += distance(points[i], points[i+1])
	return perimeter

>>> import math
>>> class Point(object):
	def __init__(self, x, y):
		self.x = x
		self.y = y
	def distance(self, p2):
		return math.sqrt((self.x-p2.x)**2 + (self.y-p2.y)**2)

	
>>> class Polygon(object):
	def __init__(self):
		self.vertices = list()
	def perimeter(self):
		perimeter = 0
		points = self.vertices + [self.vertices[0]]
		for x in range(len(self.vertices)):
			perimeter += points[i].distance(points[i+1])
		return perimeter

	
>>> sq = Polygon()
>>> sq.add_point(Point(1,1))
Traceback (most recent call last):
  File "<pyshell#180>", line 1, in <module>
    sq.add_point(Point(1,1))
AttributeError: 'Polygon' object has no attribute 'add_point'
>>> class Polygon(object):
	def __init__(self):
		self.vertices = list()
	def perimeter(self):
		perimeter = 0
		points = self.vertices + [self.vertices[0]]
		for x in range(len(self.vertices)):
			perimeter += points[i].distance(points[i+1])
		return perimeter
	def add_point(self, point):
		self.vertices.append((point))

		
>>> sq = Polygon()
>>> sq.add_point(Point(1,1))
>>> sq.add_point(Point(1,2))
>>> sq.add_point(Point(2,2))
>>> sq.add_point(Point(2,1))
>>> sq.perimeter()
Traceback (most recent call last):
  File "<pyshell#190>", line 1, in <module>
    sq.perimeter()
  File "<pyshell#184>", line 8, in perimeter
    perimeter += points[i].distance(points[i+1])
NameError: name 'i' is not defined
>>> class Polygon(object):
	def __init__(self):
		self.vertices = list()
	def perimeter(self):
		perimeter = 0
		points = self.vertices + [self.vertices[0]]
		for i in range(len(self.vertices)):
			perimeter += points[i].distance(points[i+1])
		return perimeter
	def add_point(self, point):
		self.vertices.append((point))

		
>>> sq = Polygon()
>>> sq.add_point(Point(1,1))
>>> sq.add_point(Point(1,2))
>>> sq.add_point(Point(2,1))
>>> sq.add_point(Point(2,2))
>>> sq.perimeter()
4.82842712474619
>>> perimeter(square)
Traceback (most recent call last):
  File "<pyshell#199>", line 1, in <module>
    perimeter(square)
  File "<pyshell#164>", line 5, in perimeter
    perimeter += distance(points[i], points[i+1])
NameError: name 'i' is not defined
>>> def perimeter(polygon):
	perimeter = 0
	points = polygon + [polygon[0]]
	for i in range(len(polygon)):
		perimeter += distance(points[i], points[i+1])
	return perimeter

>>> perimeter(square)
4.0
>>> # using properties to add behaviour to class data
>>> #bad object oriented theory
>>> class Color(object):
	def __init__9self, rgb_value, name):
		
SyntaxError: invalid syntax
>>> class Color(object):
	def __init__(self, rgb_value, name):
		self._rgb_value = rgb_value
		self._name = name
	def set_name(self, name):
		self._name = name
	def get_name(self):
		return self._name

	
>>> c = Color('#ff0000', 'bright red')
>>> c.get_name()
'bright red'
>>> c.set_name('red')
>>> c.get_name()
'red'
>>> class Color(object):
	def __init__(self, rgb_value, name):
		self.rgb_value = rgb_value
		self.name = name

		
>>> c = Color('#ff0000', 'bright red')
>>> c.name
'bright red'
>>> c.name = 'red'
>>> c.name
'red'
>>> class Color(object):
	def __init__(self, rgb_value, name):
		self.rgb_value = rgb_value
		self._name = name
	def _set_name(self, name):
		if not name:
			raise Exception('Invalid Name')
		self._name = name
	def _get_name(self):
		return self._name
	name = property(_get_name, _set_name)

	
>>> c = Color('#ff0000', 'bright red')
>>> c.name
'bright red'
>>> c.name = 'red'
>>> c.name = ''
Traceback (most recent call last):
  File "<pyshell#240>", line 1, in <module>
    c.name = ''
  File "<pyshell#236>", line 7, in _set_name
    raise Exception('Invalid Name')
Exception: Invalid Name
>>> c.rgb_value
'#ff0000'
>>> 
>>> 
