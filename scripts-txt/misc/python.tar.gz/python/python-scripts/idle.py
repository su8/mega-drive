#!/usr/bin/env python2
import subprocess


params = ['idle2']
subprocess.check_call(params)

