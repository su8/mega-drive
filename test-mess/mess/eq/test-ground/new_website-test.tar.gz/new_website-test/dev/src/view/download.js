var downloadsTemplate = [
    "<div id='download-table' class='col-md-12'>",

        "<div class='alert alert-info'>",
            "<span>",
                "Click ",
                    "<a href='#!releaseschedule' class='alert-link'>",
                        "here",
                    "</a>",
                " to view the release schedule.",
            "</span>",
        "</div>",

        "<h4 id='newer-release'>",
        "</h4>",
        "<p>",
            "This release primarily focusses on building a ",
            "stable set of scripts that can be used to build ",
            "AryaLinux, plus a stable build that can run across multiple hardware.",
        "</p>",
        "<table class='table table-striped table-hover '>",
          "<thead>",
            "<tr class='success'>",
              "<th>Download Link</th>",
              "<th>MD5 Checksum</th>",
              "<th>Size</th>",
            "</tr>",
          "</thead>",
          "<tbody>",
            "<tr>",
              "<td id='686-url'></td>",
              "<td id='686-sum'></td>",
              "<td id='686-size'></td>",
            "</tr>",
            "<tr class='active'>",
              "<td id='x86_64-url'></td>",
              "<td id='x86_64-sum'></td>",
              "<td id='x86_64-size'></td>",
            "</tr>",
          "</tbody>",
        "</table>",

        "<h4 id='older-release'>",
        "</h4>",
        "<p>",
            "This was the second release of AryaLinux, with focus ",
            "on building a stable 64 bit system. The Live System was ",
            "itself capable of acting as the builder disk",
        "</p>",
        "<table class='table table-striped table-hover '>",
          "<thead>",
            "<tr class='success'>",
              "<th>Download Link</th>",
              "<th>MD5 Checksum</th>",
              "<th>Size</th>",
            "</tr>",
          "</thead>",
          "<tbody>",
            "<tr>",
              "<td id='mate-url'></td>",
              "<td id='mate-sum'></td>",
              "<td id='mate-size'></td>",
            "</tr>",
            "<tr class='active'>",
              "<td id='xfce-url'></td>",
              "<td id='xfce-sum'></td>",
              "<td id='xfce-size'></td>",
            "</tr>",
          "</tbody>",
        "</table>",

        "<h4>Older Releases</h4>",

        "<p>",
            "Click ",
            "<a href='https://sourceforge.net/projects/aryalinux/' target='_blank'>",
                "<strong>here</strong>",
            "</a>",
            " to visit our sourceforge.net space to view details of older releases.",
        "</p>",
    "</div>"
].join('');

var createTableMetada = function(givenArr, isLive, version, metadataObj) {
    givenArr.forEach(function(release) {
        utils.elemId(release+'-url').innerHTML =
            "<a href='" + geminiBlog.downloadURL(release, isLive) + "' target='_blank'>" +
            "AryaLinux " + version +
            (isLive ? " - " : " Builder ") +
            release + "</a>";
        utils.elemId(release+'-sum').innerHTML = metadataObj[release][0];
        utils.elemId(release+'-size').innerHTML = metadataObj[release][1];
    });
};


geminiBlog.downloadPage = function() {
    scroll(0,0);
    document.title = "Downloads";
    var x;
    var container = utils.clearElements($("#entries-wrapper"));
    var snippetViewHTML = utils.str2WrappedDOMElement(downloadsTemplate);
    container.appendChild(snippetViewHTML.childNodes[0]);

    createTableMetada(['686', 'x86_64'], false,
            geminiBlog.version, geminiBlog.metadata_one);
    createTableMetada(['xfce', 'mate'], true,
            geminiBlog.olderVersion, geminiBlog.metadata_two);

    for (x in geminiBlog.download_table_one) {
        utils.elemId(x).innerHTML = geminiBlog.download_table_one[x];
    }

    utils.elemId("newer-release").textContent = "AryaLinux " + geminiBlog.version;
    utils.elemId("older-release").textContent = "AryaLinux " + geminiBlog.olderVersion;
};
