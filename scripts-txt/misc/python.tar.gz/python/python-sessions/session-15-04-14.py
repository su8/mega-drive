Python 3.4.0 (default, Mar 17 2014, 23:20:09) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class ContactList(list):
	def search(self, name):
		'''return all contacts that contain the search value in their name.'''
		matching_contacts = list()
		for contact in self:
			if name in contact.name:
				matching_contacts.append(contact)
		return matching_contacts

	
>>> class Contact:
	all_contacts = ContactList()
	def __init__(self, name, email):
		self.name = name
		self.email = email
		self.all_contacts.append(self)

		
>>> c1 = Contact('John A', 'johna@example.net')
>>> c2 = Contact('John B', 'johnb@example.net')
>>> c3 = Contact('Jenna C', 'jennac@example.net')
>>> [c.name for c in Contact.all_contacts.search('John')]
['John A', 'John B']
>>> # overriding and super
>>> class Friend(Contact):
	def __init__(self, name, email, phone):
		self.name = name
		self.email = email
		self.phone = phone

		
>>> class Friend(Contact):
	def __init__(self, name, email, phone):
		super().__init__(name, email)
		self.phone = phone

		
>>> c3 = Contact('Jenna C', 'jennac@example.net', '555-444-333-222-111')
Traceback (most recent call last):
  File "<pyshell#32>", line 1, in <module>
    c3 = Contact('Jenna C', 'jennac@example.net', '555-444-333-222-111')
TypeError: __init__() takes 3 positional arguments but 4 were given

>>> c3 = Friend('Jenna C', 'jennac@example.net', '555-444-333-222-111')
>>> c3.name
'Jenna C'
>>> c3.email
'jennac@example.net'
>>> c3.email
'jennac@example.net'
>>> c3.phone
'555-444-333-222-111'
>>> class MailSender:
	def send_mail(self, message):
		print('Sending email to ' + self.email)

		
>>> class EmailableContact(Contact, MailSender):
	pass

>>> e = EmailableContact('John Smith', 'jsmith@example.net')
>>> Contact.all_contacts
[<__main__.Contact object at 0x7fefba1df9e8>, <__main__.Contact object at 0x7fefb9864278>, <__main__.Contact object at 0x7fefb791b6a0>, <__main__.Friend object at 0x7fefb7925198>, <__main__.EmailableContact object at 0x7fefb79251d0>]
>>> e.send_email('Hello, test e-mail here')
Traceback (most recent call last):
  File "<pyshell#47>", line 1, in <module>
    e.send_email('Hello, test e-mail here')
AttributeError: 'EmailableContact' object has no attribute 'send_email'
>>> e.send_mail('Hello, test e-mail here')
Sending email to jsmith@example.net
>>> class AddressHolder:
	def __init__(self, street, city, state, code):
		self.street = street
		self.city = city
		self.state = state
		self.code = code

		
>>> 
