#include <stdio.h>
#include <limits.h>

int main(void)
{
    printf("Maximum int value on this system = %d\n", INT_MAX);
    printf("Number of bits in a char = %d\n", CHAR_BIT);
    printf("Maximum char value on this system = %d\n", CHAR_MAX);
    printf("Minimum char value on this system = %d\n", CHAR_MIN);
    printf("Maximum signed char value on this system = %d\n", SCHAR_MAX);
    printf("Minimum signed char value on this system = %d\n", SCHAR_MIN);
    printf("Maximum unsigned char value on this system = %d\n", UCHAR_MAX);
    printf("Maximum short value on this system = %d\n", SHRT_MAX);
    printf("Minimum short value on this system = %d\n", SHRT_MIN);
    printf("Maximum unsigned short value on this system = %d\n", USHRT_MAX);
    printf("Minimum int value on this system = %d\n", INT_MIN);
    printf("Maximum unsigned int value on this system = %d\n", UINT_MAX);
    printf("Maximum long value on this system = %d\n", LONG_MAX);
    printf("Minimum long value on this system = %d\n", LONG_MIN);
    printf("Maximum unsigned long value on this system = %d\n", ULONG_MAX);
    printf("Maximum long long value on this system = %d\n", LLONG_MAX);
    printf("Minimum long long value on this system = %d\n", LLONG_MIN);
    printf("Maximum unsigned long long value on this system = %d\n", ULLONG_MAX);

    return 0;
}
