#!/usr/bin/python2
import getpass
import subprocess

userz = getpass.getuser()
subprocess.Popen(['/home/' + userz + '/Desktop/wxfiles/wxpy.py'])
subprocess.Popen(['/home/' + userz + '/Desktop/wxfiles/telnet.py'])
