# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'untitled.ui'
#
# Created: Sat Dec 21 23:17:01 2013
#      by: PyQt4 UI code generator 4.10.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui, uic

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

#uifile_1 = '/home/frost/Desktop/aboutdialog.ui'
#form_1, base_1 = uic.loadUiType(uifile_1)

#class CreateUI_2(base_1, form_1):
    #def __init__(self):
        #super(base_1,self).__init__()
        #self.setupUi(self)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(229, 257)
        MainWindow.setStyleSheet(_fromUtf8("background-color: black;"))
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.label = QtGui.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(10, 10, 81, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(120, 0, 51, 20))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(10, 60, 81, 16))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.label_4 = QtGui.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(160, 60, 21, 16))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.label_5 = QtGui.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(10, 110, 101, 16))
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.label_6 = QtGui.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(140, 110, 57, 14))
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.label_7 = QtGui.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(50, 170, 101, 21))
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.spinBox = QtGui.QSpinBox(self.centralwidget)
        self.spinBox.setGeometry(QtCore.QRect(10, 80, 91, 21))
        self.spinBox.setStyleSheet(_fromUtf8("background-color: white;"))
        self.spinBox.setObjectName(_fromUtf8("spinBox"))
        self.spinBox_2 = QtGui.QSpinBox(self.centralwidget)
        self.spinBox_2.setGeometry(QtCore.QRect(120, 80, 91, 21))
        self.spinBox_2.setStyleSheet(_fromUtf8("background-color: white;"))
        self.spinBox_2.setObjectName(_fromUtf8("spinBox_2"))
        self.comboBox = QtGui.QComboBox(self.centralwidget)
        self.comboBox.setGeometry(QtCore.QRect(10, 130, 91, 23))
        self.comboBox.setStyleSheet(_fromUtf8("background-color: gray;"))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox_2 = QtGui.QComboBox(self.centralwidget)
        self.comboBox_2.setGeometry(QtCore.QRect(120, 130, 91, 23))
        self.comboBox_2.setStyleSheet(_fromUtf8("background-color: gray;"))
        self.comboBox_2.setObjectName(_fromUtf8("comboBox_2"))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.comboBox_2.addItem(_fromUtf8(""))
        self.lineEdit = QtGui.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(10, 30, 91, 22))
        self.lineEdit.setStyleSheet(_fromUtf8("background-color: white;"))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.pushButton = QtGui.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(50, 210, 99, 23))
        self.pushButton.setStyleSheet(_fromUtf8("background-color: gray;"))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow", None))
        self.label.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#a0a0a0;\"> Resolution</span></p></body></html>", None))
        self.label_2.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#a0a0a0;\">About</span></p></body></html>", None))
        self.label_3.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#a0a0a0;\">From page:</span></p></body></html>", None))
        self.label_4.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#a0a0a0;\">To:</span></p></body></html>", None))
        self.label_5.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#a0a0a0;\">Image format</span></p></body></html>", None))
        self.label_6.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#a0a0a0;\">sDevice</span></p></body></html>", None))
        self.label_7.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#ffffff;\">Select PDF file</span></p></body></html>", None))
        self.comboBox.setItemText(0, _translate("MainWindow", "png", None))
        self.comboBox.setItemText(1, _translate("MainWindow", "jpg", None))
        self.comboBox.setItemText(2, _translate("MainWindow", "bmp", None))
        self.comboBox.setItemText(3, _translate("MainWindow", "tiff", None))
        self.comboBox_2.setItemText(0, _translate("MainWindow", "png16m", None))
        self.comboBox_2.setItemText(1, _translate("MainWindow", "pngalpha", None))
        self.comboBox_2.setItemText(2, _translate("MainWindow", "pnggray", None))
        self.comboBox_2.setItemText(3, _translate("MainWindow", "jpeg", None))
        self.comboBox_2.setItemText(4, _translate("MainWindow", "jpegcmyk", None))
        self.comboBox_2.setItemText(5, _translate("MainWindow", "jpeggray", None))
        self.comboBox_2.setItemText(6, _translate("MainWindow", "bmp16m", None))
        self.comboBox_2.setItemText(7, _translate("MainWindow", "bmpgray", None))
        self.comboBox_2.setItemText(8, _translate("MainWindow", "tiff24nc", None))
        self.comboBox_2.setItemText(9, _translate("MainWindow", "tiffgray", None))
        self.pushButton.setText(_translate("MainWindow", "PushButton", None))
        QtCore.QObject.connect(self.pushButton, QtCore.SIGNAL('clicked()'), self.oncomboClicked)
        QtCore.QObject.connect(self.comboBox, QtCore.SIGNAL('currentIndexChanged(int)'), self.oncombo)
        QtCore.QObject.connect(self.comboBox_2, QtCore.SIGNAL('currentIndexChanged(int)'), self.oncombo2)

    def oncombo2(self):
        active = self.comboBox_2.currentText()
        if active == "png16m" or active == "pngalpha" or active == "pnggray":
            self.comboBox.setCurrentIndex(0)
        if active == "jpeg" or active == "jpegcmyk" or active == "jpeggray":
            self.comboBox.setCurrentIndex(1)
        if active == "bmp16m" or active == "bmpgray":
            self.comboBox.setCurrentIndex(2)
        if active == "tiff24nc" or active == "tiffgray":
            self.comboBox.setCurrentIndex(3)


    def oncombo(self):
        active = self.comboBox.currentText()
        if active == "png":
            self.comboBox_2.setCurrentIndex(0)
        if active == "jpg":
            self.comboBox_2.setCurrentIndex(3)
        if active == "bmp":
            self.comboBox_2.setCurrentIndex(6)
        if active == "tiff":
            self.comboBox_2.setCurrentIndex(8)

    def oncomboClicked(self):
        self.ui = uic.loadUi('/home/frost/Desktop/about_images/aboutdialog.ui')
        self.ui.show()
        #global UI_1
        #UI_1=CreateUI_2()
        #UI_1.show()
        #fname = QtGui.QFileDialog.getOpenFileName(None, 'Open file', '/home/frost/', filter='PDF files (*.pdf);;All files (*)')
        #print fname
        #self.pushButton.setText("Hoho")
        #print("yay")#self.comboBox.get_active()


if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

