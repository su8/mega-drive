/* The mass of a single molecule of water is about
3.0x10-23 grams. A quart of water is about 950 grams.
Write a program that requests an amount of water, in quarts,
and displays the number of water molecules in that amount. */
#include <stdio.h>
int main(void)
{
    float molecule_grams = 3.0e-23, water_grams = 950;
    float entered_quarts, molecules;

    printf("Supply some amount of water in quarts: ");
    scanf("%f", &entered_quarts);

    molecules = entered_quarts * water_grams / molecule_grams;

    printf("%.0f water quarts has %e molecules\n",
           entered_quarts, molecules);

    return 0;
}
