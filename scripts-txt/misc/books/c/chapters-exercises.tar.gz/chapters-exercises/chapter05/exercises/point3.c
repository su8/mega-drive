/* Write a program that asks the user to enter the number of days
 * and convert that value to weeks and days. For example, it would
 * convert 18 days to 2 weeks, 4 days.
 * Display results in the following format:
 * 18 days are 2 weeks, 4 days.
 * 
 * Use a while loop to allow the user to repeatedly enter day values;
 * terminate the loop when the users enters a nonpositive value,
 * such as 0 or -20. */
#include <stdio.h>
#define DAYS_IN_A_WEEK 7
int main(void)
{
    int days, weeks, left;

    printf("Enter the number of days (<=0 to quit):\n");

    while (days > 0)
    {
        scanf("%d", &days);
        weeks = days / DAYS_IN_A_WEEK;
        left = days % DAYS_IN_A_WEEK;

        printf("%d days are %d weeks, %d days.\n",
               days, weeks, left);
        printf("Enter the next day value (<=0 to quit):\n");

    }
    printf("Done!\n");

    return 0;
}
