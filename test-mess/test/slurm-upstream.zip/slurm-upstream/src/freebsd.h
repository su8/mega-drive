int get_stat(void);
int checkinterface(void);
