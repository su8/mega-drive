/* point4.c -- 

Using if else statements, write a program that reads input up to # , replaces each period
with an exclamation mark, replaces each exclamation mark initially present with two
exclamation marks, and reports at the end the number of substitutions it has made.

 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main(void)
{
    unsigned short int shebang, exclamation_mark;
    char ch;

    while ((ch = getchar()) != '#')
    {
        /* ispunct(ch) */
        if (ch == '.')
        {
            ch = '!';
            putchar(ch);
            shebang++;
        }
        else if (ch == '!')
        {
            ch = '!';
            putchar(ch);
            putchar(ch);
            exclamation_mark++;
        }
        else
            putchar(ch);
    }
    printf("\nEncountered shebangs = %hu, exclamation marks = %hu\n",
        shebang, exclamation_mark);

    return EXIT_SUCCESS;
}