/* 5. You suspect that the following program is not perfect. What errors can you find? */
#include <stdio.h>
int main(void)
{                                    // line 3
    int i, j, list(10);              // line 4
    
    for (i = 1, i <= 10, i++)        // line 6
    {                                // line 7
        list[i] = 2*i + 3;           // line 8
        for (j = 1, j > = i, j++)    // line 9
            printf(" %d", list[j]);  // line 10
        printf("\n");                // line 11
    }
    
}                                    // line 12

/*
 * line 4, list(10) is totally wrong assigned integer
 * line 6, no semicolons but comma operators
 * line 7, unclosed {
 * line 8, attempt to index "list" char while it is wrongly assigned as integer
 * line 9, same as line 6
 * line 10, same as line 8 plus you can't use decimal format specifier for char
 * line 12, no "return"
 */
