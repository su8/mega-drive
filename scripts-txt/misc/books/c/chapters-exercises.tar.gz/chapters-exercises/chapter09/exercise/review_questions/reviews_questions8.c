/* 8. Write a function that returns the largest of three integer arguments. */
#include <stdio.h>
#include <stdlib.h>

int find_out(int a, int b, int c);

int main(void)
{
    printf("The largest integer in range of 3 10 1 is %d\n",
        find_out(3, 10, 1));

    return EXIT_SUCCESS;
}

int find_out(int a, int b, int c)
{
    int largest = 0;

    if (a > b && a > c)
        largest = a;
    else if (b > a && b > c)
        largest = b;
    else
        largest = c;

    return largest;
}