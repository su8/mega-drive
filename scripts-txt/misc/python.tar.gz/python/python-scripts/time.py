#!/usr/bin/python
import sys
import os

class build_the_program:

    def __init__(self):
        while True:
            try:
                os.system(['clear', 'cls'][os.name == 'nt'])


                print(bcolors.OKBLUE + """
    """ + bcolors.OKGREEN + """===  """ + bcolors.ENDC + """""" + bcolors.HEADER + """TimeSet(tings) - Configure the System Date and Time""" + bcolors.ENDC + """""" + bcolors.OKGREEN + """  ===""" + bcolors.ENDC + """
    """ + bcolors.OKGREEN + """""" + bcolors.ENDC + """
    """ + bcolors.OKBLUE + """[""" + bcolors.ENDC + """""" + bcolors.WARNING + """1""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Show Current Date and Time Configuration""" + bcolors.OKGREEN + " "*15 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """2""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Show Known Timezones (press q to return to menu)""" + bcolors.OKGREEN + " "*7 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """3""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Set System Timezone""" + bcolors.OKGREEN + " "*36 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """4""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Synchronize Time from the Network (NTP)""" + bcolors.OKGREEN + " "*16 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """5""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Control whether NTP is used or not""" + bcolors.OKGREEN + " "*21 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """6""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Enable NTP at Startup""" + bcolors.OKGREEN + " "*34 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """7""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Disable NTP at Startup""" + bcolors.OKGREEN + " "*33 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """8""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Control whether Hardware Clock is in Local Time or not""" + bcolors.OKGREEN + " " + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """9""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.ENDC + """Read the time from the Hardware Clock""" + bcolors.OKGREEN + " "*18 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """10""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """] """ + bcolors.ENDC + """Synchronize Hardware Clock to System Time""" + bcolors.OKGREEN + " "*14 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """11""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """] """ + bcolors.ENDC + """Synchronize System Time from Hardware Clock""" + bcolors.OKGREEN + " "*12 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """12""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """] """ + bcolors.ENDC + """Set System Time manually""" + bcolors.OKGREEN + " "*31 + """=""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """
    [""" + bcolors.ENDC + """""" + bcolors.WARNING + """0""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """]  """ + bcolors.RED + """Exit/Quit""" + bcolors.ENDC + """""" + bcolors.OKGREEN + " "*46 + """=
    =============================================================""" + bcolors.ENDC + """\n""")
    
                #print(bcolors.OKBLUE + """
                 #_________ """ + bcolors.HEADER + """File Encrypter v2""" + bcolors.ENDC + """ """ + bcolors.OKBLUE + """________
                #|                                    |
                #|          """ + bcolors.OKGREEN + """e""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """)""" + bcolors.ENDC + """ Encrypt File           """ + bcolors.OKBLUE + """|
                #|                                    |
                #|          """ + bcolors.RED + """d""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """)""" + bcolors.ENDC + """ Decrypt File           """ + bcolors.OKBLUE + """|
                #|                                    |
                #|          """ + bcolors.WARNING + """q""" + bcolors.ENDC + """""" + bcolors.OKBLUE + """)""" + bcolors.ENDC + """ Quit                   """ + bcolors.OKBLUE + """|
                #|                                    |
                #|____________________________________|""" + bcolors.ENDC + """\n\n""")

                selection = int(raw_input(" "*4 +"Enter your choice:  "))

                if selection == 0:
                        print("\n")
                        break
                elif selection == 1:
                        os.system("timedatectl status")
                elif selection == 2:
                        os.system("timedatectl list-timezones")
                elif selection == 3:
                        os.system("timedatectl set-timezone")
                elif selection == 4:
                        os.system("ntpdate -u pool.ntp.org")
                elif selection == 5:
                        os.system("timedatectl set-ntp")
                elif selection == 6:
                    os.system("systemctl enable ntpd")
                elif selection == 7:
                    os.system("systemctl disable ntpd")
                elif selection == 8:
                    os.system("timedatectl set-local-rtc")
                elif selection == 9:
                    os.system("hwclock -D")
                elif selection == 10:
                    os.system("hwclock -w")
                elif selection == 11:
                    os.system("hwclock -s")
                elif selection == 12:
                    os.system("timedatectl set-time")
                else:
                    print(bcolors.WARNING + "\n" + " "*18 + "Not a valid choice." + bcolors.ENDC)
                raw_input("\n" + " "*15 + "Press enter to continue")
                exit
            except KeyboardInterrupt:
                sys.exit("\n\n" + " "*20 + "See you later\n")

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'

    def disable(self):
        self.HEADER = ''
        self.OKBLUE = ''
        self.OKGREEN = ''
        self.WARNING = ''
        self.RED = ''
        self.ENDC = ''

if __name__ == '__main__':
    build_the_program()