geminiblog
==========

Static blog written in JavaScript with client side markdown->html conversion using [marked.js](https://github.com/chjj/marked)

Also, using some of [iconMonstr](http://iconmonstr.com/)'s icons.
