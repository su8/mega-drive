#!/usr/bin/python2
import subprocess
import os
import getpass

userz = getpass.getuser()
os.chdir('/home/' + userz + '/Desktop/')
# os.rename('mwc/mw.py', 'mwc/mw')
par1, par2 = ['mv', 'mwc/mw', '/usr/bin/'], ['mv', 'mwc/mwc.desktop', '/usr/share/applications/']
par3, par4 = ['rm', '-rf', '/usr/share/mwc/'], ['mv', 'mwc', '/usr/share']
for files in par1, par2, par3, par4:
    subprocess.check_call(files)