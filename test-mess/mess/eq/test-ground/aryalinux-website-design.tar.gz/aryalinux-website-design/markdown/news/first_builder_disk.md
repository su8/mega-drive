
---

Released 32 and 64 bit versions of AryaLinux 2016.04 builder disk.

This version is based on the latest SVN version of the LFS and BLFS books.

Unlike the This builder disk fixes a lot of bugs in the previous builder disks and enhances and speeds up the build process through usage of multiple-processors if available.

This builder DVD ships with a lot of scripts not covered in the LFS/BLFS books like programming stacks, Mate Desktop Environment etc.

Click [here] to view full release notes

[here]: http://aryalinux.org/releaseNotes.php?id=1 
