var frontPageTemplate = [
    "<div class='front-page'>",
        "<div class='jumbotron'>",
            "<div class='row'>",
                "<div class='col-md-8 col-sm-12'>",
                    "<h2 class='jumbo-title'></h2>",
                "</div>",
                "<div class='col-md-8 col-sm-12'>",
                    "<p>",
                        "Using the AryaLinux " + geminiBlog.version ,
                        " builder disks you can build ",
                        "AryaLinux from scratch on your computer. In this version we ",
                        "have streamlined the process of building your GNU/Linux ",
                        "system from scratch and updated alps for a simpler and faster build experience.",
                    "</p>",
                    "<p><a href='#!download' class='btn btn-primary btn-lg'>Download</a></p>",
                "</div>",
                "<div class='col-md-4 col-sm-12'>",
                    "<img src='2.png' alt='' />",
                "</div>",
            "</div>",
        "</div>",
    "<div class=col-md-7>",
        "<h2>Welcome to AryaLinux</h2>",
        "<p>",
            "AryaLinux is a GNU/Linux based operating system that is built by building source code ",
            "of the various components packages that it comprises of. In more geeky terms its a ",
            "source based Linux Distribution. Its fast, comprehensive and provides pre-installed ",
            "applications that are pretty much enough for the day to day user. AryaLinux also ",
            "provides the flexibility to build your own Linux distribution by providing the ",
            "necessary tools to do so. ",
        "</p>",
    "</div>",
].join('');

geminiBlog.frontPage = function() {
    scroll(0,0);
    document.title = "AryaLinux";
    utils.show($("#download-sidebar-links"));
    var container = utils.clearElements($("#entries-wrapper"));
    var frontPageHTML = utils.str2WrappedDOMElement(frontPageTemplate);
    var wrapper = $('.front-page', frontPageHTML);

    $('.jumbo-title', wrapper).innerHTML = geminiBlog.version + ' Builder Disks Released';

    container.appendChild(frontPageHTML.childNodes[0]);
    geminiBlog.showDownloadSidebar();

};
