Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> def a(*arg):
	print(['Nice to meet you {0}. My name is {1}'.format(arg[0], arg[1])])

	
>>> a('John', 'James')
['Nice to meet you John. My name is James']
>>> def a(*arg):
	print({'Nice to meet you {0}. My name is {1}'.format(arg[0], arg[1]})
	      
SyntaxError: invalid syntax
>>> 
>>> def a(*arg):
	print({'Nice to meet you {0}. My name is {1}'.format(arg[0], arg[1])})

	
>>> a('John', 'James')
{'Nice to meet you John. My name is James'}
>>> a = set()
>>> a.send('hi')
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    a.send('hi')
AttributeError: 'set' object has no attribute 'send'
>>> for x in range(11):
	a.add(x)

	
>>> a.send(2)
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    a.send(2)
AttributeError: 'set' object has no attribute 'send'
>>> a
{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
>>> def cd(n):
	while n > 0:
		print("T-minus", n)
		yield
		n -= 1
	print('Blastoff!')

	
>>> cd(5)
<generator object cd at 0x7f6e34c13820>
>>> 
>>> for x in cd(5):
	print(x)

	
T-minus 5
None
T-minus 4
None
T-minus 3
None
T-minus 2
None
T-minus 1
None
Blastoff!
>>> import imp
>>> #imp.reload(spam)
>>> from collections import deque
>>> class TaskScheduler:
	def __init__(self):
		self._task_queue = deque()
	def new_task(self, task):
		'''
Admin a newly started task to the scheduler
'''
		self._task_queue.append(task)
	def run(self):
		'''run until there are no more tasks'''
		while self._task_queue:
			task = self._task_queue.popleft()
			try:
				next(task)
				self._task_queue.append(task)
			except StopIteration:
				pass

			
>>> import pls
>>> sched = TaskScheduler()
>>> sched.new_task(pls.last.upgrade())
>>> sched.run()
>>> sched.new_task(cd(5))
>>> sched.run()
T-minus 5
T-minus 4
T-minus 3
T-minus 2
T-minus 1
Blastoff!
>>> sched.new_task(pls.last.access())
>>> sched.run()
Traceback (most recent call last):
  File "<pyshell#57>", line 1, in <module>
    sched.run()
  File "<pyshell#49>", line 14, in run
    next(task)
TypeError: 'str' object is not an iterator
>>> sched.new_task(pls.package('kde'))
>>> sched.run()
>>> sched.new_task(pls.last.access())
>>> sched.run()
Traceback (most recent call last):
  File "<pyshell#61>", line 1, in <module>
    sched.run()
  File "<pyshell#49>", line 14, in run
    next(task)
TypeError: 'str' object is not an iterator
>>> sched.new_task(pls.last.upgrade())
>>> sched.run()
>>> for x in pls.last.upgrade():
	print(x)

	
[2014-03-05 10:38] [PACMAN] starting full system upgrade
-> 22 packages to upgrade ::
[2014-03-05 11:19] [PACMAN] upgraded clementine (1.2.1-2 -> 1.2.2-1)
[2014-03-05 11:19] [PACMAN] upgraded cups-filters (1.0.45-1 -> 1.0.46-1)
[2014-03-05 11:19] [PACMAN] upgraded ffmpeg (1:2.1.3-1 -> 1:2.1.4-1)
[2014-03-05 11:19] [PACMAN] upgraded kdenlive (0.9.6-2 -> 0.9.6-3)
[2014-03-05 11:19] [PACMAN] upgraded kdeplasma-applets-plasma-nm (0.9.3.2-1 -> 0.9.3.3-1)
[2014-03-05 11:19] [PACMAN] upgraded libgphoto2 (2.5.3.1-1 -> 2.5.3.1-1.1)
[2014-03-05 11:19] [PACMAN] upgraded libmariadbclient (5.5.35-1 -> 5.5.36-1)
[2014-03-05 11:19] [PACMAN] upgraded python2 (2.7.6-2 -> 2.7.6-3)
[2014-03-05 11:19] [PACMAN] upgraded libtorrent-rasterbar (1:0.16.12-2 -> 1:0.16.15-1)
[2014-03-05 11:19] [PACMAN] upgraded libwbclient (4.1.4-1 -> 4.1.5-1)
[2014-03-05 11:19] [PACMAN] upgraded linux310-virtualbox-host-modules (4.3.6-4 -> 4.3.8-1)
[2014-03-05 11:19] [PACMAN] upgraded mariadb-clients (5.5.35-1 -> 5.5.36-1)
[2014-03-05 11:19] [PACMAN] upgraded mariadb (5.5.35-1 -> 5.5.36-1)
[2014-03-05 11:19] [PACMAN] upgraded net-snmp (5.7.2-8 -> 5.7.2.1-1)
[2014-03-05 11:19] [PACMAN] upgraded networkmanager (0.9.8.8-1 -> 0.9.8.8-3)
[2014-03-05 11:19] [PACMAN] upgraded sbc (1.1-1 -> 1.2-1)
[2014-03-05 11:19] [PACMAN] upgraded simplescreenrecorder (0.1.2-1 -> 0.2.0-2)
[2014-03-05 11:19] [PACMAN] upgraded smbclient (4.1.4-1 -> 4.1.5-1)
[2014-03-05 11:19] [PACMAN] upgraded telepathy-glib (0.22.0-1 -> 0.22.1-1)
[2014-03-05 11:19] [PACMAN] upgraded virtualbox (4.3.6-3 -> 4.3.8-1)
[2014-03-05 11:20] [PACMAN] upgraded vlc (2.1.3-1 -> 2.1.4-1)
[2014-03-05 11:20] [PACMAN] upgraded webkitgtk (2.2.4-2 -> 2.2.5-1)
>>> class TaskScheduler:
	def __init__(self):
		self._task_queue = deque()
	def new_task(self, task):
		'''
Admin a newly started task to the scheduler
'''
		self._task_queue.append(task)
	def run(self):
		'''run until there are no more tasks'''
		while self._task_queue:
			task = self._task_queue.popleft()
			try:
				print(next(task))
				self._task_queue.append(task)
			except StopIteration:
				pass

			
>>> sched = TaskScheduler()
>>> sched.new_task(pls.last.access())
>>> sched.run()
Traceback (most recent call last):
  File "<pyshell#71>", line 1, in <module>
    sched.run()
  File "<pyshell#68>", line 14, in run
    print(next(task))
TypeError: 'str' object is not an iterator
>>> # the following code illustrates the use of generators to implement a thread-free version of actors
>>> from collections import deque
>>> class ActorScheduler:
	def __init__(self):
		self._actors = {} # mapping of names to actors
		self._msg_queue = deque() # message queue
	def new_actor(self, name, actor):
		'''admit a newly started actor to the scheduler and give it a name'''
		self._msg_queue.append((actor, None))
		self._actors[name] = actor
	def send(self, name, msg):
		'''send a message to a named actor'''

>>> class ActorScheduler:
	def __init__(self):
		self._actors = {} # mapping of names to actors
		self._msg_queue = deque() # message queue
	def new_actor(self, name, actor):
		'''admit a newly started actor to the scheduler and give it a name'''
		self._msg_queue.append((actor, None))
		self._actors[name] = actor
	def send(self, name, msg):
		'''send a message to a named actor'''
		actor = self._actors.get(name)
		if actor:
			self._msg_queue.append((actor, msg))
	def run(self):
		'''run as long as there are pending messages'''
		while self._msg_queue:
			actor, msg = self._msg_queue.poplef()
			try:
				actor.send(msg)
			except StopIteration:
				pass

			
>>> if __name__ == '__main__':
	def printer():
		while True:
			msg = yield
			print('Got:', msg)
	def counter(sched):
		while True:
			#receive the current count
			n = yield
			if n == 0:
				break
			#send to the printer task
			sched.send('printer', n)
			#send the next count to the counter task (recursive)
			sched.send('counter', n-1)
	sched = AcotrScheduler()
	#create the inital actors
	sched.new_actor('printer', printer())
	sched.new_actor('counter', counter(sched))
	# send an inital message to the counter to initate
	sched.send('counter', 10000)
	sched.run()

	
Traceback (most recent call last):
  File "<pyshell#118>", line 16, in <module>
    sched = AcotrScheduler()
NameError: name 'AcotrScheduler' is not defined
>>> if __name__ == '__main__':
	def printer():
		while True:
			msg = yield
			print('Got:', msg)
	def counter(sched):
		while True:
			#receive the current count
			n = yield
			if n == 0:
				break
			#send to the printer task
			sched.send('printer', n)
			#send the next count to the counter task (recursive)
			sched.send('counter', n-1)
	sched = ActorrScheduler()
	#create the inital actors
	sched.new_actor('printer', printer())
	sched.new_actor('counter', counter(sched))
	# send an inital message to the counter to initate
	sched.send('counter', 10000)
	sched.run()

Traceback (most recent call last):
  File "<pyshell#119>", line 16, in <module>
    sched = ActorrScheduler()
NameError: name 'ActorrScheduler' is not defined
>>> if __name__ == '__main__':
	def printer():
		while True:
			msg = yield
			print('Got:', msg)
	def counter(sched):
		while True:
			#receive the current count
			n = yield
			if n == 0:
				break
			#send to the printer task
			sched.send('printer', n)
			#send the next count to the counter task (recursive)
			sched.send('counter', n-1)
	sched = ActorScheduler()
	#create the inital actors
	sched.new_actor('printer', printer())
	sched.new_actor('counter', counter(sched))
	# send an inital message to the counter to initate
	sched.send('counter', 10000)
	sched.run()

	
Traceback (most recent call last):
  File "<pyshell#121>", line 22, in <module>
    sched.run()
  File "<pyshell#96>", line 17, in run
    actor, msg = self._msg_queue.poplef()
AttributeError: 'collections.deque' object has no attribute 'poplef'
>>> #popleft , not poplef
>>> class ActorScheduler:
	def __init__(self):
		self._actors = {} # mapping of names to actors
		self._msg_queue = deque() # message queue
	def new_actor(self, name, actor):
		'''admit a newly started actor to the scheduler and give it a name'''
		self._msg_queue.append((actor, None))
		self._actors[name] = actor
	def send(self, name, msg):
		'''send a message to a named actor'''
		actor = self._actors.get(name)
		if actor:
			self._msg_queue.append((actor, msg))
	def run(self):
		'''run as long as there are pending messages'''
		while self._msg_queue:
			actor, msg = self._msg_queue.popleft()
			try:
				actor.send(msg)
			except StopIteration:
				pass

			
>>> if __name__ == '__main__':
	def printer():
		while True:
			msg = yield
			print('Got:', msg)
	def counter(sched):
		while True:
			#receive the current count
			n = yield
			if n == 0:
				break
			#send to the printer task
			sched.send('printer', n)
			#send the next count to the counter task (recursive)
			sched.send('counter', n-1)
	sched = ActorScheduler()
	#create the inital actors
	sched.new_actor('printer', printer())
	sched.new_actor('counter', counter(sched))
	# send an inital message to the counter to initate
	sched.send('counter', 10000)
	sched.run()

	
Got: 10000
Got: 9999
Got: 9998
Got: 9997
Got: 9996
Got: 9995
Got: 9994
Got: 9993
Got: 9992
Got: 9991
Got: 9990
Got: 9989
Got: 9988
Got: 9987
Got: 9986
Got: 9985
Got: 9984
Got: 9983
Got: 9982
Got: 9981
Got: 9980
Got: 9979
Got: 9978
Got: 9977
Got: 9976
Got: 9975
Got: 9974
Got: 9973
Got: 9972
Got: 9971
Got: 9970
Got: 9969
Got: 9968
Got: 9967
Got: 9966
Got: 9965
Got: 9964
Got: 9963
Got: 9962
Got: 9961
Got: 9960
Got: 9959
Got: 9958
Got: 9957
Got: 9956
Got: 9955
Got: 9954
Got: 9953
Got: 9952
Got: 9951
Got: 9950
Got: 9949
Got: 9948
Got: 9947
Got: 9946
Got: 9945
Got: 9944
Got: 9943
Got: 9942
Got: 9941
Got: 9940
Got: 9939
Got: 9938
Got: 9937
Got: 9936
Got: 9935
Got: 9934
Got: 9933
Got: 9932
Got: 9931
Got: 9930
Got: 9929
Got: 9928
Got: 9927
Got: 9926
Got: 9925
Got: 9924
Got: 9923
Got: 9922
Got: 9921
Got: 9920
Got: 9919
Got: 9918
Got: 9917
Got: 9916
Got: 9915
Got: 9914
Got: 9913
Got: 9912
Got: 9911
Got: 9910
Got: 9909
Got: 9908
Got: 9907
Got: 9906
Got: 9905
Got: 9904
Got: 9903
Got: 9902
Got: 9901
Got: 9900
Got: 9899
Got: 9898
Got: 9897
Got: 9896
Got: 9895
Got: 9894
Got: 9893
Got: 9892
Got: 9891
Got: 9890
Got: 9889
Got: 9888
Got: 9887
Got: 9886
Got: 9885
Got: 9884
Got: 9883
Got: 9882
Got: 9881
Got: 9880
Got: 9879
Got: 9878
Got: 9877
Got: 9876
Got: 9875
Got: 9874
Got: 9873
Got: 9872
Got: 9871
Got: 9870
Got: 9869
Got: 9868
Got: 9867
Got: 9866
Got: 9865
Got: 9864
Got: 9863
Got: 9862
Got: 9861
Got: 9860
Got: 9859
Got: 9858
Got: 9857
Got: 9856
Got: 9855
Got: 9854
Got: 9853
Got: 9852
Got: 9851
Got: 9850
Got: 9849
Got: 9848
Got: 9847
Got: 9846
Got: 9845
Got: 9844
Got: 9843
Got: 9842
Got: 9841
Got: 9840
Got: 9839
Got: 9838
Got: 9837
Got: 9836
Got: 9835
Got: 9834
Got: 9833
Got: 9832
Got: 9831
Got: 9830
Got: 9829
Got: 9828
Got: 9827
Got: 9826
Got: 9825
Got: 9824
Got: 9823
Got: 9822
Got: 9821
Got: 9820
Got: 9819
Got: 9818
Got: 9817
Got: 9816
Got: 9815
Got: 9814
Got: 9813
Got: 9812
Got: 9811
Got: 9810
Got: 9809
Got: 9808
Got: 9807
Got: 9806
Got: 9805
Got: 9804
Got: 9803
Got: 9802
Got: 9801
Got: 9800
Got: 9799
Got: 9798
Got: 9797
Got: 9796
Got: 9795
Got: 9794
Got: 9793
Got: 9792
Got: 9791
Got: 9790
Got: 9789
Got: 9788
Got: 9787
Got: 9786
Got: 9785
Got: 9784
Got: 9783
Got: 9782
Got: 9781
Got: 9780
Got: 9779
Got: 9778
Got: 9777
Got: 9776
Got: 9775
Got: 9774
Got: 9773
Got: 9772
Got: 9771
Got: 9770
Got: 9769
Got: 9768
Got: 9767
Got: 9766
Got: 9765
Got: 9764
Got: 9763
Got: 9762
Got: 9761
Got: 9760
Got: 9759
Got: 9758
Got: 9757
Got: 9756
Got: 9755
Got: 9754
Got: 9753
Got: 9752
Got: 9751
Got: 9750
Traceback (most recent call last):
  File "<pyshell#126>", line 22, in <module>
    sched.run()
  File "<pyshell#124>", line 19, in run
    actor.send(msg)
  File "<pyshell#126>", line 5, in printer
    print('Got:', msg)
  File "/usr/lib/python3.3/idlelib/PyShell.py", line 1339, in write
    return self.shell.write(s, self.tags)
KeyboardInterrupt
>>> raise SystemExit('it failed!')
>>> import sys
>>> sys.stderr.write('it failed!')
it failed!10
>>> raise SystemExit(1)
>>> 
