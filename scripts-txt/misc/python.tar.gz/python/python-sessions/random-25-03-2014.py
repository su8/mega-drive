Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> 'Нинджа-ИДЕ беше инсталирана успешно'
'Нинджа-ИДЕ беше инсталирана успешно'
>>> import gettext
>>> lang1 = gettext.translation('mymodule.dial', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#2>", line 1, in <module>
    lang1 = gettext.translation('mymodule.dial', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'mymodule.dial'
>>> lang1 = gettext.translation('mymodules.dial', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    lang1 = gettext.translation('mymodules.dial', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'mymodules.dial'
>>> import os
>>> os.chdir('/home/frost/github projects/yoimnotpro3/')
>>> lang1 = gettext.translation('mymodules.dial', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#6>", line 1, in <module>
    lang1 = gettext.translation('mymodules.dial', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'mymodules.dial'
>>> lang1 = gettext.translation('mymodules.action.dial', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#7>", line 1, in <module>
    lang1 = gettext.translation('mymodules.action.dial', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'mymodules.action.dial'
>>> lang1 = gettext.translation('mymodules/action/dial', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    lang1 = gettext.translation('mymodules/action/dial', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'mymodules/action/dial'
>>> gettext.install('yoimnotpro', '/usr/share/locale')
>>> lang1 = gettext.translation('yoimnotpro', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#10>", line 1, in <module>
    lang1 = gettext.translation('yoimnotpro', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'yoimnotpro'
>>> gettext.translation('yoimnotpro', '/usr/share/locale', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#11>", line 1, in <module>
    gettext.translation('yoimnotpro', '/usr/share/locale', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'yoimnotpro'
>>> gettext.translation('mymodules/action/dial', '/usr/share/locale', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    gettext.translation('mymodules/action/dial', '/usr/share/locale', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: 'mymodules/action/dial'
>>> os.getcwd()
'/home/frost/github projects/yoimnotpro3'
>>> gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#14>", line 1, in <module>
    gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: '/mymodules/action/dial'
>>> gettext.install('/mymodules/action/dial', '/usr/share/locale')
>>> gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#16>", line 1, in <module>
    gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: '/mymodules/action/dial'
>>> gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['bg'])
Traceback (most recent call last):
  File "<pyshell#17>", line 1, in <module>
    gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['bg'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: '/mymodules/action/dial'
>>> gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['fr'])
Traceback (most recent call last):
  File "<pyshell#18>", line 1, in <module>
    gettext.translation('/mymodules/action/dial', '/usr/share/locale', languages=['fr'])
  File "/usr/lib/python3.3/gettext.py", line 401, in translation
    raise IOError(ENOENT, 'No translation file found for domain', domain)
FileNotFoundError: [Errno 2] No translation file found for domain: '/mymodules/action/dial'
>>> a = 'Ninja-IDE беше инсталарина успешно'.encode(encoding='cp1251')
>>> a
b'Ninja-IDE \xe1\xe5\xf8\xe5 \xe8\xed\xf1\xf2\xe0\xeb\xe0\xf0\xe8\xed\xe0 \xf3\xf1\xef\xe5\xf8\xed\xee'
>>> a.decode('cp1251')
'Ninja-IDE беше инсталарина успешно'
>>> class a:
	b = b'\xe1\xe5\xf8\xe5 \xe8\xed\xf1\xf2\xe0\xeb\xe0\xf0\xe8\xed\xe0 \xf3\xf1\xef\xe5\xf8\xed\xee'

	
>>> a.b.decode('cp1251')
'беше инсталарина успешно'
>>> class MyClass:
    """A simple example class"""
    i = 12345
    def f(self):
        return 'hello world'

>>> Myclass.f
Traceback (most recent call last):
  File "<pyshell#28>", line 1, in <module>
    Myclass.f
NameError: name 'Myclass' is not defined
>>> MyClass.f
<function MyClass.f at 0x7fc6e1c32440>
>>> MyClass.f()
Traceback (most recent call last):
  File "<pyshell#30>", line 1, in <module>
    MyClass.f()
TypeError: f() missing 1 required positional argument: 'self'
>>> MyClass.f(1)
'hello world'
>>> MyClass.i.__doc__
"int(x=0) -> integer\nint(x, base=10) -> integer\n\nConvert a number or string to an integer, or return 0 if no arguments\nare given.  If x is a number, return x.__int__().  For floating point\nnumbers, this truncates towards zero.\n\nIf x is not a number or if base is given, then x must be a string,\nbytes, or bytearray instance representing an integer literal in the\ngiven base.  The literal can be preceded by '+' or '-' and be surrounded\nby whitespace.  The base defaults to 10.  Valid bases are 0 and 2-36.\nBase 0 means to interpret the base from the string as an integer literal.\n>>> int('0b100', base=0)\n4"
>>> MyClass.__doc__
'A simple example class'
>>> class A:
	b = "ahoa"

	
>>> class B(A):
	b = "hehe from b"

	
>>> class C(A):
	b = "qewq from c"

	
>>> A.b
'ahoa'
>>> B.b
'hehe from b'
>>> C.b
'qewq from c'
>>> class B(A):
	print(b)

	
Traceback (most recent call last):
  File "<pyshell#48>", line 1, in <module>
    class B(A):
  File "<pyshell#48>", line 2, in B
    print(b)
NameError: name 'b' is not defined
>>> class A:
	def __init__(self):
		self.b = "hello from A"

		
>>> class B(A):
	def __init__(self):
		print(self.b)

		
>>> B()
Traceback (most recent call last):
  File "<pyshell#57>", line 1, in <module>
    B()
  File "<pyshell#56>", line 3, in __init__
    print(self.b)
AttributeError: 'B' object has no attribute 'b'
>>> class B(A):
	def __init__(self):
		print(A.b)

		
>>> B()
Traceback (most recent call last):
  File "<pyshell#60>", line 1, in <module>
    B()
  File "<pyshell#59>", line 3, in __init__
    print(A.b)
AttributeError: type object 'A' has no attribute 'b'
>>> A().b
'hello from A'
>>> class A:
	b = "ahoa"

	
>>> class B(A):
	nonlocal b
	
SyntaxError: no binding for nonlocal 'b' found
>>> class B(A):
	local b
	
SyntaxError: invalid syntax
>>> class B(A):
	global b
	print(b)

	
Traceback (most recent call last):
  File "<pyshell#68>", line 1, in <module>
    class B(A):
  File "<pyshell#68>", line 3, in B
    print(b)
NameError: global name 'b' is not defined
>>> class B(A):
	print(A.b)

	
ahoa
>>> B()
<__main__.B object at 0x7fc6e1c2efd0>
>>> class A:
	def spam(self):
		print('A.spam')

		
>>> class B(A):
	def spam(self):
		print('B.spam')
		super().spam() # call parent spam

		
>>> B.spam()
Traceback (most recent call last):
  File "<pyshell#82>", line 1, in <module>
    B.spam()
TypeError: spam() missing 1 required positional argument: 'self'
>>> B.spam(3)
B.spam
Traceback (most recent call last):
  File "<pyshell#83>", line 1, in <module>
    B.spam(3)
  File "<pyshell#81>", line 4, in spam
    super().spam() # call parent spam
TypeError: super(type, obj): obj must be an instance or subtype of type
>>> 
>>> A.spam(3)
A.spam
>>> B.spam(4)
B.spam
Traceback (most recent call last):
  File "<pyshell#86>", line 1, in <module>
    B.spam(4)
  File "<pyshell#81>", line 4, in spam
    super().spam() # call parent spam
TypeError: super(type, obj): obj must be an instance or subtype of type
>>> class B(A):
	def spam(self):
		print('B.spam')
		super().spam(3) # call parent spam

		
>>> B.spam()
Traceback (most recent call last):
  File "<pyshell#89>", line 1, in <module>
    B.spam()
TypeError: spam() missing 1 required positional argument: 'self'
>>> B.spam(5)
B.spam
Traceback (most recent call last):
  File "<pyshell#90>", line 1, in <module>
    B.spam(5)
  File "<pyshell#88>", line 4, in spam
    super().spam(3) # call parent spam
TypeError: super(type, obj): obj must be an instance or subtype of type
>>> class B(A):
	def spam():
		print('B.spam')
		super().spam() # call parent spam

		
>>> B.spam(3)
Traceback (most recent call last):
  File "<pyshell#93>", line 1, in <module>
    B.spam(3)
TypeError: spam() takes 0 positional arguments but 1 was given
>>> B.spam()
B.spam
Traceback (most recent call last):
  File "<pyshell#94>", line 1, in <module>
    B.spam()
  File "<pyshell#92>", line 4, in spam
    super().spam() # call parent spam
RuntimeError: super(): no arguments
>>> class A:
	def __init(self):
		self.x = 0

		
>>> class B(A):
	def __init__(self):
		super().__init__()
		self.y = 1

		
>>> A(3).x
Traceback (most recent call last):
  File "<pyshell#104>", line 1, in <module>
    A(3).x
TypeError: object() takes no parameters
>>> A.x
Traceback (most recent call last):
  File "<pyshell#105>", line 1, in <module>
    A.x
AttributeError: type object 'A' has no attribute 'x'
>>> A().x
Traceback (most recent call last):
  File "<pyshell#106>", line 1, in <module>
    A().x
AttributeError: 'A' object has no attribute 'x'
>>> class A:
	def __init__(self):
		self.x = 0

		
>>> class B(A):
	def __init__(self):
		super().__init__()
		self.y = 1

		
>>> A().x
0
>>> B().y
1
>>> B().x
0
>>> class B(A):
	def __init__(self):
		super().__init__()
		self.y = 1
		print(self.x)

		
>>> B()
0
<__main__.B object at 0x7fc6e1c2efd0>
>>> for x in range(1,8):
	print(x)

	
1
2
3
4
5
6
7
>>> button = ""
>>> for x in range(1, 8):
	button[x] = "aheheh"

	
Traceback (most recent call last):
  File "<pyshell#124>", line 2, in <module>
    button[x] = "aheheh"
TypeError: 'str' object does not support item assignment
>>> button['1']
Traceback (most recent call last):
  File "<pyshell#125>", line 1, in <module>
    button['1']
TypeError: string indices must be integers
>>> button['1'] = "ae"
Traceback (most recent call last):
  File "<pyshell#126>", line 1, in <module>
    button['1'] = "ae"
TypeError: 'str' object does not support item assignment
>>> for x in range(1, 8):
	button+x = "aheheh"
	
SyntaxError: can't assign to operator
>>> 
>>> for x in range(1, 8):
	button + x = "aheheh"
	
SyntaxError: can't assign to operator
>>> a = {'button': '1', '2', '3', '4','5','6','7'}
SyntaxError: invalid syntax
>>> a = {'button': ('1', '2', '3', '4','5','6','7')}
>>> a['button'][0]
'1'
>>> a['button'][0] = 2
Traceback (most recent call last):
  File "<pyshell#133>", line 1, in <module>
    a['button'][0] = 2
TypeError: 'tuple' object does not support item assignment
>>> for x in range(0, 7):
	a['button'][x] = "aheheh"

	
Traceback (most recent call last):
  File "<pyshell#135>", line 2, in <module>
    a['button'][x] = "aheheh"
TypeError: 'tuple' object does not support item assignment
>>> for x in range(0, 7):
	a['button'][x] = "button{}".format(x)

	
Traceback (most recent call last):
  File "<pyshell#137>", line 2, in <module>
    a['button'][x] = "button{}".format(x)
TypeError: 'tuple' object does not support item assignment
>>> a['button'][x]
'1'
>>> class A:
	pass

>>> from collections import namedtuple
>>> S = namedtuple('A', [a['button'][x] for x in range(0, 7)])
Traceback (most recent call last):
  File "<pyshell#143>", line 1, in <module>
    S = namedtuple('A', [a['button'][x] for x in range(0, 7)])
  File "/usr/lib/python3.3/collections/__init__.py", line 343, in namedtuple
    'identifiers: %r' % name)
ValueError: Type names and field names must be valid identifiers: '1'
>>> S = namedtuple('A', ['button{}'.format(a['button'][x]) for x in range(0, 7)])
>>> S.button1
<property object at 0x7fc6e7394838>
>>> d = S(1,2,3,4,5,6,7)
>>> d.button1
1
>>> d.button2
2
>>> d.button3
3
>>> d.button4
4
>>> d.button5
5
>>> d.button6
6
>>> d.button7
7
>>> d.button8
Traceback (most recent call last):
  File "<pyshell#154>", line 1, in <module>
    d.button8
AttributeError: 'A' object has no attribute 'button8'
>>> S(1)
Traceback (most recent call last):
  File "<pyshell#155>", line 1, in <module>
    S(1)
TypeError: __new__() missing 6 required positional arguments: 'button2', 'button3', 'button4', 'button5', 'button6', and 'button7'
>>> S.button1
<property object at 0x7fc6e7394838>
>>> S = namedtuple('A', ['button{}'.format(x) for x in range(0, 7)]).(1,2,3,4,5,6,7)
SyntaxError: invalid syntax
>>> D = ['button{}'.format(x) for x in range(0, 7)]
>>> D = S(['button{}'.format(x) for x in range(0, 7)])
Traceback (most recent call last):
  File "<pyshell#159>", line 1, in <module>
    D = S(['button{}'.format(x) for x in range(0, 7)])
TypeError: __new__() missing 6 required positional arguments: 'button2', 'button3', 'button4', 'button5', 'button6', and 'button7'
>>> a = ""
>>> for x in range(5):
	a += x

	
Traceback (most recent call last):
  File "<pyshell#163>", line 2, in <module>
    a += x
TypeError: Can't convert 'int' object to str implicitly
>>> for x in range(5):
	a += str(x)

	
>>> a
'01234'
>>> a.split()
['01234']
>>> 
