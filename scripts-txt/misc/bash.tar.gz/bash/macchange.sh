gksu ifconfig enp2s0 hw ether 0A:A0:04:D4:AA:12
#echo 'gksu ifconfig enp2s0 hw ether 0A:A0:04:D4:AA:11' > macchange.sh && chmod +x macchange.sh
