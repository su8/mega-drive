Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> import configparser
>>> config = configparser.ConfigParser()
>>> config['DEFAULT'] = {'ServerAliveInterval': '45',
		     'Compression': 'yes',
		     'CompressionLevel': '9' }
>>> config['bitbucket.org'] = {}
>>> config['bitbucket.org']['User'] = 'hg'
>>> config['topsecret.server.com'] = {}
>>> topsecret = config['topsecret.server.com']
>>> topsecret['Port'] = '50022'
>>> topsecret['ForwardX11'] = 'no' # mutatetes the parser
>>> config['DEFAULT']['ForwardX11'] = 'yes'
>>> with open('example.ini', 'wt') as conf:
	conf.write(configfile)

	
Traceback (most recent call last):
  File "<pyshell#14>", line 2, in <module>
    conf.write(configfile)
NameError: name 'configfile' is not defined
>>> with open('example.ini', 'wt') as conf:
	conf.write(config)

	
Traceback (most recent call last):
  File "<pyshell#16>", line 2, in <module>
    conf.write(config)
TypeError: must be str, not ConfigParser
>>> with open('example.ini', 'w') as conf:
	conf.write(config)

	
Traceback (most recent call last):
  File "<pyshell#18>", line 2, in <module>
    conf.write(config)
TypeError: must be str, not ConfigParser
>>> with open('example.ini', 'w') as conf:
	config.write(conf)

	
>>> # let's imoprt the ini file
>>> config = configparser.ConfigParser()
>>> config.sections()
[]
>>> config.read('example.ini')
['example.ini']
>>> config.sections()
['bitbucket.org', 'topsecret.server.com']
>>> 'bitbucket.org' in config
True
>>> config['bitbucket.org']['User']
'hg'
>>> for key in config['bitbucket.org']:
	print(key)

	
user
serveraliveinterval
compression
compressionlevel
forwardx11
>>> topsecret.get('Port')
'50022'
>>> config.get('bitbucket.org', 'monster',
	fallback='No such things as monsters')
'No such things as monsters'
>>> # configparser.ExtendedInterpolation()
>>> '''[Common]
home_dir: /Users
library_dir: /Library
system_dir: /System
macports_dir: /opt/local

[Frameworks]
Python: 3.2
path: ${Common:system_dir}/Library/Frameworks/

[Arthur]
nickname: Two Sheds
last_name: Jackson
my_dir: ${Common:home_dir}/twosheds
my_pictures: ${my_dir}/Pictures
python_dir: ${Frameworks:path}/Python/Versions/${Frameworks:Python}'''
'[Common]\nhome_dir: /Users\nlibrary_dir: /Library\nsystem_dir: /System\nmacports_dir: /opt/local\n\n[Frameworks]\nPython: 3.2\npath: ${Common:system_dir}/Library/Frameworks/\n\n[Arthur]\nnickname: Two Sheds\nlast_name: Jackson\nmy_dir: ${Common:home_dir}/twosheds\nmy_pictures: ${my_dir}/Pictures\npython_dir: ${Frameworks:path}/Python/Versions/${Frameworks:Python}'
>>> 
