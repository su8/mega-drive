#/usr/bin/python2
import os
import shlex
import getpass
import subprocess
from gi.repository import Gtk


class inxi_gui:







    def __init__(self):
        intf = Gtk.Builder()
        intf.add_from_file('inxi_gui.glade')
        intf.connect_signals(self)
        #entry = intf.get_object('entry1')
        #entry.connect("changed", self.on_entry1_activate)
        window = intf.get_object("window1")
        #notebook = intf.get_object("notebook1")
        #window.add(notebook)
        #vbox = Gtk.VBox()
        #window.add(vbox)
        #vbox.pack_start(notebook, True, True, 0)

        
        textview1 = intf.get_object("textview1")
        textbuffer1 = textview1.get_buffer()
        sp = subprocess.Popen(shlex.split('inxi -f -c 0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer1.set_text("{0}".format(out[7:-1]))

        textview2 = intf.get_object("textview2")
        textbuffer2 = textview2.get_buffer()
        sp = subprocess.Popen(shlex.split('inxi -G -c 0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer2.set_text("{0}".format(out[17:-1]))

        textview3 = intf.get_object("textview3")
        textbuffer3 = textview3.get_buffer()
        sp = subprocess.Popen(shlex.split('inxi -Dlo -c 0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer3.set_text("{0}".format(out[11:-1]))


        textview4 = intf.get_object("textview4")
        textbuffer4 = textview4.get_buffer()
        sp = subprocess.Popen(shlex.split('inxi -A -c 0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer4.set_text("{0}".format(out[11:-1]))
        
        textview5 = intf.get_object("textview5")
        textbuffer5 = textview5.get_buffer()
        sp = subprocess.Popen(shlex.split('inxi -n -c 0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer5.set_text("{0}".format(out[11:-1]))

        textview6 = intf.get_object("textview6")
        textbuffer6 = textview6.get_buffer()
        sp = subprocess.Popen(shlex.split('inxi -M -c 0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        textbuffer6.set_text("{0}".format(out[11:-1]))

        textview7 = intf.get_object("textview7")
        textbuffer7 = textview7.get_buffer()
        sp = subprocess.Popen(shlex.split('inxi -S -c 0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = sp.communicate()
        #os.system("sensors > sensors.txt")
        #with open("/home/frost/Desktop/sensors.txt") as sensors:
            #sensors.read()
        sp = subprocess.Popen(shlex.split('sensors'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out2, err = sp.communicate()
        textbuffer7.set_text("{0}\n\nSensors:\n{1}".format(out[11:-1], out2))

        #self.textview = Gtk.TextView()
        #self.textbuffer = self.textview.get_buffer()
        #self.textbuffer.set_text("")

        window.connect("delete-event", Gtk.main_quit)
        window.show_all()

if __name__ == '__main__':
    inxi_gui()
    Gtk.main()