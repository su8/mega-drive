/*
 * ion/de/private.h
 *
 * Copyright (c) Tuomo Valkonen 1999-2009. 
 *
 * See the included file LICENSE for details.
 */

#ifndef ION_DE_PRIVATE_H
#define ION_DE_PRIVATE_H

#define DE_SUB_IND " ->"
#define DE_SUB_IND_LEN 3

#endif /* ION_DE_PRIVATE_H */
