/*
  11/16/2016

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
  MA 02110-1301, USA.
*/
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define STRZIZE(x) ((sizeof(x) / sizeof(char)))

static inline void update_line(const char *);
static inline void check_n_update(void);

int main(void) {
  struct timespec tc = { 0, 500L * 1000000L };

  while (1) {
    check_n_update();
    if (-1 == (nanosleep(&tc, NULL))) {
      exit(EXIT_FAILURE);
    }
  }
  return EXIT_SUCCESS;
}

static inline void 
check_n_update(void) {
  static char buf[300] = "Hello World";
  FILE *fp = NULL;

  if (NULL != (fp = fopen("/tmp/yepstat", "r"))) {
    if (EOF == (fscanf(fp, "%[^\n]", buf))) {
      fclose(fp);
      exit(EXIT_FAILURE);
    }
    if (EOF == (fclose(fp))) {
      exit(EXIT_FAILURE);
    }
  }
  update_line(buf);
}

static inline void 
update_line(const char *buf) {
  static char x = 0, z = 0, newbuf[350] = "Hello World";
  static const char str1[] = "\0337\033[1;1H\033[K";
  static const char str2[] = "\0338";
  static char *const first_end = newbuf + STRZIZE(str1)-1;

  static size_t len1 = STRZIZE(str1)-1, len2 = STRZIZE(str2);
  size_t buflen = strlen(buf);

  if (z == x) {
    memcpy(newbuf, str1, len1);
    x = 1;
  }
  memcpy(first_end, buf, buflen);
  memcpy(first_end + buflen, str2, len2);

  fputs(newbuf, stdout);
  if (0 != (fflush(stdout))) {
    exit(EXIT_FAILURE);
  }
}
