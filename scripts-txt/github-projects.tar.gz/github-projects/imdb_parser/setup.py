#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from distutils.core import setup
setup(
    name='imdb',
    version='0.1',
    py_modules=['imdb'],
    author='Aaron Caffrey',
    author_email='aaron_caffrey@hotmail.com',
    license='GPLv3')