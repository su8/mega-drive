Simple System Stats

status.c is what I use and the rest were made along the way.