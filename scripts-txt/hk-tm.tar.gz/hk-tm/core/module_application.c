#include <stdio.h>
#include <unistd.h>

#include "module.h"

void *module_application_start(void *args)
{
   printf("Starting module APPLICATION\n");

   while(modulelist[MODULE_APPLICATION_INDEX].status != MODULE_STOPPING) {
      if(modulelist[MODULE_APPLICATION_INDEX].status == MODULE_STARTING) modulelist[MODULE_APPLICATION_INDEX].status = MODULE_STARTED;
      sleep(1);
   }

   printf("Stopping module APPLICATION\n");
   modulelist[MODULE_APPLICATION_INDEX].status = MODULE_STOPPED;

   return NULL;
}
