pygobject-examples
==================

Python gobject examples for your next project. Whether you need inspiration or need to solve some issue, those examples will serve you well. I've wrote them in range of 3 days and tried to cover as many aspects as possible.
