#!/usr/bin/env python2
from random import choice
from string import printable, whitespace

class RandomPassword(object):
    def __init__(self, number):
        crazy = str().join(x for x in printable if not x in whitespace)
        print(str().join(choice(crazy) for _ in range(number)))

if __name__ == '__main__':
    RandomPassword()