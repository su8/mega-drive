/*
 * module to include the modules
 */

void init_ip_scalars(void);

config_require(ip-mib/data_access/scalars_common)
