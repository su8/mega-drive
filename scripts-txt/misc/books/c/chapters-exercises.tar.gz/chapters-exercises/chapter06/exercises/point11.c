/* 11. Write a program that reads eight integers into an array and then prints them in reverse
order. */
#include <stdio.h>
int main(void)
{
    int nums[8];
    int n2;
    
    for (n2 = 0; n2 <= 8; n2++)
        nums[n2] = n2;
    for (n2 = 8 - 1; n2 > 0; n2--)
        printf("%d", nums[n2]);
    
    return 0;
}
