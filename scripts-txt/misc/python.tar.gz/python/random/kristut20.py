x = input("Enter Something:  ")

# let's split the input by adding it in a list and try to find out
# if it contains numbers, e.g: my2comma5nd9 will become ['m','y','2','c','o','m','m','a','5','n','d','9']

x_in_list = list(x)

# creating second list that will hold the numbers, because we will delete
# them from the first list and will leave the letters only

x_numbers = list()

# append only the numbers from the x_in_list to x_numbers list

for detected_numbers in x_in_list:
    # basically the for loop will loop over all characters and those
    # that are numbers [.isdigit()] will be added to the x_numbers list
    if detected_numbers.isdigit():
        x_numbers.append(detected_numbers)

# concatenate the letters from the x_in_list in a single statement with
# list comprehension, so ['m','y','c','o','m','m','a','n','d'] will become 'mycommand'

x2 = ''.join([x for x in x_in_list if not x.isdigit()])

# check if the x_numbers is not empty and print the items in it

if x_numbers:
    print("Integers {0}".format(''.join(x_numbers)))

# in this 'print' we don't use format, but we could use it.
if x2:
    print("You entered", x2)
#>>> s = "haho"
#>>> z = list(s)
#>>> z = [s]
#>>> z
#['haho']
#>>> z = list(s)
#>>> z
#['h', 'a', 'h', 'o']
#>>> [x for x in s]
#['h', 'a', 'h', 'o']
#>>> z
#['h', 'a', 'h', 'o']
#>>> s = 'ha1ho3'
#>>> z = list(s)
#>>> z
#['h', 'a', '1', 'h', 'o', '3']
#>>> mynewlist = [s for s in z if s.isdigit()]
#>>> mynewlist
#['1', '3']
#>>> mynewlist2 = [s for s in z if not s.isdigit()]
#>>> mynewlist2
#['h', 'a', 'h', 'o']
#>>>