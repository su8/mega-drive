
---

Release 2016.04 is round the corner.

Here is a quick list of things that one can expect from release 2016.04:

* Based on LFS systemd and BLFS systemd development versions.

* Arya in all DEs listed in BLFS and also Mate. Mate actually is undergoing some serious work of late so need to catch up with that.

* I have created a lot of extra scripts that would be tested and eventually uploaded for download. As of now the LFS, X-Server and Mate Scripts are pretty stable. Would share them soon.

* A lot of work is in progress to get a nice bootsplash going during the boot process. Hopefully would succeed in getting either one of Splashy or Plymouth integrated into the boot system.

* Far more refined and stable desktop compared to the previous versions. Of course we would not disturb the existing integrity by making more changes but things would definitely be more stable.

* Blueman is back with version 2.0 and bluez5. It was dropped off BLFS a version or so back because Blueman was incompatible with bluez5. A few days back, did build both on Mate and things just worked, yet need to test it though.

* Generic kernel to ensure most systems would be able to run AryaLinux - x86 and x86_64 of course.

* LFS part builds a little faster in multi core systems and by incorporation of ccache building other stuff becomes a little faster as well (llvm, kernel etc.)

* Initramfs support. This sould have been like there, no questions asked. My bad. Took some time, but initramfs support, yes of course.

* Package version would by and large be the same as in the LFS and BLFS books.
