! function(w) {
    "use strict";
    // !-- -------------------------------------------------------- -->
    // !-- Utilities												-->
    // !-- -------------------------------------------------------- -->
    // implementing $ with queryselector(+all)
    var $ = function(selector, rootNode) {
        return (rootNode || document).querySelector(selector);
    };
    var styleContainer = function(container, class1, class2) {
        var classes = container.className.split(' ');
        [class1, class2].forEach(function(curClazz) {
            if (classes.indexOf(curClazz) !== -1)
                classes.splice(classes.indexOf(curClazz), 1);
        });
        container.className = classes.join(' ') + ' ' + class2;
    };
    var utils = {
        escapeRegExp: function(string) { // escape regex
            return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
        },
        capFirst: function(text) { // capitalize first char, lower the rest
            return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
        },
        clearElements: function(container) {
            while (container.firstChild) {
                container.removeChild(container.firstChild);
            }
            return container;
        },
        hideElement: function(container) {
            container.style.opacity = "0";
        },
        showElement: function(container) {
            container.style.opacity = "1";
        },
        show: function(container) {
            styleContainer(container, 'hide', 'show');
        },
        hide: function(container) {
            styleContainer(container, 'show', 'hide');
        },
        // register custom events
        registerEvent: function(event, bubbles, cancelable) {
            return (CustomEvent) ? new CustomEvent(event, {
                bubbles: bubbles,
                cancelable: cancelable
            }) : (document.createEvent('Event').initEvent(event, bubbles, cancelable));
        },
        // custom listeners
        registerListener: function(target, type, callback) {
            (target.addEventListener || target.attachEvent)
                (target.addEventListener ? type: 'on' + type, callback);
        },
        removeListener: function(target, type, callback) {
            (target.removeEventListener || target.detachEvent)
                (target.removeEventListener ? type: 'on' + type, callback);
        },
        // template string to dom element , remember to return el.childNodes[0] // or use element accordingly;
        str2WrappedDOMElement: function(html) {
            var el = document.createElement('div');
            el.innerHTML = html;
            // return el.childNodes[0];
            return el;
        },
        elemId: function(id) {
            return document.getElementById(id);
        },
        // minimal ajax // use this.<attr> in callbacks to access the xhr object directly
        ajax: function(o) {
            o.useAsync = o.useAsync || true;
            if (!o.method || ! o.url || ! o.success) return false;
            var xhr = w.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            xhr.timeout = geminiBlog.timeout || 4000;
            // throws syntax error otherwise
            if (o.mimeType) {
                xhr.overrideMimeType(o.mimeType);
            }
            xhr.ontimeout = function() {
                console.error("Request timed out: " + o.url);
            };
            xhr.onerror = o.error ? o.error: function() {
                console.log(xhr);
            };
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    o.success ? o.success(xhr) : (function() {
                        console.log(xhr);
                    })();
                }
            };
            xhr.open(o.method, o.url, o.useAsync);
            xhr.send(null);
        },
    };
    // !-- -------------------------------------------------------- -->
    // !-- Variables												-->
    // !-- -------------------------------------------------------- -->
    // global var
    var geminiBlog = {
        version         : '',
        olderVersion    : '',
        metadata_one    : {},
        metadata_two    : {},
        releaseSchedule : {},
        entries			: [],
        about           : [],
        notes           : [],
        notesLinks      : [],
        newsArr         : [],
        variables       : [],
        download_table  : {},
        CategoriesEmpty : true,
        categories      : [],
        repoBase		: "./markdown/",
        useAsync		: true,
        timeout			: 10000,
    };
    geminiBlog.escapeTitle = function(title) {
        var re = new RegExp('[^A-Za-z0-9_ ]', 'g');
        return title.replace('.md', '').replace(re, '')
            .replace(/\s+/g, '-').toLowerCase();
    };
    // !-- -------------------------------------------------------- -->
    // !-- Functions												-->
    // !-- -------------------------------------------------------- -->
    geminiBlog.registerEntry = function(entryUrl, title, categories) {
        // if url begins with ./ replace it with repoBase, else leave as is and consider as full url
        var eurl = (entryUrl.slice(0, 2) === "./") ?
            geminiBlog.repoBase + entryUrl.slice(2) : entryUrl;
        var categories_clean = categories.toLowerCase().replace(" ", "").split(",");
        var categories_num = categories_clean.length;

        // create the entry object
        var entry = { // properties of each entry
            index: geminiBlog.entries.length,
            id: geminiBlog.escapeTitle(title || entryUrl),
            url: eurl,
            title: title,
            categories: categories_clean,
        };

        geminiBlog.entries.push(entry);

        if (categories && categories !== "") {
            geminiBlog.CategoriesEmpty = false;
            while (categories_num--)
                if (geminiBlog.categories.indexOf(
                            categories_clean[categories_num]) == - 1) {
                    geminiBlog.categories.push(categories_clean[categories_num]);
                }
        }
    };
    // sort list by a key - default: date
    geminiBlog.sortEntries = function(key, elist, reverse) {
        key = key || "date";
        elist = elist || geminiBlog.entries;
        reverse = reverse || true; // most recent first // highest value first
        elist.sort(function(a, b) {
            var keyA = a[key];
            var keyB = b[key];
            if (reverse) {
                return ((keyA < keyB) ? 1: ((keyA > keyB) ? - 1: 0));
            }
            else {
                return ((keyA < keyB) ? - 1: ((keyA > keyB) ? 1: 0));
            }
        });
    };
    // find entries by their id/index/category
    geminiBlog.getEntryBy = function(itsCategory, keyword, eid, customList, fromInt) {
        var i;
        var parseEid = fromInt ? JSON.stringify(eid) : eid;
        var theList = customList || geminiBlog.entries;
        if (theList.length === 0) {
            return false;
        }
        if (theList.length === 1) {
            return theList[0];
        }

        if (!itsCategory) {
            for (i in theList) {
                if (theList[i][keyword] === parseEid) {
                    return theList[i];
                }
            }
            return false;
        }
        var categories_entries = [];

        for (i in theList) {
            var entry = theList[i];
            if (entry.categories.indexOf(keyword) !== - 1) {
                categories_entries.push(entry);
            }
        }
        return (categories_entries.length > 0) ? categories_entries: false;
    };
    /* markdown2html parser https://github.com/chjj/marked/ */
    if (w.marked) {
        geminiBlog.markDownOptions = {
            renderer: new marked.Renderer(),
            gfm: true,
            tables: true,
            breaks: false,
            pedantic: false,
            sanitize: true,
            smartLists: true,
            smartypants: false,
            //langPrefix: 'hljs ',
            highlight: function(code, lang) {
                return hljs.highlightAuto(code, [lang]).value;
            }
        };
        // this function makes html from markdown
        geminiBlog.mdToHTML = function(md) {
            var regularTable = new RegExp('<table>', 'g');
            if (marked && geminiBlog.markDownOptions) {
                return marked(md, geminiBlog.markDownOptions)
                    .replace(regularTable, '<table class="table table-hover">');
            }
            return false;
        };
    }
    geminiBlog.normalizeLeftColumn = function() {
        utils.elemId('left-column').setAttribute('class',
                'page-content col-md-10 col-sm-8');
    };



    geminiBlog.router = function() {
        // if anchored - show entry maching id with anchor or tag matching anchor or default page
        var anchor = document.location.hash.substring(2).toLowerCase(); // substring(2) removing hashbang
        utils.hide($("#download-sidebar-links"));
        utils.hide($("#CategoriesBar"));
        geminiBlog.normalizeLeftColumn();

        if (anchor !== "") {

            // routing done here based on hashbang anchors
            switch (true) {
                case anchor === "home" : return geminiBlog.homePage();
                case anchor === "news"   : return geminiBlog.viewNewsOrDocs(geminiBlog.newsArr, 'News', false);
                case anchor === "about" : return geminiBlog.aboutDetailsView(geminiBlog.about[0][1]);
                case anchor === "contact": return geminiBlog.contactPage();
                case anchor === "docs": return geminiBlog.viewNewsOrDocs(false, 'Documentation', true);
                case anchor === "download": return geminiBlog.downloadPage();
                case anchor === "releaseschedule":  return geminiBlog.schedulePage();

                case(/^entry=(.*)/.test(anchor)):
                    if (geminiBlog.getEntryBy(false, 'id', anchor.match(/^entry=(.*)/)[1])) {
                        return geminiBlog.detailsView(geminiBlog.getEntryBy(false,
                                    'id', anchor.match(/^entry=(.*)/)[1]), true);
                } else {
                    document.location.href = "#!home";
                }
                break;

                case(/^notes=(.*)/.test(anchor)):
                    if (geminiBlog.getEntryBy(false, 'escaped', anchor.match(/^notes=(.*)/)[1], geminiBlog.notes)) {
                        return geminiBlog.detailsView(geminiBlog.getEntryBy(false,
                                    'escaped', anchor.match(/^notes=(.*)/)[1], geminiBlog.notes));
                } else {
                    document.location.href = "#!home";
                }
                break;

                case(/^news=(.*)/.test(anchor)):
                    if (geminiBlog.getEntryBy(false, 'escaped', anchor.match(/^news=(.*)/)[1], geminiBlog.newsArr)) {
                        return geminiBlog.detailsView(geminiBlog.getEntryBy(false,
                                    'escaped', anchor.match(/^news=(.*)/)[1], geminiBlog.newsArr));
                } else {
                    document.location.href = "#!home";
                }
                break;

                case(/^about=(.*)/.test(anchor)):
                    if (geminiBlog.getEntryBy(false, 'escaped', anchor.match(/^about=(.*)/)[1], geminiBlog.about)) {
                        return geminiBlog.aboutDetailsView(geminiBlog.getEntryBy(false,
                                    'escaped', anchor.match(/^about=(.*)/)[1], geminiBlog.about));
                } else {
                    document.location.href = "#!home";
                }
                break;

                case (/^docs=(.*)/.test(anchor)):
                    if (anchor.match(/^docs=(.*)/)[1]) {
                        return geminiBlog.viewNewsOrDocs(geminiBlog.getEntryBy(true,
                                    anchor.match(/^docs=(.*)/)[1]), 'Categories', true);
                } else {
                    document.location.href = "#!home";
                }
                break;

                default:
                    document.location.href = "#!home";
                break;
            }
        }

        return geminiBlog.homePage();
    };

    // setup = these functions are run after the page finishes loading
    geminiBlog.init = function() {
        // sort the lists
        geminiBlog.sortEntries("index", geminiBlog.entries, true);
        geminiBlog.sortEntries("id", geminiBlog.newsArr, true);
        geminiBlog.categories.sort();

        geminiBlog.router();
        utils.registerListener(w, 'hashchange', geminiBlog.router);
    };

    // Bootstrap dropdown menu without jquery
    var daMenus = {

        // Navbar and dropdowns
        toggle: document.getElementsByClassName('navbar-toggle')[0],
        collapse: document.getElementsByClassName('navbar-collapse')[0],

        toggleMenu: function() { // Toggle if navbar menu is open or closed
            daMenus.collapse.classList.toggle('collapse');
        },

        // Close dropdowns when screen becomes big enough to switch to open by hover
        closeMenusOnResize: function() {
            if (document.body.clientWidth >= 768) {
                daMenus.collapse.classList.add('collapse');
            }
        },
    };

    // !-- -------------------------------------------------------- -->
    // !-- Start the event listeners								-->
    // !-- -------------------------------------------------------- -->
    // fire geminiBlog.init() after page load or if the anchor changes
    utils.registerListener(w, 'load', geminiBlog.init);

    // dropdown menu listeners
    utils.registerListener(w, 'resize', daMenus.closeMenusOnResize);
    daMenus.toggle.addEventListener('click', daMenus.toggleMenu, false);


    // debug
    w.geminiBlog = geminiBlog;

} (window);
