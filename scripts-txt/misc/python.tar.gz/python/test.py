# a = dict()

# for x in range(10000000):
#     a[x] = x

# if 7638902 in a.keys():
#     print('we have a match in list "a"')
from contextlib import contextmanager
from time import time

@contextmanager
def timeit():
    start = time()
    try:
        yield
    finally:
        end = time()
        print(end - start)

with timeit():
    a =  list()
    for x in range(10000000):
        a.append(x)