var detailsViewTemplate = [
    "<article class='details-wrapper'>",
        "<div class='details-head'>",
            "<div class='details-head-wrapper'>",
                "<h4 class='details-title'></h4>",
            "</div>",
        "</div>",
        "<div class='details-body'>",
        "</div>",
        "<div class='details-footer'>",
            "<div id='the-links'>",
                "<hr>",
                "<ul class='pager'>",
                    "<li class='previous'>",
                        "<a id='previous-link'>&larr; Older</a>",
                    "</li>",
                    "<li class='next'>",
                        "<a id='next-link'>Newer &rarr;</a>",
                    "</li>",
                "</ul>",
            "</div>",
        "</div>",
    "</article>"
].join('');

geminiBlog.createDetails = function(entry, showCategories) {
    var detailsViewHTML = utils.str2WrappedDOMElement(detailsViewTemplate);

    var head = $('.details-head-wrapper', detailsViewHTML);

    $('.details-title', head).setAttribute("id", entry.id);
    $('.details-title', head).textContent = entry.title;

    //set content
    $('.details-body', detailsViewHTML).innerHTML = entry.html;

    //footer
    var footer = $('.details-footer', detailsViewHTML);
    var clonedEntries = geminiBlog.newsArr.slice(0);
    var currentLocation = document.location.hash.split('=')[0];

    if (showCategories)
        geminiBlog.showCategories();

    if (currentLocation !== '#!news') {
        utils.hide($('#the-links', footer));
    } else {
        // previous link
        if (entry.index > 0) {
            $('#previous-link', footer).setAttribute("href", "#!news=" +
                    geminiBlog.getEntryBy(false, 'id', parseInt(entry.index) - 1,
                        clonedEntries, true).escaped);
        } else {
            // remove link
            utils.hide($('#previous-link', footer));
        }
        // next link
        if (entry.index < clonedEntries.length - 1) {
            $('#next-link', footer).setAttribute("href", "#!news=" +
                    geminiBlog.getEntryBy(false, 'id', parseInt(entry.index) + 1,
                        clonedEntries, true).escaped);
        } else {
            // remove link
            utils.hide($('#next-link', footer));
        }
    }

    return detailsViewHTML.childNodes[0];
};

geminiBlog.detailsView = function(entry, showCategories) {
    document.title = entry.title;
    var container = utils.clearElements($("#entries-wrapper"));

    var detailsViewInstructions = function(entry) {
        //create and add snippet
        container.appendChild(geminiBlog.createDetails(entry, showCategories));

        utils.elemId(entry.id).scrollIntoView(true);
    };

    // fetch entry and process
    if (!entry.text) {
        utils.ajax({
            method: "GET",
            url: entry.url,
            mimeType: "text/plain; charset=x-user-defined",
            success: function(xhr) {
                entry.text = xhr.responseText;
                entry.html = geminiBlog.mdToHTML(xhr.responseText);

                //generate
                detailsViewInstructions(entry, showCategories);

            },
            error: function() {
                console.log("err");
                return false;
            }
        });
    } else {
        //create and add details
        detailsViewInstructions(entry, showCategories);
    }
};
