Python 3.3.4 (default, Feb 11 2014, 15:56:08) 
[GCC 4.8.2 20140206 (prerelease)] on linux
Type "copyright", "credits" or "license()" for more information.
>>> class NoMixedCaseMeta(type):
	def __new__(cls, clsname, bases, clsdict):
		for name in clsdict:
			if name.lower() != name:
				raise TypeError('Bad attribute name: ' + name)
		return super().__new__(cls, clsname, bases, clsdict)

	
>>> class Root(metaclass=NoMiXedCaseMeta):
	pass

Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    class Root(metaclass=NoMiXedCaseMeta):
NameError: name 'NoMiXedCaseMeta' is not defined
>>> class Root(metaclass=NoMixedCaseMeta):
	pass

>>> class A(Root):
	def foo_bar(self):
		pass

	
>>> class B(Root):
	def fooBar(self): # TypeError
		pass

	
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    class B(Root):
  File "<pyshell#6>", line 5, in __new__
    raise TypeError('Bad attribute name: ' + name)
TypeError: Bad attribute name: fooBar
>>> # defining classes programmatically
>>> def __init__(self, name, shares, price):
	self.name = name
	self.price = price
	self.shares = shares

	
>>> def __init__(self, name, shares, price):
	self.name = name
	self.price = price
	self.shares = shares

def cost(self):
	
SyntaxError: invalid syntax
>>> def __init__(self, name, shares, price):
	self.name = name
	self.price = price
	self.shares = shares

	
>>> def cost(self):
	return self.shares * self.price

>>> cls_dict = {
	'__init__' : __init__,
	'cost' : cost,
	}
>>> 
>>> import types
>>> Stock = types.new_class('Stock', (), {}, lambda ns: ns.update(cls_dict))
>>> Stock.__module__ = __name__
>>> s = Stock('ACME', 50, 91.1)
>>> s.cost()
4555.0
>>> s
<__main__.Stock object at 0x7f6240e6ec50>
>>> import abc
>>> Stock = types.new_class('Stock', (), {'metaclass': abc.ABCMeta},
			lambda ns: ns.update(cls_dict))
>>> Stock.__module__ = __name__
>>> Stock.cost()
Traceback (most recent call last):
  File "<pyshell#48>", line 1, in <module>
    Stock.cost()
TypeError: cost() missing 1 required positional argument: 'self'
>>> s = Stock('ACME', 50, 91.1)
>>> s
<__main__.Stock object at 0x7f6240e6e750>
>>> s.cost()
4555.0
>>> type(Stock)
<class 'abc.ABCMeta'>
>>> Stock
<class '__main__.Stock'>
>>> class Spam(Base, debug=True, typecheck=False):
	pass

Traceback (most recent call last):
  File "<pyshell#56>", line 1, in <module>
    class Spam(Base, debug=True, typecheck=False):
NameError: name 'Base' is not defined
>>> # is the same as
>>> Spam = types.new_class('Spam', (Base,), {'debug': True, 'typecheck': Fa;se},
		       
SyntaxError: invalid syntax
>>> Spam = types.new_class('Spam', (Base,), {'debug': True, 'typecheck': False},
		       lambda ns: ns.update(cls_dict))
Traceback (most recent call last):
  File "<pyshell#60>", line 1, in <module>
    Spam = types.new_class('Spam', (Base,), {'debug': True, 'typecheck': False},
NameError: name 'Base' is not defined
>>> 
