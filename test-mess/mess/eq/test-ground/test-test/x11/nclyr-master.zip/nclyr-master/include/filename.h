#ifndef INCLUDE_FILENAME_H
#define INCLUDE_FILENAME_H

/* Returns an alloced string, that is the full path of 's' with '~' expanded */
char *filename_get(const char *s);

#endif
