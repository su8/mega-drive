/* 
   compile with:
   gcc -Wall -O3 -o pdf2img pdf2img.c `pkg-config --cflags --libs gtk+-3.0`

   or just use the provided 'Makefile'
*/

#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "my_constants.h"

/* function prototypes */
void RaiseWarning(void);
void on_image_combo(void);
void on_sdevice_combo(void);
void on_about_clicked(void);
void on_button1_clicked(void);
void pdf_to_img(char *filename);

/* gtk related classes */
GtkWidget *window, *box, *grid, *spinbutton1, *spinbutton2;
GtkWidget *entry_label, *entry, *about_button, *button1;
GtkWidget *from_label, *to_label, *button1_lbl, *about_dialog;
GtkWidget *image_label, *sdevice_lbl, *image_combo, *sdev_combo;
GtkWidget *chooser_dialog, *response, *warn_dialog, *reversed_nums;
GtkFileFilter *filter_pdf;

int main (int argc, char *argv[])
{
    gtk_init(&argc, &argv);

    window       = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), PROGRAM_TITLE);
    gtk_container_set_border_width(GTK_CONTAINER(window), 6);
    gtk_window_set_default_size(GTK_WINDOW(window), 200, 20);
    gtk_window_set_default_icon_from_file(PROGRAM_ICON, NULL);

    box          = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), box);

    grid         = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 7);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_container_set_border_width(GTK_CONTAINER(grid), 2);

    entry_label  = gtk_label_new(RESOLUTION_LBL);
    gtk_grid_attach(GTK_GRID(grid), entry_label, POSITION_LEFT,1,1,1);

    entry        = gtk_entry_new();
    gtk_entry_set_width_chars(GTK_ENTRY(entry), 1);
    gtk_entry_set_text(GTK_ENTRY(entry), "100");
    gtk_entry_set_max_length(GTK_ENTRY(entry), 4);
    gtk_grid_attach(GTK_GRID(grid), entry, POSITION_LEFT,2,1,1);

    about_button = gtk_button_new_with_label(ABOUT_LBL);
    g_signal_connect(G_OBJECT(about_button), "clicked", G_CALLBACK(on_about_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), about_button, POSITION_RIGHT,2,1,1);

    from_label   = gtk_label_new(FROM_LBL);
    gtk_grid_attach(GTK_GRID(grid), from_label, POSITION_LEFT,4,1,1);

    spinbutton1  = gtk_spin_button_new_with_range(1, 9999, 1);
    gtk_grid_attach(GTK_GRID(grid), spinbutton1, POSITION_LEFT,5,1,1);

    to_label     = gtk_label_new(TO_LBL);
    gtk_grid_attach(GTK_GRID(grid), to_label, POSITION_RIGHT,4,1,1);

    spinbutton2  = gtk_spin_button_new_with_range(1, 9999, 1);
    gtk_grid_attach(GTK_GRID(grid), spinbutton2, POSITION_RIGHT,5,1,1);

    image_label  = gtk_label_new(IMG_LBL);
    gtk_grid_attach(GTK_GRID(grid), image_label, POSITION_LEFT,6,1,1);

    image_combo  = gtk_combo_box_text_new();
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(image_combo), PNG, PNG);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(image_combo), JPG, JPG);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(image_combo), BMP, BMP);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(image_combo), TIFF, TIFF);
    gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 0);
    g_signal_connect(G_OBJECT(image_combo), "changed", G_CALLBACK(on_image_combo), NULL);
    gtk_grid_attach(GTK_GRID(grid), image_combo, POSITION_LEFT,7,1,1);

    sdevice_lbl  = gtk_label_new(SDEVICE_LBL);
    gtk_grid_attach(GTK_GRID(grid), sdevice_lbl, POSITION_RIGHT,6,1,1);

    sdev_combo   = gtk_combo_box_text_new();
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), PNG16M, PNG16M);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), PNGALPHA, PNGALPHA);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), PNGGRAY, PNGGRAY);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), JPEG, JPEG);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), JPEGCMYK, JPEGCMYK);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), JPEGGRAY, JPEGGRAY);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), BMP16M, BMP16M);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), BMPGRAY, BMPGRAY);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), TIFF24NC, TIFF24NC);
    gtk_combo_box_text_append (GTK_COMBO_BOX_TEXT(sdev_combo), TIFFGRAY, TIFFGRAY);
    gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 0);
    g_signal_connect(G_OBJECT(sdev_combo), "changed", G_CALLBACK(on_sdevice_combo), NULL);
    gtk_grid_attach(GTK_GRID(grid), sdev_combo, POSITION_RIGHT,7,1,1);

    /* g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(on_select), (gpointer) 1); */

    button1_lbl  = gtk_label_new(SELECT_PDF_LBL);
    gtk_grid_attach(GTK_GRID(grid), button1_lbl, POSITION_LEFT,8,2,1);

    button1      = gtk_button_new_with_label(BUTTONE_LBL);
    g_signal_connect(G_OBJECT(button1), "clicked", G_CALLBACK(on_button1_clicked), NULL);
    gtk_grid_attach(GTK_GRID(grid), button1, POSITION_LEFT,9,2,1);

    /* button1 = gtk_button_new_from_icon_name(GTK_STOCK_INDEX, GTK_ICON_SIZE_BUTTON); */

    gtk_container_add(GTK_CONTAINER(box), grid);
    gtk_box_pack_start(GTK_BOX(box), button1, TRUE, TRUE, 0);

    g_signal_connect(G_OBJECT(window), "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}


/* About dialog */
void on_about_clicked(void)
{
    about_dialog = gtk_about_dialog_new();
    gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG(about_dialog),ABOUT_PROG_NAME);
    gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(about_dialog),ABOUT_COMMENTS);
    gtk_about_dialog_set_website(GTK_ABOUT_DIALOG(about_dialog),ABOUT_WEBSITE);
    gtk_about_dialog_set_website_label(GTK_ABOUT_DIALOG(about_dialog),ABOUT_WEBSITE_LABEL);
    gtk_about_dialog_set_license_type(GTK_ABOUT_DIALOG(about_dialog),GTK_LICENSE_GPL_3_0);
    gtk_dialog_run(GTK_DIALOG(about_dialog));
    gtk_widget_destroy(about_dialog);

}


/* sdevice combobox changed */
void on_sdevice_combo(void)
{
    char *active = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(sdev_combo));

    if ((0 == strcmp(active,PNG16M)) || (0 == strcmp(active,PNGALPHA)) || (0 == strcmp(active,PNGGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 0);

    if ((0 == strcmp(active,JPEG)) || (0 == strcmp(active,JPEGCMYK)) || (0 == strcmp(active,JPEGGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 1);

    if ((0 == strcmp(active,BMP16M)) || (0 == strcmp(active,BMPGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 2);

    if ((0 == strcmp(active,TIFF24NC)) || (0 == strcmp(active,TIFFGRAY)))
        gtk_combo_box_set_active(GTK_COMBO_BOX(image_combo), 3);
}


/* image format combobox changed */
void on_image_combo(void)
{
    char *active = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(image_combo));

    if (0 == strcmp(active,PNG))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 0);

    if (0 == strcmp(active,JPG))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 3);

    if (0 == strcmp(active,BMP))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 6);

    if (0 == strcmp(active,TIFF))
        gtk_combo_box_set_active(GTK_COMBO_BOX(sdev_combo), 8);
}


/* File chooser dialog */
void on_button1_clicked(void)
{

    int spin1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
    int spin2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));

    if (spin1 > spin2)
    {
        char warn_str[70];
        sprintf(warn_str, "From page %d To %d = OK\nFrom page %d To %d = Not working", spin2, spin1, spin1, spin2);

        reversed_nums = gtk_message_dialog_new(GTK_WINDOW(window),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,REVERSED);
        gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(reversed_nums), warn_str);
        gtk_dialog_run(GTK_DIALOG(reversed_nums));
        gtk_widget_destroy(reversed_nums);
    }
    else
    {
        char *filename;
        chooser_dialog = gtk_file_chooser_dialog_new(SELECT_PDF_LBL,NULL,GTK_FILE_CHOOSER_ACTION_OPEN,CANCEL_BTN,GTK_RESPONSE_CANCEL,CONVERT_BTN,GTK_RESPONSE_ACCEPT,NULL);
        
        filter_pdf = gtk_file_filter_new();
        gtk_file_filter_set_name(GTK_FILE_FILTER(filter_pdf),PDF_FILTER);
        gtk_file_filter_add_pattern(GTK_FILE_FILTER(filter_pdf),PDF_PATTERN);
        gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(chooser_dialog),GTK_FILE_FILTER(filter_pdf));

        if(gtk_dialog_run(GTK_DIALOG(chooser_dialog)) == GTK_RESPONSE_ACCEPT)
        {
            filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(chooser_dialog));
            pdf_to_img(filename);
        }
        gtk_widget_destroy(chooser_dialog);
    }
}


/* 
   In gtk2 the yellow warning icon is
   displayd but not in gtk3, weird.
*/
void RaiseWarning(void)
{
    warn_dialog = gtk_message_dialog_new(GTK_WINDOW(window),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,WARNING);
    gtk_message_dialog_format_secondary_text(GTK_MESSAGE_DIALOG(warn_dialog),RESOLUTION_WARN);
    gtk_dialog_run(GTK_DIALOG(warn_dialog));
    gtk_widget_destroy(warn_dialog);
}


/* 
   Remove the '.pdf' extension, 'gs' the formal parameter
   'filename' and rename the converted images to match the 
   'from' and 'to' page range.
*/
void pdf_to_img(char *filename)
{
    char pdfname[400], params[600], ren1[400], ren2[400];
    int spin1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton1));
    int spin2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton2));
    char *im_combo = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(image_combo));

    int small_range = (spin2 - spin1) + 2;
    int big_range = spin1;
    int x;

    strncpy(pdfname, filename, strlen(filename)-4);
    pdfname[strlen(filename)-4] = '\0';

    sprintf(params, "gs -dBATCH -dNOPAUSE -dFirstPage=%d -dLastPage=%d -sOutputFile=\"%s\"_page_%%01d.%s -sDEVICE=%s -r%s \"%s\"",
        spin1, spin2, pdfname, im_combo,
        gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(sdev_combo)),
        gtk_entry_get_text(GTK_ENTRY(entry)), filename);
    system(params);

    for (x = 1; x < small_range; x++, big_range++)
    {
        sprintf(ren1, "%s_page_%d.%s", pdfname, x, im_combo);
        sprintf(ren2, "%s_page_%d.%s", pdfname, big_range, im_combo);

        rename(ren1, ren2);
    }
}