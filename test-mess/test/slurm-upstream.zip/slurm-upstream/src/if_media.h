/* interface speed detection errors */
#define ERR_IFACE_NO_SPEED -1
#define ERR_IFACE_DOWN -2

int get_if_speed(char *);
