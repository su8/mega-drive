#!/bin/sh
#
#  ============================
#
#   DEPRECATED, use `bootstrap'
#
#  ============================
#
# If the build files are obsolete run:
# sh autogen.sh --prefix=/usr
set -e

test -n "$srcdir" || srcdir=`dirname "$0"`
test -n "$srcdir" || srcdir=.

olddir=`pwd`
cd "$srcdir"

# This will run autoconf, automake, etc. for us
autoreconf --force --install

cd "$olddir"

if test -z "$NOCONFIGURE"; then

"$srcdir"/configure "$@"
fi

# to remove the auto configured files type: 
# rm -rf Makefile config.log config.status aclocal.m4 pdf2img.desktop Makefile.in configure autom4te.cache .deps src/Makefile src/Makefile.in src/pdf2img src/pdf2img-main.o src/pdf2img-my_functions.o src/.deps missing install-sh depcomp compile po/POTFILES po/stamp-it po/Makefile po/en_GB.gmo po/Makefile.in