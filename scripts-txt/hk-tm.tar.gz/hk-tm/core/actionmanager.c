#define _BSD_SOURCE
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>

#include "actionmanager.h"
#include "module.h"
#include "config.h"

static void *run(void *data);

static int actionc = 0;
static action_t *actionlist = NULL;
static pthread_t t;
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static int qstatus[2];

void am_parseactions(json_object *config)
{
   int i, j;
   json_object *actions, *subactions, *a;
   char *type, *v;
   subaction_t *s;

   pthread_mutex_lock(&m);

   for(i = 0; i < actionc; i++) {
      for(j = 0; j < actionlist[i].subactionc; j++) if(actionlist[i].subactionlist[j].param) free(actionlist[i].subactionlist[j].param);
      if(actionlist[i].subactionlist) free(actionlist[i].subactionlist);
   }
   if(actionlist) free(actionlist);

   actions = json_object_object_get(config, "actions");
   actionc = json_object_array_length(actions);
   actionlist = malloc(actionc * sizeof(action_t));

   for(i = 0; i < actionc; i++) {
      subactions = json_object_object_get(json_object_array_get_idx(actions, i), "subactions");
      actionlist[i].subactionc = json_object_array_length(subactions);
      actionlist[i].subactionlist = malloc(actionlist[i].subactionc * sizeof(subaction_t));
      actionlist[i].sched = 0;
      actionlist[i].queue = QUEUE_FAST;

      for(j = 0; j < actionlist[i].subactionc; j++) {
         a = json_object_array_get_idx(subactions, j);

         s = &actionlist[i].subactionlist[j];
         s->type = SUBACTION_NONE;

         if(get_string(a, "action", &type)) continue;
         if(!strcmp(type, "uninstall")) {
            s->param = NULL;
            s->type = SUBACTION_UNINSTALL;
            actionlist[i].queue = QUEUE_SLOW;
         } else if(!strcmp(type, "execute")) {
            if(!(s->param = malloc(sizeof(subaction_execute_t)))) continue;
            if(get_string(a, "command", &v)) continue;
            snprintf(((subaction_execute_t *)s->param)->command, sizeof(((subaction_execute_t *)s->param)->command), "%s", v);
            s->type = SUBACTION_EXECUTE;
            actionlist[i].queue = QUEUE_SLOW;
         } else if(!strcmp(type, "log")) {
            if(!(s->param = malloc(sizeof(subaction_log_t)))) continue;
            if(get_string(a, "text", &v)) continue;
            snprintf(((subaction_log_t *)s->param)->text, sizeof(((subaction_log_t *)s->param)->text), "%s", v);
            s->type = SUBACTION_LOG;
         } else if(!strcmp(type, "synchronize")) {
            if(!(s->param = malloc(sizeof(subaction_synchronize_t)))) continue;
            if(get_string(a, "host", &v)) continue;
            snprintf(((subaction_synchronize_t *)s->param)->host, sizeof(((subaction_synchronize_t *)s->param)->host), "%s", v);
            if(get_int(a, "bandwidth", &((subaction_synchronize_t *)s->param)->bandwidth)) continue;
            if(get_int(a, "mindelay", &((subaction_synchronize_t *)s->param)->mindelay)) continue;
            if(get_int(a, "maxdelay", &((subaction_synchronize_t *)s->param)->maxdelay)) continue;
            if(get_boolean(a, "stop", &((subaction_synchronize_t *)s->param)->stop)) continue;
            s->type = SUBACTION_SYNCHRONIZE;
            actionlist[i].queue = QUEUE_SLOW;
         } else if(!strcmp(type, "destroy")) {
            if(!(s->param = malloc(sizeof(subaction_destroy_t)))) continue;
            if(get_boolean(a, "permanent", &((subaction_destroy_t *)s->param)->permanent)) continue;
            s->type = SUBACTION_DESTROY;
         } else if(!strcmp(type, "event")) {
            if(!(s->param = malloc(sizeof(subaction_event_t)))) continue;
            if(get_int(a, "event", &((subaction_event_t *)s->param)->event)) continue;
            if(get_string(a, "status", &v)) continue;
            ((subaction_event_t *)s->param)->status = (strcmp(v, "enable") ? 0 : 1);
            s->type = SUBACTION_EVENT;
         } else if(!strcmp(type, "module")) {
            if(!(s->param = malloc(sizeof(subaction_module_t)))) continue;
            if(get_string(a, "module", &v)) continue;
            if(!strcmp(v, "device")) ((subaction_module_t *)s->param)->module = MODULE_DEVICE_INDEX;
            else if(!strcmp(v, "screenshot")) ((subaction_module_t *)s->param)->module = MODULE_SCREENSHOT_INDEX;
            else if(!strcmp(v, "application")) ((subaction_module_t *)s->param)->module = MODULE_APPLICATION_INDEX;
            else if(!strcmp(v, "position")) ((subaction_module_t *)s->param)->module = MODULE_POSITION_INDEX;
            else continue;
            if(get_string(a, "status", &v)) continue;
            ((subaction_module_t *)s->param)->status = (strcmp(v, "start") ? 0 : 1);
            s->type = SUBACTION_MODULE;
         }
      }
   }

   pthread_mutex_unlock(&m);

   return;
}

void am_flushactions(void)
{
   int i, j;

   pthread_mutex_lock(&m);

   for(i = 0; i < actionc; i++) {
      for(j = 0; j < actionlist[i].subactionc; j++) if(actionlist[i].subactionlist[j].param) free(actionlist[i].subactionlist[j].param);
      if(actionlist[i].subactionlist) free(actionlist[i].subactionlist);
   }
   if(actionlist) free(actionlist);

   actionlist = NULL;
   actionc = 0;

   pthread_mutex_unlock(&m);

   return;
}

void createactions(void)
{
   qstatus[QUEUE_SLOW] = STATUS_STARTED;
   qstatus[QUEUE_FAST] = STATUS_STARTED;

   pthread_create(&t, NULL, run, (void *)QUEUE_SLOW);
   pthread_create(&t, NULL, run, (void *)QUEUE_FAST);

   return;
}

void am_queueaction(int actionnum)
{
   if(actionnum < actionc) actionlist[actionnum].sched = 1;

   return;
}

void am_startqueue(int q)
{
   qstatus[q] = STATUS_STARTING;

   while(qstatus[q] != STATUS_STARTED) sleep(1);

   return;
}

void am_stopqueue(int q)
{
   qstatus[q] = STATUS_STOPPING;

   while(qstatus[q] != STATUS_STOPPED) sleep(1);

   return;
}

static void *run(void *data)
{
   int i, j, queue = (int)data, ret;
   subaction_t *s;

   while(1) {
      for(i = 0; i < actionc; i++) {
         if(qstatus[queue] == STATUS_STOPPING) {
            qstatus[queue] = STATUS_STOPPED;
            while(qstatus[queue] != STATUS_STARTING) sleep(1);
            qstatus[queue] = STATUS_STARTED;
            break;
         }
         if((actionlist[i].queue != queue) || (!actionlist[i].sched)) continue;
         for(j = 0; j < actionlist[i].subactionc; j++) {
            if(qstatus[queue] == STATUS_STOPPING) {
               qstatus[queue] = STATUS_STOPPED;
               while(qstatus[queue] != STATUS_STARTING) sleep(1);
               break;
            }

            s = &actionlist[i].subactionlist[j];

            switch(s->type) {
               case SUBACTION_UNINSTALL:
                  am_uninstall();
                  break;
               case SUBACTION_EXECUTE:
                  am_execute((subaction_execute_t *)s->param);
                  break;
               case SUBACTION_LOG:
                  am_log((subaction_log_t *)s->param);
                  break;
               case SUBACTION_SYNCHRONIZE:
                  ret = am_synchronize((subaction_synchronize_t *)s->param);
                  if(ret == 3) qstatus[queue] = STATUS_STARTING;
                  else if(ret == -2) exit(0); // TODO UNINSTALL
                  break;
               case SUBACTION_DESTROY:
                  am_destroy((subaction_destroy_t *)s->param);
                  break;
               case SUBACTION_EVENT:
                  am_event((subaction_event_t *)s->param);
                  break;
               case SUBACTION_MODULE:
                  am_module((subaction_module_t *)s->param);
                  break;
               default:
                  break;
            }
         }
         if(qstatus[queue] == STATUS_STARTING) {
            qstatus[queue] = STATUS_STARTED;
            break;
         }

         actionlist[i].sched = 0;
      }

      sleep(1);
   }

   return NULL;
}
