#define _XOPEN_SOURCE
#include <string.h>
#include <stdio.h>
#include <openssl/bio.h>

#include "module.h"
#include "evidencemanager.h"

struct additional {
   unsigned int version;
   unsigned int type;
   unsigned int structnum;
} __attribute__((packed));

struct position {
   unsigned char bssid[6];
   unsigned char pad[2];
   unsigned int essidlen;
   char essid[32];
   int rssi;
} __attribute__((packed));

void *module_position_start(void *args)
{
   BIO *bio_additional = NULL, *bio_data = NULL;
   int additionallen, datalen;
   char *additionalptr, *dataptr;
   FILE *fp = NULL;
   struct additional a;
   struct position p;
   char buf[128];

   printf("Running module POSITION\n");

   if(modulelist[MODULE_POSITION_INDEX].status == MODULE_STARTING) modulelist[MODULE_POSITION_INDEX].status = MODULE_STARTED;

   do {
      if((fp = popen("nm-tool|sed -nr '/ *(.*): *Infra, ((..:){5}(..)).*, Strength ([0-9]+).*/s//\\2 \\5 \\1/p'", "r")) == NULL) break;
      bio_additional = BIO_new(BIO_s_mem());
      bio_data = BIO_new(BIO_s_mem());

      a.version = 2010082401;
      a.type = 0x03;
      a.structnum = 0;

      while(fgets(buf, sizeof(buf), fp)) {
         sscanf(buf, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx %d %30s", &p.bssid[0], &p.bssid[1], &p.bssid[2], &p.bssid[3], &p.bssid[4], &p.bssid[5], &p.rssi, p.essid);
         p.rssi = (60 * p.rssi / 100) - 95;
         p.essidlen = strlen(p.essid);
         a.structnum++;

         BIO_write(bio_data, &p, sizeof(p));
      }

      if(!a.structnum) break;

      BIO_write(bio_additional, &a, sizeof(a));

      BIO_flush(bio_additional);
      BIO_flush(bio_data);

      additionallen = BIO_get_mem_data(bio_additional, &additionalptr);
      datalen = BIO_get_mem_data(bio_data, &dataptr);

      evidence_write(EVIDENCE_TYPE_POSITION, additionalptr, additionallen, dataptr, datalen);
   } while(0);

   if(bio_additional) BIO_free(bio_additional);
   if(bio_data) BIO_free(bio_data);
   if(fp) pclose(fp);

   modulelist[MODULE_POSITION_INDEX].status = MODULE_STOPPED;

   return NULL;
}

