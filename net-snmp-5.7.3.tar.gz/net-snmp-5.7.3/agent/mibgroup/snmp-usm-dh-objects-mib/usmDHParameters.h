#ifndef USMDHPARAMETERS_H
#define USMDHPARAMETERS_H

config_require(snmp-usm-dh-objects-mib/usmDHParameters/usmDHParameters)

#endif /* USMDHPARAMETERS_H */
