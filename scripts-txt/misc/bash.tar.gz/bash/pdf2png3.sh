#!/bin/bash
pdf=/home/frost/Desktop/e
n=$RANDOM
for file in $pdf; do
    gs -dBATCH -dNOPAUSE -sDEVICE=jpeg -sOutputFile=$n.jpeg -dFirstPage=1 -dLastPage=1 *.pdf
done
