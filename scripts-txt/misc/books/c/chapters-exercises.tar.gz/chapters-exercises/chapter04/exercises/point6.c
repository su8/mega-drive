/* write a program that requests the user's first name and then
the user's last name. Have it print the entered names on one line
and the number of letters in each name on the following line.
Align each letter count with the end of corresponding name,
as in the following:
Melissa Honeybee
      7        8

Next, have it print the same information, but with counts
aligned with the beginning of each name
Melissa Honeybee
7       8
*/
#include <stdio.h>
#include <string.h>
int main(void)
{
    char first[20], last[20];
    int len_f, len_l;

    printf("Enter your first name and then your last name:\n");
    scanf("%s %s", first, last);

    len_f = strlen(first);
    len_l = strlen(last);

    printf("%s %s\n", first, last);
    printf("%*d %*d\n", len_f, len_f, len_l, len_l);

    printf("%s %s\n", first, last);
    printf("%0d %*d\n", len_f, len_f - 1, len_l);

    return 0;
}
