When experimenting locally:

```bash
sudo make rmconfig fetch extract reinstall
```
