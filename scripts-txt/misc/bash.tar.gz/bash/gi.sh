#!/bin/bash
xfce4-terminal -H -x /home/frost/blog/update-upload-scripts/gi2.sh
exit

