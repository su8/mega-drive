# This program is not ready to be executed
import os
import py_compile
from sys import argv
from zipfile import ZipFile
from shutil import copy, move, rmtree

class SpeedyGreedy(object):
    def __init__(self):
        ms  = 'modules.zip'
        mso = 'modules-orig.zip'
        cwd = os.getcwd()

        if int(argv[1]) != 1:
            copy(mso, ms)
        else:
            with ZipFile(mso, 'r') as ziP:
                ziP.extractall()

            [py_compile.compile(x, x+'c', None, 3) for x in os.listdir(cwd) if not x == mso]

            with ZipFile(ms, 'a') as z:
                [z.write(x) for x in os.listdir(cwd) if x.endswith('c')]

            rmtree(cwd)

        move(ms, os.path.join(os.path.split(cwd)[0], ms))

if __name__ == '__main__':
    SpeedyGreedy()

# extra optimizations (12, 373KB)
# python3 -c'import os;from distutils.util import byte_compile;os.chdir(os.path.join("static", "modules"));byte_compile(os.listdir(os.getcwd()), 2, True)'

# normal optimaztions (12, 388KB)
#python3 -c'import os,py_compile;os.chdir(os.path.join("static", "modules"));[py_compile.compile(x, None, None, 3) for x in os.listdir(os.getcwd())]'