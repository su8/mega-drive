#!/usr/bin/python2
import subprocess
import getpass
import os

userz = getpass.getuser()
os.chdir("/home/" + userz + "/Desktop/")
params = ['xfce4-terminal', '-H', '-x', 'telnet', '192.168.10.254']
subprocess.check_call(params)
