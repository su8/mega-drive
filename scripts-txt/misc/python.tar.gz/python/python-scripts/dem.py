#import os
#import sys


class pydemo:
    def __init__(self):
        self.msg = 'Hello GitHub~~'  # runs that first

    def start(self):    # runs that third
        self.printMsg()
        print("that1")

    def printMsg(self):    # runs that second
        print(self.msg)
        print("that2")

if __name__ == '__main__':
    op = pydemo()
    op.start()
