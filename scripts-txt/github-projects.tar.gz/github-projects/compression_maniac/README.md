Why do you have to rely on a slow GUI frontend program to compress and extract your archives ?

The **compress_extract.zsh** file contains the following functions that do:

* tar compression
* xz compression
* gzip compression
* bzip compression
* lzma compression
* lz4 compression
* lzo compression
* 7zip compression
* zip compression

There is **extract** function inside the file that will decompress all of your archives compressed with the above compression programs. The functions inside the file can handle multiple files and folders flawlessly.

I rely mainly on these functions in Thunar and/or the terminal emulator to extract and compress everything. Having that said, the functions integration into your file manager will be seamless.

## Requirements

    zlib
    python2 or python3
    tar
    bzip2
    gzip
    lzo
    lzop
    p7zip
    lz4
    xz
    shell (bash, zsh, etc.)