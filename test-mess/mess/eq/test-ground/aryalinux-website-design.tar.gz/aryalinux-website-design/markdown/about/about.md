
---

AryaLinux is a source-based Linux distribution inspired by LFS/BLFS. We use bash scripts for building the entire distribution ground up. As of now, AryaLinux has Mate and XFCE spins as the supported desktop environments but suport for other desktops is in progress.

One might wonder what might be the need to compile an Operating system from scratch and not use an existing one, especially since there are hundereds of thousands of Linuxes and their variants out there and there are doing a great job. Well other than learning how a Linux system works internally(which BTW is the reason why most of us try LFS), one reason why AryaLinux exists in because when you build your own GNU/Linux system, you can control everything that goes into your system ranging from the packages to their versions to services and a whole lot of other things as well. Most Linuxes out there are generic in nature, meaning they are built to run on most systems possible. This makes them accomodate a lot of things, actually a lot more than that might be actually needed by you or your computer like kernel modules and services like samba etc. This is one issue that source based distros address.

Secondly when you build the system from scratch on a particular computer, the compiler optimizes the object code for that hardware, thus the System you end up building is the best possible system that you can get because its built in your system, by your system. This gives a little bit of performance boost as well.

Our objective is to foray into other hardware as well like smart phones, Raspberry PI etc in near future and provide a stable system that would free one from the cycles of updates, upgrades and bloat. 
