# MediaCrush-cli

Uploads files to MediaCrush from your favorite shell.

## Installation

    $ make
    $ sudo make install
