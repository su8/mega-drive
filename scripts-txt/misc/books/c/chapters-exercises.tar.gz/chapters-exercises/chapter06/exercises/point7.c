/* 7. Write a program that reads a single word into a character array and then prints the word
backward. Hint: Use strlen() ( Chapter 4 ) to compute the index of the last character in
the array. */
#include <stdio.h>
#include <string.h>
int main(void)
{
    int num;
    char name[20];
    
    printf("Enter some word/name: ");
    scanf("%s", name);
    
    printf("Printing %s backwards: ", name);
    for (num = strlen(name); num >= 0; num--)
    {
        printf("%c", name[num]);
    }
    
    return 0;
}
