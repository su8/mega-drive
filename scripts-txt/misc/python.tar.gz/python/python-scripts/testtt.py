import argparse
parser = argparse.ArgumentParser(description='A foo that bars')
args = parser.print_help()